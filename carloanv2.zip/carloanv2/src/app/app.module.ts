import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { WatermarkComponent } from './COMPONENTS/watermark/watermark.component';
import { SpinnerComponent } from './COMPONENTS/spinner/spinner.component';
import { PagenotfoundComponent } from './COMPONENTS/pagenotfound/pagenotfound.component';
import { SidenavListComponent } from './COMPONENTS/sidenav-list/sidenav-list.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MaterialModule } from './AngularMaterial/material.module';
import { ToastrModule } from 'ngx-toastr';
import { LoginComponent } from './AUTH/login/login.component';
import { CrifListComponent } from './COMPONENTS/crif-list/crif-list.component';
import { LoanRefTitleComponent } from './COMPONENTS/loan-ref-title/loan-ref-title.component';
import { CrifDetailsStepperComponent } from './COMPONENTS/crif-details-stepper/crif-details-stepper.component';
import { CrifFirmFetchPageComponent } from './COMPONENTS/crif-firm-fetch-page/crif-firm-fetch-page.component';
import { CrifFirmDisplayStepperComponent } from './COMPONENTS/crif-firm-display-stepper/crif-firm-display-stepper.component';
import { CrifCommGuarantorStepperComponent } from './COMPONENTS/crif-comm-guarantor-stepper/crif-comm-guarantor-stepper.component';
import { CrifCommGuarantorListComponent } from './COMPONENTS/crif-comm-guarantor-list/crif-comm-guarantor-list.component';
import { DashboardComponent } from './COMPONENTS/dashboard/dashboard.component';
import { AuthGuard } from './AUTH/auth.guard';
import { IncomeBusinessComponent } from './COMPONENTS/income-business/income-business.component';
import { IncomePensionComponent } from './COMPONENTS/income-pension/income-pension.component';
import { IncomeSalaryComponent } from './COMPONENTS/income-salary/income-salary.component';
import { QuotationDetailsComponent } from './COMPONENTS/quotation-details/quotation-details.component';
import { ReferenceIdGenerationComponent } from './COMPONENTS/reference-id-generation/reference-id-generation.component';
import { DoclistComponent } from './COMPONENTS/doclist/doclist.component';
import { ApplicationSearchComponent } from './COMPONENTS/application-search/application-search.component';
import { AppraisalNoteComponent } from './COMPONENTS/appraisal-note/appraisal-note.component';
import { BorrowerIndividualComponent } from './COMPONENTS/borrower-individual/borrower-individual.component';
import { BorrowerFirmComponent } from './COMPONENTS/borrower-firm/borrower-firm.component';
import { GuarantorIndividualComponent } from './COMPONENTS/guarantor-individual/guarantor-individual.component';
import { GuarantorCorporateComponent } from './COMPONENTS/guarantor-corporate/guarantor-corporate.component';
import { ItrDetailsListComponent } from './COMPONENTS/itr-details-list/itr-details-list.component';
import { LonRefTitleComponent } from './COMPONENTS/lon-ref-title/lon-ref-title.component';
import { CibilIndividualAllComponent } from './COMPONENTS/cibil-individual-all/cibil-individual-all.component';
import { CibilCommercialAllComponent } from './COMPONENTS/cibil-commercial-all/cibil-commercial-all.component';
import { CoappIndividualComponent } from './COMPONENTS/coapp-individual/coapp-individual.component';
import { KycPanAadharVerifyComponent } from './COMPONENTS/kyc-pan-aadhar-verify/kyc-pan-aadhar-verify.component';
import { KycPanGstCommercialComponent } from './COMPONENTS/kyc-pan-gst-commercial/kyc-pan-gst-commercial.component';
import { CommonModule } from '@angular/common';
import { IncomeMainListComponent } from './COMPONENTS/income-main-list/income-main-list.component';
import { QuantumOfFinanceComponent } from './COMPONENTS/quantum-of-finance/quantum-of-finance.component';
import { DeviationDisplayComponent } from './COMPONENTS/deviation-display/deviation-display.component';
import { DeviationApprovalComponent } from './COMPONENTS/deviation-approval/deviation-approval.component';
import { ItrVerifyCoapp1Component } from './COMPONENTS/itr-verify-coapp1/itr-verify-coapp1.component';
import { ItrVerifyCoapp2Component } from './COMPONENTS/itr-verify-coapp2/itr-verify-coapp2.component';
import { ItrDisplayCoapp2Component } from './COMPONENTS/itr-display-coapp2/itr-display-coapp2.component';
import { ItrDisplayCoapp1Component } from './COMPONENTS/itr-display-coapp1/itr-display-coapp1.component';
import { ItrVerificationApplicantComponent } from './COMPONENTS/itr-verification-applicant/itr-verification-applicant.component';
import { ItrDisplayApplicantComponent } from './COMPONENTS/itr-display-applicant/itr-display-applicant.component';
import { DocumentsAndRemarksComponent } from './COMPONENTS/documents-and-remarks/documents-and-remarks.component';

@NgModule({
  declarations: [
    AppComponent,
    SidenavListComponent,
    PagenotfoundComponent,
    WatermarkComponent,
    SpinnerComponent,
    LoginComponent,
    CrifListComponent,
    LoanRefTitleComponent,
    CrifDetailsStepperComponent,
    CrifFirmFetchPageComponent,
    CrifFirmDisplayStepperComponent,
    CrifCommGuarantorStepperComponent,
    CrifCommGuarantorListComponent,
    DashboardComponent,
    IncomeBusinessComponent,
    IncomePensionComponent,
    IncomeSalaryComponent,
    ReferenceIdGenerationComponent,
    QuotationDetailsComponent,
    DoclistComponent,
    ApplicationSearchComponent,
    AppraisalNoteComponent,
    BorrowerIndividualComponent,
    BorrowerFirmComponent,
    CoappIndividualComponent,
    GuarantorIndividualComponent,
    GuarantorCorporateComponent,
    ItrDetailsListComponent,
    LonRefTitleComponent,
    CibilIndividualAllComponent,
    CibilCommercialAllComponent,
    KycPanAadharVerifyComponent,
    KycPanGstCommercialComponent,
    IncomeMainListComponent,
    QuantumOfFinanceComponent,
    DeviationDisplayComponent,
    DeviationApprovalComponent,
    ItrVerifyCoapp1Component,
    ItrVerifyCoapp2Component,
    ItrDisplayCoapp2Component,
    ItrDisplayCoapp1Component,
    ItrVerificationApplicantComponent,
    ItrDisplayApplicantComponent,
    DocumentsAndRemarksComponent
    
  ],
  imports: [
    AppRoutingModule,
    NgbModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MaterialModule,
    CommonModule,
    ToastrModule.forRoot({
      positionClass: 'toast-center-center',
      timeOut: 3000, // Set the timeout duration
      progressBar: true, // Show a progress bar
      closeButton: true, // Show a close button
      preventDuplicates: true,
    }),
  ],
  providers:[AuthGuard,
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
