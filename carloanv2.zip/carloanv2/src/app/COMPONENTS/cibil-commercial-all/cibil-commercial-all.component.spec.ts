import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CibilCommercialAllComponent } from './cibil-commercial-all.component';

describe('CibilCommercialAllComponent', () => {
  let component: CibilCommercialAllComponent;
  let fixture: ComponentFixture<CibilCommercialAllComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CibilCommercialAllComponent]
    });
    fixture = TestBed.createComponent(CibilCommercialAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
