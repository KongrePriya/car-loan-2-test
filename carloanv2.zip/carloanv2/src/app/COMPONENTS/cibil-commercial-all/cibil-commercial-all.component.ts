import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatStepper } from '@angular/material/stepper';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { UserModelDataForApplicationList } from 'src/app/MODELS/application-list/application-list-data-get.model';
import { CibilCommercialBasicDetailsModel, CibilCommercialNewHistoryDetailsModel, CibilCommercialSummaryDetailsModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-commercial.model';
import { CibilCrifRemarksFinalModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-final-Remark.model';
import { AppraisalNoteService } from 'src/app/SERVICES/appraisal-note/appraisal-note.service';
import { CommercialCibilService } from 'src/app/SERVICES/CIBIL-commercial-all/commercial-cibil.service';
import { CibilCrifRemarksFinalService } from 'src/app/SERVICES/CIBIL-CRIF-Remarks/cibil-crif-remarks.service';

@Component({
  selector: 'app-cibil-commercial-all',
  templateUrl: './cibil-commercial-all.component.html',
  styleUrls: ['./cibil-commercial-all.component.css']
})
export class CibilCommercialAllComponent implements OnInit{

  userModelData = {} as UserModelData;
  localStorageRefrenceId : string ="";
  isSpinnerLoading:boolean = false;
  basicDetailsModel ={} as CibilCommercialBasicDetailsModel;
  basicDetailsModelArray : CibilCommercialBasicDetailsModel[]=[]
  newHistoryDetailsModelArray:CibilCommercialNewHistoryDetailsModel[]=[];
  historyDetailsModel={} as CibilCommercialNewHistoryDetailsModel;

  summaryDetailsModelArray:CibilCommercialSummaryDetailsModel[]=[];
  summaryDetailsModel={} as CibilCommercialSummaryDetailsModel;
  cibilCrifRemarksFinalModel={} as CibilCrifRemarksFinalModel;
  AnyOverduePresentCommercial:boolean=false;
  AnyAccountSettledCommercial:boolean=false;
  AnyAccountWrittenOffCommercial:boolean=false;
  AnyAccountSuitFilledCommercial:boolean=false;
  haveCreditDefault: boolean = false;
  commercialCibilPresent:string='No';

//FOR OVERDUE CLEARANCE CERTIFICATE
  overdueClearedCertificate:string='No';
  documentsDataPresent: string ='No';
  fileTypePdf: boolean | undefined;
  files: any;
  overdueClearanceCertificateName: string='';
  selectedFile!:File|null;


  @ViewChild('stepper', { static: false }) stepper!: MatStepper;
  @ViewChild('cibilform') cibilform!: NgForm;


  constructor(private modalService: NgbModal,
              private router: Router,
              private toastr: ToastrService ,
              private appraisalNoteService : AppraisalNoteService,
              private cibilCrifRemarksFinalService:CibilCrifRemarksFinalService,
              private commercialCibilService : CommercialCibilService) {}

  ngOnInit(): void {
    this.isSpinnerLoading= true;
   
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    console.log("USER DATA MODEL:", this.userModelData);

    this.BasicDetailsCommercialCibilGetAll();
   
  }


  openVerticallyCentered(content: TemplateRef<any>) {
    this.modalService.open(content, {
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'md',
      centered: true,
    });
  }
  toggleCollapse(guarantor: any) {
    guarantor.collapsed = !guarantor.collapsed;
  }
  highlightRows(index: number, highlight: boolean): void {
    this.newHistoryDetailsModelArray[index].highlighted = highlight;
    if (highlight===true){
      this.newHistoryDetailsModelArray[index].collapsed = false;
  
    }
  }
  com_cibil_basic_Header = [
    'Sr. No.',
    'Customer Type',
    'Corporate Entity Name',
    'Rank Name',
    'Rank',
    'Ranking Reason',
    'Total Accounts',
    'Regular Accounts',
    'Overdue Accounts',
    'Zero Balance Accounts'
  ];

com_cibil_history_Header = [
    'Sr. No.',
    // 'Corporate Guarantor Name',
    'Facility Type',
    'Ownership',
    'Banker',
    'Sanction Date',
    'Sanction Amount',
    'Amount Outstanding',
    'Overdue Amount',
    'Status',
    'Asset Classification'
  ];

com_cibil_summary_header = [
    'Sr.No',
    'Customer Type',
    'Corporate Entity Name',
    'Rank Above CMR-7',
    'Account Written-Off',
    'Account Settled',
    'Suitfilled Accounts',
    'Account Overdue'
  ];

  submitCibil(stepper?: MatStepper) {
    this.stepper.next();

  }

// ************************************ METHOD TO GET BASIC CIBIL DETAILS OF ALL CORPORATE GUARANTORS ********************* 

BasicDetailsCommercialCibilGetAll() {
  // this.basicDetailsModel.referenceId='MGBGST@202407304bc'; //DUMMY

  this.isSpinnerLoading = true;
  this.commercialCibilService.getAllBasicDetailsList(this.userModelData.referenceId).subscribe(
    (response) => {
      if(response!== null){
        this.basicDetailsModelArray = response;
        console.log("BASIC COMMERCIAL CIBIL DETAILS : ", JSON.stringify(response));
        this.commercialCibilPresent='Yes';
   
      //CALLING THIS SERVICES HERE WHEN Commercial CIBIL DETAILS ARE Present 
      this.HistoryDetailsCommercialCibilGetAll();
      this.SummaryDetailsCommercialCibilGetAll();
      this.RemarksGuarantorsCommercialCibilGet();
      this.isSpinnerLoading = false;
      }
      },
      (error: HttpErrorResponse) => {
        if(error.status===404){
          this.commercialCibilPresent='No';
          console.warn("COMMERCIAL CIBIL DETAILS NOT PRESENT AGAINST THIS REF-ID :"+this.userModelData.referenceId);         
        }else{
        console.error("ERROR WHILE GETTING CIBIL BASIC DETAILS: " + error);
        this.toastr.error("ERROR WHILE GETTING CIBIL BASIC DETAILS: " + error.message);
        }
         this.isSpinnerLoading = false;
      }
   );
  }
// ************************************ METHOD TO GET HISTORY DETAILS OF ALL CORPORATE GUARANTORS ********************* 

HistoryDetailsCommercialCibilGetAll() {
  // this.historyDetailsModel.referenceId='MGBGST@202407304bc'; //DUMMY
  
  this.isSpinnerLoading = true;
  this.commercialCibilService.getAllHistoryDetailsList(this.userModelData.referenceId).subscribe(
    (response) => {
      if(response!== null){
        this.newHistoryDetailsModelArray = response;
        console.log("HISTORY COMMERCIAL CIBIL DETAILS : ", JSON.stringify(response));
      }
      this.isSpinnerLoading = false;
      }
   );
  }
// ************************************ METHOD TO GET SUMMARY DETAILS OF ALL CORPORATE GUARANTORS ********************* 

SummaryDetailsCommercialCibilGetAll() {
  // this.summaryDetailsModel.referenceId='MGBGST@202407304bc'; //DUMMY
  
  this.isSpinnerLoading = true;
  this.commercialCibilService.getAllSummaryDetailsList(this.userModelData.referenceId).subscribe(
    (response) => {
      if(response!== null){
        console.warn("COMBINED CIBIL SUMMARY :"+response);
        
        this.summaryDetailsModelArray = response;
        //setting a combined overdue flag after checking if any one has overdue= YES
        this.AnyOverduePresentCommercial =  response.some(item => item.accountOverdueSummary === 'YES');
        console.log("this.AnyOverduePresentCommercial : ", this.AnyOverduePresentCommercial);

          //for settled accounts
          this.AnyAccountSettledCommercial = response.some(item => item.accountSettledSummary === 'YES');
          console.log("this.AnyAccountSettledIndGuarantors : ", this.AnyAccountSettledCommercial);

          //for written off accounts
          this.AnyAccountWrittenOffCommercial = response.some(item => item.accountWrittenOffSummary === 'YES');
          console.log("this.AnyAccountWrittenOffIndGuarantors : ", this.AnyAccountWrittenOffCommercial);

          //for suit-filled accounts
          this.AnyAccountSuitFilledCommercial = response.some(item => item.accountSettledSummary === 'YES');
          console.log("this.AnyAccountSuitFilledIndGuarantors : ", this.AnyAccountSuitFilledCommercial);

          // Set the haveCreditDefault flag
        this.haveCreditDefault = this.AnyOverduePresentCommercial || this.AnyAccountSettledCommercial || this.AnyAccountWrittenOffCommercial || this.AnyAccountSuitFilledCommercial;
        console.log("Corporate guarantors: this.haveCreditDefault : ", this.haveCreditDefault);

        console.log("SUMMARY COMMERCIAL CIBIL DETAILS : ", JSON.stringify(response));

         //IF ANY OVERDUE PRESENT THEN WANT TO SHOW ONE LOCK TO UPLOAD PROOF
            if(this.AnyOverduePresentCommercial){
              this.overdueClearedCertificate='Yes';
            }
      }
      this.isSpinnerLoading = false;
      }
   );
  }
// ************************************ METHOD TO GET ALL COMMERCIAL CIBIL REMARKS  OF CORPORATE GUARANTORS ********************* 
RemarksGuarantorsCommercialCibilGet() {
  this.cibilCrifRemarksFinalModel.referenceId=this.userModelData.referenceId;
  this.isSpinnerLoading = true;
  this.cibilCrifRemarksFinalService.getAllCibilCrifRemarks(this.userModelData.referenceId).subscribe(
    (response) => {
      if(response!== null){
        this.cibilCrifRemarksFinalModel = response;
        console.log("ALL REMARKS OF CIBIL & CRIF  : ", JSON.stringify(response));
        if(this.cibilCrifRemarksFinalModel.overdueClearanceCertificateName !=null){
          this.overdueClearanceCertificateName=this.cibilCrifRemarksFinalModel.overdueClearanceCertificateName;
          this.documentsDataPresent='Yes';
          console.log("documentsDataPresent : ",this.documentsDataPresent);
          
          }
      }
      this.isSpinnerLoading = false;
      }
   );
  }

// ************************************ METHOD TO SAVE/POST ALL COMMERCIAL CIBIL REMARKS OF CORPORATE GUARANTORS ********************* 
RemarksGuarantorsCommercialCibilSave() {

  if (!this.cibilform.valid) {
    console.log(" cibilform Form is not valid!");
    this.toastr.info("Kindly Enter CIBIL Remark to Proceed Further.");
    this.stepper.selectedIndex = 0; //redirect to stepper step-1
    return; // Exiting method if the form is not valid
  } else{
  this.cibilCrifRemarksFinalModel.referenceId=this.userModelData.referenceId;

  console.warn("this.cibilCrifRemarksModel.referenceId : "+  this.cibilCrifRemarksFinalModel.referenceId);
  

  this.isSpinnerLoading = true;
  this.cibilCrifRemarksFinalService.CibilCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksFinalModel).subscribe(
    (response) => {
      if(response!== null){
        console.log("ALL REMARKS OF CIBIL & CRIF  : ", JSON.stringify(response));
       this.goNext();
      }
      this.isSpinnerLoading = false;
      }
   );
  }
}
// ************************************ METHOD TO SAVE Remark & REJECT (confirmation & navigation)********************* 
  RejectApplicationByCorporateCibil(){
   
    this.isSpinnerLoading = true;
    var confirmed = confirm("Are you sure you want to reject the application?");
     if(confirmed){
      // this.RemarksGuarantorsCommercialCibilSave();
      this.cibilCrifRemarksFinalService.rejectDueToCibilCrif(this.cibilCrifRemarksFinalModel).subscribe(
        (response) => {
          if(response!== null){
            console.log("ALL REMARKS OF CIBIL & CRIF  : ", JSON.stringify(response));
            console.log("APPLICATION REJECTED... REDIRECTING TO HOME PAGE .");
            this.setRejectSubmit();
          }
          this.isSpinnerLoading = false;
          }
       ),(error : HttpErrorResponse) => {
        this.isSpinnerLoading=false;
        console.error("ERROR WHILE APPLICATION REJECTION CIBIL REMARKS DATA: "+error)
        this.toastr.error("ERROR WHILE APPLICATION REJECTION CIBIL REMARKS DATA: " +error.message);
      }
      this.isSpinnerLoading=false;
      this.modalService.dismissAll();
      this.router.navigate(['/gstmsme']);
     }
   
  }
 // ************************************ // ************************************ // ************************************  

 userModelDataForApplicationList = {} as UserModelDataForApplicationList;

//REJECT The Application
setRejectSubmit(){

  this.userModelDataForApplicationList.branchCode=this.userModelData.brcode;
  this.userModelDataForApplicationList.custType=this.userModelData.custType;
  this.userModelDataForApplicationList.referenceId=this.userModelData.referenceId;
  this.userModelDataForApplicationList.regionName=this.userModelData.roname;
  this.userModelDataForApplicationList.userId=this.userModelData.userId;
  this.userModelDataForApplicationList.userLoc=this.userModelData.u_loc;
  this.userModelDataForApplicationList.userScale=this.userModelData.scale;
  this.userModelDataForApplicationList.userType=this.userModelData.u_type;

  this.appraisalNoteService
   .setReject(this.userModelDataForApplicationList)
   .subscribe(
      (response) => {
        this.isSpinnerLoading=false;
        console.log("In Reject On GST PAGE");
        if (response!=null) {
          console.log("Reject Application SuccessFully... ");
        }
        else{
          this.toastr.info("Reject status could not be updated")           
        }     
      },
       (error) => {
        this.isSpinnerLoading=false;
        console.log("ERROR OCCURED In Reject On CIBIL " + JSON.stringify(error));
       }
    );
}


//**************************************** UPLOAD OVERDUE CLEARANCE DOCUMENT ***********************************************//
  // Handle file change event and upload the file immediately
  uploadSelectedFile(event: any) {
   this.selectedFile = event.target.files[0];
      this.documentsDataPresent='No'; //to show upload button
   }
  
  // Upload the selected file immediately
  uploadFile() {
    if (!this.selectedFile) {
      console.warn("NO FILE SELECTED.");
      this.toastr.info("Kindly Select File.");
      return;
    }
     if(this.selectedFile.type != 'application/pdf'){
      this.fileTypePdf=false;
      this.toastr.warning("Only PDF File is allowed.");
      console.warn("Only PDF File is allowed.");
      return;
    }

    this.isSpinnerLoading = true;
    this.fileTypePdf=true;
    const formData = new FormData();
    formData.append("overdueClearanceFile", this.selectedFile);

    this.cibilCrifRemarksFinalService.uploadFile(this.userModelData.referenceId, this.userModelData.userId, formData).subscribe(
      (response: any) => {
        // Update only the specific file that was uploaded
        this.toastr.success("File Uploaded Successfully...!!!");
         this.documentsDataPresent='Yes';
         console.log(" documentsDataPresent :" +this.documentsDataPresent);
         
        console.log('File uploaded successfully Upload response', response);

        // After upload, call getDataWithAccountNo() to update existing files
        this.BasicDetailsCommercialCibilGetAll
        this.isSpinnerLoading = false;
      },
      (error) => {
        this.toastr.error("Error uploading file...!!!");
        this.isSpinnerLoading = false;
        console.error('Error uploading file :', error);
      }
    );
  }

  //***************************************************************************************
  // Method to preview a file
   previewFile() {
    this.cibilCrifRemarksFinalService.previewFile(this.userModelData.referenceId).subscribe(
      (response: Blob) => {
        const fileURL = URL.createObjectURL(response);
        window.open(fileURL, '_blank');  // Open the file in a new tab
      },
      (error) => {
        console.error('Error previewing file', error);
      }
    );
  }
//***************************************************************************************

  downloadFile() {
    this.cibilCrifRemarksFinalService.downloadFile(this.userModelData.referenceId).subscribe(
      (response) => {
      
        const contentDisposition = response.headers.get('Content-Disposition');
        let filename = this.overdueClearanceCertificateName; 
  
        console.log("overdueClearanceCertificateName/filename : "+this.overdueClearanceCertificateName);
        
        // Extract filename from Content-Disposition header
        if (contentDisposition) {
          const matches = /filename="([^"]*)"/.exec(contentDisposition);
          if (matches != null && matches[1]) {
            filename = matches[1];  // Set filename to the one from the response header
          }
        }
        if (response.body) {
          const fileURL = URL.createObjectURL(response.body);
          const a = document.createElement('a');
          a.href = fileURL;
          a.download = filename;
          a.click();
        } else {
          console.error('Failed to download the file. The response body is null.');
        }
      },
      (error) => {
        console.error('Error downloading file', error);
      }
    );
  }
  
  
//************************************** REDIRECT METHODS *************************************************

goNext(){
  this.router.navigate(['/carLoanV2/itr-list'])
}

goBack(){
  this.router.navigate(['/carLoanV2/borrower-firm']); 
}

}
