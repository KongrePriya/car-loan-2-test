import { Component, OnInit } from '@angular/core';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';

@Component({
  selector: 'app-lon-ref-title',
  templateUrl: './lon-ref-title.component.html',
  styleUrls: ['./lon-ref-title.component.css']
})
export class LonRefTitleComponent implements OnInit {
  referenceId!:String;
  userModelData={} as UserModelData;


  ngOnInit(): void {
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  this.referenceId=this.userModelData.referenceId;

  console.log("REFERENCE ID DATA in user data model:"+this.userModelData);
  
  }
}
