import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LonRefTitleComponent } from './lon-ref-title.component';

describe('LonRefTitleComponent', () => {
  let component: LonRefTitleComponent;
  let fixture: ComponentFixture<LonRefTitleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LonRefTitleComponent]
    });
    fixture = TestBed.createComponent(LonRefTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
