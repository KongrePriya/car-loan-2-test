import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrifCommGuarantorListComponent } from './crif-comm-guarantor-list.component';

describe('CrifCommGuarantorListComponent', () => {
  let component: CrifCommGuarantorListComponent;
  let fixture: ComponentFixture<CrifCommGuarantorListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CrifCommGuarantorListComponent]
    });
    fixture = TestBed.createComponent(CrifCommGuarantorListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
