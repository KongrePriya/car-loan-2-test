import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { CibilCrifStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-STATUS.model';
import { CibilCrifStatusService } from 'src/app/SERVICES/CIBIL-CRIF-STATUS/cibil-crif-status.service';
import { CorporateGuarantorService } from 'src/app/SERVICES/corporate-guarantor/corporate-guarantor.service';
import { CommercialCrifService } from 'src/app/SERVICES/CRIF-commercial-all/fetch-commercial-crif.service';

@Component({
  selector: 'app-crif-comm-guarantor-list',
  templateUrl: './crif-comm-guarantor-list.component.html',
  styleUrls: ['./crif-comm-guarantor-list.component.css']
})
export class CrifCommGuarantorListComponent {
  ngOnInit(): void {
    const abc = sessionStorage.getItem("userModelData");
    this.userDataModel = JSON.parse(abc!);
    this.getAllIndGuarantors();
  }


 //to assign fetched data fields also have additional fields
  allCommGuarantorsModel: any[] = [];
  isSpinnerLoading:boolean = false;
  userDataModel = {} as UserModelData;
  disableProceedWithoutFlag?:string;
  disableProceedWithFlag:string='yes';
  isChecked: boolean = false;
  showCheckBox?:string;
  cibilCrifStatusModel=  {} as CibilCrifStatusModel;

 
  countYes:number=0;

  constructor(
    private modalService: NgbModal,
    private corporateGuarantorService: CorporateGuarantorService,
    private fetchCommercialCrifService: CommercialCrifService,
    private router: Router,
    private cibilCrifStatusService:CibilCrifStatusService,
    private toastr :ToastrService,
  ) {}

  //****************************** GET LIST OF EXISTING INDIVIDUAL GUARANTORS ******************************/
 //asdas
  getAllIndGuarantors() {
    this.isSpinnerLoading = true;
    this.corporateGuarantorService.getAllCorpGuarList(this.userDataModel.referenceId).subscribe(
      // this.corporateGuarantorService.getAllCorpGuarList('MGBGST20241203hdfj8').subscribe(
        (response) => {
        if(response!== null){
         
          console.log("I AM IN IF"+JSON.stringify(response));
          this.allCommGuarantorsModel = response;
         this.allCommGuarantorsModel.map(i => {
          console.log("I AM IN MAP");
          if(i.crifCommFetched == 'no'){ 
            this.disableProceedWithoutFlag = 'yes';
          }
          if(i.crifCommFetched == 'yes'){
              this.countYes++;
              console.log("I AM IN COUNT" + this.countYes);
              
            }
         })
         if(this.countYes==this.allCommGuarantorsModel.length){
          this.disableProceedWithFlag='yes';
          this.showCheckBox='yes';
        }
          this.isSpinnerLoading = false;
        }
        this.isSpinnerLoading = false;
      },(error)=>{
        this.isSpinnerLoading=false;
        console.log("ERROR OCCURED " + JSON.stringify(error));
        
      }
    ); }



    PostDataToGetCrifResponse(i:number){
      this.isSpinnerLoading=true; 
      //alert(this.allCommGuarantorsModel[i])
      console.warn(this.allCommGuarantorsModel[i]);
      
      this.fetchCommercialCrifService.responseFromCrifGuarantor(this.allCommGuarantorsModel[i]).subscribe((response) => {
      if(response!=null && response=='CRIF Data Successfully fetched and saved'){
          console.log("THIS IS CRIF RESPONSE " + response);
          this.isSpinnerLoading=false;
          this.countYes=0;
          this.getAllIndGuarantors();
          this.toastr.success("CRIF FETCHED SUCCESSFULLY");
          this.cibilCrifStatusService.individualCRIFCount(this.userDataModel.referenceId).subscribe((response:CibilCrifStatusModel)=>{
            this.cibilCrifStatusModel=response;
          });
        }else{
          this.isSpinnerLoading=false;
        }
        
      },(error)=>{
        this.isSpinnerLoading=false;
        console.log("ERROR OCCURED " + JSON.stringify(error));
      }
    );

    }

   
    onCheckboxChange(event: any): void {
      this.isChecked = event.target.checked;
      if(this.isChecked==true){
        this.disableProceedWithFlag='no';
      }else{
        this.disableProceedWithFlag='yes';
      }
    }
}
