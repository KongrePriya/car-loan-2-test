import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { DocumentsAndRemarksService } from 'src/app/SERVICES/Documents-and-Remarks/documents-and-remarks.service';
import { DocumentsAndRemarksModel, SingleDocumentRemarkDetailsModel } from 'src/app/MODELS/documents-and-remarks.model';

@Component({
selector: 'app-deviation-approval',
templateUrl: './deviation-approval.component.html',
styleUrls: ['./deviation-approval.component.css']
})
export class DeviationApprovalComponent implements OnInit {

constructor ( private router: Router, 
    private toastr: ToastrService,
    private documentsAndRemarksService:DocumentsAndRemarksService) {}

isSpinnerLoading: boolean = false;
userModelData = {} as UserModelData;
isChecked: boolean = false;
selectedFile!:File|null;
showUploadButton: string ='No';
fileTypePdf: boolean | undefined;
singleDocumentRemarkDetails ={} as SingleDocumentRemarkDetailsModel;
documentsAndRemarkModel ={} as DocumentsAndRemarksModel;


ngOnInit(): void {
  this.isSpinnerLoading=true;
  const abc = sessionStorage.getItem("userModelData");
  this.userModelData = JSON.parse(abc!);
  this.getAllDocumentRemarkData();
  this.isSpinnerLoading=false;

}


//----------------------------------------------------------------------------------------------------------------------------------------//
getAllDocumentRemarkData(){
this.isSpinnerLoading=true;
this.documentsAndRemarksService.getAllDocumentRemarkData(this.userModelData.referenceId).subscribe(
(response:DocumentsAndRemarksModel)=> {

  if(response != null){
  this.documentsAndRemarkModel=response;
  console.log("RESPONSE FROM DocumentsAndRemarksModel : "+JSON.stringify(this.documentsAndRemarkModel));

  if(this.documentsAndRemarkModel.deviationSanctionLetterFileName!=null){
    this.showUploadButton='fileUploaded';
  }
  
}
  this.isSpinnerLoading=false;
},
(error :HttpErrorResponse)=> {
  console.error("ERROR WHILE GETTING DOCUMENTS AND REMARKS DATA FOR REF-ID :"+this.userModelData.referenceId +" error details :"+error);
  this.toastr.error("ERROR WHILE GETTING DOCUMENTS AND REMARKS DATA FOR REF-ID :"+this.userModelData.referenceId);
  this.isSpinnerLoading=false;
}
);
}

//**************************************** UPLOAD OVERDUE CLEARANCE DOCUMENT ***********************************************//
// Handle file change event and upload the file immediately
uploadSelectedFile(event: any, fileType:string ) {
  this.selectedFile = event.target.files[0];
  this.showUploadButton=fileType; //to show upload button
  this.documentsAndRemarkModel.deviationDeclarationCheck=false; //to show checkbox
  }

// Upload the selected file immediately
uploadFile(fileType:string) {

  const remarkInput=this.documentsAndRemarkModel.deviationSanctionLetterRemark;

  if (!this.selectedFile) {
    console.warn("NO FILE SELECTED.");
    this.toastr.info("Kindly Select File.");
    return;
  }
    if(this.selectedFile.type != 'application/pdf'){
    this.fileTypePdf=false;
    this.toastr.warning("Only PDF File is allowed.");
    console.warn("Only PDF File is allowed.");
    return;
  }
  if(this.documentsAndRemarkModel.deviationSanctionLetterNumber ===null){
    this.toastr.warning("Kindly Enter Valid Sanction Number.");
    console.warn("Kindly Enter Valid Sanction Number.");
    return;
  }
  if(!remarkInput || remarkInput.trim() === '' || remarkInput === null ){
    this.toastr.warning("Kindly Enter Valid Remark.");
    console.warn("Kindly Enter Valid Remark.");
    return;
  }
  if(!this.documentsAndRemarkModel.deviationDeclarationCheck){
   this.toastr.warning("Kindly Tick Deviation Approval Check-Box.");
   return;
  }
  this.singleDocumentRemarkDetails={
  referenceId:this.userModelData.referenceId,
  fileType: fileType ,
  userId: this.userModelData.userId,
  remark: remarkInput,
  deviationSanctionLetterNumber:this.documentsAndRemarkModel.deviationSanctionLetterNumber,
  declarationCheck:this.documentsAndRemarkModel.deviationDeclarationCheck
  }
  console.warn("singleDocumentRemarkDetails : "+JSON.stringify(this.singleDocumentRemarkDetails));

  this.isSpinnerLoading = true;
  this.fileTypePdf=true;
  this.documentsAndRemarksService.uploadFile(this.selectedFile,this.singleDocumentRemarkDetails).subscribe(
    (response: any) => {
      // Update only the specific file that was uploaded
      this.toastr.success("File Uploaded Successfully...!!!");
      this.showUploadButton='fileUploaded';
      console.log(" showUploadButton :" +this.showUploadButton);
      console.log('File uploaded successfully Upload response', response);
      this.getAllDocumentRemarkData()
      this.isSpinnerLoading = false;
    },
    (error:HttpErrorResponse) => {
      this.toastr.error("Error uploading file...!!!");
      this.isSpinnerLoading = false;
      console.error('Error uploading file :', error);
    }
  );
}

//*********************************************************************************************************************//
// Method to preview a file
  previewFile(fileType:string) {
  this.documentsAndRemarksService.previewFile(this.userModelData.referenceId,fileType).subscribe(
    (response: Blob) => {
      const fileURL = URL.createObjectURL(response);
      window.open(fileURL, '_blank');  // Open the file in a new tab
    },
    (error) => {
      console.error('Error previewing file', error);
    }
  );
}
//****************************************************************************************************************
downloadFile(fileType:string) {
  this.documentsAndRemarksService.downloadFile(this.userModelData.referenceId,fileType).subscribe(
    (response) => {
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = this.userModelData.referenceId+'_'+fileType; 
      console.log("filename to download : "+filename);

      // Extract filename from Content-Disposition header
      if (contentDisposition) {
        const matches = /filename="([^"]*)"/.exec(contentDisposition);
        if (matches != null && matches[1]) {
          // filename = matches[1];  // Set filename to the one from the response header
        }
      }
      if (response.body) {
        const fileURL = URL.createObjectURL(response.body);
        const a = document.createElement('a');
        a.href = fileURL;
        a.download = filename;
        a.click();
      } else {
        console.error('Failed to download the file. The response body is null.');
      }
    },
    (error:HttpErrorResponse) => {
      this.toastr.error("Error While Downloading File.")
      console.error('Error downloading file', error);
    }
  );
}

//****************************************************************************************************************

checkWheatherFileUploaded() {
if ( this.showUploadButton!='fileUploaded'){
    this.toastr.warning("Kindly Upload Deviation Sanction Letter File...");
  return;
}

this.goNext();

}
//******************************************* REDIRECT METHODS *****************************************************
goBack() {
  this.router.navigate(['carLoanV2/deviation-display']);
}

goNext(){
  this.router.navigate(['/carLoanV2/documents-upload']);
}



}
