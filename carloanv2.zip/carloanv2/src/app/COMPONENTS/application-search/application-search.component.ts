import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { RefidGenerationService } from 'src/app/SERVICES/reference-id-generation/ref-id-generation.service';

@Component({
  selector: 'app-application-search',
  templateUrl: './application-search.component.html',
  styleUrls: ['./application-search.component.css']
})
export class ApplicationSearchComponent implements OnInit{

searchReferenceId!:string;
isSpinnerLoading:boolean = false;
refidFound:boolean=true;
userModelData = {} as UserModelData;

constructor(
  private router: Router,
  private toast:ToastrService,
    private refidGenerationService : RefidGenerationService,
) {}

  ngOnInit() {
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    console.log("user data in appraisal note: "+JSON.stringify(this.userModelData) );
  }


searchReferenceIdMethod(searchRefId:string): void {
  this.isSpinnerLoading=true;
  
  if (this.searchReferenceId) {
    this.refidGenerationService.getReferenceId(searchRefId).subscribe(
      (response:any) => {
        console.log('REFERENCE ID PRESENT:', response);
        if(response != null ){
          this.refidFound=true;
          console.log("Car-loan Reference ID Found...!", +this.refidFound);
           this.userModelData=response;

          // this.userModelData.referenceId=response.referenceId;
          sessionStorage.setItem("userModelData" , JSON.stringify(this.userModelData));
          console.log("userModelData AFTER REF-ID FOUND :"+ JSON.stringify(this.userModelData));

          this.router.navigate(['/carLoanV2/appraisalnote']); 

        }else{
          this.refidFound=false;
          this.toast.error("Reference Id "+searchRefId+"  Not Found in System")
          console.log("Car-loan Reference ID Not Found...!", +this.refidFound);
        }
            
        },
      (error:any) => {
        console.error('REFERENCE ID SEARCH ERROR :', error);
        this.isSpinnerLoading=false;

      }
   );
  }
  this.isSpinnerLoading=false;

}
}
