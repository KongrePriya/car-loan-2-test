import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItrDisplayCoapp2Component } from './itr-display-coapp2.component';

describe('ItrDisplayCoapp2Component', () => {
  let component: ItrDisplayCoapp2Component;
  let fixture: ComponentFixture<ItrDisplayCoapp2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ItrDisplayCoapp2Component]
    });
    fixture = TestBed.createComponent(ItrDisplayCoapp2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
