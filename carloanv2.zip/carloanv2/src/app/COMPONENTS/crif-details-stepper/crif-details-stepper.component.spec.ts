import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrifDetailsStepperComponent } from './crif-details-stepper.component';

describe('CrifDetailsStepperComponent', () => {
  let component: CrifDetailsStepperComponent;
  let fixture: ComponentFixture<CrifDetailsStepperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CrifDetailsStepperComponent]
    });
    fixture = TestBed.createComponent(CrifDetailsStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
