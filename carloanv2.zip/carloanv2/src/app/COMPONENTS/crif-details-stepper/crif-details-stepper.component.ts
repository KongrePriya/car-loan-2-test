import { Component, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { DecisionStatusUserInfoDTO } from 'src/app/MODELS/decision-status-all.model';
import { IndvCrifDetailsModel, IndvCrifHistoryMainModel, IndvCrifSummaryModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CRIF-individual-details.model';
import { DecisionStatusService } from 'src/app/SERVICES/decision-status/decision-status.service';
import { FetchIndividualCrifService } from 'src/app/SERVICES/CRIF-individual-all/fetch-individual-crif.service';
import { CibilCrifRemarksFinalModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-final-Remark.model';
import { CibilCrifRemarksFinalService } from 'src/app/SERVICES/CIBIL-CRIF-Remarks/cibil-crif-remarks.service';

@Component({
  selector: 'app-crif-details-stepper',
  templateUrl: './crif-details-stepper.component.html',
  styleUrls: ['./crif-details-stepper.component.css']
})
export class CrifDetailsStepperComponent {

  indvCrifDetails: Array<IndvCrifDetailsModel>=[]
  // indvCrifHistory: 
  // indvCrifHistoryMainModel: Array<IndvCrifHistoryMainModel>=[];
  indvCrifHistoryMainModel:IndvCrifHistoryMainModel[]=[];

  userModelData = {} as UserModelData;
  cibilCrifRemarksFinalModel = {} as CibilCrifRemarksFinalModel;
  isSpinnerLoading = false;
  indvCrifSummaryModel:  Array<IndvCrifSummaryModel>=[];
  showOverdueRemarkField:string="";
  showWrittenOffRemarkField:string="";
  showSettledRemarkField:string="";
  disableNext:string=""; 
  decisionStatusUserInfoDTO = {} as DecisionStatusUserInfoDTO;


  
  constructor(private indvCrifService : FetchIndividualCrifService, 
    private router:Router, private cibilCrifRemarksFinalService :CibilCrifRemarksFinalService, private decisionStatusService:DecisionStatusService,
    private toastr : ToastrService, private modalService: NgbModal){}


    ngOnInit(): void {

      this.isSpinnerLoading=true;
      
      const abc = sessionStorage.getItem('userModelData');
      this.userModelData = JSON.parse(abc!);
    

      // this.userModelData.referenceId="MGBHOME@2025013047a";
        this.getCrifDetailsData();
        this.getCrifHistoryData();
        this.getCrifSummaryData();
        this.getCrifRemarks();

      
    }


    //Get CRIF Details Data for all Individual Guarantors

    getCrifDetailsData(){
      this.isSpinnerLoading=true;
       this.indvCrifService.getAllIndGuardetailsList(this.userModelData.referenceId).subscribe((response) => {
       // this.indvCrifService.getAllIndGuardetailsList("MGBGST@20240808db0").subscribe((response) => {
        this.isSpinnerLoading=false;
        
        if(response!=null){
          this.indvCrifDetails = response;
          // console.log("THS IS RESPONSE " + this.indvCrifDetails);
          if(this.indvCrifDetails.length===0){
            this.disableNext="yes";
          }
        }else{
          // alert("HERE")
          this.disableNext="yes";
        }
      },(error) => {
        console.log("ERROR OCCURED INDV CRIF DISPLAY" + JSON.stringify(error));
        this.isSpinnerLoading=false;
      })
    }


    //Get CRIF History Data for all Individual Guarantors

    getCrifHistoryData(){
      this.isSpinnerLoading=true;
       this.indvCrifService.getAllIndGuarhistoryList(this.userModelData.referenceId).subscribe((response) => {
       // this.indvCrifService.getAllIndGuarhistoryList("MGBGST@20240808db0").subscribe((response) => {
        this.isSpinnerLoading=false;
        if(response!=null){
        this.indvCrifHistoryMainModel = response;
        // console.log("INDIVIDUAL CRIF HISTORY" + JSON.stringify(this.indvCrifHistoryMainModel));
        
        if(this.indvCrifHistoryMainModel.length===0){
          this.disableNext="yes";
        }
      }else{
        this.disableNext="yes";
      }
      },(error) => {
        console.log("ERROR OCCURED INDV CRIF DISPLAY" + JSON.stringify(error));
        this.isSpinnerLoading=false;
      })
    }



         //Get CRIF Details Data for all Individual Guarantors
         getCrifSummaryData(){
          this.isSpinnerLoading=true;
           this.indvCrifService.getAllIndGuarSummaryList(this.userModelData.referenceId).subscribe((response) => {
           // this.indvCrifService.getAllIndGuarSummaryList("MGBGST@20240808db0").subscribe((response) => {
            this.isSpinnerLoading=false;
            if(response!=null){
              this.indvCrifSummaryModel = response;
              this.indvCrifSummaryModel.map(item => {
                if(item.overdueAccounts == 'YES'){
                  this.showOverdueRemarkField='yes';
                }
                if(item.writtenOffAccounts == 'YES'){
                  this.showWrittenOffRemarkField='yes';
                }
                if(item.settledAccounts == 'YES'){
                  this.showSettledRemarkField='yes';
                }
              })
              console.log("THS IS RESPONSE SUMMARY " + this.indvCrifSummaryModel);
              if(this.indvCrifSummaryModel.length===0){
                this.disableNext="yes";
              }
            }else{
              this.disableNext="yes";
            }
          },(error) => {
            console.log("ERROR OCCURED INDV CRIF DISPLAY" + JSON.stringify(error));
        this.isSpinnerLoading=false;
            
          })
        }


     //Post CRIF Remark for all Individual Guarantors

     onSubmitRemark(){
      console.log(this.cibilCrifRemarksFinalModel);
      
      this.isSpinnerLoading=true;
      this.cibilCrifRemarksFinalModel.referenceId=this.userModelData.referenceId;
      this.cibilCrifRemarksFinalModel.userId=this.userModelData.userId;
      this.cibilCrifRemarksFinalModel.userType=this.userModelData.u_type;
      this.cibilCrifRemarksFinalService.CrifPersonalRemarksSaveOrUpdate(this.cibilCrifRemarksFinalModel).subscribe((response) => {
        
        this.isSpinnerLoading=false;
        console.log("THS IS RESPONSE " + response);
        // this.router.navigate(['/carLoanV2/financial']);
      },(error) => {
        console.log("ERROR OCCURED INDV CRIF DISPLAY" + JSON.stringify(error));
        this.isSpinnerLoading=false;
      })
    }



    openVerticallyCentered(content: TemplateRef<any>) {
      this.modalService.open(content, {
        scrollable: true,
        backdrop: 'static',
        keyboard: false,
        size: 'md',
        centered: true,
      });
    }

    postRejectRemark(){
      this.isSpinnerLoading=true;
      this.cibilCrifRemarksFinalModel.referenceId=this.userModelData.referenceId;
      this.cibilCrifRemarksFinalModel.userId=this.userModelData.userId;
      this.cibilCrifRemarksFinalModel.userType=this.userModelData.u_type;
      this.cibilCrifRemarksFinalService.CrifPersonalRemarksSaveOrUpdate(this.cibilCrifRemarksFinalModel).subscribe((response) => {
        
        this.isSpinnerLoading=false;
        if(response!=null){
          console.log("THS IS RESPONSE " + response);
          this.setRejectSubmit();
        }else{
          this.toastr.info("Post Reject Remark In Indv CRIF")
        }
      
      }
      ,(error) => {
        console.log("ERROR OCCURED INDV CRIF DISPLAY Reject" + JSON.stringify(error));
        this.isSpinnerLoading=false;
      })
    }

    

    postOverdueRemark(){
      this.isSpinnerLoading=true;
      this.cibilCrifRemarksFinalModel.referenceId=this.userModelData.referenceId;
      this.cibilCrifRemarksFinalModel.userId=this.userModelData.userId;
      this.cibilCrifRemarksFinalService.CrifPersonalRemarksSaveOrUpdate(this.cibilCrifRemarksFinalModel).subscribe((response) => {
        
        this.isSpinnerLoading=false;
        console.log("THS IS RESPONSE " + response);
        const onlyTopUpLoanTypes = [
          'Top-up Loan for Repair & Renovation to Standalone Borrower',
          'Top-up Loan for Repair & Renovation to Existing Housing Loan Borrower',
          'Top-up Loan for General Purpose to Existing Housing Loan Borrower'
        ];
        if (onlyTopUpLoanTypes.includes(this.userModelData.loanType)) {
          this.router.navigate(['/carLoanV2/deviation-top-up']);
      }else{
        this.router.navigate(['/carLoanV2/deviation-list']);
      }
        
      }
      ,(error) => {
        console.log("ERROR OCCURED INDV CRIF DISPLAY" + JSON.stringify(error));
        this.isSpinnerLoading=false;
      })
    
    }


    getCrifRemarks() {
      this.cibilCrifRemarksFinalModel.referenceId=this.userModelData.referenceId;
      this.isSpinnerLoading = true;
      this.cibilCrifRemarksFinalService.getAllCibilCrifRemarks(this.cibilCrifRemarksFinalModel.referenceId).subscribe(
        (response) => {
          if(response!== null){
            this.cibilCrifRemarksFinalModel = response;
            // console.log("ALL REMARKS OF CIBIL & CRIF  : ", JSON.stringify(response));
          }
          this.isSpinnerLoading = false;
          },(error) => {
            console.log("ERROR OCCURED INDV CRIF DISPLAY" + JSON.stringify(error));
            this.isSpinnerLoading=false;
          }
       );
      }

      toggleCollapse(guarantor: any) {
        guarantor.collapsed = !guarantor.collapsed;
      }


//======================================================Check Min Length Should Be 100======================================================
      

        characterCount: number = 0;
        overDueCount:number=0;
        rejectCount:number=0;
        settledCount:number=0;
        writtenCount:number=0;
        minLength: number = 100;
        isRemarkCountOk:boolean=false;
        isOverDueCountOk:boolean=false;
        isRejectCountOk:boolean=false;
        isSettledCountOk:boolean=false;
        isWrittenCountOk:boolean=false;
       
        //First Page CRIF Remark
        // updateRemarkCount(){
        //   this.characterCount = this.cibilcibilCrifRemarksFinalModel.patnerOrGuaCrifRemark.trim().split(/\s+/).filter(Boolean).length;
        //   if(this.characterCount>100){
        //     this.isRemarkCountOk=true;
        //   }
        // }

        
        //CRIF OverDue Remark
        //     updateOverDueRemarkCount(){
        //       this.overDueCount = this.cibilcibilCrifRemarksFinalModel.patnerOrGuaCrifOverdueRemark.trim().split(/\s+/).filter(Boolean).length;
        //       if(this.overDueCount>100){
        //       this.isOverDueCountOk=true;
        //   }
        // }
//CRIF REJECT Remark
        // updateRejectRemarkCount(){
        //   this.rejectCount = this.cibilcibilCrifRemarksFinalModel.patnerOrGuaCrifRejectRemark.trim().split(/\s+/).filter(Boolean).length;
        //   if(this.rejectCount>100){
        //     this.isRejectCountOk=true;
        //   }
        // }
   
//CRIF SETTLED Remark
// updateSettledRemarkCount(){
//   this.settledCount = this.cibilcibilCrifRemarksFinalModel.patnerOrGuaCrifAccountSettledRemark.trim().split(/\s+/).filter(Boolean).length;
//   if(this.settledCount>100){
//     this.isSettledCountOk=true;
//   }
// }

//CRIF SETTLED Remark
// updateWrittenOffRemarkCount(){
//   this.writtenCount = this.cibilcibilCrifRemarksFinalModel.patnerOrGuaCrifWrittenOffRemark.trim().split(/\s+/).filter(Boolean).length;
//   if(this.writtenCount>100){
//     this.isWrittenCountOk=true;
//   }
// }


// userModelDataForApplicationList = {} as UserModelDataForApplicationList;
//REJECT The Application
setRejectSubmit(){

  this.decisionStatusUserInfoDTO.referenceId = this.userModelData.referenceId;
  this.decisionStatusUserInfoDTO.userId=this.userModelData.userId;
  this.decisionStatusUserInfoDTO.userType=this.userModelData.u_type;
  this.decisionStatusUserInfoDTO.userScale=this.userModelData.scale;
  this.decisionStatusUserInfoDTO.userLocation=this.userModelData.u_loc;
  this.decisionStatusUserInfoDTO.userRegion=this.userModelData.roname;
  this.decisionStatusUserInfoDTO.branchCode=this.userModelData.brcode;
  this.decisionStatusUserInfoDTO.loanType=this.userModelData.loanType;
  this.decisionStatusUserInfoDTO.loanAmount=0;
 this.modalService.dismissAll();
 
  this.decisionStatusService
   .buttonActionReject(this.decisionStatusUserInfoDTO)
   .subscribe(
      (response) => {
        this.isSpinnerLoading=false;
        console.log("In Reject On CRIF PAGE");
        if (response!=null) {
          console.log("Reject Application SuccessFully... ");
          this.toastr.success("Application With ReferenceId " + this.userModelData.referenceId + " Rejected Successfully");
          this.router.navigate(['carLoanV2/'])
       //   alert(JSON.stringify(response))
        }
        else{
          this.toastr.info("Reject status could not be updated")           
        }
      },
       (error) => {
        this.isSpinnerLoading=false;
        console.log("ERROR OCCURED In Reject On CRIF " + JSON.stringify(error));
       }
    );
}

}
