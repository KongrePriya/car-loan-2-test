import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviationDisplayComponent } from './deviation-display.component';

describe('DeviationDisplayComponent', () => {
  let component: DeviationDisplayComponent;
  let fixture: ComponentFixture<DeviationDisplayComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeviationDisplayComponent]
    });
    fixture = TestBed.createComponent(DeviationDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
