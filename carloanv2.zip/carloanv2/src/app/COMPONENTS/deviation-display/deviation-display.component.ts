import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { DeviationFlagModel } from 'src/app/MODELS/deviation-data-model';
import { QuantamOfFinanceModel } from 'src/app/MODELS/quantam-of-finance.model';
import { DeviationService } from 'src/app/SERVICES/Deviation/deviation.service';
import { ApiService } from 'src/app/SERVICES/Login/api.service';
import { QuantumOfFinanceService } from 'src/app/SERVICES/quantum-of-finance/quantum-of-finance.service';

@Component({
  selector: 'app-deviation-display',
  templateUrl: './deviation-display.component.html',
  styleUrls: ['./deviation-display.component.css']
})
export class DeviationDisplayComponent  implements OnInit {
  deviationFlagModel={} as DeviationFlagModel;
  data: any[] = [];
  showUpload: boolean = false;
  selectedFileArray: any[] = [];
  selectedFile: File | null = null;
  remark: string = '';
  userModelData = {} as UserModelData;
  isSpinnerLoading: boolean = false;
  isdeviation:string='no';
  isLoanTypeIsTakeOver:boolean=false;
  isPaperSecurityMortgage:boolean=false;
  quantamOfFinanceModel = {} as QuantamOfFinanceModel; 
  reasonModel: any[]=[];

  constructor( private deviationUploadService: DeviationService,
     private router:Router,private toastr: ToastrService,
     private quantumOfService: QuantumOfFinanceService) {}
        
  ngOnInit(): void {
    const abc = sessionStorage.getItem("userModelData");
    this.userModelData = JSON.parse(abc!);
    this.getDeviationFlag(this.userModelData.referenceId);
  }

  getDeviationFlag(referenceId:string){
    this.isSpinnerLoading=true;
    this.deviationUploadService.getDeviationFlagData(referenceId).subscribe((response)=>{
        if(response!=null){    
        this.deviationFlagModel=response;
        console.log("DEVIATION DATA :",+JSON.stringify(this.deviationFlagModel))
        this.isSpinnerLoading=false;
        };
       (error: HttpErrorResponse)=>{
      this.isSpinnerLoading=false;
      console.error("Error Occur While Fetching DeviationFlag"+JSON.stringify(error));
       }
    });
  }
  

 // -------------------------------------- Previous Button - GoBack ---------------------------------------------
 goBack() {
  this.router.navigate(['carLoanV2/calculation']);
}
goNext(){
 if(this.deviationFlagModel.anyDeviationPresent.toLocaleLowerCase()=='yes'){
      this.router.navigate(['/carLoanV2/deviation-approval']);
    }else{
      this.router.navigate(['/carLoanV2/documents-upload']);
    // this.router.navigate(['/carLoanV2/appraisalnote'],
    //   {
    //         queryParams: { refid: this.userModelData.referenceId}
    //   });
    }
}
// -------------------------------------- // -------------------------------------- // -------------------------------------- // --------------------------------------  
 
}
