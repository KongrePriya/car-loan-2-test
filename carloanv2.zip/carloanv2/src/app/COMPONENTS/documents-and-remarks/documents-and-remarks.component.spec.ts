import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentsAndRemarksComponent } from './documents-and-remarks.component';

describe('DocumentsAndRemarksComponent', () => {
  let component: DocumentsAndRemarksComponent;
  let fixture: ComponentFixture<DocumentsAndRemarksComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DocumentsAndRemarksComponent]
    });
    fixture = TestBed.createComponent(DocumentsAndRemarksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
