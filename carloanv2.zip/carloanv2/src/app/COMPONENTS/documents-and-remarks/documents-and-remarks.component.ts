import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { DocumentsAndRemarksModel, MandatoryDocumentsModel, SingleDocumentRemarkDetailsModel } from 'src/app/MODELS/documents-and-remarks.model';
import { DocumentsAndRemarksService } from 'src/app/SERVICES/Documents-and-Remarks/documents-and-remarks.service';

@Component({
selector: 'app-documents-and-remarks',
templateUrl: './documents-and-remarks.component.html',
styleUrls: ['./documents-and-remarks.component.css']
})
export class DocumentsAndRemarksComponent implements OnInit {

isSpinnerLoading:boolean = false;
userModelData = {} as UserModelData;
selectedFile!:File|null;
showUploadButton: string ='No';
fileTypePdf: boolean | undefined;
singleDocumentRemarkDetails ={} as SingleDocumentRemarkDetailsModel;
documentsAndRemarkModel ={} as DocumentsAndRemarksModel;
mandatoryDocumentsModel ={} as MandatoryDocumentsModel;
selectedRemark!:string;

constructor(
private router: Router,
private documentsAndRemarksService:DocumentsAndRemarksService,
private toastr :ToastrService,
) {}


ngOnInit(): void {
  this.isSpinnerLoading=true;
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  console.warn("USER DATA MODEL"+JSON.stringify(this.userModelData));
  
  this.getAllMandatoryDocumentData();
  this.getAllDocumentRemarkData();

  this.isSpinnerLoading=false;
}

//**************************************************************************************************************************//

getAllDocumentRemarkData(){
this.isSpinnerLoading=true;
this.documentsAndRemarksService.getAllDocumentRemarkData(this.userModelData.referenceId).subscribe(
(response:DocumentsAndRemarksModel)=> {
  if(response !=null){
  this.documentsAndRemarkModel=response;
  console.log("RESPONSE FROM DocumentsAndRemarksModel : "+JSON.stringify(this.documentsAndRemarkModel));
  }
  this.isSpinnerLoading=false;
},
(error :HttpErrorResponse)=> {
  console.error("ERROR WHILE GETTING DOCUMENTS AND REMARKS DATA FOR REF-ID :"+this.userModelData.referenceId +" error details :"+error);
  this.toastr.error("ERROR WHILE GETTING DOCUMENTS AND REMARKS DATA FOR REF-ID :"+this.userModelData.referenceId);
  this.isSpinnerLoading=false;
}
);
}

//**************************************************************************************************************************//

getAllMandatoryDocumentData(){
this.isSpinnerLoading=true;
this.documentsAndRemarksService.getAllMandatoryDocumentData(this.userModelData.referenceId).subscribe(
(response:MandatoryDocumentsModel)=> {

  this.mandatoryDocumentsModel=response;
  console.log("RESPONSE FROM mandatory Documents Model : "+JSON.stringify(this.mandatoryDocumentsModel));
  this.isSpinnerLoading=false;
},
(error :HttpErrorResponse)=> {
  console.error("ERROR WHILE GETTING MANDATORY DOCUMENTS DATA FOR REF-ID :"+this.userModelData.referenceId +" error details :"+error);
  this.toastr.error("ERROR WHILE GETTING MANDATORY DOCUMENTS DATA FOR REF-ID :"+this.userModelData.referenceId);
  this.isSpinnerLoading=false;
}
);
}
//*********************************************************************************************************************//
getRemarkToPost(fileType:String){

  switch(fileType){
        case "applicantDueDiligence":            
          return this.documentsAndRemarkModel.applicantDueDiligenceRemark;
        case "applicantItrForm16":
          return this.documentsAndRemarkModel.applicantITRForm16Remark;
        case "applicantKyc":            
          return this.documentsAndRemarkModel.applicantKYCRemark;
        case "applicantSalaryPension":
          return this.documentsAndRemarkModel.applicantSalaryPensionRemark;
        case "applicantPassport":
           return this.documentsAndRemarkModel.applicantPassportRemark;
        case "applicantBankStatement":
           return this.documentsAndRemarkModel.applicantBankStatementRemark;


        case "coappDueDiligence":
          return this.documentsAndRemarkModel.coAppDueDiligenceRemark;
        case "coappItrForm16":
          return this.documentsAndRemarkModel.coAppITRForm16Remark;
        case "coappKyc":
          return this.documentsAndRemarkModel.coAppKYCRemark;
        case "coappSalaryPension":
          return this.documentsAndRemarkModel.coAppSalaryPensionRemark;

        case "guarantorDueDiligence":
          return this.documentsAndRemarkModel.guarantorDueDiligenceRemark;
        case "guarantorItrForm16":
          return this.documentsAndRemarkModel.guarantorITRForm16Remark;
        case "guarantorKyc":
          return this.documentsAndRemarkModel.guarantorKYCRemark;
        case "guarantorSalaryPension":
          return this.documentsAndRemarkModel.guarantorSalaryPensionRemark;

        case "quotation":
          return this.documentsAndRemarkModel.quotationFileRemark;
        case "visitReport":
          return this.documentsAndRemarkModel.visitReportRemark;
        case "employmentOrBusinessProof":
          return this.documentsAndRemarkModel.employmentOrBusinessProofRemark;

        case "other":
          return this.documentsAndRemarkModel.otherRemark;     
        default : return "";
  }
}
//***************************************************** UPLOAD DOCUMENT ************************************************************//
// Handle file change event and upload the file immediately
uploadSelectedFile(event: any, fileType:string ) {
  this.selectedFile = event.target.files[0];
  this.showUploadButton=fileType; //to show upload button
  }

// Upload the selected file immediately
uploadFile(fileType:string) {

  const remarkInput=this.getRemarkToPost(fileType);
  if (!this.selectedFile) {
    console.warn("NO FILE SELECTED.");
    this.toastr.info("Kindly Select File.");
    return;
  }
    if(this.selectedFile.type != 'application/pdf'){
    this.fileTypePdf=false;
    this.toastr.warning("Only PDF File is allowed.");
    console.warn("Only PDF File is allowed.");
    return;
  }
  if(!remarkInput || remarkInput.trim() === '' || remarkInput === null){
    this.toastr.warning("Kindly add valid Remark.");
    console.warn("Kindly add valid Remark.");
    return;
  }
  this.singleDocumentRemarkDetails={
  referenceId:this.userModelData.referenceId,
  fileType: fileType ,
  userId: this.userModelData.userId,
  remark: remarkInput,
  // deviationSanctionLetterNumber:'', //extra for deviation
  // declarationCheck:false //extra for deviation
  }
  console.warn("singleDocumentRemarkDetails : "+JSON.stringify(this.singleDocumentRemarkDetails));

  this.isSpinnerLoading = true;
  this.fileTypePdf=true;
  this.documentsAndRemarksService.uploadFile(this.selectedFile,this.singleDocumentRemarkDetails).subscribe(
    (response: any) => {
      // Update only the specific file that was uploaded
      this.toastr.success("File Uploaded Successfully...!!!");
      this.showUploadButton='No';
      console.log(" showUploadButton :" +this.showUploadButton);
      console.log('File uploaded successfully Upload response', response);
      this.getAllDocumentRemarkData()
      this.isSpinnerLoading = false;
    },
    (error:HttpErrorResponse) => {
      this.toastr.error("Error uploading file...!!!");
      this.isSpinnerLoading = false;
      console.error('Error uploading file :', error);
    }
  );
}

//*********************************************************************************************************************//
// Method to preview a file
  previewFile(fileType:string) {
  this.documentsAndRemarksService.previewFile(this.userModelData.referenceId,fileType).subscribe(
    (response: Blob) => {
      const fileURL = URL.createObjectURL(response);
      window.open(fileURL, '_blank');  // Open the file in a new tab
    },
    (error) => {
      console.error('Error previewing file', error);
    }
  );
}
//**********************************************************************************************************************//
downloadFile(fileType:string) {
  this.documentsAndRemarksService.downloadFile(this.userModelData.referenceId,fileType).subscribe(
    (response) => {
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = this.userModelData.referenceId+'_'+fileType; 
      console.log("filename to download : "+filename);

      // Extract filename from Content-Disposition header
      if (contentDisposition) {
        const matches = /filename="([^"]*)"/.exec(contentDisposition);
        if (matches != null && matches[1]) {
          // filename = matches[1];  // Set filename to the one from the response header
        }
      }
      if (response.body) {
        const fileURL = URL.createObjectURL(response.body);
        const a = document.createElement('a');
        a.href = fileURL;
        a.download = filename;
        a.click();
      } else {
        console.error('Failed to download the file. The response body is null.');
      }
    },
    (error) => {
      this.toastr.error("Error While Downloading File.")
      console.error('Error downloading file', error);
    }
  );
}


//************************************************ REDIRECT METHODS ***************************************************//

goNext(){
//need to check if all required documents uploaded
  this.router.navigate(['/carLoanV2/appraisalnote'],
    { queryParams: { refid: this.userModelData.referenceId} });
}

goBack(){
  this.router.navigate(['/carLoanV2/deviation-display']);
}
//*********************************************************//*****************************************************//
}
