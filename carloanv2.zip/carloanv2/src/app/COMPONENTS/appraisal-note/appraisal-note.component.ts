import { Component, OnInit, ViewChild } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';



import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { finalize } from 'rxjs';
import { NgForm } from '@angular/forms';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { CibilFetchStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-fetch-status.model';
import {  CibilFetchStatusService } from 'src/app/SERVICES/CIBIL-individual-all/cibil-details.service';
import { IPAddressService } from 'src/app/SERVICES/Login/ip.service';

@Component({
  selector: 'app-appraisal-note-old',
  templateUrl: './appraisal-note.component.html',
  styleUrls: ['./appraisal-note.component.css'],
  // providers: [MainServiceService],
})
export class AppraisalNoteComponent implements OnInit {
  coapplicantFlag: boolean = true;
  gaurantorFlag: boolean = true;
  userModelData={} as UserModelData;
  
  // finalAppraisalMaker={} as finalAppraisalModel;
  teststring!: string;
  searchFlag!:string;
  showNewCibil!:string;
  isSpinnerLoading=false;
cibilStatusModel={} as CibilFetchStatusModel;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cibilFetchStatusService: CibilFetchStatusService,
    private http: HttpClient,
    private ipService: IPAddressService,

  ) {
    console.log('appraisal note component loaded using lazy loading');
  }

  async ngOnInit() {
    //spinner Loading

    this.isSpinnerLoading = true;
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    console.log("user data in appraisal note: "+JSON.stringify(this.userModelData) );


      //To get Reference Id from Application List
   this.activatedRoute.queryParams.subscribe(params => {
    this.searchFlag = params['flag'];
  });
  
  } //ngOnInIt closed herefirstName

allServicesGet(){
  
}


  @ViewChild('appraisalForm') appraisalForm!: NgForm;

  
//================================ OLD CIBIL DATA ================================//
 

  cibil_history_Header = [
    'Customer',
    'Name',
    'Facility Type',
    'Ownership',
    'Banker',
    'Sanction Date',
    'CC Limit',
    'Amount Outstanding',
    'Overdue (if any)',
    'Status',
  ];

  cibilChecks = [
    'CIBIL Score Not Acceptable(Less than 600)',
    'Account Written-Off',
    'Account Settled',
    'Account Overdue',
  ];

  cibil_summ_Header = [
    'Name',
    'Cibil Score',
    'Total Accounts',
    'Regular Accounts',
    'Overdue Accounts',
    'Zero Balance Accounts',
  ];

  primaryTerms = [
    'Facility Type',
    'Banker',
    'Sanction Date',
    'Sanction Amount',
    'Amount Outstanding',
    'Overdue (if any)',
  ];

  Termsandconditions_optional: any[] = [
    'Disbursement to be made only after getting the document vetted from legal office/empanelled advocate of designated allotted branch',
    'Kotak Mahindra MIS Portal information should be filled up immediately after disbursement',
  ];

  
  editApplication(): void {
    alert("ref id: "+JSON.stringify(this.userModelData));
  
   if(this.userModelData.custType === "individual"){
     this.router.navigate(['/carLoanV2/borrower-individual'],{
      queryParams: { refId: this.userModelData.referenceId },
    });
    }else 
      if(this.userModelData.custType === "corporate"){
    this.router.navigate(['/carLoanV2/borrower-firm'],{
      queryParams: { refId: this.userModelData.referenceId },
    });
    }


  } //ngOnInit closed


 

  //this function will display pdf file in other browser// for preview
  types: string = '';
  async gotoPreviewFile(indexnumber: number) {
    switch (indexnumber) {
      case 0:
        this.types = 'Quotation';
        break;
      case 1:
        this.types = 'DueDiligence';
        break;
      case 2:
        this.types = 'VisitReport';
        break;
      case 3:
        this.types = 'Form60ITR';
        break;
      case 4:
        this.types = 'SalarySlip';
        break;
      case 5:
        this.types = 'coDueDiligence';
        break;
      case 6:
        this.types = 'coForm60ITR';
        break;
      case 7:
        this.types = 'coSalarySlip';
        break;
      case 8:
        this.types = 'other';
        break;
      default:
        break;
    }

   
    this.isSpinnerLoading=true;
    try {
      setTimeout(() => {
        const result = this.downloadFile(
         'Reference Number',
          this.types
        );   
      }, 2000);
     // console.log(result); // It will be a boolean value
      // this.isSpinnerLoading = result;
      this.isSpinnerLoading = false;

    } catch (error) {
      this.isSpinnerLoading = false;
      console.error('Error:', error);
    }
  }

  // async buttonClickDecision(): Promise<void> {
  //   // alert(JSON.stringify(this.decisionLogModel))
    
  //   await this.postAppraisal_maker_Final();
   
  //   setTimeout(() => {
  //     this.decisionLogService
  //     .patchButtonDecisionPower(this.decisionLogModel, this.referenceNumber)
  //     .subscribe((response) => {
  //       this.isSpinnerLoading=false;
  //       this.router.navigate(['/carloan'])
  //     });  
  //   }, 5000);
  //   console.log("ButtonClick Decision Complete 4")


    
  // }

  //preview files
  previewFile(fileNumber: any, prevfilename: string) {
    if (prevfilename != null) {
      // alert(this.uploadedFileData.salaryFile.length);
      this.isSpinnerLoading = true;
      this.gotoPreviewFile(fileNumber);
    }
  }
//******************************************************************* */
  //========================OLD CIBIL STATUS API ======================//

  
    //========================NEW CIBIL STATUS API ======================//



//Download File PReview Button

    downloadFile(referenceNumber: string, types: any): void {
      this.isSpinnerLoading = true; // Start loading animation    
    
      const url =
      'http://' +
      this.ipService.getIPAddress() +
      '/fileUpload/files/' +
      referenceNumber +
      '/' +
      types;
    
       
     
      const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*', // Adjust this based on your server configuration
           'Accept':'application/pdf'    });
      this.http.get(url, {
        headers: headers,
        responseType: 'blob' // Specify the response type as blob
      }).pipe(
        finalize(() => {
          this.isSpinnerLoading = false; // Stop loading animation
        })
      ).subscribe(
        (response: Blob) => {
          const blob = new Blob([response], { type: 'application/pdf' });
          const fileUrl = window.URL.createObjectURL(blob);
          window.open(fileUrl);
          // Cleanup
          window.URL.revokeObjectURL(fileUrl);
        },
        (error) => {
          // Handle the error here
          console.error('Download failed', error);
          this.isSpinnerLoading = false; // Stop loading animation in case of error
        }
      );
      
    
    }

//***************************************//***************************************//***************************************//***************************************
//*************************************** CIBIL DETAILS *******************************************//*************************************** */



cibil_details_Header = [
  'Customer Type',
  'Name',
  'CIBIL Score',
  'Personal Loan Score',
  'Total Accounts',
  'Regular Accounts',
  'Overdue Accounts',
  'Zero Balance Accounts',

];

cibil_history_Header_new = [
// 'Gurantor Name',
  'SR.NO',
  'Facility Type',
  'Ownership',
  'Banker',
  'Sanction Date',
  'Sanction Amount',
  'EMI Amount',
  'Amount Outstanding',
  'Overdue',
  'Status'
];

cibilChecks_new = [
 'Customer Type',
  'Name',
  'CIBIL Score Less than 600',
  'Account Written-Off',
  'Account Settled',
  'Account Overdue',
];
// ==================== METHOD TO GET BASIC CIBIL DETAILS OF INDIVIDUAL GUARANTORS ====================// 


// ==================== METHOD TO GET BASIC CIBIL SUMMARY OF INDIVIDUAL GUARANTORS ====================//
  
//=================== other CIBIL functions ===================================//
  toggleCollapse(guarantor: any) {
    guarantor.collapsed = !guarantor.collapsed;
  }



}
