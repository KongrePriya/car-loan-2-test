import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { ApplicationListButtonDataModel } from 'src/app/MODELS/application-list/application-list-button-data.model';
import { UserModelDataForApplicationList } from 'src/app/MODELS/application-list/application-list-data-get.model';
import { AllApplicationStatusModel } from 'src/app/MODELS/application-list/application-list.model';
import { AppraisalNoteRemarksAndConditions } from 'src/app/MODELS/appraisal-remarks-conditions.model';
// import { AppraisalNoteModel } from 'src/app/MODELS/appraisal-note.model';
import { CibilFetchStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-fetch-status.model';
import { AppraisalNoteService } from 'src/app/SERVICES/appraisal-note/appraisal-note.service';
import { CibilAllDetailsService, CibilFetchStatusService } from 'src/app/SERVICES/CIBIL-individual-all/cibil-details.service';

@Component({
  selector: 'app-appraisal-remark-condition',
  templateUrl: './appraisal-remark-condition.component.html',
  styleUrls: ['./appraisal-remark-condition.component.css']
})
export class AppraisalRemarkConditionComponent{

}