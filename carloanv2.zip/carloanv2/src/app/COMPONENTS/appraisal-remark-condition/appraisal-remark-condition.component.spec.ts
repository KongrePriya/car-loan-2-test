import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppraisalRemarkConditionComponent } from './appraisal-remark-condition.component';

describe('AppraisalRemarkConditionComponent', () => {
  let component: AppraisalRemarkConditionComponent;
  let fixture: ComponentFixture<AppraisalRemarkConditionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AppraisalRemarkConditionComponent]
    });
    fixture = TestBed.createComponent(AppraisalRemarkConditionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
