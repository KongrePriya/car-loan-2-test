import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { IncomeSalariedModel } from 'src/app/MODELS/income-salaried.model';
import { IncomeDetailsForAllService } from 'src/app/SERVICES/Income-Details/income-details-all.service';

@Component({
  selector: 'app-income-salary',
  templateUrl: './income-salary.component.html',
  styleUrls: ['./income-salary.component.css']
})
export class IncomeSalaryComponent {

  //***************************************************** *CONSTRUCTOR BLOCK*****************************

  constructor(private incomeDetailsAllService: IncomeDetailsForAllService, private router: Router,private toastr : ToastrService, private activatedRoute: ActivatedRoute,){
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();

    const currentMonthIndex = currentDate.getMonth(); // Month is 0-indexed

    // Set current month in YYYY-MM format
    this.currentMonth = `${currentYear}-${(currentMonthIndex + 1).toString().padStart(2, '0')}`;

    // Calculate the month one year back
    const oneYearBackDate = new Date(currentDate);
    oneYearBackDate.setFullYear(currentYear - 1);
    this.minMonth = `${oneYearBackDate.getFullYear()}-${(oneYearBackDate.getMonth() + 1).toString().padStart(2, '0')}`;
    //this.generateYearRanges();
  }
//***************************************************** *CONSTRUCTOR BLOCK END *****************************
ngOnInit(): void {
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
 
  // this.activatedRoute.queryParams.subscribe(params => {
  //   this.incomeSalariedModel.panNumber = params['pan'];
  // });
  // this.activatedRoute.queryParams.subscribe(params => {
  //   this.incomeSalariedModel.customerType = params['customerType'];
  // });

  //----------------To get PAN and Customer-Type from Income-List----------------------//
  this.activatedRoute.queryParams.subscribe(params => {
    this.panNumber = params['panNumber'],
    this.custType = params['custType'];
    this.customerName = params['customerName'];
       this.referenceId = this.userModelData.referenceId;
  });
  this.referenceId=this.userModelData.referenceId;
  
  this.getIncomeDetailsSalaried();
  
  this.generateYearRanges();
  //this.getAppraisalNoteData();
 
}
  userModelData = {} as UserModelData;
  incomeSalariedModel = {} as IncomeSalariedModel;
  
  // referenceId: string = 'MGB@INCOME';
  // panNumber: string = 'AUJPT0678C';
  referenceId: string = this.userModelData.referenceId;
  panNumber: string = '';
  customerName: string = '';
  custType:string = '';
  isSpinnerLoading = false;
  currentYear!:number;
  currentMonth: string;
  minMonth: string;
  dateFlag: boolean = false;
  yearFlag: boolean = false;
  yearRanges: string[] = [];
  fiscalYearStartMonth: number = 3; // April (0-based index, so 3 represents April)
  ages: number[] = [];
  expYears: number[] = [];
  expMonths: number[] = [];
  totalYears: number[] = [];
  totalMonths: number[] = [];
  salaryFlag:boolean = false;

// -------------------------------------- For validation of salary months ---------------------------------------------


checkForDuplicates(): void {
  const months = [this.incomeSalariedModel.monthOneTitle, this.incomeSalariedModel.monthTwoTitle, this.incomeSalariedModel.monthThreeTitle];
  const filteredMonths = months.filter(month => month);
  
  // Create a Set to track unique months
  const uniqueMonths = new Set(filteredMonths);
 
  this.dateFlag = uniqueMonths.size < filteredMonths.length; 
 
}



checkForDuplicatesYear(): void {
  
  const year =[this.incomeSalariedModel.selectedFirstYear,this.incomeSalariedModel.selectedSecondYear];
  const filteredyear = year.filter(year => year);
  // Create a Set to track unique year
 
  const uniqueYear=new Set(filteredyear);
 
  this.yearFlag = uniqueYear.size < filteredyear.length; 
}
onMonthChange(): void {
  this.checkForDuplicates();
}
onYearChange(): void {
  this.checkForDuplicatesYear();
}
  
  

// ----------------------------------------------- Calculate Total Current Deducations ---------------------------------------------

  calculateTotalCurrentDeductions(){
    this.incomeSalariedModel.totalCurrentDeduction = this.incomeSalariedModel.currentEmiDeduction+this.incomeSalariedModel.incomeTaxDeduction+this.incomeSalariedModel.salarySlipDeduction+this.incomeSalariedModel.otherDeduction
  }



  goBack() {
  throw new Error('Method not implemented.');
  }




  // ----------------------------------------------- Get Year For Income Details as per ITR/Form 16 ---------------------------------------------
  private generateYearRanges(): void {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth(); // 0 = January, ..., 11 = December

    let startYear: number;

    // Determine starting year for previous fiscal years
    if (currentMonth >= this.fiscalYearStartMonth) {
      startYear = currentYear - 1; // Last fiscal year
    } else {
      startYear = currentYear - 2; // Two fiscal years ago
    }

    // Generate year ranges for previous fiscal years (excluding current FY)
    for (let i = 0; i < 3; i++) { // Only two previous fiscal years
    const yearRange = `${startYear - i}-${(startYear - i + 1).toString().slice(2,4)}`;
      this.yearRanges.unshift(yearRange); // Add to the beginning for reverse order
    }

    // Retirement Age Drop-Down
    for (let age = 18; age <= 65; age++) {
      this.ages.push(age);
    }
    //  Experience In Current Org. Year Drop-Down
    for (let expyear = 0; expyear <= 45; expyear++) {
      this.expYears.push(expyear);
    }

     //  Experience In Current Org. Month Drop-Down
     for (let expnonth = 0; expnonth <= 11; expnonth++) {
      this.expMonths.push(expnonth);
    }

     // Total Experience Year Drop-Down
     for (let totalyear = 0; totalyear <= 45; totalyear++) {
      this.totalYears.push(totalyear);
    }

    // Total Experience Month Drop-Down
     for (let age = 0; age <= 11; age++) {
      this.totalMonths.push(age);
    }
    

  }



    // -------------------------------------- Get Data For Income Borrower ---------------------------------------------
   
    getIncomeDetailsSalaried(){
    this.isSpinnerLoading=true;
    this.incomeDetailsAllService.getIncomeDetailsSalaried(this.referenceId,this.panNumber).subscribe((response) => {
      this.isSpinnerLoading=false;
      if(response!=null){
        this.incomeSalariedModel=response;
        // if(this.incomeSalariedModel.kotakOptions=='rejected'){
        //   this.disableKliPremium='yes'
        //   this.disableKliFunded='yes'
        // }
        // if(this.incomeSalariedModel.kotakOptions=='nonfunded'){
        //   this.disableKliPremium='no'
        //   this.disableKliFunded='yes'
        // }
        // if(this.incomeSalariedModel.kotakOptions=='funded'){
        //    this.disableKliPremium='no'
        //   this.disableKliFunded='no'
        // }
      }else{
        if (this.incomeSalariedModel.organisationType == undefined) {
          this.incomeSalariedModel.organisationType = '';
        }
        if (this.incomeSalariedModel.retirementAge == undefined) {
          this.incomeSalariedModel.retirementAge = '';
        }
        if (this.incomeSalariedModel.currentOrgExperienceYears == undefined) {
          this.incomeSalariedModel.currentOrgExperienceYears = null;
        }
        if (this.incomeSalariedModel.currentOrgExperienceMonthsFrontEnd == undefined) {
          this.incomeSalariedModel.currentOrgExperienceMonthsFrontEnd = null;
        }
        if (this.incomeSalariedModel.totalWorkExperienceYears == undefined) {
          this.incomeSalariedModel.totalWorkExperienceYears = null;
        }
        if (this.incomeSalariedModel.totalWorkExperienceMonthsFrontEnd == undefined) {
          this.incomeSalariedModel.totalWorkExperienceMonthsFrontEnd = null;
        }
        if (this.incomeSalariedModel.selectedFirstYear == undefined) {
          this.incomeSalariedModel.selectedFirstYear = '';
        }
        if (this.incomeSalariedModel.selectedSecondYear == undefined) {
          this.incomeSalariedModel.selectedSecondYear = '';
        }
        if (this.incomeSalariedModel.incomeDetailOption == undefined) {
          this.incomeSalariedModel.incomeDetailOption = '';
        }
       

      }
    },(error)=>{
      this.isSpinnerLoading=false;
      this.toastr.error("Error occured Get Income Borrower")
      console.log("Error occured Get Income Borrower " + JSON.stringify(error));
    }
  )
  }
   // ----------------------------------------------- CHECK SALARY CONDITION ---------------------------------------------

 checkSalaryAmount(){
  if(this.incomeSalariedModel.monthOneSalary<25000||this.incomeSalariedModel.monthTwoSalary<25000||this.incomeSalariedModel.monthThreeSalary<25000)
  {
    this.toastr.info("Salary should be above 25000/-")
    
     this.salaryFlag=true;
  }
  else{
     this.salaryFlag=false;
  }
}
   //--------------------------------------------POST DATA AND SAVED INTO DATABASE
   
   
   
    onSubmitBorrowerIncome(){

      console.log(this.incomeSalariedModel);
      
      if (this.dateFlag||this.yearFlag||this.salaryFlag) { 
        this.toastr.info("Form is invalid due to duplicate months/year or salary amount.")
      }else{
      this.isSpinnerLoading = true
      this.incomeSalariedModel.referenceId=this.referenceId;
      
      this.incomeSalariedModel.userId=this.userModelData.userId;
      this.incomeSalariedModel.branchCode=this.userModelData.brcode;
      this.incomeSalariedModel.customerType=this.custType;
      this.incomeSalariedModel.incomeType='Salaried';
      this.incomeSalariedModel.customerName=this.customerName;
      this.incomeSalariedModel.panNumber=this.panNumber;

     
      this.incomeDetailsAllService.postIncomeDetailsSalaried(this.incomeSalariedModel).subscribe((response) => {
            this.isSpinnerLoading=false
           // this.router.navigate(['']);
            console.log("Income Borower Response " + JSON.stringify(response));
            console.log("Income Borower Response " + this.incomeSalariedModel);
            this.goNext();
      },(error) => {
        console.log("Error Occured In Saving Income Details - Borrower " + JSON.stringify(error));
        
        this.isSpinnerLoading=false
      }
    )}
    }
   // ********************************************************navigate to next page
   goNext(){

    this.router.navigate(["/carLoanV2/income-main-list"])}

    //// -------------------------------------------------------------Reset fields based on the selected option-------------------------------------------------------------
resetFields() {
  // Reset fields based on the selected option
  if (this.incomeSalariedModel.incomeAvailableFor === 'One Year') {
    this.incomeSalariedModel.netIncomeFirstYear = 0;
    this.incomeSalariedModel.grossIncomeFirstYear = 0;
    this.incomeSalariedModel.selectedFirstYear = '';
   
  } 
  // else if (this.incomeSalariedModel.incomeAvailableFor === 'Not Available') {
  //   this.incomeSalariedModel.netIncomeFirstYear = 0;
  //   this.incomeSalariedModel.grossIncomeFirstYear = 0;
  //   this.incomeSalariedModel.selectedFirstYear = '';

  //   this.incomeSalariedModel.netIncomeSecondYear = 0;
  //   this.incomeSalariedModel.grossIncomeSecondYear = 0;
  //   this.incomeSalariedModel.selectedSecondYear = '';
   
  // }
  
}

}
