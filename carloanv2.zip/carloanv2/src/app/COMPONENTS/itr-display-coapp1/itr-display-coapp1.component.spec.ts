import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItrDisplayCoapp1Component } from './itr-display-coapp1.component';

describe('ItrDisplayCoapp1Component', () => {
  let component: ItrDisplayCoapp1Component;
  let fixture: ComponentFixture<ItrDisplayCoapp1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ItrDisplayCoapp1Component]
    });
    fixture = TestBed.createComponent(ItrDisplayCoapp1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
