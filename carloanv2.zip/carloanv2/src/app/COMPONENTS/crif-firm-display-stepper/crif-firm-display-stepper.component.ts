import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { UserModelDataForApplicationList } from 'src/app/MODELS/application-list/application-list-data-get.model';
import { CibilCrifRemarksFinalModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-final-Remark.model';
import { CibilCrifStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-STATUS.model';
import { CommCrifDetailsModel, CommCrifHistoryModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CRIF-commercial.model';
import { AppraisalNoteService } from 'src/app/SERVICES/appraisal-note/appraisal-note.service';
import { CibilCrifRemarksFinalService } from 'src/app/SERVICES/CIBIL-CRIF-Remarks/cibil-crif-remarks.service';
import { CibilCrifStatusService } from 'src/app/SERVICES/CIBIL-CRIF-STATUS/cibil-crif-status.service';
import { CommercialCrifService } from 'src/app/SERVICES/CRIF-commercial-all/fetch-commercial-crif.service';

@Component({
  selector: 'app-crif-firm-display-stepper',
  templateUrl: './crif-firm-display-stepper.component.html',
  styleUrls: ['./crif-firm-display-stepper.component.css']
})
export class CrifFirmDisplayStepperComponent implements OnInit{



  commCrifDetails: Array<CommCrifDetailsModel>=[]
  commCrifHistory: Array<CommCrifHistoryModel>=[]
  cibilCrifRemarksModel = {} as CibilCrifRemarksFinalModel;
  showOverdueRemarkField:string="";
  AnyOverduePresent:boolean=false;
  AnyAccountSettled:boolean=false;
  AnyAccountWrittenOff:boolean=false;
  AnyAccountSuitFilled:boolean=false;


  userModelData = {} as UserModelData;
  cibilCrifStatusModel = {} as CibilCrifStatusModel;
  routeToPage:string='';
  isSpinnerLoading = false;
  
  constructor(
    private commCrifService : CommercialCrifService,
     private cibilCrifRemarksService :CibilCrifRemarksFinalService, 
    private router:Router, 
    private modalService: NgbModal,
    private toastr : ToastrService,
    private appraisalNoteService : AppraisalNoteService,
    private cibilCrifStatusService: CibilCrifStatusService,
    ){}


    ngOnInit(): void {
      const abc = sessionStorage.getItem('userModelData');
      this.userModelData = JSON.parse(abc!);
        this.getguarantorsCount();
        this.getCrifDetailsData();
        this.getCrifHistoryData();
        this.getCrifSummaryData();
        this.RemarksFirmCommercialCrifGet();
    }



    getCrifDetailsData(){
   //   this.isSpinnerLoading=true;
   console.warn("reference id :"+this.userModelData.referenceId);
      this.commCrifService.getCommCrifFirmData(this.userModelData.referenceId,'BORROWER').subscribe((response) => {
        // this.commCrifService.getCommCrifFirmData('MGBGST@20240729735','BORROWER').subscribe((response) => {
          this.isSpinnerLoading=false;
        this.commCrifDetails = response;
        console.log("THS IS RESPONSE Details" + JSON.stringify(this.commCrifDetails));
        
      },(error) => {
        this.isSpinnerLoading=false;
        console.log("ERROR OCCURED IN FIRM DATA DISPLAY CRIF" + JSON.stringify(error));
      })
      this.isSpinnerLoading=false;

    }


    //Get CRIF History Data for all Individual Guarantors

    getCrifHistoryData(){
   //   this.isSpinnerLoading=true;
     this.commCrifService.getCommCrifFirmHistoryData(this.userModelData.referenceId,'BORROWER').subscribe((response) => {
         //this.commCrifService.getCommCrifFirmHistoryData('MGBGST@20240729735','BORROWER').subscribe((response) => {
          this.isSpinnerLoading=false;
            this.commCrifHistory = response;
        console.log("THS IS RESPONSE History" +  JSON.stringify(this.commCrifHistory));
        
      },(error) => {
        this.isSpinnerLoading=false;
        console.log("ERROR OCCURED IN FIRM DATA DISPLAY CRIF" + JSON.stringify(error));
      })
      this.isSpinnerLoading=false;

    }
    summaryDetailsModel={} as CommCrifHistoryModel;
    summaryDetailsModelArray:CommCrifHistoryModel[]=[];
    OverduePresentCorpGuarantors:boolean=false;
   
    // highlightRows(index: number, highlight: boolean): void {
    //   this.newHistoryDetailsModelArray[index].highlighted = highlight;
    //   if (highlight===true){
    //     this.newHistoryDetailsModelArray[index].collapsed = false;
    
    //   }
    // }
   
    com_crif_summary_header = [
      'Sr.No',
      'Corporate Guarantor Name',
      'Pan',
      'Account Written-Off',
      'Account Settled',
      'Suitfilled Accounts',
      'Account Overdue'
    ];

    getCrifSummaryData() {
      // this.summaryDetailsModel.referenceId='MGBGST20241203545'; //DUMMY
      this.isSpinnerLoading = true;
   
   this.commCrifService.getCommCrifFirmSummaryData(this.userModelData.referenceId,"BORROWER").subscribe(
    //this.commCrifService.getCommCrifFirmSummaryData('MGBGST@20240729735','BORROWER').subscribe(
      (response:CommCrifHistoryModel[]) => {
          if(response!== null){
            this.summaryDetailsModelArray = response;
            console.log("CRIF COMMERCIAL Firm LIST : ", JSON.stringify(this.summaryDetailsModelArray));
           
             //setting a combined overdue flag after checking if any one has overdue= YES
     this.AnyOverduePresent = response.some(item => item.overdueStatus === 'YES');
     console.log("this.AnyOverduePresent : ", this.AnyOverduePresent);
       //for settled accounts
       this.AnyAccountSettled = response.some(item => item.settledStatus === 'YES');
       console.log("this.AnyAccountSettled : ", this.AnyAccountSettled);

       //for written off accounts
       this.AnyAccountWrittenOff = response.some(item => item.writtenOffStatus === 'YES');
       console.log("this.AnyAccountWrittenOff : ", this.AnyAccountWrittenOff);

       //for suit-filled accounts
       this.AnyAccountSuitFilled = response.some(item => item.suitFiledStatus === 'YES');
       console.log("this.AnyAccountSuitFilled : ", this.AnyAccountSuitFilled);
          }
          this.isSpinnerLoading = false;
          },(error)=>{
            this.isSpinnerLoading=false;
            console.log("ERROR OCCURED IN FIRM DATA DISPLAY CRIF" + JSON.stringify(error));
          }
       );
      }

      openVerticallyCentered(content: TemplateRef<any>) {
        this.modalService.open(content, {
          scrollable: true,
          backdrop: 'static',
          keyboard: false,
          size: 'md',
          centered: true,
        });
      }
     
      postCommCrifFirmRemarks(){
        this.isSpinnerLoading=true;
        this.cibilCrifRemarksModel.userId=this.userModelData.userId;
     
     this.cibilCrifRemarksModel.referenceId=this.userModelData.referenceId;
    //  this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";
        this.cibilCrifRemarksService.CrifCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksModel).subscribe((response) => {
         
          this.isSpinnerLoading=false;
          console.log("THS IS RESPONSE For Commercial FIrm Remark" + response);
        }
        ,(error) => {
          this.isSpinnerLoading=false;
          console.log("ERROR OCCURED IN FIRM DATA DISPLAY CRIF" + JSON.stringify(error));
         
        });
      }
    
      onSubmitRemark(form: NgForm) {
        const crifFirmRemarkfield = form.controls['crifFirmRemarkfield'];
        console.log('Remarkfield errors:', crifFirmRemarkfield.errors);
        console.log('Form submitted:', form.submitted);
        
        if (form.invalid) {
          // Handle invalid form case
          console.log('Form is invalid');
         } else {
          // Handle valid form case
          console.log('Form is valid');
          this.postCommCrifFirmRemarks();
       }
      } 
      
      onSubmitOverDue(form: NgForm) {
        const crifGuarantoroverdueRemarkfield = form.controls['crifGuarantoroverdueRemarkfield'];
        console.log('Overdue errors:', crifGuarantoroverdueRemarkfield.errors);
        console.log('Form submitted:', form.submitted);
        
        if (form.invalid) {
          // Handle invalid form case
          console.log('Form is invalid');
        } else {
          // Handle valid form case
          console.log('Form is valid');
          this.postOverdueRemark();
  
        }
      }
      RemarksFirmCommercialCrifGet() {
        // this.cibilCrifRemarksModel.referenceId='MGBGST20241203545';//this.userModelData.referenceId;

        this.isSpinnerLoading = true;
        this.cibilCrifRemarksService.getAllCibilCrifRemarks(this.userModelData.referenceId).subscribe(
         // this.cibilCrifRemarksService.getAllCibilCrifRemarks("MGBGST@20240729735").subscribe(
            (response) => {
          //  alert(JSON.stringify(response))

            if(response!== null){
              this.cibilCrifRemarksModel = response;
              console.log("ALL REMARKS OF CIBIL & CRIF  : ", JSON.stringify(response));
            }
            this.isSpinnerLoading = false;
            },(error)  => {
              this.isSpinnerLoading=false;
              console.log("ERROR OCCURED IN FIRM DATA DISPLAY CRIF" + JSON.stringify(error));
            }
         );
        }

        postOverdueRemark(){
          this.isSpinnerLoading=true;
          this.cibilCrifRemarksModel.userId=this.userModelData.userId;
          // this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";
          this.cibilCrifRemarksModel.referenceId=this.userModelData.referenceId;

        
           this.cibilCrifRemarksService.CrifCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksModel).subscribe((response) => {
            
            this.isSpinnerLoading=false;
            console.log("THS IS RESPONSE " + response);
          }
          ,(error) => {
            this.isSpinnerLoading=false;
            console.log("ERROR OCCURED IN FIRM DATA DISPLAY CRIF" + JSON.stringify(error));
          
          })
        
        }

        postRejectRemark(){
          this.isSpinnerLoading=true;
          this.cibilCrifRemarksModel.referenceId=this.userModelData.referenceId;
          // this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";
        
            this.cibilCrifRemarksModel.userId=this.userModelData.userId;
          this.cibilCrifRemarksService.CrifCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksModel).subscribe((response) => {
            
            this.isSpinnerLoading=false;
            if(response!=null){
              console.log("THS IS RESPONSE " + response);
              this.setRejectSubmit()
            }
          }
          ,(error) => {
            this.isSpinnerLoading=false;
            console.log("ERROR OCCURED IN FIRM DATA DISPLAY CRIF" + JSON.stringify(error));
          })
        }

        RemarksFirmCommercialCrifSave(){
        
          
          this.cibilCrifRemarksModel.referenceId=this.userModelData.referenceId;
          // this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";
          
            this.isSpinnerLoading = true;
            this.cibilCrifRemarksService.CrifCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksModel).subscribe(
              (response) => {
                if(response!== null){
                  console.log("ALL REMARKS OF CIBIL & CRIF  : ", JSON.stringify(response));

                  // if(this.userModelData.cgtmse==='yes'){
                  //   if(this.userModelData.cgtmse==='covered'){

                  //   //As If CGTMSE Covered Then skip Guarantor CRIF
                  //   this.router.navigate(['/carLoanV2/financial']);
                  // }
                  // else{

                  // AS DUSCUSSED WE HAVE TO REMOVE CONDITION FOR this.userModelData.cgtmse==='yes' . DATE:18-09-2025.. If CIBIL Is Fetched then CRIF-INDIVIDUAL Is to be fetched
                    if(this.routeToPage==='financial'){
                      // alert("financial");
                      this.router.navigate(['/carLoanV2/financial']);
                    }else if(this.routeToPage==='corporateguarantor') {
                      // alert("corporateguarantor");
                      this.router.navigate(['/carLoanV2/guarantorcrif']);
                    }else if(this.routeToPage==='individualguarantor'){
                      // alert("individualguarantor");
                      this.router.navigate(['/carLoanV2/individualcrif']);
                    }
                    // this.router.navigate(['/carLoanV2/guarantorcrif']);
                  // }
                }
                this.isSpinnerLoading = false;
                },(error) => {
                  this.isSpinnerLoading=false;
                  console.log("ERROR OCCURED IN FIRM DATA DISPLAY CRIF" + JSON.stringify(error));
                }
             );
          
        }

        //Check Min Length Should Be 100
      

        characterCount: number = 0;
        overDueCount:number=0;
        rejectCount:number=0;
        suitFilkedCount:number=0;
        settledCount:number=0;
        writtenCount:number=0;
        minLength: number = 100;
        isRemarkCountOk:boolean=false;
        isOverDueCountOk:boolean=false;
        isRejectCountOk:boolean=false;
        isSuitFilkedCountOk:boolean=false;
        isSettledCountOk:boolean=false;
        isWrittenCountOk:boolean=false;
       
//First Page CRIF Remark
updateRemarkCount(){
  this.characterCount = this.cibilCrifRemarksModel.commercialCrifRemark.trim().split(/\s+/).filter(Boolean).length;
  if(this.characterCount>100){
    this.isRemarkCountOk=true;
  }
}

        
//CRIF OverDue Remark
updateOverDueRemarkCount(){
  this.overDueCount = this.cibilCrifRemarksModel.commercialCrifOverdueRemark.trim().split(/\s+/).filter(Boolean).length;
  if(this.overDueCount>100){
  this.isOverDueCountOk=true;
  }
}
//CRIF REJECT Remark
updateRejectRemarkCount(){
  this.rejectCount = this.cibilCrifRemarksModel.commercialCrifRejectRemark.trim().split(/\s+/).filter(Boolean).length;
  if(this.rejectCount>100){
  this.isRejectCountOk=true;
  }
}
//CRIF SUITFILED Remark
updateSuitfiledRemarkCount(){
  this.suitFilkedCount = this.cibilCrifRemarksModel.commercialCrifSuitFilledRemark.trim().split(/\s+/).filter(Boolean).length;
  if(this.suitFilkedCount>100){
    this.isSuitFilkedCountOk=true;
  }
}   
//CRIF SETTLED Remark
updateSettledRemarkCount(){
  this.settledCount = this.cibilCrifRemarksModel.commercialCrifAccountSettledRemark.trim().split(/\s+/).filter(Boolean).length;
  if(this.settledCount>100){
    this.isSettledCountOk=true;
  }
}

//CRIF SETTLED Remark
updateWrittenOffRemarkCount(){
  this.writtenCount = this.cibilCrifRemarksModel.commercialCibilWrittenOffRemark.trim().split(/\s+/).filter(Boolean).length;
  if(this.writtenCount>100){
    this.isWrittenCountOk=true;
  }
}
       

// ============================================ Get Guarantors Count For Routing =============================================
getguarantorsCount(){
  this.cibilCrifStatusService.getAllCibilCrifStatus(this.userModelData.referenceId).subscribe((response) => {
    this.cibilCrifStatusModel=response;
    if((this.cibilCrifStatusModel.corpGurantorsCount===null || this.cibilCrifStatusModel.corpGurantorsCount===0) && (this.cibilCrifStatusModel.indvGurantorsCount===null || this.cibilCrifStatusModel.indvGurantorsCount===0)){
        //Go To financial Page
        this.routeToPage='financial'
    }else if((this.cibilCrifStatusModel.corpGurantorsCount>0) && ((this.cibilCrifStatusModel.indvGurantorsCount===null || this.cibilCrifStatusModel.indvGurantorsCount===0))){
        //Go To commercial Guarantors Crif fetch-list Page
        this.routeToPage='corporateguarantor'
    }else if ((this.cibilCrifStatusModel.corpGurantorsCount===null || this.cibilCrifStatusModel.corpGurantorsCount===0) && (this.cibilCrifStatusModel.indvGurantorsCount>0)){
        //Go To Individual Guarantors CRIF fetch-list Page
        this.routeToPage='individualguarantor'
    }
  });
}

userModelDataForApplicationList = {} as UserModelDataForApplicationList;

//REJECT The Application
  setRejectSubmit(){

    this.userModelDataForApplicationList.branchCode=this.userModelData.brcode;
    this.userModelDataForApplicationList.custType=this.userModelData.custType;
    this.userModelDataForApplicationList.referenceId=this.userModelData.referenceId;
    this.userModelDataForApplicationList.regionName=this.userModelData.roname;
    this.userModelDataForApplicationList.userId=this.userModelData.userId;
    this.userModelDataForApplicationList.userLoc=this.userModelData.u_loc;
    this.userModelDataForApplicationList.userScale=this.userModelData.scale;
    this.userModelDataForApplicationList.userType=this.userModelData.u_type;
    this.modalService.dismissAll();
   
    this.appraisalNoteService
     .setReject(this.userModelDataForApplicationList)
     .subscribe(
        (response) => {
          this.isSpinnerLoading=false;
          console.log("In Reject On GST PAGE");
          if (response!=null) {
     
            console.log("Reject Application SuccessFully... ");
           
            this.router.navigate(['carLoanV2/'])
         //   alert(JSON.stringify(response))
          }
          else{
            this.toastr.info("Reject status could not be updated")           
          }
          
        },
         (error) => {
          this.isSpinnerLoading=false;
          console.log("ERROR OCCURED In Reject On CIBIL " + JSON.stringify(error));
         }
      );
  }

}

