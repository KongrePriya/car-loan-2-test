import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrifFirmDisplayStepperComponent } from './crif-firm-display-stepper.component';

describe('CrifFirmDisplayStepperComponent', () => {
  let component: CrifFirmDisplayStepperComponent;
  let fixture: ComponentFixture<CrifFirmDisplayStepperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CrifFirmDisplayStepperComponent]
    });
    fixture = TestBed.createComponent(CrifFirmDisplayStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
