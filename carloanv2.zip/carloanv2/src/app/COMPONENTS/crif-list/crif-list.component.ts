import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { IndividualBasicDetailsModel } from 'src/app/MODELS/Individual-basic-details.model';
import { CibilFetchStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-fetch-status.model';
import { CibilFetchStatusService } from 'src/app/SERVICES/CIBIL-individual-all/cibil-details.service';
// import { CibilFetchStatusService } from 'src/app/SERVICES/cibil-details/cibil-details.service';
import { FetchIndividualCrifService } from 'src/app/SERVICES/CRIF-individual-all/fetch-individual-crif.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-crif-list',
  templateUrl: './crif-list.component.html',
  styleUrls: ['./crif-list.component.css']
})
export class CrifListComponent {

  ngOnInit(): void {
    const abc = sessionStorage.getItem("userModelData");
    this.userModelData = JSON.parse(abc!);
    //this.userModelData.referenceId = "MGBHOME@20250206fe1"; //REMOVE THIS LATER
    this.getCibilFetchStatusAll();
    // this.getAllIndGuarantors();
  }


  IndividualBasicDetailsModel = {} as IndividualBasicDetailsModel; //to assign fetched data fields also have additional fields
  allGuarantorsModel: any[] = [];
  isSpinnerLoading: boolean = false;
  userModelData = {} as UserModelData;
  // disableProceedWithoutFlag:string="";
  disableFetchButton: string = 'yes';
  // isChecked: boolean = false;
  showCheckBox?: string;
  disableNext?: string;

  // countYes:number=0;
  cibilFetchStatusModel = {} as CibilFetchStatusModel;

  constructor(
    private modalService: NgbModal,
    private fetchIndividualCrifService: FetchIndividualCrifService,
    private router: Router,
    private toastr : ToastrService,
    private cibilFetchStatusService: CibilFetchStatusService
  ) { }

  //****************************** GET LIST OF EXISTING INDIVIDUAL GUARANTORS ******************************/

  getAllIndGuarantors() {
    this.IndividualBasicDetailsModel.referenceId = this.userModelData.referenceId;

    this.isSpinnerLoading = true;
    this.fetchIndividualCrifService.getCrifList(this.IndividualBasicDetailsModel.referenceId).subscribe(
      (response) => {
        this.isSpinnerLoading = false;
        if (response !== null) {
        
          this.allGuarantorsModel = response;

            const sortOrder = ['APPLICANT', 'COAPPLICANT1', 'COAPPLICANT2','COAPPLICANT3','COAPPLICANT','GUARANTOR'];
    
            this.allGuarantorsModel.sort((a, b) => {
              const indexA = sortOrder.indexOf(a.customerType);
              const indexB = sortOrder.indexOf(b.customerType);
              return indexA - indexB;
            });

          this.checkAllCrifFetched(this.allGuarantorsModel);
        } else {
          this.disableNext = 'yes';
        }

      }, (error) => {
        this.isSpinnerLoading = false;
        console.log("ERRROR OCCURED " + JSON.stringify(error));
      }
    );
  }



  PostDataToGetCrifResponse(i: number) {
    this.isSpinnerLoading = true;
    console.log(this.allGuarantorsModel[i]);

    this.fetchIndividualCrifService.responseFromCrif(this.allGuarantorsModel[i]).subscribe((response) => {
      if (response != null) {
        console.log("THis  CRIF RESPONSE " + response);
        this.isSpinnerLoading = false;
        // this.countYes=0;

        this.toastr.success("CRIF FETCHED SUCCESSFULLY");
        this.updateCrifFetchFlag(this.allGuarantorsModel[i].panNumber, this.allGuarantorsModel[i].referenceId, "yes");

      }
    }, (error) => {
      console.log("ERROR OCCURED " + JSON.stringify(error));
      this.isSpinnerLoading = false;
    }
    )

  }


  onCheckboxChange(event: any, panNumber: any): void {
    if(window.confirm('Are you sure you want to Refetch CRIF Data?')){

      if (event.target.checked) {
        // this.isChecked = event.target.checked;
        this.updateCrifFetchFlag(panNumber, this.userModelData.referenceId, "no");
        // this.getAllIndGuarantors();
      }
    }else{
      event.target.checked = false;
      this.toastr.info("User Clicked Cancel");
    }
  }

  updateCrifFetchFlag(referenceId: string, panNumber: string, crifFlagStatus: string) {
    this.isSpinnerLoading = true;
    this.fetchIndividualCrifService.updateCrifFlag(panNumber, referenceId, crifFlagStatus).subscribe((response) => {
      this.isSpinnerLoading = false;
      if (response != null) {
        console.log("CRIF Fetch Flag Updated SUbmitted Successfully");
        this.getAllIndGuarantors();
      }
    }, (error) => {
      this.isSpinnerLoading = false;
      console.log("Error Occurred While Updating CRIF Fetch Flag in Applicant CoApp Basic Details Table " + JSON.stringify(error));
    })
  }


  checkAllCrifFetched(allGuarantorsModel: any) {
    const allCrifFetchFlagsAreYes = allGuarantorsModel.every((item: { crifFetched: string; }) => item.crifFetched === 'yes')
    if (allCrifFetchFlagsAreYes) {
      this.showCheckBox = 'yes';
      this.disableNext = 'no';
    } else {
      this.disableNext = 'yes';

    }
  }


  //========================= METHOD TO GET CIBIL/CRIF FETCH STATUS ===================================//
  getCibilFetchStatusAll() {
    this.isSpinnerLoading = true;
    this.cibilFetchStatusService.getCibilFetchStatusDetails(this.userModelData.referenceId).subscribe(
      (result) => {
        this.cibilFetchStatusModel = result;
        console.log("CIBIL/CRIF FETCHED STATUS in CRIF LIST: " + JSON.stringify(this.cibilFetchStatusModel));
        if((this.cibilFetchStatusModel.allCrifFetched==false) && (this.cibilFetchStatusModel.applicantCrifFetched==false) && 
          (this.cibilFetchStatusModel.coappIncomeCrifCount>0 && this.cibilFetchStatusModel.coappIncomeCrifFetched==false) &&
          (this.cibilFetchStatusModel.coappNonIncomeCrifCount>0 && this.cibilFetchStatusModel.coappNonIncomeCrifFetched==false) && 
          (this.cibilFetchStatusModel.guarantorCrifCount>0 &&this.cibilFetchStatusModel.guarantorCrifFetched==false)){
           this.resetAllCrifFlag();
        }
        else{
          this.getAllIndGuarantors();
        }
        const abc = (this.cibilFetchStatusModel.coappNonIncomeCrifFetched==false)
        console.log(abc);
        
      }, (error: HttpErrorResponse) => {
        this.isSpinnerLoading = false;
        console.error("ERROR WHILE GETTING CIBIL/CRIF-FETCH STATUS in CRIF LIST: " + JSON.stringify(error));
      });
    this.isSpinnerLoading = false;
  }



  // ----------------------------- To Reset All CRIF FLAGS AFTER 10th Of Every Month ------------------------------
  resetAllCrifFlag(){
    alert("RESET CALLED");
    
    this.isSpinnerLoading = true;
    this.fetchIndividualCrifService.resetAllCrifFlagsMonthly(this.userModelData.referenceId).subscribe((response) => {
      this.isSpinnerLoading = false;
      if (response != null) {
        console.log("CRIF Flag RESET Submitted Successfully in App CoApp Basic Details Form- (After 10th of Every Month)");
        this.cibilFetchStatusModel.allCrifFetched==true;
        this.getAllIndGuarantors();
      }
    }, (error) => {
      this.isSpinnerLoading = false;
      console.log("Error Occurred While Resetting CRIF Fetch Flag in Applicant CoApp Basic Details Table " + JSON.stringify(error));
    })
  }

  //==================================================================================================== //
  onCheckboxChangeNew(event: any, panNumber: any): void {
      
        Swal.fire({
          title: 'Are you sure you want to Refetch CRIF Data ?',
          text: 'The previously fetched details will be removed.',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Yes',
          cancelButtonText: 'No',
          reverseButtons: true
        }).then((result) => {
          if (result.isConfirmed) {

            this.updateCrifFetchFlag(panNumber, this.userModelData.referenceId, "no");

            console.log('CRIF REFETCH CONFIRMED.');
          } else {
            event.target.checked = false;
            setTimeout(() => {
              this.toastr.info("User Clicked Cancel");
              console.log('CRIF REFETCH CANCELLED.');
            }, 0);
          }
        });
    }

}
