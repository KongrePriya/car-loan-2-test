import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrifListComponent } from './crif-list.component';

describe('CrifListComponent', () => {
  let component: CrifListComponent;
  let fixture: ComponentFixture<CrifListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CrifListComponent]
    });
    fixture = TestBed.createComponent(CrifListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
