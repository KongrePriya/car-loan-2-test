import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { RawDataForDeviationModel } from 'src/app/MODELS/deviation-data-model';
import { DeviationRawDataRedirectService } from 'src/app/SERVICES/itr-list-deviation-raw-data/deviation-raw-data.service';

@Component({
  selector: 'app-itr-details-list',
  templateUrl: './itr-details-list.component.html',
  styleUrls: ['./itr-details-list.component.css']
})
export class ItrDetailsListComponent  implements OnInit{
 

  isSpinnerLoading:Boolean= false;
  
  userModelData = {} as UserModelData;
  rawDataForDeviationModel = {} as RawDataForDeviationModel;
  isConsentGiven: boolean = false;

  
  constructor(
    private router: Router,
    private toastr:ToastrService,
    private deviationRawDataRedirectService:DeviationRawDataRedirectService

    ) {}
  
  ngOnInit(): void {
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  console.warn("USER DATA MODEL:", this.userModelData);
  // this.userModelData.referenceId='MGBHOME1234'
  this.getDeviationRawData();
  }
  
  itr_list = [
    'Sr. No.',
    'Individual Type',
    'Name',
    'Income Source',
    'Income Considered',
    'ITR Available',
  ];

    
  // **************************** METHOD TO GET ITR DETAILS FROM ITR PROJECT ****************************************//
  
  getDeviationRawData(){
    this.isSpinnerLoading=true;
      console.log("Inside  getDeviationRawData function, ref id: ", this.userModelData.referenceId);
      this.deviationRawDataRedirectService.getDeviationRawData(this.userModelData.referenceId).subscribe(
        (response) => { 
          this.rawDataForDeviationModel=response;
          console.log("Response from getDeviationRawData, rawDataForDeviationModel : ", JSON.stringify(this.rawDataForDeviationModel));
          this.isSpinnerLoading=false;
      },
     (error : HttpErrorResponse) => {
        this.isSpinnerLoading=false;
        console.error("ERROR WHILE GETTING RAW-DATA DETAILS FOR DEVIATION : "+error)
      }
    ); 
    }



    redirectToVerification(customerType:string){
      this.deviationRawDataRedirectService.redirectToItrUsingRawData(this.userModelData.referenceId,customerType);
    }

    redirectToItrDisplay(customerType:string){
      this.deviationRawDataRedirectService.redirectToItrView(this.userModelData.referenceId,customerType);
    }

      
  // **************************************** REDIRECT TO NEXT PAGE  ************************************* 
  
  goBack(){
     console.log("CUSTOMER TYPE : "+this.userModelData.custType);
    if(this.userModelData.custType === "individual"){
      this.router.navigate(['/carLoanV2/cibil-individual-all']);
    }else if(this.userModelData.custType === "corporate"){
    this.router.navigate(['/carLoanV2/cibil-commmercial-all']);
    }
  }
// **************************************** REDIRECT TO PREVIOUS PAGE  ************************************* 
  
  goNext(){
     if(this.rawDataForDeviationModel.allItrFetched){
     this.router.navigate(['/carLoanV2/income-main-list']);
    }else{
      this.toastr.warning("ITR Not Verified For All The Eligible Members.");
    }
  }
// ***************************************************************************************************//    

}
