import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItrDetailsListComponent } from './itr-details-list.component';

describe('ItrDetailsListComponent', () => {
  let component: ItrDetailsListComponent;
  let fixture: ComponentFixture<ItrDetailsListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ItrDetailsListComponent]
    });
    fixture = TestBed.createComponent(ItrDetailsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
