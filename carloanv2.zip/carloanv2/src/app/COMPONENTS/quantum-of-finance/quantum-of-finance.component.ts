import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { QuantamOfFinanceModel } from 'src/app/MODELS/quantam-of-finance.model';
import { QuantumOfFinanceService } from 'src/app/SERVICES/quantum-of-finance/quantum-of-finance.service';

@Component({
  selector: 'app-quantum-of-finance',
  templateUrl: './quantum-of-finance.component.html',
  styleUrls: ['./quantum-of-finance.component.css']
})
export class QuantumOfFinanceComponent implements OnInit{
userModelData = {} as UserModelData;
quantamOfFinanceModel = {} as QuantamOfFinanceModel;
isSpinnerLoading = false;
disableNext:string='no';

constructor(
  private toastr : ToastrService, 
  private quantumOfService: QuantumOfFinanceService, 
  private router : Router) {}

ngOnInit() {
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  console.log('userModelData on QUANTAM OF FINANCE' + this.userModelData.referenceId);
  this.isSpinnerLoading = true;
  this.getFetchDataForQOF(this.userModelData.referenceId);
}
//------------------------------------------- GET CALCULATION DATA -------------------------------------------//
getFetchDataForQOF(referenceId:string) {
  this.isSpinnerLoading = true;
  this.quantumOfService.getCalculationSummary(referenceId).subscribe(
    (response: QuantamOfFinanceModel) => {
      this.isSpinnerLoading = false;
      this.quantamOfFinanceModel = response;
      console.log("CALCULATION DATA SUMMARY : "+this.quantamOfFinanceModel);
    },(error) => {
      this.disableNext='yes';
      this.isSpinnerLoading=false;
      this.toastr.info("Cant Get Calculation Data....")
      console.error("Error Occured While getting calculation data : " + JSON.stringify(error));
    }
  );
}

//-------------------------------------------- REDIRECT METHODS ---------------------------------------------//

goBack(){
  this.router.navigate(['/carLoanV2/quotation-details']);
}
goNext(){
  this.router.navigate(['/carLoanV2/deviation-display']);
}
//--------------------------------------------------------------------------------------------------------------//

}
