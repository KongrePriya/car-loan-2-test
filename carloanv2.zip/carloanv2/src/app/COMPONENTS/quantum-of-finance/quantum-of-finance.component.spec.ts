import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuantumOfFinanceComponent } from './quantum-of-finance.component';

describe('QuantumOfFinanceComponent', () => {
  let component: QuantumOfFinanceComponent;
  let fixture: ComponentFixture<QuantumOfFinanceComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [QuantumOfFinanceComponent]
    });
    fixture = TestBed.createComponent(QuantumOfFinanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
