import { Component, EventEmitter, Output, OnInit } from '@angular/core';

import { AuthService } from '../../AUTH/auth.service';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
// import { MisReportDownloadService } from 'src/app/SERVICES/download-report/mis-report-download.service';
// import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-sidenav-list',
  templateUrl: './sidenav-list.component.html',
  styleUrls: ['./sidenav-list.component.css'],
})
export class SidenavListComponent implements OnInit {
  @Output() closeSidenav = new EventEmitter<void>();

  currentyr!:number;
  isSpinnerLoading:boolean = false;

  constructor(private authServise: AuthService,
    // private misReportDownloadService:MisReportDownloadService,
    // private toastr:ToastrService

  ) {}

  userModelData!: UserModelData;
  ngOnInit() {
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    console.log("USER DATA MODEL :"+JSON.stringify(this.userModelData));
    
    const currentdate = new Date();
    this.currentyr = currentdate.getFullYear();
  }

  onClose() {
    this.closeSidenav.emit();
  }
  logout() {
    this.authServise.logout();
    sessionStorage.clear();
  }

  //*******************************METHOD TO DOWNLOAD MIS REPORT************************************ */
  // downloadMisReport() {
  //   this.isSpinnerLoading = true;
  //   console.log("INSIDE downloadMisReport, userModelData :" + JSON.stringify(this.userModelData));
  
  //   this.misReportDownloadService.exportToExcel(this.userModelData.brcode, this.userModelData.u_loc, this.userModelData.roname)
  //     .subscribe(response => {
  //       const contentDisposition = response.headers.get('Content-Disposition');
  //       let filename: string = 'KPLS.xlsx';  // Default filename
  
  //       console.warn(contentDisposition);
        
  //       if (contentDisposition) {
  //         const matches = /filename="([^"]*)"/.exec(contentDisposition);
  //         console.warn(matches);
          
  //         if (matches && matches[1]) {
  //           filename = matches[1]; 
  //         }
  //       }
  //       // Proceed to download the file 
  //       if (response.body) {
  //         const fileURL = URL.createObjectURL(response.body);
  
  //         const a = document.createElement('a');
  //         a.href = fileURL;
  //         a.download = filename; 
  //         a.click();
  //         URL.revokeObjectURL(fileURL);
  //       } else {
  //         console.error('Failed to download the file. The response body is null.');
  //       }
  
  //       this.isSpinnerLoading = false;
  //       this.toastr.success("KPLS Data Report Downloading Started Successfully..!!!");
  //     },
  //     (error) => {
  //       console.error('Error downloading MIS file', error);
  //       console.error('Error downloading MIS file, ERROR DETAILS: ', error.getMessage());

  //       this.isSpinnerLoading = false;
  //     });
  // }
}
