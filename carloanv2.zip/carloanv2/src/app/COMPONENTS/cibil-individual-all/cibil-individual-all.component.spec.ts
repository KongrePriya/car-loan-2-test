import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CibilIndividualAllComponent } from './cibil-individual-all.component';

describe('CibilIndividualAllComponent', () => {
  let component: CibilIndividualAllComponent;
  let fixture: ComponentFixture<CibilIndividualAllComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CibilIndividualAllComponent]
    });
    fixture = TestBed.createComponent(CibilIndividualAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
