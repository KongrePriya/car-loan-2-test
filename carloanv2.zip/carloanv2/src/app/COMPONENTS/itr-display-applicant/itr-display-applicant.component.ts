import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { ItrFilingDetailsModel } from 'src/app/MODELS/itrFilingDetailsModel.model';
import { ItrDetailsDisplayService } from 'src/app/SERVICES/itr-details-display/itr-details-display.service';

@Component({
  selector: 'app-itr-display-applicant',
  templateUrl: './itr-display-applicant.component.html',
  styleUrls: ['./itr-display-applicant.component.css']
})
export class ItrDisplayApplicantComponent implements OnInit{
 

  isSpinnerLoading:Boolean= false;
  
  itrFilingDetailsModel ={} as ItrFilingDetailsModel;
  userModelData = {} as UserModelData;
  
  constructor(
    private router: Router,
    private toastr:ToastrService,
    private itrDetailsDisplayService : ItrDetailsDisplayService,
    // private itrDetailsSaveToAppraisalService: ItrDetailsSaveToAppraisalService
    ) {}
  
  ngOnInit(): void {
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  console.warn("USER DATA MODEL:", this.userModelData);
  // this.userModelData.referenceId='MGBHOME12345'
  this.getITRDetails();
  }
  
  // **************************** METHOD TO GET ITR DETAILS FROM ITR PROJECT ****************************************//
  
  getITRDetails(){
  this.isSpinnerLoading=true;
    console.log("Inside  getITRDetails function, ref id: ", this.userModelData.referenceId);
    this.itrDetailsDisplayService.getITRFilingDetails(this.userModelData.referenceId,'APPLICANT').subscribe(
      (response) => { 
        this.itrFilingDetailsModel=response;
        console.log("Response from getITRDetails: ", JSON.stringify(this.itrFilingDetailsModel));
        this.isSpinnerLoading=false;
    },
   (error : HttpErrorResponse) => {
      this.isSpinnerLoading=false;
      console.error("ERROR WHILE GETTING  ITR DETAILS OF APPLICANT : "+error)
    }
  );
  
  }
  // ***************************************************************************************************//    
  // **************************************** REDIRECT TO NEXT PAGE  ************************************* 
  
  goBack(){
    this.router.navigate(['/carLoanV2/applicant-itr-verify'])
  }
  // **************************************** REDIRECT TO PREVIOUS PAGE  ************************************* 
  
  goNext(){
  this.SaveItrDetailsToAppraisal();
  this.router.navigate(['/carLoanV2/itr-list'])

  // this.router.navigate(['/carLoanV2/coapp-one-itr-verify'])
  }
  
  //******************************** SAVE ITR DETAILS TO APPRAISAL *************************************************** */
  SaveItrDetailsToAppraisal(){
  // HOME  this.isSpinnerLoading=true;
  //   console.log("Inside  SaveItrDetailsToAppraisal function, ref id: ", this.userModelData.referenceId);
  //   this.itrDetailsSaveToAppraisalService.retrierAndSaveITRDetails(this.userModelData.referenceId,'APPLICANT').subscribe(
  //     (response) => { 
  //       console.log("Response from SaveItrDetailsToAppraisal: ", response);
  //       this.isSpinnerLoading=false;
  //   },
  //   (error : HttpErrorResponse) => {
  //     this.isSpinnerLoading=false;
  //     console.error("ERROR in SaveItrDetailsToAppraisal OF APPLICANT : "+error)
  //   }
  // );
  }
  //*********************************************************************************** */
  
  
  }
  