import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItrDisplayApplicantComponent } from './itr-display-applicant.component';

describe('ItrDisplayApplicantComponent', () => {
  let component: ItrDisplayApplicantComponent;
  let fixture: ComponentFixture<ItrDisplayApplicantComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ItrDisplayApplicantComponent]
    });
    fixture = TestBed.createComponent(ItrDisplayApplicantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
