import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BorrowerIndividualComponent } from './borrower-individual.component';

describe('BorrowerIndividualComponent', () => {
  let component: BorrowerIndividualComponent;
  let fixture: ComponentFixture<BorrowerIndividualComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BorrowerIndividualComponent]
    });
    fixture = TestBed.createComponent(BorrowerIndividualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
