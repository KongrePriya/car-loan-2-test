import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { IndividualBasicDetailsModel } from 'src/app/MODELS/Individual-basic-details.model';
import { CibilFetchStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-fetch-status.model';
import { AadharResponseModel, AllKycInfoModel, AuthorizeOtpAadharReponse, AuthorizeOtpAadharRequest, GenerateOtpRequestModel, OTPresponseModel, PANverifyRequestModel, PANverifyResponseModel } from 'src/app/MODELS/panAadharModel.model';
import { IndividualBasicDetailsService } from 'src/app/SERVICES/Basic-details-individual/individual-basic-details.service';
import { CibilFetchStatusService } from 'src/app/SERVICES/CIBIL-individual-all/cibil-details.service';
import { FetchIndividualCrifService } from 'src/app/SERVICES/CRIF-individual-all/fetch-individual-crif.service';
import { AADHARverifyService, PanVerificationService } from 'src/app/SERVICES/Kyc-Verification/kyc-verification.service';
import { StatesServiceService } from 'src/app/SERVICES/States-Service/states-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-borrower-individual',
  templateUrl: './borrower-individual.component.html',
  styleUrls: ['./borrower-individual.component.css']
})
export class BorrowerIndividualComponent  implements OnInit{

 
@ViewChild('borrowerIndividualForm') borrowerIndividualForm!: NgForm;

isSpinnerLoading:Boolean= false;
isPANVerified = false;
aadhar!:string;
isOTPGenerated = false;
otp = '';
isFinalSubmitEnabled = false;
pan!: string;
otpResent: boolean = false;
otpResentMsg:boolean=false;
userModelData = {} as UserModelData;
// userModelData !: any;
states: string[]=[];
resendTimeout: number = 60; // Resend timeout in seconds
resendButtonText: string = 'Resend OTP';
resendDisabled: boolean = false;
otpExpired:boolean=false;
individualBasicDetailsModel={} as IndividualBasicDetailsModel;
inputFormAvailable:boolean=false;  //before saving APPLICANT data, only verified data present
applicantDataPresent:boolean=false; //when data is saved
applicationStatusSetModel :any;
aadharResponseModel= {} as AadharResponseModel;
panVerifyRequest={} as PANverifyRequestModel;
panVerifyResponseModel={} as PANverifyResponseModel;
otpResponseModel={} as OTPresponseModel;
generateOtpRequestModel={} as GenerateOtpRequestModel;
authorizeOtpAadharRequest={} as AuthorizeOtpAadharRequest;
UserAadharData={} as AadharResponseModel;
cibilFetchStatusModel={} as CibilFetchStatusModel;
otpGenerationError:boolean=false;
existingValueForITR : string = "No";
incomeConsiderationValue!: string ;
consentToRefetch: boolean = false;

constructor(
  private panVerifyService: PanVerificationService,
  private aadharVerifyService: AADHARverifyService,
  private router: Router,
  private individualBasicDetailsService: IndividualBasicDetailsService,
  private toastr:ToastrService,
  private stateListService: StatesServiceService,
  private fetchIndividualCrifService: FetchIndividualCrifService,
  private cibilFetchStatusService:CibilFetchStatusService
  ) {}

// ************************************ COMPONENT INITIALIZED ********************************* 

  ngOnInit(): void {
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    console.warn("USER DATA MODEL:", this.userModelData);
    this.panVerifyRequest.loanRefNo= this.userModelData.referenceId;
    console.warn("REF NO:", this.panVerifyRequest.loanRefNo);

    // this.userModelData.referenceId='MGBHOME1234';

    this.getStateList();
    this.getApplicantData();
    // this.getCibilFetchedStatus();
  }

//*******************************************************************************************/

getStateList(){
  this.stateListService.getStates().subscribe((data: string[]) => { 
    this.states = data;
  });
}

// ************************************ METHOD FOR FINAL SUBMIT BUTTON ********************************* 

  updateFinalSubmitEnabled() {
    // Logic to check if final submit should be enabled
    // this.isFinalSubmitEnabled = !!this.otp;
    this.isFinalSubmitEnabled = !!(this.otp && /^\d{6}$/.test(this.otp));

  }

// ********************************************************************************************************* 

// ************************************ METHOD FOR RESET FORM AND FLAGS ********************************* 

resetFormState() {
  this.pan = '';
  this.aadhar = '';
  this.isPANVerified = false;
  this.isOTPGenerated = false;
  this.otp = '';
  this.otpResent = false;
  this.isFinalSubmitEnabled = false;
  this.otpResentMsg=false;
  this.otpGenerationError=false;
}

// ************************************ METHOD FOR PAN VERIFICATION METHOD SERVICE INTEGRATION ********************************* 

postPANtoVerify() {
  
  const panVerifyRequest={
    loanRefNo: this.userModelData.referenceId,
    pan: this.pan
   }
   this.isSpinnerLoading=true;
  this.panVerifyService.verifyPAN(panVerifyRequest).subscribe(
    (response) => {
      if (response && response.responseCode) {
        this.panVerifyResponseModel = response;
      console.log('PAN RESPONSE from API :', this.panVerifyResponseModel);
        if(response.responseCode === 'SRC001'){
          this.isPANVerified = true;
          this.aadharResponseModel
          this.isSpinnerLoading=false;       
      }else{
        this.isSpinnerLoading=false;
        this.toastr.warning("No Data Found From PAN. Kindly Check PAN")
      } 
    } else {
      this.isSpinnerLoading=false;
        this.toastr.warning("Invalid response received from the server.","Please Try Again...");
      }
    },
    (error: any) => {
      console.error('ERROR IN PAN VERIFICATION ON INDIVIDUAL GUARANTOR :', error)
      this.isSpinnerLoading=false;
    }
  );
  // this.isSpinnerLoading=false;
}

// ************************************ METHOD FOR OTP GENERATE SERVICE INTEGRATION ********************************* 

generateOTP() {
  this.isSpinnerLoading=true;

  const authorizeOtpAadharRequest = {
    aadhaar_number: this.aadhar,
    loanRefNo: this.userModelData.referenceId
  };
  this.aadharVerifyService.generateAadharOTP(authorizeOtpAadharRequest).subscribe(
    (response: OTPresponseModel) => {
      this.otpResponseModel = response;
      console.log('OTP GENERATION RESPONSE:', this.otpResponseModel);

      if(response.responseCode === 'SOS174'){
      this.isPANVerified = true;
      this.isOTPGenerated = true;
      this.isSpinnerLoading=false;
      this.startResendTimer(); // Start resend timer after OTP generation
    }
    else{
      let message: string = response.responseMessage;
      this.toastr.warning(message);
      this.toastr.error('Please try again after a few moments.','OTP generation failed...!!!')
      this.isSpinnerLoading= false;

    }
  },
    (error: any) => {
      console.error('Error generating OTP:', error);
      this.toastr.error('Error generating OTP');
      this.isSpinnerLoading=false;
      this.otpGenerationError=true;
    }
  );
}
//to allow OTP input box manually
onOTPReceivedChange() {
  if (this.isOTPGenerated) {
    console.log('OTP checkbox checked');
  } else {
    console.log('OTP checkbox unchecked');
  }
}
//+++++=DUMMY OTP++++++++++//
generateOTPdummy() {
  this.isPANVerified = true;
  this.isOTPGenerated = true;
}
// ************************************ METHOD FOR RESEND OTP ********************************* 

resendOTP(){
  this.isSpinnerLoading=true;
  this.otpResentMsg=true;

  this.otp ='';
  this.generateOTP();
}

// ************************************ METHOD FOR RESENT OTP TIMER  ********************************* 

startResendTimer() {
  this.resendTimeout = 60; // Reset timer to 60 seconds
  this.resendDisabled = true;
  let timer = setInterval(() => {
    this.resendTimeout--;
    this.resendButtonText = `Resend OTP in ${this.resendTimeout} seconds`;
    this.otpResent=true;
    if (this.resendTimeout === 0) {
      clearInterval(timer);
      this.resendDisabled = false;
      this.resendButtonText = 'Resend OTP';
    }
  }, 1000);
}

// ************************************ METHOD FOR RESET FORM  ********************************* 

resetForm(){
  this.isSpinnerLoading=true;
this.isPANVerified = false;
this.resetFormState();
this.isSpinnerLoading=false;
}

// *********************** METHOD FOR AADHAR VERIFICATION AND DATA EMIT SERVICE INTEGRATION  ********************************* 

submitAadharData() {
   this.isSpinnerLoading= true;
  //request data
  const authorizeOtpAadharRequest ={
      otp:this.otp,
      aadhaar_number:this.aadhar,
      loanRefNo:this.userModelData.referenceId,
    };
    console.log(" REQUEST DATA TO VERIFY OTP : ", authorizeOtpAadharRequest);

    this.aadharVerifyService.authorizeAadharOTP(authorizeOtpAadharRequest).subscribe((result:AuthorizeOtpAadharReponse) => {
      console.log("DATA: ", result);
     
    if(result.responseCode ==='SRC001'){
      const allData :AllKycInfoModel = {
        pan: this.pan,
        aadhar: this.aadhar,
        kycData:result
      };
      console.log("Data prepared to emit to individual-gurantor component :",allData);
      this.setFetchedValues(allData);

      // kycFetchedData.emit(allData);  
      // console.log("Data emitted to individual-gurantor component: ", JSON.stringify(allData));
      
      }else{
        //ERROR CODES

        this.isFinalSubmitEnabled=false;

        if(result.responseCode ==='EOE794'){
          this.toastr.error('OTP Expired. Kindly regenerate OTP.');
          this.otpExpired = true; // TO SHOW RESEND BUTTON
        }else
        if(result.responseCode ==='ETP011'){
          this.toastr.error('Incorrect OTP, Kindly Check');
          this.otpExpired = true; // TO SHOW RESEND BUTTON

        }else
        if(result.responseCode ==='ENI004'){
          this.toastr.error('No Information found for provided Aadhar Number...!!!');
          this.otpExpired = true; // TO SHOW RESEND BUTTON

        }else{
          this.toastr.warning('Aadhar Verification Failed, Please Try again...!!!');
          this.otpExpired = true; // TO SHOW RESEND BUTTON

        }
      this.otp='';
      this.isSpinnerLoading= false;
      return;
     }      
        this.resetFormState();
    },
      (error: any) => {
          // alert('Aadhar Verification Failed, Please Try again');
          this.toastr.error('Aadhar Verification Failed, Please Try again...!!!');

          console.error('Error verifying PAN Aadhar:', error);
          this.isSpinnerLoading= false;
          this.isFinalSubmitEnabled=false;

          this.resetFormState();
        });
}

// ***************************************************************************************************//


setFetchedValues(kycFetchedData:AllKycInfoModel) {

  // this.individualBasicDetailsModel.fullName= kycFetchedData.kycData.data.name;
  // console.warn("APPLICANT NAME: " ,this.individualBasicDetailsModel.fullName);
   
  if (kycFetchedData && kycFetchedData.kycData )
    {
  this.individualBasicDetailsModel = {
      idDto: 0,
      referenceId: this.userModelData.referenceId,
      branchCode: this.userModelData.brcode,
      userId: this.userModelData.userId,

      fullName: kycFetchedData.kycData.data.name,
      gender: kycFetchedData.kycData.data.gender,
    
      pan: kycFetchedData.pan,
      aadhar: kycFetchedData.aadhar,
    
      mobileNumber: kycFetchedData.kycData.data.mobile,
      email: kycFetchedData.kycData.data.email,
      dateOfBirth: kycFetchedData.kycData.data.dateOfBirth,
     
      // Fetched fields from Aadhar
      careOf: kycFetchedData.kycData.data.careOf,
      house: kycFetchedData.kycData.data.house,
      street: kycFetchedData.kycData.data.street,
      district: kycFetchedData.kycData.data.district,
      subDistrict: kycFetchedData.kycData.data.subDistrict,
      landmark: kycFetchedData.kycData.data.landmark,
      locality: kycFetchedData.kycData.data.locality,
      postOfficeName: kycFetchedData.kycData.data.postOfficeName,
      state: kycFetchedData.kycData.data.state,
      pincode: kycFetchedData.kycData.data.pincode,
      country: kycFetchedData.kycData.data.country,
      vtcName: kycFetchedData.kycData.data.vtcName,
      mobile: kycFetchedData.kycData.data.mobile,
      aadharAddress: kycFetchedData.kycData.data.careOf +
        ' ' +
        kycFetchedData.kycData.data.house +
        ' ' +
        kycFetchedData.kycData.data.street +
        ' ' +
        kycFetchedData.kycData.data.locality +
        ' ' +
        kycFetchedData.kycData.data.landmark,
        
      
      title: '',
      fatherName: '', 
      alternateEmail: '',
      altMobile: '',
      netWorth:'',
      permanentAddress: '',
      residenceOwnership: '',
      voterIdCard: '',
      drivingLicence: '', 
      passportNum: '', 
      rationCardNumber: '', 
      qualification: '',
      tempAddressLine1: '',
      // tempAddressLine2: '',
      tempAddressLandmark: '',
      tempAddressSubDist: '',
      tempAddressDist: '',
      tempAddressState: '',
      tempAddressPincode: '',
      cif:'',
      presentAddress:'',
      customerType:'APPLICANT',
      timestamp:'',
      consideringIncome:'',
      incomeSourceType:'',
      itrFilledForAnyYear:'',
      form16Available:'',
      occupation:''
    }

    this.inputFormAvailable=true;
    this.isSpinnerLoading= false;
 
  }
  else {
    this.inputFormAvailable=false;
    this.isSpinnerLoading= false;
    this.toastr.error("KYC Verification Failed")
    console.error('Some properties are undefined in KYC fetched Data.');
  }
}
// ******************************** SAVE APPLICANT DATA AND FETCH CIBIL ********************************//


//******************************* CANCEL SAVING APPLICANT DATA ****************************************//
cancelSavingBorrower() {
  this.inputFormAvailable = false;
  this.applicantDataPresent=false;
  this.resetForm();
}

// ***************************************************************************************************//
onConsideringIncomeChange() {
  if (this.individualBasicDetailsModel.consideringIncome === 'No') {
    // Reset dependent fields if Income Considered is No
    this.individualBasicDetailsModel.itrFilledForAnyYear = 'No';
    this.individualBasicDetailsModel.form16Available='No';
  }
}
// ********************************** SERVICE INTEGRATION TO SAVE/UPDATE APPLICANT  ********************* 
saveOrUpdateBorrowerDetails() {
  this.isSpinnerLoading = true;

  if (!this.borrowerIndividualForm.valid) {
    console.log("Form is not valid!");
    this.toastr.info("Kindly Fill all the Required Fields to Save the details");
    this.isSpinnerLoading = false;
    return; // Exiting method if the form is not valid
  } else{

  this.individualBasicDetailsModel.branchCode=this.userModelData.brcode;
  this.individualBasicDetailsModel.customerType='APPLICANT';

  this.individualBasicDetailsService.saveOrUpdateDetails(this.individualBasicDetailsModel).subscribe(
    (response: any) => { 
      console.log("Response from individualBasicDetailsService: ", response);
      this.isSpinnerLoading=false;
      this.toastr.success("Applicant Details Saved or Updated Successfully...!!!")

      this.applicantDataPresent=true;

      this.goNext();
  },
 (error : HttpErrorResponse) => {
 if(error.status === 400)
    { 
      console.error("Data Against the PAN : "+this.individualBasicDetailsModel.pan+" is Alraedy Present for Reference-ID :"+this.individualBasicDetailsModel.referenceId+" , Hence Can Not Add Duplicate Details. Kindly Check and Input Correct Information.");
      this.toastr.error("Data Against the PAN : "+this.individualBasicDetailsModel.pan+" is Alraedy Present for Reference-ID :"+this.individualBasicDetailsModel.referenceId+" , Hence Can Not Add Duplicate Details. Kindly Check and Input Correct Information.");

    }
    this.getApplicantData();
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE SAVING/ UPDATING APPLICANT : "+error)
  }
);
}
}

// ********************SERVICE INTEGRATION TO UPDATE APPLICANT  AND RE-FETCH CIBIL : visiting after 10 ********************* 
updateDetailsRefetchCIBIL() {
  this.isSpinnerLoading = true;

  if (!this.borrowerIndividualForm.valid) {
    console.log("Form is not valid!");
    this.toastr.info("Kindly Fill all the Required Fields to Save the details");
    this.isSpinnerLoading = false;
    return; // Exiting method if the form is not valid
  } else{

  this.individualBasicDetailsModel.branchCode=this.userModelData.brcode;
  this.individualBasicDetailsModel.customerType='APPLICANT';

  //PRIYA this.individualBasicDetailsService.updateDetailsAndRefetchCIBIL(this.individualBasicDetailsModel).subscribe(
  //   (response: any) => { 
  //     console.log("Response from individualBasicDetailsService: ", response);
  //     this.isSpinnerLoading=false;
  //     this.toastr.success("APPLICANT Details Saved or Updated Successfully...!!!")

  //     this.applicantDataPresent=true;

  //     this.goNext();
  // },
  // (error : HttpErrorResponse) => {
  //   this.getApplicantData();
  //   this.isSpinnerLoading=false;
  //   console.error("ERROR WHILE SAVING/ UPDATING APPLICANT DATA: "+error)
  // PRIYA});
    this.goNext();
}
}
// ***************************************************************************************************//

getApplicantData(){
  this.isSpinnerLoading=true;

  console.log("Inside  getApplicantData function, ref id: ", this.userModelData.referenceId);
  this.individualBasicDetailsService.getBorrowerOrGuarantorDetails(this.userModelData.referenceId,'APPLICANT').subscribe(
    (response) => { 

      console.warn("DETAILS OF INDIVIDUAL APPLICANT: "+response);
      if(response != null){
      this.individualBasicDetailsModel=response;
      this.existingValueForITR= this.individualBasicDetailsModel.itrFilledForAnyYear;
      this.incomeConsiderationValue=this.individualBasicDetailsModel.consideringIncome;

      console.log("Response from getApplicantData: ", JSON.stringify(this.individualBasicDetailsModel));
    
      this.applicantDataPresent=true;
      }else{
        this.applicantDataPresent=false;
      }
      this.isSpinnerLoading=false;
    
  },
 (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GETTING APPLICANT DETAILS: "+error)
  }
);
}

// **************************************** DELETE APPLICANT DETAILS  ************************************* 

deleteBorrowerDetails() {
  console.log("Inside deleteBorrowerDetails function");
  // Confirm before proceeding with the deletion
  const userConfirmed = confirm("Are you sure you want to delete the APPLICANT details ?");
  
  if (userConfirmed) {
    this.isSpinnerLoading = true;

    this.individualBasicDetailsService.deleteBorrowerOrGuarantor(this.individualBasicDetailsModel.referenceId, 'APPLICANT',this.individualBasicDetailsModel.pan, this.userModelData.userId).subscribe(
      (response) => { 
        console.log("Response from deleteBorrowerDetails: ", response);
        
        if (response != null) {
          this.applicantDataPresent = false;
          this.inputFormAvailable = false;
          this.resetFormState();
          this.getApplicantData();

          // ----------------------------------------------- CRIF DATA DELETION -----------------------------------------
          this.updateCrifDetailAndHistoryTables(this.individualBasicDetailsModel.referenceId, this.individualBasicDetailsModel.pan);

          this.toastr.warning("APPLICANT Details Deleted Successfully...!!!");
        }
        this.isSpinnerLoading = false;     
      },
      (error: HttpErrorResponse) => { 
        this.isSpinnerLoading = false; 
        console.error("ERROR WHILE DELETING APPLICANT DETAILS: ", error);
      }
    );
  } else {
    console.log("Deletion cancelled by the user.");
  }
}

// **************************************** REDIRECT TO NEXT PAGE  ************************************* 
goNext(){
    // this.router.navigate(['/homeloan/cibil-all'])
    this.router.navigate(['/carLoanV2/coapp-individual'])

}
goBack(){
  // this.router.navigate(['/homeloan/applicant-form'])
  alert("PATH NOT CONFIGURED YET.")
}


// **************************************** UPDATE CRIF DETAILS AND HISTORY TABLES ************************************* 

updateCrifDetailAndHistoryTables(referenceId:string, pan:string){
  this.isSpinnerLoading= true;

  this.fetchIndividualCrifService.removeIndividualCrifData(referenceId,pan).subscribe((response) => {
  this.isSpinnerLoading= false;

    console.log("CRIF DATA SAVED IN HISTORY"+response);
  },(error) => {
    this.isSpinnerLoading=false;
    console.log("ERROR OCCURED IN CRIF DELETION OF GUARANTOR" +JSON.stringify(error));
    
  })
}

// ***************************************************************************************************//

getCibilFetchedStatus(){
  this.isSpinnerLoading=true;

  console.log("Inside  getCibilFetchedStatus function, ref id: ", this.userModelData.referenceId);
  this.cibilFetchStatusService.getCibilFetchStatusDetails(this.userModelData.referenceId).subscribe(
    (response) => { 
      if(response !=null){
      this.cibilFetchStatusModel=response;
      }
      console.warn("Response from getCibilFetchStatusDetails, CIBIL-CRIF STATUS FETCHED: ", JSON.stringify(this.cibilFetchStatusModel));
      
      this.isSpinnerLoading=false;
  },
  (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GETTING CIBIL-FETCHED STATUS DATA: "+error)
  });
}
//********************************************************************************************** *//

//METHOD TO SHOW ALERT WHEN ITR FIELD IS CHANGED TO NO FROM YES
onItrSelectionChange(currentValue: string, newValue: string): void {
  if (currentValue === 'Yes' && newValue === 'No') {
    Swal.fire({
      title: 'Are you sure?',
      text: 'The previously fetched ITR data will be removed, if present.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      // confirmButtonColor: '#28a745',
      // cancelButtonColor: '#dc3545' ,  
      reverseButtons: true
    }).then((result: { isConfirmed: any; }) => {
      if (result.isConfirmed) {
        this.individualBasicDetailsModel.itrFilledForAnyYear = newValue;
        console.log('Confirmed: ITR data will be removed');
      } 
      else {
        setTimeout(() => {
                  this.individualBasicDetailsModel.itrFilledForAnyYear = currentValue; 
                  console.log('ITR SELECTION CHANGE CANCELLED: ITR data will not be removed');
              }, 0)
        }
    });
  }
}

//**********************************************************************************************
}
