import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuarantorIndividualComponent } from './guarantor-individual.component';

describe('GuarantorIndividualComponent', () => {
  let component: GuarantorIndividualComponent;
  let fixture: ComponentFixture<GuarantorIndividualComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GuarantorIndividualComponent]
    });
    fixture = TestBed.createComponent(GuarantorIndividualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
