import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { CibilFetchStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-fetch-status.model';
import { AllKycInfoModel, PANverifyRequestModel } from 'src/app/MODELS/panAadharModel.model';
import { IndividualBasicDetailsService } from 'src/app/SERVICES/Basic-details-individual/individual-basic-details.service';
import { CibilFetchStatusService } from 'src/app/SERVICES/CIBIL-individual-all/cibil-details.service';
import { StatesServiceService } from 'src/app/SERVICES/States-Service/states-service.service';
import { KycPanAadharVerifyComponent } from '../kyc-pan-aadhar-verify/kyc-pan-aadhar-verify.component';
import { NgForm } from '@angular/forms';
import { IndividualCoapplicantGuarantorBasicDetails } from 'src/app/MODELS/Individual-basic-details.model';

@Component({
  selector: 'app-guarantor-individual',
  templateUrl: './guarantor-individual.component.html',
  styleUrls: ['./guarantor-individual.component.css']
})
export class GuarantorIndividualComponent implements OnInit{

  @ViewChild('guarantorForm') guarantorForm!: NgForm;

  //********************************** VARIABLE INITILISED *********************************************************/
  kycFetchedData!: AllKycInfoModel;
  verified: boolean = false;
  noGuarantor: boolean = true;
  isSpinnerLoading: Boolean = false;
  editingMode: boolean = false;
  showAddFormFlag: boolean = false;
  states: string[] = [];
  guarantorBasicDetail = {} as IndividualCoapplicantGuarantorBasicDetails;
  allGuarantorBasicDetail: IndividualCoapplicantGuarantorBasicDetails[] = [];
  panVerifyRequest={} as PANverifyRequestModel;
  cibilFetchStatusModel={} as CibilFetchStatusModel;
  userModelData = {} as UserModelData;

  editingIndex: number = -1; //-1 beacause array will have 0 index with values
  customerType: string = '';
  guarantorDataPresent: boolean = false;

  //******************************************* CONSTRUCTOR INITIALISED ************************************************/

  constructor(
    private router: Router,
    private modalService: NgbModal,
    private toastr: ToastrService,
     private individualBasicDetailsService: IndividualBasicDetailsService,
    private cibilFetchStatusService:CibilFetchStatusService,
    private stateListService: StatesServiceService
  ) { }

  //*******************************************************************************************/

  ngOnInit(): void {

    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    console.log("USER DATA MODEL:", this.userModelData);
    this.panVerifyRequest.loanRefNo= this.userModelData.referenceId;
    console.log("REF NO:", this.panVerifyRequest.loanRefNo);
    this.getCibilFetchedStatus();
    this.getAllGuarantorList();
    this.getStateList();
}


//******************************************** GET STATE LIST ***********************************************/
  getStateList() {
    this.stateListService.getStates().subscribe(data => {
      this.states = data;
      console.log('state *************:' + this.states);
    });
  }

  //****************************************** METHOD TO OPEN MODAL - GUARANTOR ***************************************************************************** */
  openPanAadharVerificationModal() {
    const modalRef = this.modalService.open(KycPanAadharVerifyComponent,
      {
        backdrop: 'static',
        keyboard: false,
        centered: true,
      });

    modalRef.componentInstance.kycFetchedData.subscribe(async (data: AllKycInfoModel) => {
      try {
        await this.getkycFetchedData(data);
      } catch (error) {
        console.error('Error fetching KYC data:', error);
      }
    });

  }

  
//****************************** GET & SET DATA FROM PAN AADHAR VERIFICATION COMPONENT ******************************/
async getkycFetchedData(data: AllKycInfoModel) {
  try {
    this.kycFetchedData = data;
    console.log('Data from Aadhar to guarantor component:', JSON.stringify(data));
    await this.setFetchedValues();
  } catch (error) {
    console.error('Error setting fetched values:', error);
  }
}


//************************ SET FETCHED VALUES ******************************************************************************** */
  async setFetchedValues() {
    console.log("Data this.kycFetchedData.kycData : ", JSON.stringify(this.kycFetchedData.kycData));
    if (this.kycFetchedData && this.kycFetchedData.kycData) {
      this.guarantorBasicDetail = {

        idDto:0,
        referenceId: this.userModelData.referenceId,
        branchCode: this.userModelData.brcode,
        userId: this.userModelData.userId,
        fullName: this.kycFetchedData.kycData.data.name,
        gender: this.kycFetchedData.kycData.data.gender,
        pan: this.kycFetchedData.pan,
        aadhar: this.kycFetchedData.aadhar,
        mobileNumber: this.kycFetchedData.kycData.data.mobile,
        email: this.kycFetchedData.kycData.data.email,
        dateOfBirth: this.kycFetchedData.kycData.data.dateOfBirth,

        // Fetched fields from Aadhar
        careOf: this.kycFetchedData.kycData.data.careOf,
        house: this.kycFetchedData.kycData.data.house,
        street: this.kycFetchedData.kycData.data.street,
        district: this.kycFetchedData.kycData.data.district,
        subDistrict: this.kycFetchedData.kycData.data.subDistrict,
        landmark: this.kycFetchedData.kycData.data.landmark,
        locality: this.kycFetchedData.kycData.data.locality,
        postOfficeName: this.kycFetchedData.kycData.data.postOfficeName,
        state: this.kycFetchedData.kycData.data.state,
        pincode: this.kycFetchedData.kycData.data.pincode,
        country: this.kycFetchedData.kycData.data.country,
        vtcName: this.kycFetchedData.kycData.data.vtcName,
        mobile: this.kycFetchedData.kycData.data.mobile,
        aadharAddress: this.kycFetchedData.kycData.data.careOf +
          ' ' +
          this.kycFetchedData.kycData.data.house +
          ' ' +
          this.kycFetchedData.kycData.data.street +
          ' ' +
          this.kycFetchedData.kycData.data.locality +
          ' ' +
          this.kycFetchedData.kycData.data.landmark,

        title: '',
        fatherName: '',
        alternateEmail: '',
        altMobile: '',
        netWorth: '',
        permanentAddress: '',
        residenceOwnership: '',
        voterIdCard: '',
        drivingLicence: '',
        passportNum: '',
        rationCardNumber: '',
        qualification: '',
        tempAddressLine1: '',
        // tempAddressLine2: '',
        tempAddressLandmark: '',
        tempAddressSubDist: '',
        tempAddressDist: '',
        tempAddressState: '',
        tempAddressPincode: '',
        cif: '',
        presentAddress: '',
        customerType: 'GUARANTOR',
        pfNomineeAge: '',
        timestamp: '',
        occupation: '',
        consideringIncome: '',
        incomeSourceType: '',
        itrFilledForAnyYear: '',
        form16Available:'',
        relationWithApplicant:'',
        relationWithApplicantOther:''
      }
      this.verified = true; //TO OPEN THE INPUT FORM WITH FETCHED DATA
    }
    else {
      this.verified = false;
      this.isSpinnerLoading = false;
      this.toastr.error("Data Not Available")
      console.error('Some properties are undefined in KYC fetched Data.');
    }

  }

  // ************************************************* REDIRECT TO NEXT PAGE  ********************************************** //

  goNext() {
    this.router.navigate(['/carLoanV2/cibil-individual-all']);
  }

  // ************************************************* REDIRECT TO BACK PAGE  ********************************************** //

  goBack() {
    //  this.router.navigate(['/carLoanV2/coapp-individual']);
    if(this.userModelData.custType === "individual"){
     this.router.navigate(['/carLoanV2/borrower-individual']);
    }else if(this.userModelData.custType === "corporate"){
    this.router.navigate(['/carLoanV2/borrower-firm']);
    }
  }

//************************************************* CANCEL SAVING GUARANTOR DATA *************************************************//

cancelSavingGuarantor() {
  this.verified = false;
  this.editingMode=false;
  this.resetGuarantorForm();
}

// ******************************************* SERVICE  SAVE/UPDATE  INDIVIDUAL GURANTOR  *************************************** //
saveSingleGuarantor() {
    this.isSpinnerLoading = true;
  
    if (!this.guarantorForm.valid) {
      console.log("Form is not valid!");
      this.toastr.info("Kindly Fill all the Required Fields to Save the details");
      this.isSpinnerLoading = false;
      return; // Exiting method if the form is not valid
    }

    // Checking if we are in editing mode or adding new security
    if (this.editingMode) {
      this.allGuarantorBasicDetail[this.editingIndex] = { ...this.guarantorBasicDetail };
    } else {
      this.allGuarantorBasicDetail.push({ ...this.guarantorBasicDetail });
    }
    this.saveOrUpdateGuarantorBasicDetail();// Save or update the corporate guarantor in the backend
  }


  //**************************************** SERVICE  SAVE/UPDATE  CO-APPLICANT ************************************************************************** */
  async saveOrUpdateGuarantorBasicDetail() {
    this.isSpinnerLoading = true;

       console.log('IN SAVE METHOD');
    if (this.guarantorForm && !this.guarantorForm.valid) {
      console.log("Form is not valid!");
      this.toastr.info("Kindly Fill all the Required Fields to Save the details");
      this.isSpinnerLoading = false;
      return; // Exit method if the form is not valid
    }
    try {
     
      this. individualBasicDetailsService.saveOrUpdateDetails(this.guarantorBasicDetail).subscribe(
        (response) => {
          console.log("Response from  individualBasicDetailsService: ", response);
          this.isSpinnerLoading = false;
          this.toastr.success("Guarantor Details Saved or Updated Successfully...!!!");

          // Reset the form and refresh the coapplicant list
          this.resetGuarantorForm();
          this.getAllGuarantorList();
        },
        (error: HttpErrorResponse) => {
           if(error.status === 400){
          console.error("Data Against the PAN : "+this.guarantorBasicDetail.pan+" is Alraedy Present for Reference-ID :"+this.guarantorBasicDetail.referenceId+" , Hence Can Not Add Duplicate Details. Kindly Check and Input Correct Information.");
          this.toastr.error("Data Against the PAN : "+this.guarantorBasicDetail.pan+" is Alraedy Present for Reference-ID :"+this.guarantorBasicDetail.referenceId+" , Hence Can Not Add Duplicate Details. Kindly Check and Input Correct Information.");
      }

          this.individualBasicDetailsService.getCoapplicantData(
            this.guarantorBasicDetail.referenceId,
            this.guarantorBasicDetail.aadhar,
            this.guarantorBasicDetail.pan
          )
          this.isSpinnerLoading = false;
          console.error("ERROR WHILE SAVING/UPDATING GUARANTOR: ", error);
        }
      );
    } catch (error) {
      console.error("Error while saving/updating guarantor details:", error);
      this.isSpinnerLoading = false;
    }
  }


// ************************************** GET CO-APPLICANT GUARANTOR DATA *************************************************************//

getGuarantorData(referenceId: string,  aadhar: string,  pan: string){

  this.isSpinnerLoading=true;
  console.log("Inside  getGuarantorData , reference id : ", this.userModelData.referenceId);

  this.individualBasicDetailsService.getCoapplicantData(referenceId,aadhar,pan).subscribe(
    (response) => { 
      this.guarantorBasicDetail=response;
      console.log("Response from getApplicantData: ", JSON.stringify(this.guarantorBasicDetail));
    if(response != null){
      this.guarantorDataPresent=true;
      }else{
        this.guarantorDataPresent=false;
      }
      this.isSpinnerLoading=false;

  },
 (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GETTING APPLICANT DETAILS: "+error)
  }
);
}
  // ******************************************** METHOD TO RESET FORM  *******************************************

  resetGuarantorForm() {
    this.guarantorForm.resetForm(); // Reset the form using ViewChild  
  }
  // ***************************************** METHOD TO EDIT CO-APPLICANT ***********************************

  editGuarantorDetails(guarantor: IndividualCoapplicantGuarantorBasicDetails) {
    console.log('IN EDIT FUNCTION')
    this.editingMode = true;
    this.guarantorBasicDetail = { ...guarantor }; // Cloning guarantor object to prevent direct modification

    this.editingIndex = this.allGuarantorBasicDetail.indexOf(guarantor);
   
    this.editingMode = true;
  }

  // ************************************ METHOD TO GET ALL CO-APPLICANT   ********************* 

  getAllGuarantorList() {
    this.isSpinnerLoading = true;

    this.individualBasicDetailsService.getAllGuarantorList(this.userModelData.referenceId).subscribe(
      (response) => {
        if (response !== null) {
          this.allGuarantorBasicDetail = response;
          console.log("GUARANTOR LIST: ", JSON.stringify(response));
          const result = JSON.stringify(response);

          this.noGuarantor = false;
          console.log(this.noGuarantor);

          if (this.editingMode) {
            
            this.editingMode = false;
            this.editingIndex = -1;
          } else {
          
            this.verified = false;
          }

        } else {
          this.noGuarantor = true;
        }

        this.isSpinnerLoading = false;
      }, (error: HttpErrorResponse) => {
        this.isSpinnerLoading = false;
        console.error("ERROR WHILE GETTING LIST OF CORPORATE GUSRANTORS : " + error)
      }
    );
    this.showAddFormFlag = false; // Hide the form after successful operation

  }

  // ********************************** SERVICE INTEGRATION TO DELETE SINGLE CORP GUARANTOR  ************************ 

  confirmDeleteGuarantor(referenceId: string, name: string, customerType: string,aadhar:string) {
    console.log("INSIDE DELETE FROM BACKEND REF_ID: " + this.guarantorBasicDetail.referenceId + " ID: " + referenceId);
    const confirmed = window.confirm('Are you sure you want to delete  Guarantor : ' + name + ' ?');

    let custType: string = this.guarantorBasicDetail.customerType;
    console.log("CUSTOMER TYPE " + customerType)
 
    this.guarantorBasicDetail.referenceId = this.userModelData.referenceId;
    let userId=this.userModelData.userId;


    if (confirmed) {
      this.individualBasicDetailsService.deleteBorrowerOrGuarantor(referenceId, customerType,aadhar, userId)
        .subscribe(
          (response: string) => {
            console.log('Message from backend:', response);

            this.getAllGuarantorList(); // get the updated list after deleting
            this.toastr.success('Guarantor Deleted Successfully...!', 'Deleted', { timeOut: 1000 });



            if (this.allGuarantorBasicDetail.length === 0) {
              this.verified = true;

            }
          }
        );
    }
  }

  //**************************************************** COPING ADDRESS SAME AS ABOVE ****************************************************************************** */
  sameAsPermanentAddress = false;
  copyAddress() {
    if (this.sameAsPermanentAddress) {
      this.guarantorBasicDetail.tempAddressLine1 = this.guarantorBasicDetail.aadharAddress;
      this.guarantorBasicDetail.tempAddressDist = this.guarantorBasicDetail.district;
      this.guarantorBasicDetail.tempAddressState = this.guarantorBasicDetail.state;

      this.guarantorBasicDetail.tempAddressPincode = this.guarantorBasicDetail.pincode;

      // Copy permanent address to correspondent address
    } else {
      this.guarantorBasicDetail.tempAddressLine1 = '',
        // tempAddressLine2: '',
        this.guarantorBasicDetail.tempAddressDist = '',
        this.guarantorBasicDetail.tempAddressState = '',
        this.guarantorBasicDetail.tempAddressPincode = ''

    }
  }
//**********************************************************************************************************************************
getCibilFetchedStatus(){
  this.isSpinnerLoading=true;

  console.log("Inside  getCibilFetchedStatus function, ref id: ", this.userModelData.referenceId);
  this.cibilFetchStatusService.getCibilFetchStatusDetails(this.userModelData.referenceId).subscribe(
    (response) => { 
      if(response !=null){
      this.cibilFetchStatusModel=response;
      }
      console.warn("Response from getCibilFetchStatusDetails, CIBIL-CRIF STATUS FETCHED: ", JSON.stringify(this.cibilFetchStatusModel));
      
      this.isSpinnerLoading=false;
  },
  (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GETTING CIBIL-FETCHED STATUS DATA: "+error)
  });
}


// ********************SERVICE INTEGRATION TO UPDATE APPLICANT  AND RE-FETCH CIBIL : visiting after 10 ********************* 
updateDetailsRefetchCIBILSingle() {
  this.isSpinnerLoading = true;

  this.guarantorBasicDetail.branchCode=this.userModelData.brcode;

  console.warn("this.coapplicantBasicDetails.customerTyp :"+this.guarantorBasicDetail.customerType);
  
  this.individualBasicDetailsService.updateDetailsAndRefetchCIBIL(this.guarantorBasicDetail).subscribe(
    (response) => { 
      console.log("Response from updateDetailsRefetchCIBILSingle: ", response);
      this.isSpinnerLoading=false;
      this.toastr.success("Guarantor Details Saved or Updated Successfully...!!!")
      this.getAllGuarantorList();

  },
  (error : HttpErrorResponse) => {
    //to get saved data so that update button get displayed
    this.getAllGuarantorList();
    // this.getCibilFetchedStatus();
    this.isSpinnerLoading=false;

    console.error("ERROR WHILE SAVING/ UPDATING APPLICANT DATA: "+error)
  });
}

// ********************SERVICE INTEGRATION TO UPDATE APPLICANT  AND RE-FETCH CIBIL : visiting after 10 ********************************* 

updateDetailsRefetchCIBILAll() {
  this.isSpinnerLoading = true;
  console.log(" this.userModelData.referenceId : "+this.userModelData.referenceId);
  
  this.individualBasicDetailsService.RefetchCIBILForAll(this.userModelData.referenceId).subscribe(
    (response) => { 
      console.log("Response from individualBasicDetailsService: ", response);
      this.isSpinnerLoading=false;
      this.toastr.success("CIBIL DETAILS OF ALL GURANTORS FETCHED SUCCESSFULLY...!!!")

     this.goNext();
  },
  (error : HttpErrorResponse) => {
 
    this.isSpinnerLoading=false;

    console.error("ERROR WHILE FETCHING CIBIL FOR GURANTORS: "+error)
  });
}
}