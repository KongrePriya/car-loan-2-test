import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DashBoardModel } from 'src/app/MODELS/dashboard.model';

import { Router } from '@angular/router';
import { catchError } from 'rxjs';
import { Chart, Colors } from 'chart.js/auto';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { ApiService } from 'src/app/SERVICES/Login/api.service';
import { UserModelDataForApplicationList } from 'src/app/MODELS/application-list/application-list-data-get.model';
import { DashBoardService } from 'src/app/SERVICES/dashboard/dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChild('myChart', { static: true }) chartRef!: ElementRef;
  @ViewChild('myChart2', { static: true }) chartRef2!: ElementRef;

  //date year
  currentyr!: number;
  previousyr!: number;
  fypreviousyr!: number;
  fycurrentyr!: number;

  
     dashBoardModel = {} as DashBoardModel;
     currentMonthPieChartData!: DashBoardModel;

  //userModel
  userDataModel!: UserModelData;
  userDataModelForList={} as  UserModelDataForApplicationList;
  currentmonth: string = '';

  //spinner
  //spinner Loading
  isSpinnerLoading = false;
  //For Bar Chart i need date and have to called 4 times as data not comes in quarter wise

  dashBoardModelq1={} as DashBoardModel;
  dashBoardModelq2= {} as DashBoardModel;
  dashBoardModelq3= {} as  DashBoardModel;
  dashBoardModelq4= {} as  DashBoardModel;

  

  getMonthsInString(): string {
    const monthNames = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return monthNames[new Date().getMonth()];
  }

  ngOnInit() {
    const abc = sessionStorage.getItem('userModelData');
    this.userDataModel = JSON.parse(abc!);
    //alert(JSON.stringify(this.userDataModel))
    this.userDataModelForList.branchCode=this.userDataModel.brcode;
    this.userDataModelForList.userLoc=this.userDataModel.u_loc;
    this.userDataModelForList.userType=this.userDataModel.u_type;
    this.userDataModelForList.regionName=this.userDataModel.roname;
    
    this.userDataModelForList.userId=this.userDataModel.userId;
    this.userDataModelForList.status=this.userDataModel.u_status;
    this.userDataModelForList.userName=this.userDataModel.u_name;
    this.userDataModelForList.userScale=this.userDataModel.scale;

    this.userDataModelForList.custType=this.userDataModel.custType;
    this.userDataModelForList.referenceId=this.userDataModel.referenceId;

    this.isSpinnerLoading = true;

    const currentdate = new Date();
    this.currentyr = currentdate.getFullYear();

    this.currentmonth = this.getMonthsInString();
    const currentMonth = new Date().getMonth();


    
    if (currentMonth > 2) {
      this.fycurrentyr = this.currentyr + 1  ;
      this.fypreviousyr = this.currentyr;
    } else {
      this.fycurrentyr = this.currentyr ;
      this.fypreviousyr = this.currentyr - 1;
    }
   
    this.previousyr = this.currentyr - 1;
   
   
    this.getDashBoardData();
    // this.getDashBoardPieData();
    // this.getDashBoardBarData();
  

  // this.authService.startAutoLogout();
  }
  constructor(
    private router: Router,
    private dashboarService: DashBoardService
  ) {}

 // DashBoard Model
 getDashBoardData() {
  this.dashboarService
    .getDashBoardCount(this.userDataModelForList)
    .pipe(
      catchError((error) => {
        //  alert(error);
        this.isSpinnerLoading = false;
        console.error('Error fetching data:', error);
        return [];
      })
    )
    .subscribe(
      (response) => {
        // alert('i got here');
        this.dashBoardModel = response;
          this.getDashBoardPieData();
      },
      (e) => {this.getDashBoardPieData();this.isSpinnerLoading = false;}
    );

}
getDashBoardPieData() {
  

  this.dashboarService
    .getDashBoardPie(this.userDataModelForList)
    .pipe(
      catchError((error) => {
        
        this.isSpinnerLoading = false;
        console.error('Error fetching data:', error);
        return [];
      })
    )
    .subscribe(
      (response) => {
       
        this.currentMonthPieChartData = response;
          
        this.getDashBoardBarData()
      },
      (e) => {this.getDashBoardBarData();
        this.isSpinnerLoading = false;}
    );

}
getDashBoardBarData() {
  

  this.dashboarService
    .getDashBoardbar(this.userDataModelForList)
    .pipe(
      catchError((error) => {
        
        this.isSpinnerLoading = false;
        console.error('Error fetching data:', error);
        return [];
      })
    )
    .subscribe(
      (response:DashBoardModel[]) => {
        this.isSpinnerLoading = false;
        this.dashBoardModelq1 = response[0];
        this.dashBoardModelq2 = response[1];
        this.dashBoardModelq3 = response[2];
        this.dashBoardModelq4 = response[3];
         // alert(JSON.stringify(this.dashBoardModelq1))
        this.createBarChart();
        this.createPieChart();
      },
      (e) => {
        this.isSpinnerLoading=false
        console.log("ERROR IN DASHBOARD BAR-CHART DATA" + JSON.stringify(e));
        
      }
    );

}

  createPieChart() {
    // console.log(JSON.stringify(this.dashBoardModel))
    // const recommended=this.dashBoardModel.statusRecommended;
    // const pending=this.dashBoardModel.statusPending;
    const ctx = this.chartRef.nativeElement;
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: [
          'Recommended',
          'Pending',
          'Sanctioned',
          'Return',
          'Rejected',
          'Deviation',
        ],
        datasets: [
          {
            label: 'Pie Chart',
            data: [
              this.currentMonthPieChartData!.statusRecommended,
              this.currentMonthPieChartData!.statusPending,
              this.currentMonthPieChartData!.statusSanctioned,
              this.currentMonthPieChartData!.statusReturn,
              this.currentMonthPieChartData!.statusReject,
              this.currentMonthPieChartData!.statusDeviation, 
              // this.dashBoardModel!.statusRecommended,
              // this.dashBoardModel!.statusPending,
              // this.dashBoardModel!.statusSanctioned,
              // this.dashBoardModel!.statusReturn,
              // this.dashBoardModel!.statusReject,
              // this.dashBoardModel!.statusDeviation,    
                  ],
            backgroundColor: [
              'rgb(106, 94, 237)',
              'hotpink',
              'green',
              'rgb(230, 137, 32)',
              'red',
              'rgba(128, 0, 128)',
            ],
            hoverOffset: 50,
          },
        ],
      },
      options: {
        //   responsive: true,

        plugins: {
          tooltip: {
            callbacks: {
              label: (context: any) => {
                const label = context.label || '';
                if (context.parsed) {
                  const value = context.parsed as number;
                  const total = context.dataset.data.reduce(
                    (acc: number, data: number) => acc + data,
                    0
                  );
                  const percentage = Math.round((value / total) * 100);
                  return `${label}: ${percentage}%` + ` (` + value + ')';
                }
                return '';
              },
            },
          },
        },
      },
    });
  
  }

  createBarChart() {
    const ctxx = (this.chartRef2.nativeElement as HTMLCanvasElement).getContext(
      '2d'
    );
    if (ctxx) {
      new Chart(ctxx, {
        type: 'bar',
        data: {
          labels: ['Q1', 'Q2', 'Q3', 'Q4'], // Label for the category
          datasets: [
            {
              label: 'Recommended', // Label for value 1
              data: [
                this.dashBoardModelq1!.statusRecommended,
                this.dashBoardModelq2!.statusRecommended,
                this.dashBoardModelq3!.statusRecommended,
                this.dashBoardModelq4!.statusRecommended,
              ], // Value 1
              backgroundColor: 'rgb(106, 94, 237)',
              borderColor: ' rgba(255, 205, 86, 1)', //'rgba(255, 99, 132, 1)',
              borderWidth: 1,
            },
            {
              label: 'Pending', // Label for value 2
              data: [
                this.dashBoardModelq1!.statusPending,
                this.dashBoardModelq2!.statusPending,
                this.dashBoardModelq3!.statusPending,
                this.dashBoardModelq4!.statusPending,
              ], // Value 2
              backgroundColor: 'hotpink',
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 1,
            },
            {
              label: 'Sanctioned', // Label for value 3
              data: [
                this.dashBoardModelq1!.statusSanctioned,
                this.dashBoardModelq2!.statusSanctioned,
                this.dashBoardModelq3!.statusSanctioned,
                this.dashBoardModelq4!.statusSanctioned,
              ], // Value 3
              backgroundColor: 'green',
              borderColor: 'green',
              borderWidth: 1,
            },
            {
              label: 'Return', // Label for value 4
              data: [
                this.dashBoardModelq1!.statusReturn,
                this.dashBoardModelq2!.statusReturn,
                this.dashBoardModelq3!.statusReturn,
                this.dashBoardModelq4!.statusReturn,
              ], // Value 4
              backgroundColor: 'rgb(230, 137, 32)',
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1,
            },
            {
              label: 'Rejected', // Label for value 4
              data: [
                this.dashBoardModelq1!.statusReject,
                this.dashBoardModelq2!.statusReject,
                this.dashBoardModelq3!.statusReject,
                this.dashBoardModelq4!.statusReject,
              ], // Value 4
              backgroundColor: 'red',
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1,
            },

            {
              label: 'Deviation', // Label for value 4
              data: [
                this.dashBoardModelq1!.statusDeviation,
                this.dashBoardModelq2!.statusDeviation,
                this.dashBoardModelq3!.statusDeviation,
                this.dashBoardModelq4!.statusDeviation,
              ], // Value 4
              backgroundColor: 'rgb(128, 0, 128)',
              borderColor: 'rgba(128, 0, 128, 1)',
              borderWidth: 1,
            },
          ],
        },
        options: {
          //         responsive: true,

          indexAxis: 'x', // Display bars vertically
          scales: {
            y: {
              beginAtZero: true,
              type: 'linear' // Start x-axis from zero
            },
            x:{
              type: 'category' // Start x-axis from zero
            }
          },
        },
      });
    }else{
      
    }
  }

  // Function For Reroute to the another component  with value
  gotoDisplayListPage(data: string) {
    sessionStorage.setItem('liststatus', data);
    this.router.navigate(['/gstmsme/applicationlist']);
 
  }
}
