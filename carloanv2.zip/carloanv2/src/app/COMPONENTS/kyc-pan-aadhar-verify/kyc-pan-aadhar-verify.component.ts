import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AADHARverifyService, PanVerificationService } from 'src/app/SERVICES/Kyc-Verification/kyc-verification.service';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { AllKycInfoModel, AuthorizeOtpAadharReponse, OTPresponseModel, PANverifyRequestModel, PANverifyResponseModel } from 'src/app/MODELS/panAadharModel.model';

@Component({
  selector: 'app-kyc-pan-aadhar-verify',
  templateUrl: './kyc-pan-aadhar-verify.component.html',
  styleUrls: ['./kyc-pan-aadhar-verify.component.css']
  
})
export class KycPanAadharVerifyComponent {
  @Output() kycFetchedData: EventEmitter<AllKycInfoModel> = new EventEmitter();

  pan!: string;
  isPANVerified = false;
  aadhar!:string;
  otp = '';
  isOTPGenerated = false;
  otpResent: boolean = false;
  isSpinnerLoading: Boolean = false;
  panVerifyRequest = {} as PANverifyRequestModel;
  panVerifyResponseModel = {} as PANverifyResponseModel;
  otpResponseModel={} as OTPresponseModel;
  resendTimeout: number = 60; // Resend timeout in seconds
  resendButtonText: string = 'Resend OTP';
  resendDisabled: boolean = false;
  otpExpired:boolean=false;
  otpResentMsg:boolean=false;
  isFinalSubmitEnabled = false;
  userModelData = {} as UserModelData;
  // *************************************************************************************************************************** 
  
  constructor(
    private activeModal: NgbActiveModal,
    private panVerifyService: PanVerificationService,
    private aadharVerificationService:AADHARverifyService,
    private toastr: ToastrService,
    private router:Router

  ) { }

  // ***************************************************************************************************************************
  
  ngOnInit(): void {
    console.log('KYC PAN AADHAR ');
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    console.warn("USER DATA MODEL:", this.userModelData);
    this.panVerifyRequest.loanRefNo= this.userModelData.referenceId;
    console.warn("REF NO:", this.panVerifyRequest.loanRefNo);
  }

  // ************************************ METHOD FOR CLOSE MODAL *************************************************************** 

  closeModal() {
    this.activeModal.dismiss('Cross click');
  }

// ************************************ METHOD FOR RESET FORM AND FLAGS ********************************* 

resetFormState() {
  this.pan = '';
  this.aadhar = '';
  this.isPANVerified = false;
  this.isOTPGenerated = false;
  this.otp = '';
  this.otpResent = false;
  this.isFinalSubmitEnabled = false;
}
  // ************************************ METHOD FOR PAN VERIFICATION METHOD SERVICE INTEGRATION ********************************* 

  postPANtoVerify() {
    const panVerifyRequest = {
      loanRefNo: this.userModelData.referenceId,
      pan: this.pan
    }
    this.isSpinnerLoading = true;

    this.panVerifyService.verifyPAN(panVerifyRequest).subscribe(
      (response) => {
        if (response && response.responseCode) {
          this.panVerifyResponseModel = response;
          console.log('PAN RESPONSE from API :', this.panVerifyResponseModel);
          if (response.responseCode === 'SRC001') {
            this.isPANVerified = true;
            this.isSpinnerLoading = false;
          } else {
            this.isSpinnerLoading = false;
            // this.toastr.info("No Data Found From PAN. Kindly Check PAN", 'Custom', {
            //   timeOut: 5000,
            //   positionClass: 'toast-top-full-width',
            //   progressBar: true  // Display a progress bar

            this.toastr.warning("No Data Found From PAN. Kindly Check PAN")
          }
        } else {
          this.isSpinnerLoading = false;
          this.toastr.warning("Invalid response received from the server.", "Please Try Again...");
        }

      },
      (error: any) => {
        console.error('ERROR IN PAN VERIFICATION  :', error)
        this.isSpinnerLoading = false;
      }
    );

  }

  
// ************************************ METHOD FOR OTP GENERATE SERVICE INTEGRATION ********************************* 

generateOTP() {
  this.isSpinnerLoading=true;

  const authorizeOtpAadharRequest = {
    aadhaar_number: this.aadhar,
    loanRefNo: this.userModelData.referenceId
  };
  this.aadharVerificationService.generateAadharOTP(authorizeOtpAadharRequest).subscribe(
    (response: OTPresponseModel) => {
      this.otpResponseModel = response;
      console.log('OTP GENERATION RESPONSE:', this.otpResponseModel);

      if(response.responseCode === 'SOS174'){
      this.isPANVerified = true;
      this.isOTPGenerated = true;
      this.isSpinnerLoading=false;
      this.startResendTimer(); // Start resend timer after OTP generation
    }
    else{
      this.toastr.warning('Please retry.','OTP generation failed...!!!')
      this.isSpinnerLoading= false;

    }
  },
    (error: any) => {
      console.error('Error generating OTP:', error);
      this.toastr.error('Error generating OTP');
      this.isSpinnerLoading=false;

    }
  );
}
//+++++=DUMMY OTP++++++++++//
generateOTPdummy() {
  this.isPANVerified = true;
  this.isOTPGenerated = true;
}

// ************************************ METHOD FOR RESENT OTP TIMER  ********************************* 

startResendTimer() {
  this.resendTimeout = 60; // Reset timer to 60 seconds
  this.resendDisabled = true;
  let timer = setInterval(() => {
    this.resendTimeout--;
    this.resendButtonText = `Resend OTP in ${this.resendTimeout} seconds`;
    this.otpResent=true;
    if (this.resendTimeout === 0) {
      clearInterval(timer); //Stops the timer when the countdown reaches 0, allowing the button to be re-enabled.
      this.resendDisabled = false;
      this.resendButtonText = 'Resend OTP';
    }
  }, 1000); //Runs every second to update the countdown and the button text
}

// ************************************ METHOD FOR RESEND OTP ********************************* 

resendOTP(){
  this.isSpinnerLoading=true;
  this.otpResentMsg=true;

  this.otp ='';
  this.generateOTP();
}


updateFinalSubmitEnabled() {
  // Logic to check if final submit should be enabled
  this.isFinalSubmitEnabled = !!this.otp;
}


// *********************** METHOD FOR AADHAR VERIFICATION AND DATA EMIT SERVICE INTEGRATION  ********************************* 

submitAadharData() {
  this.isSpinnerLoading= true;
 //request data
 const authorizeOtpAadharRequest ={
     otp:this.otp,
     aadhaar_number:this.aadhar,
    //  loanRefNo:this.userModelData.referenceId,
    loanRefNo:'AAAA',
   };
   console.log(" REQUEST DATA TO VERIFY OTP : ", authorizeOtpAadharRequest);

   this.aadharVerificationService.authorizeAadharOTP(authorizeOtpAadharRequest).subscribe((result:AuthorizeOtpAadharReponse) => {
     console.log("DATA: ", result);

     // if (!result || Object.keys(result).length === 0) {
    
   if(result.responseCode ==='SRC001'){
     const allData :AllKycInfoModel = {
       pan: this.pan,
       aadhar: this.aadhar,
       kycData:result
     };
     console.log("Data prepared to emit to co-applicant or co-borrower component :",allData);
     
     this.kycFetchedData.emit(allData);  
     console.log("Data emitted to co-applicant or co-borrower component: ", JSON.stringify(allData));
       this.activeModal.close('Submit');
     }else{
       //ERROR CODES

       this.isFinalSubmitEnabled=false;

       if(result.responseCode ==='EOE794'){
         this.toastr.error('OTP Expired. Kindly regenerate OTP.');
         this.otpExpired = true; // TO SHOW RESEND BUTTON
       }else
       if(result.responseCode ==='ETP011'){
         this.toastr.error('Incorrect OTP, Kindly Check');
         this.otpExpired = true; // TO SHOW RESEND BUTTON

       }else
       if(result.responseCode ==='ENI004'){
         this.toastr.error('No Information found for provided Aadhar Number...!!!');
         this.otpExpired = true; // TO SHOW RESEND BUTTON

       }else{
         this.toastr.warning('Aadhar Verification Failed, Please Try again...!!!');
         this.otpExpired = true; // TO SHOW RESEND BUTTON

       }
     this.otp='';
     this.isSpinnerLoading= false;
     return;
    }      
       this.resetFormState();
   },
     (error: any) => {
         // alert('Aadhar Verification Failed, Please Try again');
         this.toastr.error('Aadhar Verification Failed, Please Try again...!!!');

         console.error('Error verifying PAN Aadhar:', error);
         this.isSpinnerLoading= false;
         this.isFinalSubmitEnabled=false;

         this.resetFormState();
       });
}


// ************************************ METHOD FOR RESET FORM  ********************************* 

resetForm(){
  this.isPANVerified = false;
  this.resetFormState();
  }


  // **************************************** REDIRECT TO BACK PAGE  ************************************* 
goBack(){
  this.router.navigate(['/homeloan/coapplicant-details-form'])}
}

