import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycPanAadharVerifyComponent } from './kyc-pan-aadhar-verify.component';

describe('KycPanAadharVerifyComponent', () => {
  let component: KycPanAadharVerifyComponent;
  let fixture: ComponentFixture<KycPanAadharVerifyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KycPanAadharVerifyComponent]
    });
    fixture = TestBed.createComponent(KycPanAadharVerifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
