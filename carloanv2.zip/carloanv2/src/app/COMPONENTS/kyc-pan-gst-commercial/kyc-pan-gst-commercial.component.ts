import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { CorpGuarantorPANmodel } from 'src/app/MODELS/corpGuarPanGstnVerification.model';
import { GSTInfoModel } from 'src/app/MODELS/firmBorrowerDetails.model';
// import { CorpGuarantorKycService } from 'src/app/SERVICES/corp-gurantor-kyc/corp-guarantor-kyc.service';
import { PangstService } from 'src/app/SERVICES/pan-gst-verification/pangst.service';

@Component({
  selector: 'app-kyc-pan-gst-commercial',
  templateUrl: './kyc-pan-gst-commercial.component.html',
  styleUrls: ['./kyc-pan-gst-commercial.component.css']
})
export class KycPanGstCommercialComponent  {

  // @Input() pan!: string;
 
  @Output() fetchedGstnData: EventEmitter<any> = new EventEmitter();

  isPANVerified = false;
  pan!: string;
  corporateGSTNFetchedData= {} as GSTInfoModel;
  isSpinnerLoading:Boolean= false;
  corpGuarPANmodel={} as CorpGuarantorPANmodel;

  constructor(
    private modal: NgbActiveModal,
    private panGstService:PangstService,
    private router: Router,
    private toastr:ToastrService) {
     
    }

    
  ngOnInit(): void {
  }

  closeModal() {
    this.modal.dismiss('Cross click');
  }

  // verifyCorpPAN() {
  //   this.corpGuarantorKycService.verifyCorpPAN(this.pan).subscribe(
  //     () => {
  //       this.isPANVerified = true;
  //       this.corporateGSTNFetchedData.pan= this.pan
  //     },
  //     (error: any) => {
  //       console.error('Error verifying CORP PAN:', error);
  //     }
  //   );
  // }

//********************************* METHOD FOR PAN VERIFICATION *********************************************//
  verifyCorpPAN() {
    this.isSpinnerLoading=true;
    this.corpGuarPANmodel.pan=this.pan;

    this.panGstService.postPANData(this.corpGuarPANmodel).subscribe(
      (response:any) => {

        console.log("RESPONSE FROM PAN SERVICE: ",response);
        this.isPANVerified = true;
        this.corporateGSTNFetchedData.pan= this.pan
        this.isSpinnerLoading=false;
      },
      (error: any) => {
        console.error('Error verifying CORP PAN:', error);
        this.toastr.error("No data available From PAN", "PAN Verification Failed...");

        this.isSpinnerLoading=false;
      }
    );
  }

//******************************* METHOD FOR GSTN VERIFICATION ************************************************//
  submitGstnData() {
    console.log(this.pan, this.corporateGSTNFetchedData.pan);
    // alert("inside submit");
    this.panGstService.getGSTData(this.corporateGSTNFetchedData.gstin).subscribe((result: any) =>
    {
      if (!result || Object.keys(result).length === 0) {
        this.toastr.error('No data found for the provided GSTN number');
        this.isPANVerified= false;
        return;
      }
      const allData = {
        pan: this.pan,
        gstnVerificationResult: result
      };
      this.fetchedGstnData.emit(allData);  
      console.log("Data emitted to individual-gurantor component: ", result);
        this.modal.close('Submit');
        this.isPANVerified= false;
        // Reset form state
        this.resetFormState();
    },
     (error: any) => {
          this.toastr.error('GSTN Verification Failed, Please Try again');
          console.error('Error verifying PAN gstn:', error);
          
          // Reset form state
          this.resetFormState();
        });
}
//*******************************************************************************//


resetFormState() {
    // Reset form properties to their initial state
    this.pan = '';
    this.corporateGSTNFetchedData.gstin = '';  
}

resetForm(){
  this.isPANVerified = false;
this.resetFormState();
}
}

