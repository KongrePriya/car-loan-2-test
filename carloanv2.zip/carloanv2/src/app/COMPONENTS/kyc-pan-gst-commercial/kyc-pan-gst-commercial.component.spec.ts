import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KycPanGstCommercialComponent } from './kyc-pan-gst-commercial.component';

describe('KycPanGstCommercialComponent', () => {
  let component: KycPanGstCommercialComponent;
  let fixture: ComponentFixture<KycPanGstCommercialComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KycPanGstCommercialComponent]
    });
    fixture = TestBed.createComponent(KycPanGstCommercialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
