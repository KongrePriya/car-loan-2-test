import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItrVerificationApplicantComponent } from './itr-verification-applicant.component';

describe('ItrVerificationApplicantComponent', () => {
  let component: ItrVerificationApplicantComponent;
  let fixture: ComponentFixture<ItrVerificationApplicantComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ItrVerificationApplicantComponent]
    });
    fixture = TestBed.createComponent(ItrVerificationApplicantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
