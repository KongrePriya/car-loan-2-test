import { Component, TemplateRef } from '@angular/core';
import { UserModelData } from '../../AUTH/login/model/user.model';
import { Productdetails, QuotationDetailsModel } from 'src/app/MODELS/quotation-details.model';
import { QuotationDetailsService } from 'src/app/SERVICES/quotation-details/quotation-details.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { GSTInfoModel, PANmodel } from 'src/app/MODELS/firmBorrowerDetails.model';
import { PangstService } from 'src/app/SERVICES/pan-gst-verification/pangst.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-quotation-details',
  templateUrl: './quotation-details.component.html',
  styleUrls: ['./quotation-details.component.css']
})
export class QuotationDetailsComponent {


userModelData = {} as UserModelData;
isSpinnerLoading = false;
quotationDetailsModel = {} as QuotationDetailsModel;
disableKliPremium: string = "";
disableKliFunded: string = "";
loantenure: number[] = [];
productCodes: string[] = [];
panModel = {} as PANmodel;
gstDataModel = {} as GSTInfoModel;
pan:string="";
GSTNForVerification: string = "";
rateofinterest:any;
originalROI: number = 0;
productdetails ={} as Productdetails;
productdetailsList : Productdetails[]=[];

ngOnInit(): void {
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  this.getAllProductCodes();
  this.getQuotationDetails();
  this.generateTenureRanges();
}
// -------------------------------------- Constructor ---------------------------------------------
constructor
(private quotationDetailsService: QuotationDetailsService, 
  private router: Router,
  private toastr: ToastrService,   
  private modalService: NgbModal,
  private pangstService: PangstService,
) {}

// -------------------------------------- Post Data For Quotation Details ---------------------------------------------
onSubmitQuotationDetails() {
this.modalService.dismissAll()
  this.isSpinnerLoading=true;
  this.isSpinnerLoading = true
  this.quotationDetailsModel.referenceId = this.userModelData.referenceId;
  this.quotationDetailsModel.userId = this.userModelData.userId;
  this.quotationDetailsModel.branchCode = this.userModelData.brcode;
  this.quotationDetailsService.postQuotationDetails(this.quotationDetailsModel).subscribe((response: any) => {
    this.isSpinnerLoading = false
    this.toastr.success("Quotation Details Saved Successfully...!!!")
    this.goNext();
    console.log("Quotation Details Response " + JSON.stringify(response));
  }, (error:HttpErrorResponse) => {
    this.toastr.error("Please Check and Enter Valid Data.","ERROR WHILE SAVING QUOTATION DETAILS");
    console.log("Error Occured In Saving Quotation Details  " + JSON.stringify(error));
    this.isSpinnerLoading = false
  }
  )
}

// -------------------------------------- Get Data For Quotation Details ---------------------------------------------
getQuotationDetails() {
  this.isSpinnerLoading = true;
  this.quotationDetailsService.getQuotationDetails(this.userModelData.referenceId).subscribe((response) => {
    this.isSpinnerLoading = false;
    if (response != null) {
      this.quotationDetailsModel = response;
      // this.productCodeChangeInDatabase(this.quotationDetailsModel.productCode);
      this.pan=this.quotationDetailsModel.dealerPan;
      if (this.quotationDetailsModel.loanTenure == undefined) {
        this.quotationDetailsModel.loanTenure = 0;
      }
      if (this.quotationDetailsModel.kotakKliOptions == 'rejected') {
        this.disableKliPremium = 'yes'
        this.disableKliFunded = 'yes'
      }
      if (this.quotationDetailsModel.kotakKliOptions == 'nonfunded') {
        this.disableKliPremium = 'no'
        this.disableKliFunded = 'yes'
      }
      if (this.quotationDetailsModel.kotakKliOptions == 'funded') {
        this.disableKliPremium = 'no'
        this.disableKliFunded = 'no'
      }
    } else {
      // this.getDocumentationCharges();
      // this.getProcessingCharges();
      if (this.quotationDetailsModel.kotakKliOptions == undefined) {
        this.quotationDetailsModel.kotakKliOptions = '';
      }
      if (this.quotationDetailsModel.productCode == undefined) {
        this.quotationDetailsModel.productCode = '';
      }
      if (this.quotationDetailsModel.loanTenure == undefined) {
        this.quotationDetailsModel.loanTenure = 0;
      }
    }
  }, (error: any) => {
    this.isSpinnerLoading = false;
    console.log("Error occured Get Quotation Details " + JSON.stringify(error));
  }
  )
}

// -------------------------------------- Function for Kotak Funded/Non-Funded/Rejected ---------------------------------------------
onChangeKlioption(selectedOption: string) {
  if (selectedOption == 'rejected') {
    this.quotationDetailsModel.kotakKliPremiumAmount = 0
    this.quotationDetailsModel.kotakKliFundedAmount = 0
    this.disableKliPremium = 'yes'
    this.disableKliFunded = 'yes'
  }
  if (selectedOption == 'nonfunded') {
    this.quotationDetailsModel.kotakKliFundedAmount = 0
    this.disableKliPremium = 'no'
    this.disableKliFunded = 'yes'
  }
  if (selectedOption == 'funded') {
    this.quotationDetailsModel.kotakKliFundedAmount = 0
    this.disableKliPremium = 'no'
    this.disableKliFunded = 'no'
  }

}

// ----------------------------------------------- Get Number Range for Loan Tenure ---------------------------------------------
private generateTenureRanges(): void {
  // Tenure Drop-Down
  for (let tenure = 1; tenure <= 60; tenure++) {
    this.loantenure.push(tenure);
  }
}

// ----------------------------------------------- Get Documentation Charges ---------------------------------------------

// getDocumentationCharges() {
//   this.isSpinnerLoading = true;
//   this.quotationDetailsService.getDocumentationCharges().subscribe((response) => {
//     this.isSpinnerLoading = false;
//     if (response != null) {
//       this.quotationDetailsModel.documentCharges = response;
//     }
//   }, (error: any) => {
//     this.isSpinnerLoading = false;
//     console.log("Error occured Get Documentation Charge " + JSON.stringify(error));
//   }
//   )
// }

// ----------------------------------------------- Get Processing Charges ---------------------------------------------

// getProcessingCharges() {
//   this.isSpinnerLoading = true;
//   this.quotationDetailsService.getProcessingCharges().subscribe((response) => {
//     this.isSpinnerLoading = false;
//     if (response != null) {
//       this.quotationDetailsModel.processingCharges = response;
//     }
//   }, (error: any) => {
//     this.isSpinnerLoading = false;
//     console.log("Error occured Get Processing Charges " + JSON.stringify(error));
//   }
//   )
// }

// ----------------------------------------------- Get Product Codes ---------------------------------------------

getAllProductCodes() {
  this.quotationDetailsModel.margin=15;
  this.quotationDetailsModel.documentCharges=0.20;
  this.quotationDetailsModel.processingCharges=0.25;

  this.isSpinnerLoading = true;
  this.quotationDetailsService.getAllProductCodes().subscribe((response) => {
    this.isSpinnerLoading = false;
    if (response != null) {
      
      this.productdetailsList = response;
    }
  }, (error: any) => {
    this.isSpinnerLoading = false;
    console.log("Error occured Get Product Codes " + JSON.stringify(error));
  }
  )
}

// ----------------------------------------------- Get Rate Of Interest ---------------------------------------------

getRateOfInterest(productCode: string) {
  this.isSpinnerLoading = true;
  this.quotationDetailsService.getRateOfInterest(productCode).subscribe((response) => {
    this.isSpinnerLoading = false;
    if (response != null) {
      this.quotationDetailsModel.rateOfInterest = response;
      // -- Note : On successfully getting ROI Get Product Description -- //
      this.getProductDescription(productCode);
    }
  }, (error: any) => {
    this.isSpinnerLoading = false;
    console.log("Error occured Get Rate Of Interest " + JSON.stringify(error));
  }
  )
}

// ----------------------------------------------- Get Product Description ---------------------------------------------

getProductDescription(productCode: string) {
  this.isSpinnerLoading = true;
  this.quotationDetailsService.getProductDescription(productCode).subscribe((response) => {
    this.isSpinnerLoading = false;
    if (response != null) {
      this.quotationDetailsModel.productDescription = response;
    }
  }, (error: any) => {
    this.isSpinnerLoading = false;
    console.log("Error occured Get Product Description " + JSON.stringify(error));
  }
  )
}

// -----------------------------------------------On Change Product-Code Get Rate Of Interest and Product Description on front-end---------------------------------------------
// onChangeProductCode(selectedProductCode: string) {
//   this.getRateOfInterest(selectedProductCode);
//   // -- Note : On successfully getting ROI Get Product Description -- //
// }
preventInput(event:Event){
  let value=this.quotationDetailsModel.loanTenure;
  if (value > 84 || value<0){
    event.preventDefault();
    alert("TENURE SHOULD NOT BE GREATER THAN 84 MONTHS");
    this.quotationDetailsModel.loanTenure = 0;
    // this.quotationdata.tenure = parseInt(value.toString().substring(0,2));
  }
}
//---------------------------------------------------------------------------------------------------------------------//
ApplyRelaxationInROI(eligibleForROIRelaxation: string) {
  console.warn("eligibleForROIRelaxation:", eligibleForROIRelaxation);
  console.log("Original ROI (from product):", this.originalROI);

  if (eligibleForROIRelaxation === 'Yes') {
    this.rateofinterest = this.originalROI - 0.25;
    this.quotationDetailsModel.rateOfInterest = this.rateofinterest;

    console.log("RELAXATION APPLIED. NEW ROI:", this.rateofinterest);
  } else if (eligibleForROIRelaxation === 'No') {
    this.rateofinterest = this.originalROI;
    this.quotationDetailsModel.rateOfInterest = this.originalROI;

    console.log("NO RELAXATION. ROI RESET TO ORIGINAL:", this.originalROI);
  }
}
//---------------------------------------------------------------------------------------------------------------------//

calculateTotalConsideredCost(){

  if(this.quotationDetailsModel.showroomPrice==null){
    this.quotationDetailsModel.showroomPrice=0;
  }
  if(this.quotationDetailsModel.rtoCharges==null){
    this.quotationDetailsModel.rtoCharges=0;
  }
  if(this.quotationDetailsModel.carInsuranceCharges==null){
    this.quotationDetailsModel.carInsuranceCharges=0;
  }
  if(this.quotationDetailsModel.totalCostToConsider==null){
    this.quotationDetailsModel.totalCostToConsider=0;
  }
  
  this.quotationDetailsModel.totalCostToConsider=Number(this.quotationDetailsModel.showroomPrice)+Number(this.quotationDetailsModel.rtoCharges)+Number(this.quotationDetailsModel.carInsuranceCharges);
  
}

//---------------------------------------------------------------------------------------------------------------//
  
openVerticallyCentered(content: TemplateRef<any>) {
  setTimeout(() => {
    this.modalService.open(content, {
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'md',
      centered: true,
    });
  }, 0);
}

//---------------------------------------------------------------------------------------------------------------//
  verifyPan(content: TemplateRef<any>){
    this.isSpinnerLoading=true;
    this.panModel.pan=this.pan;
    console.log("PAN MODEL"+JSON.stringify(this.panModel))
    this.pangstService.postPANData(this.panModel).subscribe((response)=>{
      this.isSpinnerLoading=false;
      console.log(response);
      // this.quotationDetailsModel.dealerPan=this.panModel.pan;
      this.openVerticallyCentered(content);
    },(error)=>{
      this.isSpinnerLoading=false;

      alert('Unable To Fetch PAN data')
      console.log(error)
    })
  }
//---------------------------------------------------------------------------------------------------------------//

gstnverifyflag:string='no'
verifyGstn(){
  this.isSpinnerLoading=true
  this.gstnverifyflag = 'yes'
  
  this.pangstService.getGSTData(this.quotationDetailsModel.dealergstn).subscribe((response) => {
  this.gstDataModel=response;
  this.quotationDetailsModel.dealergstn=this.gstDataModel.gstin;
  this.quotationDetailsModel.legalName=this.gstDataModel.legalNameOfBusiness ;
  this.quotationDetailsModel.dealerAddress=this.gstDataModel.principalPlaceOfBusinessAddress ;
  this.quotationDetailsModel.dealerTradeName=this.gstDataModel.tradeName ;
  this.quotationDetailsModel.gstnNumber=this.gstDataModel.gstin;
  this.isSpinnerLoading=false;
  },(error)=>{
  this.isSpinnerLoading=false;
  console.log(error);
  })
}
//---------------------------------------------------------------------------------------------------------------//
disablepanFlag:string='no';
disablePanField(){
  this.disablepanFlag='yes';
  this.modalService.dismissAll();
  this.quotationDetailsModel.dealerPan = this.panModel.pan;
}
//---------------------------------------------------------------------------------------------------------------//
rejectGstn(){
  if(confirm("ARE YOU SURE GSTN DATA IS INCORRECT. YOU WILL BE REDIRECTED TO DASHBOARD ?")){
    this.router.navigate(['/carloanV2'])
    this.gstnverifyflag='no';
    this.GSTNForVerification="";

    this.resetGstData();
    this.modalService.dismissAll();
  }else{
    console.log("remain on same page"); 
  }
}
//---------------------------------------------------------------------------------------------------------------//
resetGstData(){
    this.gstDataModel.additionalPlaceOfBusinessAddress="";
    this.gstDataModel.centreJurisdiction="";
    this.gstDataModel.centreJurisdictionCode="";
    this.gstDataModel.constitutionOfBusiness="";
    this.gstDataModel.dateOfCancellation="";
    this.gstDataModel.dateOfRegistration="";
    this.gstDataModel.taxpayerType="";
    this.gstDataModel.tradeName="";
    this.gstDataModel.pan="";
    this.gstDataModel.principalPlaceOfBusinessAddress="";
    this.gstDataModel.stateJurisdiction="";
    this.gstDataModel.stateJurisdictionCode="";
    this.gstDataModel.gstin="";
    this.gstDataModel.gstinStatus="";
    this.gstDataModel.lastUpdatedDate="";
    this.gstDataModel.legalNameOfBusiness="";
    this.gstDataModel.natureOfBusiness="";
    this.quotationDetailsModel.dealerTradeName="";
    this.quotationDetailsModel.legalName="";
    this.quotationDetailsModel.dealerAddress="";   
    this.quotationDetailsModel.dealergstn="";
    this.GSTNForVerification="";
  }
  //---------------------------------------------------------------------------------------------------------------//
  modelEditPan(){
    this.gstnverifyflag='no'
    this.quotationDetailsModel.dealergstn="";
    this.quotationDetailsModel.dealerTradeName="";
    this.resetGstData();
    this.modalService.dismissAll();
  }

//-----------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------------------------------------------------------------//
fetchedprodcode:any;

roipopulate(productCode: any) {
  console.log("Selected product code:", productCode);

  const selected = this.productdetailsList.find(p => p.productCode === productCode);

  if (selected) {
    this.rateofinterest = selected.rateOfInterest;
    this.originalROI = selected.rateOfInterest;  // Save original value for reset later
    this.quotationDetailsModel.rateOfInterest = selected.rateOfInterest;
    this.fetchedprodcode = productCode;
    this.quotationDetailsModel.eligibleForROIRelaxation = '';

    console.warn("ROI as per selected product:", selected.rateOfInterest);
  } else {
    console.error("Product code not found in productdetails:", productCode);
    this.rateofinterest = 0;
    this.quotationDetailsModel.rateOfInterest = 0;
    this.originalROI = 0;
  }
}

// -------------------------------------- REDIRECT METHODS ---------------------------------------------//
goBack() {
  this.router.navigate(['/carLoanV2/income-main-list'])
}

goNext(){
  this.router.navigate(['/carLoanV2/calculation']);
}

}
