import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BorrowerFirmComponent } from './borrower-firm.component';

describe('BorrowerFirmComponent', () => {
  let component: BorrowerFirmComponent;
  let fixture: ComponentFixture<BorrowerFirmComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BorrowerFirmComponent]
    });
    fixture = TestBed.createComponent(BorrowerFirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
