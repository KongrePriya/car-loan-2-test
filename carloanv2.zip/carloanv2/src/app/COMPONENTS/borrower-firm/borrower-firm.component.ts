import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { CibilCrifStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-STATUS.model';
import { ErrorModel, FirmBorrowerDetailsModel, GSTInfoModel, PANmodel } from 'src/app/MODELS/firmBorrowerDetails.model';
import { AppraisalNoteService } from 'src/app/SERVICES/appraisal-note/appraisal-note.service';
import { CibilCrifStatusService } from 'src/app/SERVICES/CIBIL-CRIF-STATUS/cibil-crif-status.service';
import { FirmService } from 'src/app/SERVICES/firmdetails/firm.service';
import { PangstService } from 'src/app/SERVICES/pan-gst-verification/pangst.service';
import { StatesServiceService } from 'src/app/SERVICES/States-Service/states-service.service';

@Component({
  selector: 'app-borrower-firm',
  templateUrl: './borrower-firm.component.html',
  styleUrls: ['./borrower-firm.component.css']
})
export class BorrowerFirmComponent implements OnInit {
  isSpinnerLoading = false;

  // formTitleList = {
  //   applicant: "Firm Details",
  // };

  // formName: string = this.formTitleList.applicant;

  referenceId!: string;
  userModelData = {} as UserModelData;
  panForVerification: string = "";
  GSTNForVerification: string = "";
  maxDate!: string; // or Date
  dataIsAvailable:boolean=false;

  states: string[]=[];

  constructor(
    private router: Router,
    private firmDetailsService: FirmService,
    private modalService: NgbModal,
    private pangstService: PangstService,
    private statesService: StatesServiceService,
    private toastr : ToastrService,
    private cibilCrifStatusService: CibilCrifStatusService,
    private appraisalNoteService : AppraisalNoteService,


  ) {}

  firmBorrowerDetailsModel = {} as FirmBorrowerDetailsModel;

    //CIBIL/CRIF STATUS
    cibilCrifStatusModel = {} as CibilCrifStatusModel;
    
    //this will check if data for cibil is available or not
    hideButtonCibilCrifNotAvailble:string='no'

  firmGSTModel = {} as GSTInfoModel;

  showSaveDatabutton!: boolean;
  businessLegalName: string = "";

  fetchedGstnData: any; //to assign fetched data fields also have additional fields
  gstverified: boolean = false;
  // For Pan To BE entered to open Dialog Box Simple
  isPanEntered: boolean = false;
  disablepanFlag: string = "no";
  gstnverifyflag: string = "no";
  panModel = {} as PANmodel;
  checkGSTNComingFromPan:string[]=[];


  @ViewChild('firmForm') firmForm!: NgForm;

  //********************************** NG ONINIT*********************************************** */

  ngOnInit(): void {

    const abc = sessionStorage.getItem("userModelData");
    this.userModelData = JSON.parse(abc!);
    const today = new Date();
    this.maxDate = today.toISOString().split('T')[0];
    this.getFirmDetailsWithfetchedGstnData(this.userModelData.referenceId);

    this.firmBorrowerDetailsModel.firmCustomerType = this.userModelData.custType;
    this.firmBorrowerDetailsModel.firmTypeOfBorrower = this.userModelData.custType;

    if (this.firmBorrowerDetailsModel.firmTypeOfBorrower == undefined) {
      this.firmBorrowerDetailsModel.firmTypeOfBorrower = "";
      this.firmBorrowerDetailsModel.firmBusinessSector = "";
      this.firmBorrowerDetailsModel.firmNatureOfBusiness = "";
      this.firmBorrowerDetailsModel.firmSalutation = "";
      this.firmBorrowerDetailsModel.firmSourceOfNetWorth = "";
    }
    this.referenceId = this.userModelData.referenceId;
    console.log("THIS IS USER MODEL DATA FIRM " + JSON.stringify(this.userModelData));
    this.firmBorrowerDetailsModel.firmReferenceId = this.referenceId;
    this.firmBorrowerDetailsModel.userId= this.userModelData.userId;
    this.firmBorrowerDetailsModel.firmBranchName = this.userModelData.brcode;
    this.firmBorrowerDetailsModel.firmBranchCode = this.userModelData.brcode;
    this.firmBorrowerDetailsModel.firmRoName = this.userModelData.roname;
    this.firmBorrowerDetailsModel.firmSalutation = "M/s";
    this.checkCibilCrifStatus();
}
  /*****************************************GET STATE LIST****************************************************************** */

    getStateList(){

    
      this.statesService.getStates().subscribe(data => {
      
        this.states = data;
       
      });
    } 

  /*****************************************Disabled pan field****************************************************************** */
  disablePanField() {
    // this.disablepanFlag = "yes";
    this.modalService.dismissAll();
  }

  
  /*****************************************Reject GSTN  field****************************************************************** */
  
  rejectGstn() {
  this.gstnverifyflag='no';
  this.GSTNForVerification="";
  this.resetGstData();
  }

  /*****************************************Edit Pan GSTN  field****************************************************************** */

  modelEditPan() {
    this.gstnverifyflag = "no";
    this.GSTNForVerification = "";
    this.panForVerification = "";
    this.firmBorrowerDetailsModel.firmPan="";
    this.firmBorrowerDetailsModel.firmGstn="";
    this.resetGstData();
    this.modalService.dismissAll();
  }

  //*********************************************Reset Gst Data While Edit The Pan Button Click********************************************************** */
  
  resetGstData(){

    this.firmGSTModel.additionalPlaceOfBusinessAddress="";
    this.firmGSTModel.centreJurisdiction="";
    this.firmGSTModel.centreJurisdictionCode="";
    this.firmGSTModel.constitutionOfBusiness="";
    this.firmGSTModel.dateOfCancellation="";
    this.firmGSTModel.dateOfRegistration="";
    this.firmGSTModel.taxpayerType="";
    this.firmGSTModel.tradeName="";
    this.firmGSTModel.pan="";
    this.firmGSTModel.principalPlaceOfBusinessAddress="";
    this.firmGSTModel.stateJurisdiction="";
    this.firmGSTModel.stateJurisdictionCode="";
    this.firmGSTModel.gstin="";
    this.firmGSTModel.gstinStatus="";
    this.firmGSTModel.lastUpdatedDate="";
    this.firmGSTModel.legalNameOfBusiness="";
    this.firmGSTModel.natureOfBusiness="";
    this.firmBorrowerDetailsModel.firmTradeName="";
    this.firmBorrowerDetailsModel.firmLegalNameOfBusiness="";
    this.firmBorrowerDetailsModel.firmRegisterAddress="";   
    this.firmBorrowerDetailsModel.firmOtherAddress="";
  }
  
  
  // *******************************************************End Of Reset GST Data **************************************************************************
  //******************************************* This Function Will Get The GSTN DATA  ********************************************************************************* */
  verifyGstn() {
    this.isSpinnerLoading = true;
    this.gstnverifyflag = "yes";    
    this.pangstService.getGSTData(this.GSTNForVerification).subscribe(
      (response) => {
        this.firmGSTModel = response;
        console.warn("GSTN DATA RESPONSE: " , JSON.stringify(this.firmGSTModel))
        this.firmBorrowerDetailsModel.firmGstn = this.firmGSTModel.gstin;
        this.businessLegalName = this.firmGSTModel.legalNameOfBusiness;
        this.firmBorrowerDetailsModel.firmGstinStatus=this.firmGSTModel.gstinStatus;
        this.firmBorrowerDetailsModel.firmConstitutionOfBusiness=this.firmGSTModel.constitutionOfBusiness;
        this.firmBorrowerDetailsModel.firmDateOfRegistration=this.firmGSTModel.dateOfRegistration;
        this.firmBorrowerDetailsModel.firmPrincipalPlaceOfBusinessAddress=this.firmGSTModel.principalPlaceOfBusinessAddress;
        this.firmBorrowerDetailsModel.firmStateJurisdiction=this.firmGSTModel.stateJurisdiction;
        this.firmBorrowerDetailsModel.firmStateJurisdictionCode=this.firmGSTModel.stateJurisdictionCode;
        this.firmBorrowerDetailsModel.firmCentreJurisdiction=this.firmGSTModel.centreJurisdiction;
        this.firmBorrowerDetailsModel.firmCentreJurisdictionCode=this.firmGSTModel.stateJurisdictionCode;
        this.firmBorrowerDetailsModel.firmLastUpdatedDate=this.firmGSTModel.lastUpdatedDate;
        this.firmBorrowerDetailsModel.firmTaxpayerType=this.firmGSTModel.taxpayerType;
        this.firmBorrowerDetailsModel.firmAdditionalPlaceOfBusinessAddress=this.firmGSTModel.additionalPlaceOfBusinessAddress;
        this.firmBorrowerDetailsModel.firmDateOfCancellation=this.firmGSTModel.dateOfCancellation;
        this.firmBorrowerDetailsModel.firmTradeName = this.firmGSTModel.tradeName;
        this.firmBorrowerDetailsModel.firmLegalNameOfBusiness = this.firmGSTModel.legalNameOfBusiness;
        this.firmBorrowerDetailsModel.firmRegisterAddress=this.firmGSTModel.principalPlaceOfBusinessAddress;
        if(this.firmGSTModel.additionalPlaceOfBusinessAddress=='' || this.firmGSTModel.additionalPlaceOfBusinessAddress==null){
          this.firmBorrowerDetailsModel.firmOtherAddress='';
        }else{
          this.firmBorrowerDetailsModel.firmOtherAddress=this.firmGSTModel.additionalPlaceOfBusinessAddress;

        }
        this.isSpinnerLoading = false;
      },
      (error) => {
        this.isSpinnerLoading = false;
   
        console.error("GSTN DATA Error  "+error);
      }
    );
  }
  
  //--------------------------------- Verify Pan --------------------------------------//
  verifyPan(content: TemplateRef<any>) {
    if(this.gstnverifyflag==='yes'){
      this.modelEditPan();
    }
   // this.openVerticallyCentered(content);
    this.isSpinnerLoading = true;
  //  console.log("Pan Model "+this.panModel);
    this.panModel.pan=this.panForVerification;
    this.pangstService.postPANData(this.panModel).subscribe(
      (response) => {
        this.isSpinnerLoading = false;
        console.log("Pan Model Response"+JSON.stringify(response));
        this.firmBorrowerDetailsModel.firmPan=this.panModel.pan;
        this.openVerticallyCentered(content);
      },
      (error) => {
        this.isSpinnerLoading = false;
      }
    );
  }

  openVerticallyCentered(content: TemplateRef<any>) {
    setTimeout(() => {
      this.modalService.open(content, {
        scrollable: true,
        backdrop: "static",
        keyboard: false,
        size: "md",
        centered: true,
      });
    }, 0);
  }

  closeModel(){
    this.modalService.dismissAll()
    }

  openVerticallyModelToconfirm(content: TemplateRef<any>) {
    console.log("inside openVerticallyModelToconfirm");
    
    if (!this.firmForm.valid) {
      console.log(" Firm Form is not valid!");
      this.toastr.info("Kindly Fill all the Required Fields to Proceed Further.");
      this.isSpinnerLoading = false;
      return; // Exiting method if the form is not valid
    } else{
    setTimeout(() => {
      this.modalService.open(content, {
        scrollable: true,
        backdrop: "static",
        keyboard: false,
        size: "md",
        centered: true,
      });
    }, 0);
  }
}

//********************this will save data into matchedGstnDataModel as soon as it been verify ***************************************************************************************************************************************************************** */

  getFirmDetailsWithfetchedGstnData(referenceId:string) {
    console.log("In GSTN Get Data"+referenceId);
   this.isSpinnerLoading=true;
  //  this.dataIsAvailable=true;
    this.firmDetailsService
     .getFirmDetails(referenceId)
    .subscribe(
        (response: FirmBorrowerDetailsModel) => {
          this.isSpinnerLoading=false;
        
          console.log("In Save Firm Details");
          if (response!=null) {
            console.log("Firm Borrower Details"+JSON.stringify(this.firmBorrowerDetailsModel));
            this.firmBorrowerDetailsModel=response;
            
            this.panForVerification=this.firmBorrowerDetailsModel.firmPan;
          this.firmBorrowerDetailsModel.firmRegisterState=this.firmBorrowerDetailsModel.firmRegisterState;
          this.firmBorrowerDetailsModel.firmOtherState=this.firmBorrowerDetailsModel.firmOtherState;
                console.warn("this.firmBorrowerDetailsModel.firmRegisterState :"+this.firmBorrowerDetailsModel.firmRegisterState);           
            this.dataIsAvailable=true;       
          }
          else{
            this.firmBorrowerDetailsModel.firmSourceOfNetWorth="";
            this.firmBorrowerDetailsModel.firmBusinessSector="";
            this.firmBorrowerDetailsModel.firmNatureOfBusiness="";
            this.firmBorrowerDetailsModel.firmTypeOfBorrower="";
            this.firmBorrowerDetailsModel.firmSourceOfNetWorth="";
            this.dataIsAvailable=false;
            this.getStateList();
          }
        },
         (error: any) => {
          this.isSpinnerLoading=true;
      this.toastr.error('Error Occur'+error)
         }
      );
  }

  onDateInput(event: Event) {
        const inputElement = event.target as HTMLInputElement;
        const selectedDate = inputElement.value;
        if (selectedDate > this.maxDate) {
            inputElement.value = ''; // Clear the input if the date is invalid
        }
    }
 
  
  onSubmit() {
    // this.checkCibilCrifStatus();
    this.closeModel()
    this.isSpinnerLoading=true;
    if (!this.firmForm.valid) {
      console.log(" Firm Form is not valid!");
      this.toastr.info("Kindly Fill all the Required Fields to Save the details");
      this.isSpinnerLoading = false;
      return; // Exiting method if the form is not valid
    } 
    this.firmBorrowerDetailsModel.firmReferenceId =
      this.referenceId;
      this.firmBorrowerDetailsModel.commCrifFetchedFor="BORROWER";
     console.log("Firm Details" + JSON.stringify(this.firmBorrowerDetailsModel));

    this.firmDetailsService.saveFirmDetailsAndFetchCibil(this.firmBorrowerDetailsModel)
    .subscribe(
      (response: ErrorModel) => {
        this.isSpinnerLoading=false;
        if (response.status === "200" || response.statusCode === 200) {
          this.toastr.success("FIRM/BORROWER DETAILS SAVED.","CIBIL FETCHED SUCCESSFULLY...!!!" ,{timeOut:1000});
          console.log(JSON.stringify(response));
         this.goNext();
        } 
      },
      (error) => {
        console.error("ERROR WHILE SAVING AND FETCHING FIRM/BORROWER CIBIL: "+ JSON.stringify(error));
      this.isSpinnerLoading=false;
      }
    );  
  }

  //*****************************************Without Fetch Cibil******************************************************************** */

  onSubmitWithoutCibil(){
    // this.checkCibilCrifStatus();
    this.closeModel()
    this.isSpinnerLoading=true;
    if (!this.firmForm.valid) {
      console.log("Firm Form is not valid!");
      this.toastr.info("Kindly Fill all the Required Fields to Save the details");
      this.isSpinnerLoading = false;
      return; // Exiting method if the form is not valid
    } 
    this.firmBorrowerDetailsModel.firmReferenceId = this.referenceId;
     console.log("Firm Details" + JSON.stringify(this.firmBorrowerDetailsModel));
    this.firmDetailsService
      .saveFirmDetailswithoutCibil(this.firmBorrowerDetailsModel)
      .subscribe(
        (response: ErrorModel) => {
          
          this.isSpinnerLoading=false;
          if (response.status === "200" || response.statusCode === 200) {
            console.log(JSON.stringify(response));
            this.router.navigate(["/gstmsme/firmcibil"]);
          } 
        },
        (error) => {
              this.toastr.error(`ERROR WHILE UPDATING FIRM/BORROWER DETAILS: ${error.message}`);
        console.error("ERROR WHILE UPDATING FIRM/BORROWER DETAILS: "+ JSON.stringify(error));

        this.isSpinnerLoading=false;
        }
      );
  }

// ************************************************** Check CIBIL CRIF Status *************************************************
//Check CIBIL / CRIF STATUS 
checkCibilCrifStatus(){
  this.isSpinnerLoading=true;
  this.cibilCrifStatusService.getAllCibilCrifStatus(this.userModelData.referenceId).subscribe((response) => {
      if(response!=null){
        this.cibilCrifStatusModel=response;
        console.warn("firmComCibilUptoDate : IF TRUE ALLOW PROCEED WITHOUT FETCHING CIBIL : " +this.cibilCrifStatusModel.firmComCibilUptoDate);
        }
    console.log("cibil crif status" + JSON.stringify(response));
    this.isSpinnerLoading=false;
  },(error) => {
    this.isSpinnerLoading=false;
    console.log("ERROR OCCURED " + JSON.stringify(error));     
  })
}

// **************************************** REDIRECT TO NEXT PAGE  ************************************* 
goNext(){
    this.router.navigate(['/carLoanV2/guarantor-corporate'])
}
goBack(){
  // this.router.navigate(['/homeloan/applicant-form'])
  alert("PATH NOT CONFIGURED YET.")
}


}
