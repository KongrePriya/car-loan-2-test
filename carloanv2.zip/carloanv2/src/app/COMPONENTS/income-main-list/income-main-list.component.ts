import { Component, TemplateRef, ViewChild } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { IncomeBusinessMainModel } from 'src/app/MODELS/income-business.model';
import { IncomeDetailsListModel } from 'src/app/MODELS/income-list.model';
import { IncomePensionerModel } from 'src/app/MODELS/income-pensioner-model';
import { IncomeSalariedModel } from 'src/app/MODELS/income-salaried.model';
import { IncomeDetailsForAllService } from 'src/app/SERVICES/Income-Details/income-details-all.service';
@Component({
  selector: 'app-income-main-list',
  templateUrl: './income-main-list.component.html',
  styleUrls: ['./income-main-list.component.css']
})
export class IncomeMainListComponent {

  @ViewChild('mySalaryModal') mySalaryModal!: TemplateRef<any>;
  @ViewChild('myBusinessModal') myBusinessModal!: TemplateRef<any>;
  @ViewChild('myPensionModal') myPensionModal!: TemplateRef<any>;


  userModelData = {} as UserModelData;
  incomeDetailsListModelArray: Array<IncomeDetailsListModel> = [];
  incomeSalaryModel = {} as IncomeSalariedModel;
  incomePensionModel = {} as IncomePensionerModel;
  incomeBusinessMainModel = {} as IncomeBusinessMainModel;
  // incomeBusinessDetailModel = {} as IncomeBusinessDetailModel;
  isSpinnerLoading = false;
  incomeCount:string = "";
  disableNext:boolean = false;

  

  ngOnInit(): void {
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);

    this.getAllIncomeDetailsList();
    this.getCountIncomeDetails();
  }

  // -------------------------------------- Constructor ---------------------------------------------
  constructor(private incomeDetailsForAllService: IncomeDetailsForAllService, private router: Router,
    private toastr: ToastrService, private activatedRoute: ActivatedRoute, private modalService: NgbModal
  ) {
  }


  // -------------------------------------- Get All Income-Details List ---------------------------------------------

  getAllIncomeDetailsList() {
    // alert(this.userModelData.referenceId);
    this.isSpinnerLoading = true;
    this.incomeDetailsForAllService.getIncomeListMain(this.userModelData.referenceId).subscribe((response) => {
      this.isSpinnerLoading = false;
      if (response != null) {
        // console.log(response)
        this.incomeDetailsListModelArray = response;
        // this.incomeDetailsListModelArray.sort((a, b) => b.customerType.localeCompare(a.customerType));
        this.sortByCustomerType();
      }
    }, (error) => {
      this.isSpinnerLoading = false;
      this.disableNext = true;
      console.log("Error Occured While Getting Income Details List" + JSON.stringify(error));
    })
  }


  // -------------------------------------- Route To Respective Income Page ---------------------------------------------
  routeToRespectiveIncomePage(incomeType: string, pan: string, customerType: string, fullName: string) {
    if (incomeType == "Salaried") {
      this.router.navigate(["carLoanV2/income-salaried"],
        {
          queryParams: { panNumber: pan, custType: customerType, customerName: fullName}
        }
      );
    }
    if (incomeType == "Business") {
      this.router.navigate(["carLoanV2/income-business"],
        {
          queryParams: { panNumber: pan, custType: customerType, customerName: fullName }
        }
      );
    }
    if (incomeType == "Pensioner") {
      this.router.navigate(["carLoanV2/income-pensioner"],
        {
          queryParams: { panNumber: pan, custType: customerType, customerName: fullName }
        }
      );
    }
  }


  // -------------------------------------- Get All Income-Details Count To Enable Next Button ---------------------------------------------

  getCountIncomeDetails() {
    this.isSpinnerLoading = true;
    this.incomeDetailsForAllService.getIncomeCount(this.userModelData.referenceId).subscribe((response) => {
      this.isSpinnerLoading = false;
      if (response != null) {
        this.incomeCount = response;
      }
    }, (error) => {
      this.isSpinnerLoading = false;
      this.disableNext=true;
      console.log("Error Occured While Getting Count Income Details" + JSON.stringify(error));
    })
  }


  // -------------------------------------- Get All Income-Details For Pop-Up ---------------------------------------------

  viewIncomeDetails(pan:string, incomeType:string){
    if(incomeType=='Salaried'){
      this.getSalaryDetails(pan);
      this.openSalaryPopUp(this.mySalaryModal);
    }
    if(incomeType=='Business'){
      this.getBusinessDetails(pan);
      this.openBusinessPopUp(this.myBusinessModal);
    }
    if(incomeType=='Pensioner'){
      this.getPensionDetails(pan);
      this.openPensionPopUp(this.myPensionModal);
    }
  }

  // -------------------------------------- View -> Get Income-Salary ---------------------------------------------
  getSalaryDetails(pan:string){
    this.isSpinnerLoading=true;
    
    
    this.incomeDetailsForAllService.getIncomeDetailsSalaried(this.userModelData.referenceId,pan).subscribe((response) => {
    
      
      this.isSpinnerLoading=false;
      if(response!=null){
        this.incomeSalaryModel = response;
        console.log(response);
        
      }else{
        this.toastr.info("No Salary Data Available");
        this.closeModel();
      }
    },(error) => {
      this.isSpinnerLoading=false;
      console.log("Error Occurred in Get Income Salary" + JSON.stringify(error));
    })
  }


  // -------------------------------------- View -> Get Income-Business ---------------------------------------------
  getBusinessDetails(pan:string){
    this.isSpinnerLoading=true;
    this.incomeDetailsForAllService.getIncomeDetailsBusiness(this.userModelData.referenceId,pan).subscribe((response) => {
      this.isSpinnerLoading=false;
      if(response!=null){
        this.incomeBusinessMainModel = response;
        console.log(response);
        
      }else{
        this.toastr.info("No Business Data Available");
        this.closeModel();
      }
    },(error) => {
      this.isSpinnerLoading=false;
      console.log("Error Occurred in Get Income Salary" + JSON.stringify(error));
    })
  }


  // -------------------------------------- View -> Get Income-Pension ---------------------------------------------
  getPensionDetails(pan:string){
    this.isSpinnerLoading=true;
    this.incomeDetailsForAllService.getIncomeDetailsPensioner(this.userModelData.referenceId,pan).subscribe((response) => {
      this.isSpinnerLoading=false;
      if(response!=null){
        this.incomePensionModel = response;
      }else{
        this.toastr.info("No Pension Data Available");
        this.closeModel();
      }
    },(error) => {
      this.isSpinnerLoading=false;
      console.log("Error Occurred in Get Income Salary" + JSON.stringify(error));
    })
  }


  // -------------------------------------- Close Model ---------------------------------------------
  closeModel(){
    this.modalService.dismissAll();
  }



// -------------------------------------- Open Salary Pop-Up ---------------------------------------------
  openSalaryPopUp(content: TemplateRef<any>) {
    setTimeout(() => {
      this.modalService.open(content, {
        scrollable: true,
        backdrop: 'static',
        keyboard: false,
        size: 'xl',
        centered: true,
      });
    }, 0);
  }


// -------------------------------------- Open Business Pop-Up ---------------------------------------------
  openBusinessPopUp(content: TemplateRef<any>) {
    setTimeout(() => {
      this.modalService.open(content, {
        scrollable: true,
        backdrop: 'static',
        keyboard: false,
        size: 'xl',
        centered: true,
      });
    }, 0);
  }


// -------------------------------------- Open Pension Pop-Up ---------------------------------------------
  openPensionPopUp(content: TemplateRef<any>) {
    setTimeout(() => {
      this.modalService.open(content, {
        scrollable: true,
        backdrop: 'static',
        keyboard: false,
        size: 'xl',
        centered: true,
      });
    }, 0);
  }


  sortByCustomerType(): void {
    this.incomeDetailsListModelArray = [...this.incomeDetailsListModelArray].sort((a, b) => a.customerType.localeCompare(b.customerType)); // Creating a new array
  }

  goNext(){
    this.router.navigate(['/carLoanV2/quotation-details']);
  }

  goBack(){
      this.router.navigate(['/carLoanV2/itr-list']);
    }

}




