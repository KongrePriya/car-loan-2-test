import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeMainListComponent } from './income-main-list.component';

describe('IncomeMainListComponent', () => {
  let component: IncomeMainListComponent;
  let fixture: ComponentFixture<IncomeMainListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IncomeMainListComponent]
    });
    fixture = TestBed.createComponent(IncomeMainListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
