import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { ItrFilingDetailsModel } from 'src/app/MODELS/itrFilingDetailsModel.model';
import { ItrRequestDataLotus, itrVerificationRequestModel, itrVerificationResponseModel, ItrVerifiedRefIdResponse } from 'src/app/MODELS/itrVerificationModel.model';
import { ItrDetailsDisplayService } from 'src/app/SERVICES/itr-details-display/itr-details-display.service';
import { ItrVerificationService } from 'src/app/SERVICES/itr-verification/itr-verification.service';
@Component({
  selector: 'app-itr-verify-coapp2',
  templateUrl: './itr-verify-coapp2.component.html',
  styleUrls: ['./itr-verify-coapp2.component.css']
})
export class ItrVerifyCoapp2Component  implements OnInit {

  @ViewChild('itrform') itrform!: NgForm;

 isSpinnerLoading:boolean = false;
 itrMailSent:boolean = false;
 itrIdGenerated:boolean = false;
 isConsentGiven: boolean = false;
 consentToRefetch: boolean = false;
 proceedWithoutRefetch: boolean = false;
 itrVerificationRequestModel ={} as itrVerificationRequestModel;
 itrVerificationResponseModel ={} as itrVerificationResponseModel;
 itrReferenceId!:string;
 itrRequestDataLotus={} as ItrRequestDataLotus;
 userModelData = {} as UserModelData;
 itrAlreadyFetched:boolean = false;
 itrRefIdGenerated:boolean = false;
 itrFilingDetailsModel ={} as ItrFilingDetailsModel;
 itrVerifiedRefIdResponse ={}  as ItrVerifiedRefIdResponse;
 fetchErrorOccurred: boolean = false; //in case of time out or error
 previousVerificationFailed: boolean=false;
 itrConsentProvidedRefId:boolean = false;
 finalErrorMessage!:string;


 constructor(
  private router: Router,
  private toastr:ToastrService,
  private itrVerificationService:ItrVerificationService,
  private itrDetailsDisplayService : ItrDetailsDisplayService,
  ) {}
 
 
  ngOnInit(): void {
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    console.warn("USER DATA MODEL:", this.userModelData);
   
    // this.userModelData.referenceId='MGBHOME12345'
    this.getITRDetailsToCheck();
    this.getITRVerifiedReferenceIdDetails();

    if(this.itrReferenceId !=null){
      this.itrMailSent=true;
    }
  }

// ******************************** ITR VERIFICATION BY EMAIL METHOD ********************************//

sendDataToVerifyItr() {
  this.isSpinnerLoading = true;

  if (!this.itrform.valid) {
    console.log("ITR Verification Form is not valid!");
    this.toastr.info("Kindly Fill all the Required Fields to Proceed");
    this.isSpinnerLoading = false;
    return; // Exiting method if the form is not valid
  } 
  else{
    // //DUMMY
    // this.itrMailSent=true;
    // this.isSpinnerLoading = false;
    // //DUMMY-END

this.itrVerificationRequestModel = {
  email:this.itrVerificationRequestModel.email,
  notificationEmail:this.itrVerificationRequestModel.notificationEmail,
  // referenceIdItr: this.itrReferenceId,
  referenceIdLotus: this.userModelData.referenceId,
  branchCode: this.userModelData.brcode,
  fetchedBy:this.userModelData.userId,
  customerType:'COAPPLICANT2',
  fetchDate:''
}
console.warn("REQUEST FOR EMAIL VERIFICATION :itrVerificationRequestModel :"+JSON.stringify(this.itrVerificationRequestModel));

  this.itrVerificationService.generateRefIdForVerification(this.itrVerificationRequestModel).subscribe(
    (response) => { 

      this.itrVerificationResponseModel=response;
      console.log("Response from generateRefIdForVerification : ", this.itrVerificationResponseModel);

      console.log("Response from generateRefIdForVerification: JSON:", JSON.stringify(this.itrVerificationResponseModel));
     this.itrMailSent=true;
    //  this.itrReferenceId=this.itrVerificationResponseModel.data.referenceId;
     this.itrReferenceId=response.data.referenceId;
     if( this.itrReferenceId !=null){
      this.itrIdGenerated=true;
      console.warn("ITR VERIFICATION REFERENCE ID: "+this.itrVerificationResponseModel.data.referenceId );
     }else{
      this.itrIdGenerated=false;
      console.warn("ITR VERIFICATION REFERENCE ID Null : "+this.itrVerificationResponseModel.data.referenceId );
     }
      this.isSpinnerLoading=false;
  },
  (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GERERATING REFERENCE-ID FOR ITR VERIFICATION : "+error)
  }
);
}
}

// ******************************** ITR FETCH DETAILS FROM REFERENCE-ID (ITR REQUEST DATA MODEL) ********************************//

timeRemaining: number = 300; // 5 minutes in seconds
timer: any; // To hold the setInterval reference

generateItrdetailsByRefId() {
  this.isSpinnerLoading = true;
  this.timeRemaining = 300; // Reset timer to 5 minutes
  this.startTimer(); // Start the timer

  console.warn("GENERATED REF ID FOR ITR: " + this.itrReferenceId);
  
  if (this.itrReferenceId != null) {
    this.itrRequestDataLotus = {
      referenceIdItr: this.itrReferenceId,
      referenceIdLotus: this.userModelData.referenceId,
      branchCode: this.userModelData.brcode,
      fetchedBy: this.userModelData.userId,
      customerType: 'COAPPLICANT2',
      fetchDate: ''
    };

    console.log("ITR REQUEST DATA MODEL CREATED: " + JSON.stringify(this.itrRequestDataLotus));
    
    this.itrVerificationService.fetchDetailsFromRefId(this.itrRequestDataLotus).subscribe(
      (response) => { 
        console.log("Response from generateItrdetailsByRefId: ", JSON.stringify(response));
        this.goToViewItrDetails();
        this.isSpinnerLoading = false; // Stop spinner on success
        this.stopTimer(); // Stop the timer on success
      },
      (error: HttpErrorResponse) => {
        this.isSpinnerLoading = false; 
        this.fetchErrorOccurred = true;
        // this.toastr.error(error.message); 
        console.error("ERROR WHILE GENERATING REFERENCE-ID FOR ITR VERIFICATION: ", error);

       
          // Extract error details
          const errorMessage = error.error ? JSON.parse(error.error).message : 'Check if Email Consent is successfully Provided, Kindly provide the consent then Click on Proceed to Fetch ITR Details';
          this.finalErrorMessage=errorMessage.replace(/\\n/g, '<br>');
          // Display the toaster message
          this.toastr.error(this.finalErrorMessage);
        this.stopTimer(); // Stop the timer on error
      }
    );
  } else {
    this.isSpinnerLoading = false; // Stop spinner if ref ID is null
    this.toastr.error("ITR Reference-ID is Empty, Kindly Contact Concerned Department.");
    this.stopTimer(); // Stop timer if ref ID is null
  }
}

startTimer() {
  this.timer = setInterval(() => {
    if (this.timeRemaining > 0) {
      this.timeRemaining--;
    } else {
      this.stopTimer(); // Stop the timer when it reaches zero
      this.toastr.error("Request timed out. Please try again.");
    }
  }, 1000); // Update every second
}

stopTimer() {
  if (this.timer) {
    clearInterval(this.timer);
    this.timer = null; // Reset the timer reference
  }
}

// Method to format the time remaining
formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

ngOnDestroy() {
  this.stopTimer(); // Ensure timer is cleared when component is destroyed
}

// **************************** METHOD TO GET ITR DETAILS :TO CHECK IF DATA PRESENT OR NOT ****************************************//

getITRDetailsToCheck(){
  this.isSpinnerLoading=true;
  console.log("Inside  getITRDetails function, ref id: ", this.userModelData.referenceId);
  this.itrDetailsDisplayService.getITRFilingDetails(this.userModelData.referenceId,'COAPPLICANT2').subscribe(
    (response) => { 
      this.itrFilingDetailsModel=response;
      if(this.itrFilingDetailsModel != null){
      this.isSpinnerLoading=false;
      this.itrAlreadyFetched=true;
      }
      else{
        this.isSpinnerLoading=false;
      this.itrAlreadyFetched=false;
      }
  },
 (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GETTING  ITR DETAILS OF COAPPLICANT2 : "+error)
  }
);
}

// **************************** METHOD TO GET ITR REFERENCE-ID RESPONSE  ****************************************//
// WE CAN USE THE ITR-REF-ID ANYTIME ONCE GENERATED
getITRVerifiedReferenceIdDetails(){
  this.isSpinnerLoading=true;

  console.log("Inside  getITRVerifiedReferenceIdDetails function, ref id: ", this.userModelData.referenceId);
  this.itrDetailsDisplayService.getITRVerifiedReferenceIdDetails(this.userModelData.referenceId,'COAPPLICANT2').subscribe(
    (response) => { 
      this.itrVerifiedRefIdResponse=response;
      console.warn("RESPONSE FROM ITR REF-ID GENERATED SERVICE: "+JSON.stringify(this.itrVerifiedRefIdResponse));

      if(this.itrVerifiedRefIdResponse != null){
        this.itrReferenceId=this.itrVerifiedRefIdResponse.referenceIdItr;

      this.isSpinnerLoading=false;

      if(this.itrVerifiedRefIdResponse.consentProvided==='YES'){
      this.itrConsentProvidedRefId=true;
      }else{
        this.previousVerificationFailed=true;
      }
    }
      else{
        this.isSpinnerLoading=false;
      this.itrConsentProvidedRefId=false;
      }
  },
 (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GETTING  ITR VERIFIED REF-ID OF COAPPLICANT2 : "+error)
  }
);
}
//******************************* PROCEED TO VERIFY: AFTER TAKING CONSENT ********************************** */
//******************************* PROCEED TO VERIFY: AFTER TAKING CONSENT ********************************** */
setConsentAndFetchRefIdDetails(){
  this.setITRConsentProvided();
}

// **************************** METHOD TO SET CONSENT PROVIDED  ****************************************//
setITRConsentProvided(){
  this.isSpinnerLoading=true;

  console.log("Inside  setITRConsentProvided function, ref id: ", this.userModelData.referenceId);
  this.itrDetailsDisplayService.setITRConsentProvided(this.userModelData.referenceId,'COAPPLICANT2').subscribe(
    (response) => { 
      this.isSpinnerLoading=false;
      this.getITRVerifiedReferenceIdDetails();     
  },
 (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE SETTING CONSENT PROVIDED FIELD FOR COAPPLICANT2 : "+error)
  }
);
}

// **************************************** REFETCH ITR   ************************************* 


refetchITRDetails(){
  this.itrAlreadyFetched=false;
  this.itrMailSent=false;
  this.proceedWithoutRefetch=true;
this.itrConsentProvidedRefId=false;
}

cancelRefetchingDetails(){
  // this.itrAlreadyFetched=true;

  this.getITRDetailsToCheck();// to check whether ITR already fetched or not
  this.proceedWithoutRefetch=true;

}
// **************************************** REDIRECT TO NEXT PAGE  ************************************* 

goToViewItrDetails(){
    this.router.navigate(['/carLoanV2/coapp-two-itr-display'])
}
goBack(){
  this.router.navigate(['/carLoanV2/itr-list'])
}

}

