import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItrVerifyCoapp2Component } from './itr-verify-coapp2.component';

describe('ItrVerifyCoapp2Component', () => {
  let component: ItrVerifyCoapp2Component;
  let fixture: ComponentFixture<ItrVerifyCoapp2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ItrVerifyCoapp2Component]
    });
    fixture = TestBed.createComponent(ItrVerifyCoapp2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
