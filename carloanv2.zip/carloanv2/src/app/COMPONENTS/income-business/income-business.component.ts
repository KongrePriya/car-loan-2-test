import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { IncomeBusinessDetailModel, IncomeBusinessMainModel } from 'src/app/MODELS/income-business.model';
import { IncomeDetailsForAllService } from 'src/app/SERVICES/Income-Details/income-details-all.service';

@Component({
  selector: 'app-income-business',
  templateUrl: './income-business.component.html',
  styleUrls: ['./income-business.component.css']
})
export class IncomeBusinessComponent {
  isReadonly:boolean=false;
  panNumber: string='';
  custType: string='';
  customerName: string='';
  referenceId: string='';
  yearFlag: boolean = false;
  yearRanges: string[] = [];
  fiscalYearStartMonth: number = 3; // April (0-based index, so 3 represents April)
  ages: number[] = [];
  isSpinnerLoading = false;

  userModelData = {} as UserModelData;

  //*********************************************income main model Initialise**************************** */
    incomeBusinessMainModel: IncomeBusinessMainModel = {
    referenceId: '',
    userId: '',
    branchCode: '',
    panNumber: '',
    customerType: '',
    selectedFirstYear: '',
    selectedSecondYear: '',
    netIncomeFirstYear: 0,
    netIncomeSecondYear: 0,
    businessIncomeFirstYear: 0,
    businessIncomeSecondYear: 0,
    depreciationFirstYear: 0,
    depreciationSecondYear: 0,
    housePropertyIncomeFirstYear: 0,
    housePropertyIncomeSecondYear: 0,
    otherIncomeFirstYear: 0,
    otherIncomeSecondYear: 0,
    currentEmiDeduction: 0,
    incomeTaxDeduction: 0,
    otherDeduction: 0,
    totalCurrentDeduction: 0,
    incomeAvailableFor: '',
    customerName: '',
    incomeType: '',
    businessStandingInYears: 0,
    businessStandingInMonths: 0,
    incomeBusinessDetailModel: []
  };
 
  constructor( private activatedRoute: ActivatedRoute,private financialDetailsService: IncomeDetailsForAllService,
    private modalService: NgbModal,   private toastr : ToastrService,private router:Router ) 
  { }
 



  




  // Method to show the form for adding a new business detail entry
  divList: IncomeBusinessDetailModel[] = [];// Temporary list to store the business detail form entries

  addNewEntry() {
    const newBusinessDetail: IncomeBusinessDetailModel = {
      nameOfConstitution: '',
      natureOfBusiness: '',
      nameOfBusiness: '',
      businessSector: '',
      businessActivityDetail: '',
      businessAddress: '',
      businessPan: '',
      businessGstin: '',
      incorporationDate: '',
      customerName:this.customerName
    };
    this.divList.push(newBusinessDetail); // Add a new empty entry to the list
  }


  //*****************************************fields here to check validation for incomeDetails model

  isFormValid(): boolean {
    return this.divList.every(business => 
      business.nameOfBusiness && 
      business.nameOfConstitution && 
      business.natureOfBusiness &&
      business.businessActivityDetail && 
      business.businessAddress &&
      //business.businessGstin &&
      business.businessPan &&
      business.incorporationDate &&
      business.businessSector 
     
    );
  }

  // Method to save the new business entry into the main model 
  saveEntryToModel() {
    if (this.divList.length > 0 && this.isFormValid() ) {
      
      // Add all the new entries to the main model
      this.incomeBusinessMainModel.incomeBusinessDetailModel.push(...this.divList);

      // Clear the temporary list (form entries)
      this.divList = [];
      
      // Optionally show a success message
      alert('Entries saved successfully!');
    }
  }
  removeDiv(){
    if (this.divList.length > 0 )
    { 
      this.divList = [];
    }
    
  }

  // Method to remove the business detail from the table
  removeFromTable(index: number) {
    this.incomeBusinessMainModel.incomeBusinessDetailModel.splice(index, 1);
  }

  //************************* */ Method to submit the final data***********************************************
  submitData() {
     const result = window.confirm('Are you sure you want to proceed?');
     
    
   if (result && this.incomeBusinessMainModel.incomeBusinessDetailModel.length!==0 ) {
      console.log(this.incomeBusinessMainModel); 
      if (this.yearFlag) {
        this.toastr.info("Form is invalid due to duplicate months/year.")
      }else{
      this.isSpinnerLoading = true
      console.log(this.userModelData.referenceId);
      
      this.incomeBusinessMainModel.referenceId=this.userModelData.referenceId;
      this.incomeBusinessMainModel.userId=this.userModelData.userId;
      this.incomeBusinessMainModel.branchCode=this.userModelData.brcode;
      this.incomeBusinessMainModel.customerType=this.custType;
      this.incomeBusinessMainModel.incomeType='Business';
      this.incomeBusinessMainModel.customerName=this.customerName;
    
      this.incomeBusinessMainModel.panNumber=this.panNumber;
      this.financialDetailsService.postIncomeDetailsBusiness(this.incomeBusinessMainModel).subscribe((response) => {
            this.isSpinnerLoading=false
            this.goNext();
           // this.router.navigate(['']);
            console.log("Income Borower Response " + JSON.stringify(response));
      },(error) => {
        console.log("Error Occured In Saving Income Details - Borrower " + JSON.stringify(error));
        
        this.isSpinnerLoading=false
        alert('Data submitted successfully!');
       
      }
    
    ) 
  } // For testing purposes
     
      // Perform the action here
    } else {
      this.toastr.info('Business Detailed not added');
    }
    

}
 // ********************************************************navigate to next page
 goNext(){

  this.router.navigate(["/carLoanV2/income-main-list"])}
// ************************************************For validation of year for INCOME DETAILS AS PER ITR

checkForDuplicatesYear(): void {
  
  const year =[this.incomeBusinessMainModel.selectedFirstYear,this.incomeBusinessMainModel.selectedSecondYear];
  const filteredyear = year.filter(year => year);
  // Create a Set to track unique year
 
  const uniqueYear=new Set(filteredyear);
 
  this.yearFlag = uniqueYear.size < filteredyear.length; 
}
onYearChange(): void {
  this.checkForDuplicatesYear();
}


 // ----------------------------------------------- Get Year For Income Details as per ITR/Form 16 ---------------------------------------------
 private generateYearRanges(): void {
  const today = new Date();
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth(); // 0 = January, ..., 11 = December

  let startYear: number;

  // Determine starting year for previous fiscal years
  if (currentMonth >= this.fiscalYearStartMonth) {
    startYear = currentYear - 1; // Last fiscal year
  } else {
    startYear = currentYear - 2; // Two fiscal years ago
  }

  // Generate year ranges for previous fiscal years (excluding current FY)
  for (let i = 0; i < 3; i++) { // Only two previous fiscal years
  const yearRange = `${startYear - i}-${(startYear - i + 1).toString().slice(2,4)}`;
    this.yearRanges.unshift(yearRange); // Add to the beginning for reverse order
  }

  // Retirement Age Drop-Down
  for (let age = 1; age <= 65; age++) {
    this.ages.push(age);
  }
  
  

} 
ngOnInit(): void {
   
  const abc = sessionStorage.getItem('userModelData');
this.userModelData = JSON.parse(abc!);

this.activatedRoute.queryParams.subscribe(params => {
  this.panNumber = params['panNumber'],
  this.custType = params['custType'];
  this.customerName = params['customerName'];
  
});
this.referenceId=this.userModelData.referenceId;
//this.userModelData.referenceId='MGBHOME12345'
this.generateYearRanges();
  //Fetch financial details from the service
  this.financialDetailsService.getIncomeDetailsBusiness(this.userModelData.referenceId,this.panNumber).subscribe(data => {

    if(data!=null)
    { this.incomeBusinessMainModel= data;

      if( this.incomeBusinessMainModel.incomeAvailableFor!='Not Available')
    { 
     // this.isReadonly=true;
    }
    }
    

    console.log('business data'+ this.incomeBusinessMainModel);
    
  });


}



// ----------------------------------------------- Calculate Total Current Deducations ---------------------------------------------

calculateTotalCurrentDeductions(){
  this.incomeBusinessMainModel.totalCurrentDeduction = this.incomeBusinessMainModel.currentEmiDeduction+this.incomeBusinessMainModel.incomeTaxDeduction+this.incomeBusinessMainModel.otherDeduction
}
//// -------------------------------------------------------------Reset fields based on the selected option-------------------------------------------------------------
resetFields() {
  // Reset fields based on the selected option
  if (this.incomeBusinessMainModel.incomeAvailableFor === 'One Year') {
    this.incomeBusinessMainModel.businessIncomeFirstYear = 0;
    this.incomeBusinessMainModel.depreciationFirstYear = 0;
    this.incomeBusinessMainModel.housePropertyIncomeFirstYear = 0;
    this.incomeBusinessMainModel.netIncomeFirstYear = 0;
    this.incomeBusinessMainModel.otherIncomeFirstYear = 0;
    this.incomeBusinessMainModel.selectedFirstYear = '';
   
  } 
  // else if (this.incomeBusinessMainModel.incomeAvailableFor === 'Not Available') {
  //   this.incomeBusinessMainModel.businessIncomeFirstYear = 0;
  //   this.incomeBusinessMainModel.depreciationFirstYear = 0;
  //   this.incomeBusinessMainModel.housePropertyIncomeFirstYear = 0;
  //   this.incomeBusinessMainModel.netIncomeFirstYear = 0;
  //   this.incomeBusinessMainModel.otherIncomeFirstYear = 0;
  //   this.incomeBusinessMainModel.selectedFirstYear = '';
    
  //   this.incomeBusinessMainModel.businessIncomeSecondYear = 0;
  //   this.incomeBusinessMainModel.depreciationSecondYear = 0;
  //   this.incomeBusinessMainModel.housePropertyIncomeSecondYear = 0;
  //   this.incomeBusinessMainModel.netIncomeSecondYear = 0;
  //   this.incomeBusinessMainModel.otherIncomeSecondYear = 0;
  //   this.incomeBusinessMainModel.selectedSecondYear = '';
   
  // }
  
}


}
