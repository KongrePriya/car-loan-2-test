import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import {  IndividualCoapplicantGuarantorBasicDetails } from 'src/app/MODELS/Individual-basic-details.model';
import { CibilFetchStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-fetch-status.model';
import { AllKycInfoModel, PANverifyRequestModel } from 'src/app/MODELS/panAadharModel.model';
import { IndividualBasicDetailsService } from 'src/app/SERVICES/Basic-details-individual/individual-basic-details.service';
import { CibilFetchStatusService } from 'src/app/SERVICES/CIBIL-individual-all/cibil-details.service';
import { StatesServiceService } from 'src/app/SERVICES/States-Service/states-service.service';
import { KycPanAadharVerifyComponent } from '../kyc-pan-aadhar-verify/kyc-pan-aadhar-verify.component';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-coapp-individual',
  templateUrl: './coapp-individual.component.html',
  styleUrls: ['./coapp-individual.component.css']
})
export class CoappIndividualComponent implements OnInit{


  //*********************************** VARIABLE DECLARATION ********************************************************/

 kycFetchedData!: AllKycInfoModel;
  verified: boolean = false;
  noCoapplicant: boolean = true;
  noCoapplicantMinor: boolean = true;
  coapplicantDataPresent: boolean = false;
  coapplicantMinorDataPresent: boolean = false;
  isSpinnerLoading: Boolean = false;
  isMinor: Boolean = false;
  editingMode: boolean = false;
  showAddFormFlag: boolean = false;

  userModelData = {} as UserModelData;
  coapplicantBasicDetails = {} as IndividualCoapplicantGuarantorBasicDetails;
  existedCoapplicantBasicDetails = {} as IndividualCoapplicantGuarantorBasicDetails;
  panVerifyRequest = {} as PANverifyRequestModel;
  cibilFetchStatusModel={} as CibilFetchStatusModel;
  allcoapplicantBasicDetails: IndividualCoapplicantGuarantorBasicDetails[] = [];
  states: string[] = [];
  mergedCoapplicantDetails: any[] = [];
  editingIndex: number = -1; //-1 beacause array will have 0 index with values
  customerType: string = '';
  existingValueForITR : string = "No";
  incomeConsiderationValue: string ="No"; //intially no then Set On edit 

  incomeConsiderCount!:number;
  existingIncomeYes:string =  "undefined";

@ViewChild('coappForm') coappForm!: NgForm;

  //******************************** INITIALISED CONSTRUCTOR ***********************************************************/

  constructor(
    private router: Router,
    private modalService: NgbModal,
    private toastr: ToastrService,
    private individualBasicDetailsService: IndividualBasicDetailsService,
    private cibilFetchStatusService:CibilFetchStatusService,
    private stateListService: StatesServiceService
  ) { }

//************************************ NG ON INIT *******************************************************/

ngOnInit(): void {

  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  console.warn("USER DATA MODEL:", this.userModelData);
  this.panVerifyRequest.loanRefNo = this.userModelData.referenceId;
  // console.warn("REF NO:", this.panVerifyRequest.loanRefNo);

  this.getAllCoapplicantList();

  this.getStateList();

}

//*********************************** getStateList ********************************************************/
getStateList() {
  this.stateListService.getStates().subscribe(data => {
    this.states = data;
  });
}

//****************************************** METHOD TO OPEN MODAL ***************************************************************************** */
async openPanAadharVerificationModal() {
  //CALLED HERE SO THAT IT ONLY GET CHECKED WHILE ADDING NEW CO-APPLICANT WITHOUTING AFFECTING DISPLAY BLOCK WHILE EDITING 
      this.existingIncomeYes='New' //For New Addition
    this.incomeConsiderationValue='New';

alert(this.incomeConsiderationValue)
const modalRef = this.modalService.open(KycPanAadharVerifyComponent,
  {
    backdrop: 'static',
    keyboard: false,
    centered: true,
  });

modalRef.componentInstance.kycFetchedData.subscribe(async (data: AllKycInfoModel) => {
  try {
    await this.getkycFetchedData(data);

  } catch (error) {
    console.error('Error fetching KYC data:', error);
  }
});
this.isMinor = false;

}

//******************************* CANCEL SAVING CO-APPLICANT DATA  ****************************************//
cancelSavingCoapplicant() {
  this.verified = false;
  this.editingMode=false;
  this.resetCoapplicantForm();
  this.getAllCoapplicantList();
}

//****************************** MAJOR GET & SET DATA FROM PAN AADHAR VERIFICATION COMPONENT ******************************/

async getkycFetchedData(data: AllKycInfoModel) {
  try {
    this.kycFetchedData = data;
    console.log('Data from Aadhar to coapplicant-major component:', JSON.stringify(data));
    await this.setFetchedValues();
  } catch (error) {
    console.error('Error setting fetched values:', error);
  }
}


//************************ SET VALUES AADHAR VERIFICATION CO-APPLICANT  ******************************************************************************** */
async setFetchedValues() {
  console.log("Data this.kycFetchedData.kycData : ", JSON.stringify(this.kycFetchedData.kycData));
  if (this.kycFetchedData && this.kycFetchedData.kycData) {
    this.coapplicantBasicDetails = {
      idDto: 0,
      referenceId: this.userModelData.referenceId,
      branchCode: this.userModelData.brcode,
      userId: this.userModelData.userId,

      fullName: this.kycFetchedData.kycData.data.name,
      gender: this.kycFetchedData.kycData.data.gender,
      pan: this.kycFetchedData.pan,
      aadhar: this.kycFetchedData.aadhar,
      mobileNumber: this.kycFetchedData.kycData.data.mobile,
      email: this.kycFetchedData.kycData.data.email,
      dateOfBirth: this.kycFetchedData.kycData.data.dateOfBirth,

      // Fetched fields from Aadhar
      careOf: this.kycFetchedData.kycData.data.careOf,
      house: this.kycFetchedData.kycData.data.house,
      street: this.kycFetchedData.kycData.data.street,
      district: this.kycFetchedData.kycData.data.district,
      subDistrict: this.kycFetchedData.kycData.data.subDistrict,
      landmark: this.kycFetchedData.kycData.data.landmark,
      locality: this.kycFetchedData.kycData.data.locality,
      postOfficeName: this.kycFetchedData.kycData.data.postOfficeName,
      state: this.kycFetchedData.kycData.data.state,
      pincode: this.kycFetchedData.kycData.data.pincode,
      country: this.kycFetchedData.kycData.data.country,
      vtcName: this.kycFetchedData.kycData.data.vtcName,
      mobile: this.kycFetchedData.kycData.data.mobile,
      aadharAddress: this.kycFetchedData.kycData.data.careOf +
        ' ' +
        this.kycFetchedData.kycData.data.house +
        ' ' +
        this.kycFetchedData.kycData.data.street +
        ' ' +
        this.kycFetchedData.kycData.data.locality +
        ' ' +
        this.kycFetchedData.kycData.data.landmark,


      title: '',
      fatherName: '',
      alternateEmail: '',
      altMobile: '',
      netWorth: '',

      permanentAddress: '',
      residenceOwnership: '',
      voterIdCard: '',
      drivingLicence: '',
      passportNum: '',
      rationCardNumber: '',
      qualification: '',
      tempAddressLine1: '',
      tempAddressLandmark: '',
      tempAddressSubDist: '',
      tempAddressDist: '',
      tempAddressState: '',
      tempAddressPincode: '',
      cif: '',
      presentAddress: '',

      customerType: '',
      pfNomineeAge: '',
      timestamp: '',
      occupation: '',

      consideringIncome: '',
      incomeSourceType: '',
      itrFilledForAnyYear: '',
      form16Available: '',
      relationWithApplicant:'',
      relationWithApplicantOther:''

    }
    this.verified = true; //TO OPEN THE INPUT FORM WITH FETCHED DATA
  }
  else {
    this.verified = false;
    this.isSpinnerLoading = false;
    this.toastr.error("Data Not Available")
    console.error('Some properties are undefined in KYC fetched Data.');
  }

}

// ********************************** SERVICE  SAVE/UPDATE  CO-APPLICANT  ********************* 
saveSingleCoapplicant() {
  this.isSpinnerLoading = true;
  
  if (!this.coappForm.valid) {
    console.log("Form is not valid!");
    this.toastr.info("Kindly Fill all the Required Fields to Save the details");
    this.isSpinnerLoading = false;
    return; // Exiting method if the form is not valid
  }
  // Checking if we are in editing mode or adding new security
  if (this.editingMode) {
    this.allcoapplicantBasicDetails[this.editingIndex] = { ...this.coapplicantBasicDetails };
  } else {
    this.allcoapplicantBasicDetails.push({ ...this.coapplicantBasicDetails });
  }
  this.saveOrUpdateCoapplicantBasicDetails();// Save or update the corporate guarantor in the backend
}

//**************************************** SERVICE  SAVE/UPDATE  CO-APPLICANT ************************************************************************** */

// async saveOrUpdateCoapplicantBasicDetails() {
//   console.log('IN SAVE OR UPDATE CO-APPLICANT BASIC DETAIL METHOD');
//   this.isSpinnerLoading = true;

//       console.warn("FINAL DATA TO SAVE OR UPDATE coapplicantBasicDetails :"+JSON.stringify(this.coapplicantBasicDetails));
      
//     this.individualBasicDetailsService.saveOrUpdateDetails(this.coapplicantBasicDetails).subscribe(
//         (response) => {
//           console.log("Response from individualBasicDetailsService: ", response);
//           this.isSpinnerLoading = false;
//           this.toastr.success("Coapplicant  Details Saved or Updated Successfully...!!!");

//           // Reset the form and refresh the coapplicant list
//           this.resetCoapplicantForm();
//           this.getAllCoapplicantList();
//         },
//         (err: HttpErrorResponse) => {
//           if(err.error.includes("DATA WITH SAME PAN")){
//             console.error("Data Against the PAN : "+this.coapplicantBasicDetails.pan+" is Alraedy Present for Reference-ID :"+this.coapplicantBasicDetails.referenceId+" , Hence Can Not Add Duplicate Details. Kindly Check and Enter Correct Information.");
            
//             this.toastr.error("Data Against the PAN : "+this.coapplicantBasicDetails.pan+" is Alraedy Present for Reference-ID :"+this.coapplicantBasicDetails.referenceId+" , Hence Can Not Add Duplicate Details. Kindly Check and Enter Correct Information.");

//           }

//             this.individualBasicDetailsService.getCoapplicantData(
//             this.coapplicantBasicDetails.referenceId,
//             this.coapplicantBasicDetails.aadhar,
//             this.coapplicantBasicDetails.pan
//           )
//           this.isSpinnerLoading = false;
//           console.error("ERROR WHILE SAVING/UPDATING APPLICANT: ", err.error);
//         });
      
//   }
  async saveOrUpdateCoapplicantBasicDetails() {
    console.log('IN SAVE OR UPDATE CO-APPLICANT BASIC DETAIL METHOD');
    this.isSpinnerLoading = true;
    const getExistedData = await this.individualBasicDetailsService.getCoapplicantData(
      this.coapplicantBasicDetails.referenceId,
      this.coapplicantBasicDetails.aadhar,
      this.coapplicantBasicDetails.pan
    ).toPromise();


    if(getExistedData !== null && this.editingMode!==true){ 
      this.toastr.error("Coapplicant already saved");
    }

     else if (getExistedData !== null) {
      console.log('in get if');
      if (getExistedData?.consideringIncome === 'Yes') {
        if (this.coapplicantBasicDetails.consideringIncome === 'Yes') {
          console.log('IN YES');
          this.coapplicantBasicDetails.customerType = getExistedData.customerType;
        } else {
          this.coapplicantBasicDetails.customerType = 'COAPPLICANT';
        }
      }
      else {
        if (this.coapplicantBasicDetails.consideringIncome === 'Yes') {
          const canSave = await this.getCoapplicantIncomeConsider();
          if (!canSave) {
            console.log("Cannot save as the income consideration exceeds the limit");
            this.toastr.error("Cannot save as the income consideration exceeds the limit")
            this.isSpinnerLoading = false;
            return; // Exit method if save is not allowed
          } else {
            this.coapplicantBasicDetails.customerType = this.customerType;
            console.log(this.coapplicantBasicDetails.customerType);
          }
        } else {
          this.coapplicantBasicDetails.customerType = 'COAPPLICANT';
        }
      }
    } else {
      console.log('IN ELSE')
      const canSave = await this.getCoapplicantIncomeConsider();
      if (!canSave) {
        console.log("Cannot save as the income consideration exceeds the limit");
        this.isSpinnerLoading = false;
        return; // Exit method if save is not allowed
      } else {
        if (this.coapplicantBasicDetails.consideringIncome === 'Yes') {
          console.log('IN YES');
          this.coapplicantBasicDetails.customerType = this.customerType;
          console.log(this.coapplicantBasicDetails.customerType);
        } else {
          console.log('IN NO');
          this.coapplicantBasicDetails.customerType = 'COAPPLICANT';
          console.log(this.coapplicantBasicDetails.customerType);
        }

      }

    }


    if (this.coappForm && !this.coappForm.valid) {
      console.log("Form is not valid!");
      this.toastr.info("Kindly Fill all the Required Fields to Save the details");
      this.isSpinnerLoading = false;
      return; // Exit method if the form is not valid
    }

    console.log('*********************' + this.coapplicantBasicDetails.consideringIncome)

    // If the form is valid and we can save, proceed to save the details
    try {

      if(getExistedData !== null && this.editingMode!==true){ 
        this.toastr.error("CO-APPLICANT ALREADY EXISTED ....");

          // Reset the form and refresh the coapplicant list
          this.resetCoapplicantForm();
          this.getAllCoapplicantList();
      }else{
      this.individualBasicDetailsService.saveOrUpdateDetails(this.coapplicantBasicDetails).subscribe(
        (response) => {
          console.log("Response from applicantCoappGuarantorBasicService: ", response);
          this.isSpinnerLoading = false;
          this.toastr.success("Coapplicant  Details Saved or Updated Successfully...!!!");

          // Reset the form and refresh the coapplicant list
          this.resetCoapplicantForm();
          this.getAllCoapplicantList();
        },
        (error: HttpErrorResponse) => {

          this.individualBasicDetailsService.getCoapplicantData(
            this.coapplicantBasicDetails.referenceId,
            this.coapplicantBasicDetails.aadhar,
            this.coapplicantBasicDetails.pan
          )
          this.isSpinnerLoading = false;
          console.error("ERROR WHILE SAVING/UPDATING APPLICANT: ", error);
        }

      
      );
    } }catch (error) {
      console.error("Error while saving/updating coapplicant details:", error);
      this.isSpinnerLoading = false;
    }
  }


// ************************************** GET CO-APPLICANT DATA *************************************************************//

getCoApplicantData(referenceId: string,  aadhar: string,  pan: string){
  this.isSpinnerLoading=true;

  console.log("Inside  getCoApplicantData , reference id : ", this.userModelData.referenceId);
  this.individualBasicDetailsService.getCoapplicantData(referenceId,aadhar,pan).subscribe(
    (response) => { 
      this.coapplicantBasicDetails=response;
      console.log("Response from getApplicantData: ", JSON.stringify(this.coapplicantBasicDetails));
    if(response != null){
      this.coapplicantDataPresent=true;
      }else{
        this.coapplicantDataPresent=false;
      }
      this.isSpinnerLoading=false;

  },
 (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GETTING APPLICANT DETAILS: "+error)
  }
);
}

// ******************************************** METHOD TO RESET FORM  *******************************************

resetCoapplicantForm() {
  this.coappForm.resetForm(); // Reset the form using ViewChild  
}

// ****************************** CHECK INCOME CONSIDER OR NOT *********************************************************************//

async onConsideringIncomeChange() {
  if (this.coapplicantBasicDetails.consideringIncome === 'No') {
    // Reset dependent fields if Income Considered is No
    this.coapplicantBasicDetails.itrFilledForAnyYear = 'No';
    this.coapplicantBasicDetails.form16Available = 'No';
    this.coapplicantBasicDetails.customerType='COAPPLICANT';
  }else
    if (this.coapplicantBasicDetails.consideringIncome === 'Yes') {
    console.warn("this.coapplicantBasicDetails.customerTyp :"+this.coapplicantBasicDetails.customerType);
  }
}


// ***************************************** METHOD TO EDIT CO-APPLICANT ***********************************

editCoapplicantDetails(coapplicant: IndividualCoapplicantGuarantorBasicDetails) {
    console.log('IN CO-APPLICANT MAJOR EDIT FUNCTION')
    this.existingValueForITR= coapplicant.itrFilledForAnyYear;
    this.incomeConsiderationValue=coapplicant.consideringIncome;
    // alert("this.incomeConsiderationValue :"+this.incomeConsiderationValue)

    this.editingMode = true;
    this.isMinor = false;
    this.coapplicantBasicDetails = { ...coapplicant }; // Cloning guarantor object to prevent direct modification
    console.log('CO-APPLICANT AADHAR :' + this.coapplicantBasicDetails.aadhar);
    console.log('CO-APPLICANT PAN :' + this.coapplicantBasicDetails.pan);
    this.editingIndex = this.allcoapplicantBasicDetails.indexOf(coapplicant);
    
  }
// ************************************ METHOD TO GET ALL CO-APPLICANT   ********************* 

async getAllCoapplicantList() {
  this.isSpinnerLoading = true;
  this.getCibilFetchedStatus();
  this.individualBasicDetailsService.getAllcoappList(this.userModelData.referenceId).subscribe(
    (response) => {
      if (response !== null) {
        this.allcoapplicantBasicDetails = response;
        // console.log("CO APPLICANT LIST: ", JSON.stringify(response));
        console.log("All CO-APPLICANTS LIST: ", response.length);

        this.noCoapplicant = false;
        console.log(this.noCoapplicant);

        if (this.editingMode) {
          
          this.editingMode = false;
          this.editingIndex = -1;
        } else {  
          this.verified = false;
        }
      } else {
        this.noCoapplicant = true;
      }

      this.isSpinnerLoading = false;
    }, (error: HttpErrorResponse) => {
      this.isSpinnerLoading = false;
      console.error("ERROR WHILE GETTING LIST OF CORPORATE GUSRANTORS : " + error)
    }
  );
  this.showAddFormFlag = false; // Hide the form after successful operation

}

// ********************************** SERVICE INTEGRATION TO DELETE SINGLE CORP GUARANTOR  ************************ 

confirmDeleteCoapplicant(referenceId: string, name: string, customerType: string, aadhar: string) {
  console.log("INSIDE DELETE FROM BACKEND REF_ID: " + this.coapplicantBasicDetails.referenceId + " ID: " + referenceId);
  const confirmed = window.confirm('Are you sure you want to delete coapplicant : ' + name + ' ?');
  let custType: string = this.coapplicantBasicDetails.customerType;
  console.log("CUSTOMER TYPE " + customerType)

  this.coapplicantBasicDetails.referenceId = this.userModelData.referenceId;

  if (confirmed) {
    this.individualBasicDetailsService.deleteBorrowerOrGuarantor(referenceId, customerType, aadhar, this.userModelData.userId)
      .subscribe(
        (response: string) => {
          console.log('Message from backend:', response);

          this.getAllCoapplicantList(); // get the updated list after deleting
          this.toastr.success('Coapplicant Deleted Successfully...!', 'Deleted', { timeOut: 1000 });

          if (this.allcoapplicantBasicDetails.length === 0) {
            console.log('****************** IN DELETE ' + this.allcoapplicantBasicDetails.length)
            this.verified = true;
            this.noCoapplicant = true;

          }
        }
      );
  }
}



// **************************************** METHOD TO GET Count of Income Considered CO-APPLICANT  ************************************* 
//USED TO SHOW HIDE BLOCK (CALLED IN GET-ALL-LIST) AND WHILE SAVING 
// getIncomeConsiderCount() {

//   this.individualBasicDetailsService.getCoappIncomeConsiderCount(this.userModelData.referenceId).subscribe(
//     (responseCount :number)=> {
//       if (responseCount != undefined || responseCount != null) {
//           console.log("income Count: ", responseCount);

//             this.incomeConsiderCount=responseCount;
//           console.warn("FLAG incomeConsiderCount :"+this.incomeConsiderCount);         
//           }else{
//             this.isSpinnerLoading=false;
//             console.error("RESULT FROM  getCoappIncomeConsiderCount is  undefined or null :");
//             this.toastr.error("Error While getting Count Of Existing Coapplicants contributing Income.")          
//           }
//         }   
//   );  
// }

//**************************************************** COPING ADDRESS SAME AS ABOVE ****************************************************************************** */
sameAsPermanentAddress = false;
copyAddress() {
  if (this.sameAsPermanentAddress) {
    this.coapplicantBasicDetails.tempAddressLine1 = this.coapplicantBasicDetails.aadharAddress;
    this.coapplicantBasicDetails.tempAddressDist = this.coapplicantBasicDetails.district;
    this.coapplicantBasicDetails.tempAddressState = this.coapplicantBasicDetails.state;

    this.coapplicantBasicDetails.tempAddressPincode = this.coapplicantBasicDetails.pincode;

    // Copy permanent address to correspondent address
  } else {
    this.coapplicantBasicDetails.tempAddressLine1 = '',
      this.coapplicantBasicDetails.tempAddressDist = '',
      this.coapplicantBasicDetails.tempAddressState = '',
      this.coapplicantBasicDetails.tempAddressPincode = ''
  }
}

// ********************SERVICE INTEGRATION TO UPDATE APPLICANT  AND RE-FETCH CIBIL : visiting after 10 ********************************* 

updateDetailsRefetchCIBILAll() {
  this.isSpinnerLoading = true;
  console.log(" this.userModelData.referenceId : "+this.userModelData.referenceId);
  
  this.individualBasicDetailsService.RefetchCIBILForAll(this.userModelData.referenceId).subscribe(
    (response) => { 
      console.log("Response from individualBasicDetailsService: ", response);
      this.isSpinnerLoading=false;
      this.toastr.success("CIBIL DETAILS OF ALL CO-APPLICANTS FETCHED SUCCESSFULLY...!!!")

     this.goNext();
  },
  (error : HttpErrorResponse) => {
 
    this.isSpinnerLoading=false;

    console.error("ERROR WHILE FETCHING CIBIL FOR CO-APPLICANTS: "+error)
  });
}

//******************************************************************************************** */

getCibilFetchedStatus(){
  this.isSpinnerLoading=true;

  console.log("Inside  getCibilFetchedStatus function, ref id: ", this.userModelData.referenceId);
  this.cibilFetchStatusService.getCibilFetchStatusDetails(this.userModelData.referenceId).subscribe(
    (response) => { 
      if(response !=null){
      this.cibilFetchStatusModel=response;
      }
      console.warn("CIBIL-CRIF STATUS FETCHED Response: ", this.cibilFetchStatusModel);
      
      this.isSpinnerLoading=false;
  },
  (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE GETTING CIBIL-FETCHED STATUS DATA: "+error)
  });
}
//****************************************************************************************************************** */
//METHOD TO SHOW ALERT WHEN ITR FIELD IS CHANGED TO NO FROM YES
onItrSelectionChange(currentValue: string, newValue: string): void {
  if (currentValue === 'Yes' && newValue === 'No') {
    Swal.fire({
      title: 'Are you sure?',
      text: 'The previously fetched ITR data will be removed, if present.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      // confirmButtonColor: '#28a745',
      // cancelButtonColor: '#dc3545' ,  
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        this.coapplicantBasicDetails.itrFilledForAnyYear = newValue;
        console.log('Confirmed: ITR data will be removed');
      } 
      else {
        setTimeout(() => {
                  this.coapplicantBasicDetails.itrFilledForAnyYear = currentValue; 
                  console.log('ITR SELECTION CHANGE CANCELLED: ITR data will not be removed');
              }, 0)
        }
    });
  }
}

// ********************SERVICE INTEGRATION TO UPDATE APPLICANT  AND RE-FETCH CIBIL : visiting after 10 ********************* 
async updateDetailsRefetchCIBILSingle() {
  this.isSpinnerLoading = true;

  this.coapplicantBasicDetails.branchCode=this.userModelData.brcode;   

  this.individualBasicDetailsService.updateDetailsAndRefetchCIBIL(this.coapplicantBasicDetails).subscribe(
    (response) => { 
      console.log("Response from individualBasicDetailsService: ", response);
      this.isSpinnerLoading=false;
      this.toastr.success("Co-applicant Details Saved or Updated Successfully...!!!")
      this.getAllCoapplicantList();
  },
  (error : HttpErrorResponse) => {
    //to get saved data so that update button get displayed
    this.getCoApplicantData(this.coapplicantBasicDetails.referenceId,  this.coapplicantBasicDetails.aadhar,  this.coapplicantBasicDetails.pan);
    this.getCibilFetchedStatus();
    this.isSpinnerLoading=false;

    console.error("ERROR WHILE SAVING/ UPDATING APPLICANT DATA: "+error)
  });
}

// ***************************************************************************************************//

resetRelationWithApplicantOther()
{

  if(this.coapplicantBasicDetails.relationWithApplicant!=='Other'){
  this.coapplicantBasicDetails.relationWithApplicantOther='';
  }
}
// **************************************** REDIRECT TO NEXT PAGE  ************************************* 
goNext() {
  this.router.navigate(['/carLoanV2/guarantor-individual']);
}
// **************************************** REDIRECT TO BACK PAGE  ************************************* 
goBack() {
  console.log("CUSTOMER TYPE : "+this.userModelData.custType);
  
if(this.userModelData.custType === "individual"){
  this.router.navigate(['/carLoanV2/borrower-individual']);
}else if(this.userModelData.custType === "corporate"){
  this.router.navigate(['/carLoanV2/borrower-firm']);
}
}

//********************************* METHOD TO GET WHETHER CO-APPLICANT INCOME CONSIDER OR NOT ******************************* */

  async getCoapplicantIncomeConsider(): Promise<boolean> {
    console.log("Inside CoapplicantIncomeConsider function");

    try {
      const response = await this.individualBasicDetailsService.getCoapplicantIncomeConsider(this.coapplicantBasicDetails.referenceId).toPromise();
     
      if (!response || response.length === 0) {
        console.log('Response is empty or undefined, assigning COAPPLICANT1');
        this.customerType = 'COAPPLICANT1';
        return true; // Continue the process with COAPPLICANT1
      }

      if (response.length >= 2 && this.coapplicantBasicDetails.consideringIncome === 'Yes') {
        console.log('The response array has more than or equal to 3 items.');
        alert('Maximum 2 coapplicants income allowed');
        return false; 
      }
      if (!response.includes('COAPPLICANT1')) {
        console.log('COAPPLICANT1 is not in the response, assigning it');
        this.customerType = 'COAPPLICANT1'; // Assign COAPPLICANT1 if it's missing
      } else if (!response.includes('COAPPLICANT2')) {
        console.log('COAPPLICANT2 is not in the response, assigning it');
        this.customerType = 'COAPPLICANT2'; // Assign COAPPLICANT2 if it's missing
      } 
      return true; // Continue with the saving process if all checks are valid
    } catch (error) {
      console.error("Error in getCoapplicantIncomeConsider:", error);
      return false; // Error occurred, don't proceed with saving
    }
  }
  // **************************************** METHOD TO GET CO-APPLICANT INCOME CONSIDER COUNT  ************************************* 


  // async getCoapplicantIncomeConsiderCount(): Promise<boolean> {
  //   console.log("Inside CoapplicantIncomeConsiderCount function");

  //   try {
  //     const response = await this.individualBasicDetailsService.getCoappIncomeConsiderCount(this.coapplicantBasicDetails.referenceId).toPromise();

  //     const getExistedData = await this.individualBasicDetailsService.getCoappIncomeConsiderCount(this.coapplicantBasicDetails.referenceId).toPromise();


  //     // Check if response is undefined or null before proceeding
  //     if (response === undefined || response === null) {
  //       console.error('Received undefined or null response');
  //       return false; // Prevent proceeding with saving
  //     }

  //     console.log("Response from CoapplicantIncomeConsiderCount: ", response);

  //     if (response >= 3) {
  //       console.log('The response is greater than or equal to 3.');
  //       alert('Maximum 3 allowed');
  //       return false; // Don't proceed with saving
  //     }

  //     if (response === 0) {
  //       console.log('The response is strictly zero.');
  //       this.customerType = 'COAPPLICANT1';
  //     } else if (response === 1) {
  //       console.log('The response is strictly 1.');
  //       this.customerType = 'COAPPLICANT2';
  //     } else if (response === 2) {
  //       console.log('The response is strictly 2.');
  //       this.customerType = 'COAPPLICANT3';
  //     }

  //     return true; // Continue to save if response is less than 3
  //   } catch (error) {
  //     console.error("Error in getCoapplicantIncomeConsiderCount: ", error);
  //     return false; // Error occurred, don't proceed with saving
  //   }
  // }

}
