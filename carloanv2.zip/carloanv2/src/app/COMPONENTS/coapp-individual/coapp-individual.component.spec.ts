import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoappIndividualComponent } from './coapp-individual.component';

describe('CoappIndividualComponent', () => {
  let component: CoappIndividualComponent;
  let fixture: ComponentFixture<CoappIndividualComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CoappIndividualComponent]
    });
    fixture = TestBed.createComponent(CoappIndividualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
