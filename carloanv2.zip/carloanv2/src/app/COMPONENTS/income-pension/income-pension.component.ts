import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { IncomePensionerModel } from 'src/app/MODELS/income-pensioner-model';
import { IncomeDetailsForAllService } from 'src/app/SERVICES/Income-Details/income-details-all.service';

@Component({
  selector: 'app-income-pension',
  templateUrl: './income-pension.component.html',
  styleUrls: ['./income-pension.component.css']
})
export class IncomePensionComponent {

  isSpinnerLoading = false;
  currentYear!:number;
  currentMonth!: string;
  minMonth!: string;
  salaryFlag:boolean = false;
  dateFlag: boolean = false;
  yearFlag: boolean = false;
  yearRanges: string[] = [];
  fiscalYearStartMonth: number = 3; // April (0-based index, so 3 represents April)
  ages: number[] = [];
  expYears: number[] = [];
  expMonths: number[] = [];
  totalYears: number[] = [];
  totalMonths: number[] = [];
  // referenceId: string = 'MGB@INCOME';
  // panNumber: string = 'AUJPT0678C';
  referenceId: string = '';
  panNumber: string = '';
  customerName:  string = '';
  custType:  string = '';
  




  ngOnInit(): void {
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    this.generateYearRanges();
    this.activatedRoute.queryParams.subscribe(params => {
      this.panNumber = params['panNumber'],
      this.custType = params['custType'];
      this.customerName = params['customerName'];
      this.getIncomeDetailsPensioner();
    });
    this.referenceId=this.userModelData.referenceId;
  }
  userModelData = {} as UserModelData;
  incomePensionerModel = {} as IncomePensionerModel;

//***************************************************** *CONSTRUCTOR BLOCK*****************************

constructor(private incomeDetailsAllService: IncomeDetailsForAllService, private router: Router,private toastr : ToastrService, private activatedRoute: ActivatedRoute,){
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();

  const currentMonthIndex = currentDate.getMonth(); // Month is 0-indexed

  // Set current month in YYYY-MM format
  this.currentMonth = `${currentYear}-${(currentMonthIndex + 1).toString().padStart(2, '0')}`;

  // Calculate the month one year back
  const oneYearBackDate = new Date(currentDate);
  oneYearBackDate.setFullYear(currentYear - 1);
  this.minMonth = `${oneYearBackDate.getFullYear()}-${(oneYearBackDate.getMonth() + 1).toString().padStart(2, '0')}`;
  //this.generateYearRanges();
}
//******
  // ----------------------------------------------- Get Year For Income Details as per ITR/Form 16 ---------------------------------------------
  private generateYearRanges(): void {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth(); // 0 = January, ..., 11 = December

    let startYear: number;

    // Determine starting year for previous fiscal years
    if (currentMonth >= this.fiscalYearStartMonth) {
      startYear = currentYear - 1; // Last fiscal year
    } else {
      startYear = currentYear - 2; // Two fiscal years ago
    }

    // Generate year ranges for previous fiscal years (excluding current FY)
    for (let i = 0; i < 3; i++) { // Only two previous fiscal years
    const yearRange = `${startYear - i}-${(startYear - i + 1).toString().slice(2,4)}`;
      this.yearRanges.unshift(yearRange); // Add to the beginning for reverse order
    }

    // Retirement Age Drop-Down
    for (let age = 18; age <= 65; age++) {
      this.ages.push(age);
    }
    //  Experience In Current Org. Year Drop-Down
    for (let expyear = 0; expyear <= 45; expyear++) {
      this.expYears.push(expyear);
    }

     //  Experience In Current Org. Month Drop-Down
     for (let expnonth = 0; expnonth <= 11; expnonth++) {
      this.expMonths.push(expnonth);
    }

     // Total Experience Year Drop-Down
     for (let totalyear = 0; totalyear <= 45; totalyear++) {
      this.totalYears.push(totalyear);
    }

    // Total Experience Month Drop-Down
     for (let age = 0; age <= 11; age++) {
      this.totalMonths.push(age);
    }
    

  }

// -------------------------------------- For validation of salary months ---------------------------------------------


checkForDuplicates(): void {
  const months = [this.incomePensionerModel.monthOneTitle, this.incomePensionerModel.monthTwoTitle, this.incomePensionerModel.monthThreeTitle];
  const filteredMonths = months.filter(month => month);
    
  // Create a Set to track unique months
  const uniqueMonths = new Set(filteredMonths);
  this.dateFlag = uniqueMonths.size < filteredMonths.length; 
}

onMonthChange(): void {
  this.checkForDuplicates();
}
checkForDuplicatesYear(): void {
  
  const year =[this.incomePensionerModel.selectedFirstYear,this.incomePensionerModel.selectedSecondYear];
  const filteredyear = year.filter(year => year);
  // Create a Set to track unique year
 
  const uniqueYear=new Set(filteredyear);
 
  this.yearFlag = uniqueYear.size < filteredyear.length; 
}
onYearChange(): void {
  this.checkForDuplicatesYear();
}
  
  // ----------------------------------------------- CHECK SALARY CONDITION ---------------------------------------------

 checkSalaryAmount(){
    if(this.incomePensionerModel.monthOneSalary<25000||this.incomePensionerModel.monthTwoSalary<25000||this.incomePensionerModel.monthThreeSalary<25000)
    {
      this.toastr.info("Pension should be above 25000/-")
      
       this.salaryFlag=true;
    }
    else{
       this.salaryFlag=false;
    }
  }
// ----------------------------------------------- Calculate Total Current Deducations ---------------------------------------------

  calculateTotalCurrentDeductions(){
    this.incomePensionerModel.totalCurrentDeduction = this.incomePensionerModel.currentEmiDeduction+this.incomePensionerModel.incomeTaxDeduction+this.incomePensionerModel.pensionSlipDeduction+this.incomePensionerModel.otherDeduction
  }
// -------------------------------------- Get Data For Income Borrower ---------------------------------------------
   
getIncomeDetailsPensioner(){
  this.isSpinnerLoading=true;
  this.incomeDetailsAllService.getIncomeDetailsPensioner(this.userModelData.referenceId,this.panNumber).subscribe((response) => {
    this.isSpinnerLoading=false;
    if(response!=null){
      this.incomePensionerModel=response;
    }else{
      }
      if (this.incomePensionerModel.selectedFirstYear == undefined) {
        this.incomePensionerModel.selectedFirstYear = '';
      }
      if (this.incomePensionerModel.selectedSecondYear == undefined) {
        this.incomePensionerModel.selectedSecondYear = '';
      }
      if (this.incomePensionerModel.incomeDetailOption == undefined) {
        this.incomePensionerModel.incomeDetailOption = '';
      }
    
  },(error)=>{
    this.isSpinnerLoading=false;
    this.toastr.error("Error occured Get Income for Pensioner");
    console.log("Error occured Get Income for Pensioner " + JSON.stringify(error));
  }
)
}
 //******************************************test get mapping ********************************/
 //--------------------------------------------POST DATA AND SAVED INTO DATABASE
 
  onSubmitBorrowerIncome(){

    if (this.dateFlag||this.yearFlag||this.salaryFlag) {
      this.toastr.info("Form is invalid due to duplicate months/year or salary amount is invalid.")
    }else{
    this.isSpinnerLoading = true
    this.incomePensionerModel.referenceId=this.userModelData.referenceId;
    this.incomePensionerModel.userId=this.userModelData.userId;
    this.incomePensionerModel.branchCode=this.userModelData.brcode;
    this.incomePensionerModel.incomeType='Pensioner'
    this.incomePensionerModel.customerType=this.custType;
     
      this.incomePensionerModel.customerName=this.customerName;
      this.incomePensionerModel.panNumber=this.panNumber;
   
    this.incomeDetailsAllService.postIncomeDetailsPensioner(this.incomePensionerModel).subscribe((response) => {
          this.isSpinnerLoading=false
         // this.router.navigate(['']);
          console.log("Income Borower Response " + JSON.stringify(response));
          this.incomePensionerModel.customerType=this.custType;
          this.incomePensionerModel.incomeType='Pensioner';
          this.incomePensionerModel.customerName=this.customerName;
          this.incomePensionerModel.panNumber=this.panNumber;
          this.goNext();
    },(error) => {
      this.toastr.error("Error Occured In Saving Income Details - Pension")
      console.log("Error Occured In Saving Income Details - Borrower " + JSON.stringify(error));
      
      this.isSpinnerLoading=false
    }
  )}
  }
  // ********************************************************navigate to next page
  goNext(){
    this.router.navigate(["/carLoanV2/income-main-list"])}


//// -------------------------------------------------------------Reset fields based on the selected option-------------------------------------------------------------
resetFields() {
  // Reset fields based on the selected option
  if (this.incomePensionerModel.incomeAvailableFor === 'One Year') {
    this.incomePensionerModel.netIncomeFirstYear = 0;
    this.incomePensionerModel.grossIncomeFirstYear = 0;
    this.incomePensionerModel.selectedFirstYear = '';
   
   } 
}

}
