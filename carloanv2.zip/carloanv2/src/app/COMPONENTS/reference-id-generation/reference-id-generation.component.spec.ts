import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferenceIdGenerationComponent } from './reference-id-generation.component';

describe('ReferenceIdGenerationComponent', () => {
  let component: ReferenceIdGenerationComponent;
  let fixture: ComponentFixture<ReferenceIdGenerationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReferenceIdGenerationComponent]
    });
    fixture = TestBed.createComponent(ReferenceIdGenerationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
