import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { ReferenceIdModel, ReferenceIdResponseModel } from 'src/app/MODELS/referenceid.model';
import { RefidGenerationService } from 'src/app/SERVICES/reference-id-generation/ref-id-generation.service';

@Component({
  selector: 'app-reference-id-generation',
  templateUrl: './reference-id-generation.component.html',
  styleUrls: ['./reference-id-generation.component.css']
})
export class ReferenceIdGenerationComponent implements OnInit {

referenceIdModel = {} as ReferenceIdModel;
isSpinnerLoading = false;
loanTypes: any[] = ['Purchase of New Passenger Car', 'Purchase of New Electric Passenger Car'];
userModelData = {} as UserModelData;
referenceId: string = '';
showExistingReferenceIdDiv='no';

constructor(
  private refIdService: RefidGenerationService,
  private router: Router,
  private toastr: ToastrService,) {}

ngOnInit(): void {

  const abc = sessionStorage.getItem("userModelData");
  this.userModelData = JSON.parse(abc!);
  console.log(" USERDATA MODEL ON INIT OF REF-ID COMPONENT :"+JSON.stringify(this.userModelData));
  }

onSubmit() {
  this.generateReferenceID();
}

enableCreateAppliction() {
  this.referenceIdModel.panNumber = "";
  this.referenceIdModel.borrowerType = "";
  this.referenceIdModel.loanType = "";
  this.referenceIdModel.sourceType = "";
  this.referenceIdModel.dsaNumber = "";
  this.router.navigate(["carLoanV2/"])
}

isDsaRequired(): boolean {
  return this.referenceIdModel.sourceType === 'DSA';
}

generateReferenceID() {
  this.isSpinnerLoading = true;
  this.setReferenceIdModel();
  console.log("BEFORE GENERATION REFERENCE ID ENTITY DATA : "+JSON.stringify(this.referenceIdModel));

  this.refIdService.generateReferenceId(this.referenceIdModel).subscribe((response: any) => {
    this.referenceIdModel = response;
    console.log("REF-ID RESPONSE : "+response);
    
   if(this.referenceIdModel.refIdFlag ==="alreadyExists"){
      this.showExistingReferenceIdDiv='yes';
      this.isSpinnerLoading=false;
    }
    else{
      this.setReferenceModelVariable(this.referenceIdModel)
      console.log("USER MODEL DATA AFTER REF-ID GENERATION :"+JSON.stringify(this.userModelData))
      this.toastr.success("VERIFICATION SUCCESSFUL");
      this.isSpinnerLoading = false;
      this.router.navigate(['/carLoanV2/doc-list']);
    } 
  }, (error) => {
    this.isSpinnerLoading = false;
    console.log("Something went wrong" + JSON.stringify(error));
  })
}

setReferenceIdModel(){
  this.referenceIdModel.brcode=this.userModelData.brcode;
  this.referenceIdModel.u_loc=this.userModelData.u_loc;
  this.referenceIdModel.u_name=this.userModelData.u_name;
  this.referenceIdModel.u_status=this.userModelData.u_status;
  this.referenceIdModel.u_type=this.userModelData.u_type;
  this.referenceIdModel.userId=this.userModelData.userId;
  this.referenceIdModel.brname=this.userModelData.brname;
  this.referenceIdModel.roname=this.userModelData.roname;
  this.referenceIdModel.scale=this.userModelData.scale;
}

allowOnlyNumbers(event: any): void {
  const input = event.target.value.replace(/[^0-9]/g, ''); // remove non-numeric characters
  this.referenceIdModel.panNumber = input;
}

setReferenceModelVariable( referenceIdModel: ReferenceIdModel) {
  const abc = sessionStorage.getItem("userModelData");
  // alert("abc: "+abc)
  this.userModelData = JSON.parse(abc!);
  // alert(this.referenceIdModel)

  // console.log("ReferenceId"+JSON.stringify(referenceIdModel));
  
  this.userModelData.referenceId=referenceIdModel.referenceId;
  this.userModelData.shortLoanType=referenceIdModel.shortLoanType;
  this.userModelData.shortBorrowerType=referenceIdModel.shortBorrowerType;
  this.userModelData.sourceType=referenceIdModel.sourceType;
  this.userModelData.panNumber=referenceIdModel.panNumber;
  this.userModelData.custType=referenceIdModel.custType;
  sessionStorage.setItem("userModelData", JSON.stringify(this.userModelData));
  // alert(this.userModelData)

  // console.log("After The ReferenceId"+JSON.stringify(this.userModelData))
}

}

