import { HttpErrorResponse } from '@angular/common/http';
import { Component, TemplateRef, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatStepper, MatStepperNext } from '@angular/material/stepper';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { UserModelDataForApplicationList } from 'src/app/MODELS/application-list/application-list-data-get.model';
import { CibilCrifRemarksFinalModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-final-Remark.model';
import { CibilCrifStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-STATUS.model';
import { CommCrifDetailsModel, CommCrifHistoryModel, CrifCommercialHistoryData } from 'src/app/MODELS/CIBIL-CRIF-ALL/CRIF-commercial.model';

import { AppraisalNoteService } from 'src/app/SERVICES/appraisal-note/appraisal-note.service';
import { CibilCrifRemarksFinalService } from 'src/app/SERVICES/CIBIL-CRIF-Remarks/cibil-crif-remarks.service';
import { CibilCrifStatusService } from 'src/app/SERVICES/CIBIL-CRIF-STATUS/cibil-crif-status.service';
import { CommercialCrifService } from 'src/app/SERVICES/CRIF-commercial-all/fetch-commercial-crif.service';

@Component({
  selector: 'app-crif-comm-guarantor-stepper',
  templateUrl: './crif-comm-guarantor-stepper.component.html',
  styleUrls: ['./crif-comm-guarantor-stepper.component.css']
})
export class CrifCommGuarantorStepperComponent {


  commCrifDetails: Array<CommCrifDetailsModel> = []
  commCrifHistory: Array<CommCrifHistoryModel> = []
  crifCommercialHistoryData: CrifCommercialHistoryData[] = [];

  userModelData = {} as UserModelData;
  isSpinnerLoading = false;
  cibilCrifRemarksModel = {} as CibilCrifRemarksFinalModel;
  AnyOverduePresentCorpGuarantors: boolean = false;
  AnyAccountSettledCorpGuarantors: boolean = false;
  AnyAccountWrittenOffCorpGuarantors: boolean = false;
  AnyAccountSuitFilledCorpGuarantors: boolean = false;
  disableNext: string = "";

  cibilCrifStatusModel = {} as CibilCrifStatusModel;
  routeToPage: string = '';

  constructor(private commCrifService: CommercialCrifService, private cibilCrifRemarksService: CibilCrifRemarksFinalService,
    private appraisalNoteService : AppraisalNoteService, private router: Router, private toastr: ToastrService, private modalService: NgbModal,
    private cibilCrifStatusService: CibilCrifStatusService) { }

  @ViewChild('stepper', { static: false }) stepper!: MatStepper;

  ngOnInit(): void {
    const abc = sessionStorage.getItem('userModelData');
    this.userModelData = JSON.parse(abc!);
    this.getguarantorsCount();
    this.getCrifDetailsData();
    this.getCrifHistoryData();
    this.getCrifSummaryData();
    this.RemarksGuarantorsCommercialCrifGet();

  }



  getCrifDetailsData() {
    //   this.isSpinnerLoading=true;
    this.commCrifService.getCommCrifFirmData(this.userModelData.referenceId, 'GUARANTOR').subscribe((response) => {
      //  this.commCrifService.getCommCrifFirmData('MGBGST@20240903340','GUARANTOR').subscribe((response) => {
      this.isSpinnerLoading = false;
      if (response != null) {
        this.commCrifDetails = response;
        console.log("THS IS RESPONSE Details" + JSON.stringify(this.commCrifDetails));
        this.disableNext = "no";
      } else {
        this.disableNext = "yes";
      }
    }, (error) => {
      this.isSpinnerLoading = false;
      console.log("ERROR OCCURED IN CRIF COMM GUARANTOR " + JSON.stringify(error));
    })
    this.isSpinnerLoading = false;

  }


  //Get CRIF History Data for all Individual Guarantors

  getCrifHistoryData() {
    //   this.isSpinnerLoading=true;
    this.commCrifService.getCommCrifFirmHistoryData(this.userModelData.referenceId, 'GUARANTOR').subscribe((response) => {
      //  this.commCrifService.getCommCrifFirmHistoryData('MGBGST@20240729735','GUARANTOR').subscribe((response) => {
      this.isSpinnerLoading = false;
      // this.commCrifHistory = response;
      if (response != null) {
        this.crifCommercialHistoryData = response;

        console.log("THS IS RESPONSE History" + JSON.stringify(this.commCrifHistory));
      } else {
        this.disableNext = "yes";
      }
    }, (error) => {
      this.isSpinnerLoading = false;
      console.log("ERROR OCCURED IN CRIF COMM GUARANTOR" + JSON.stringify(error));
    })
    this.isSpinnerLoading = false;

  }

  summaryDetailsModel = {} as CommCrifHistoryModel;
  summaryDetailsModelArray: CommCrifHistoryModel[] = [];
  OverduePresentCorpGuarantors: boolean = false;

  // highlightRows(index: number, highlight: boolean): void {
  //   this.newHistoryDetailsModelArray[index].highlighted = highlight;
  //   if (highlight===true){
  //     this.newHistoryDetailsModelArray[index].collapsed = false;

  //   }
  // }

  com_cibil_summary_header = [
    'Sr.No',
    'Corporate Guarantor Name',
    'Pan',
    'Account Written-Off',
    'Account Settled',
    'Suitfilled Accounts',
    'Account Overdue'
  ];

  getCrifSummaryData() {
    // this.summaryDetailsModel.referenceId='MGBGST20241203hdfj8'; //DUMMY
    this.isSpinnerLoading = true;
    this.commCrifService.getCommCrifFirmSummaryData(this.userModelData.referenceId, "GUARANTOR").subscribe(
      // this.commCrifService.getCommCrifFirmSummaryData('MGBGST@20240729735','GUARANTOR').subscribe(


      (response: CommCrifHistoryModel[]) => {
        if (response !== null) {
          this.summaryDetailsModelArray = response;
          console.log("CRIF COMMERCIAL GUARANTOR LIST : ", JSON.stringify(this.summaryDetailsModelArray));
          //setting a combined overdue flag after checking if any one has overdue= YES
          //  this.OverduePresentCorpGuarantors = response.some(item => item.overdueStatus === 'YES');
          // console.log("this.OverduePresentCorpGuarantors : ", this.OverduePresentCorpGuarantors);
          //setting a combined overdue flag after checking if any one has overdue= YES
          this.AnyOverduePresentCorpGuarantors = response.some(item => item.overdueStatus === 'YES');
          console.log("this.AnyOverduePresentCorpGuarantors : ", this.AnyOverduePresentCorpGuarantors);

          //for settled accounts
          this.AnyAccountSettledCorpGuarantors = response.some(item => item.settledStatus === 'YES');
          console.log("this.AnyAccountSettledIndGuarantors : ", this.AnyAccountSettledCorpGuarantors);

          //for written off accounts
          this.AnyAccountWrittenOffCorpGuarantors = response.some(item => item.writtenOffStatus === 'YES');
          console.log("this.AnyAccountWrittenOffIndGuarantors : ", this.AnyAccountWrittenOffCorpGuarantors);

          //for suit-filled accounts
          this.AnyAccountSuitFilledCorpGuarantors = response.some(item => item.suitFiledStatus === 'YES');
          console.log("this.AnyAccountSuitFilledIndGuarantors : ", this.AnyAccountSuitFilledCorpGuarantors);


          //        if(this.OverduePresentCorpGuarantors){
          //   this.showOverdueRemarkField='yes';
          //  }
        }
        else {
          this.disableNext = "yes";
        }
        this.isSpinnerLoading = false;
      }, (error) => {
        this.isSpinnerLoading = false;
        console.log("ERROR OCCURED IN CRIF COMM GUARANTOR" + JSON.stringify(error));
      }
    );
  }

  postCommCrifGuarantorRemarks() {
    this.isSpinnerLoading = true;
    this.cibilCrifRemarksModel.referenceId = this.userModelData.referenceId;
    // this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";

    this.cibilCrifRemarksModel.userId = this.userModelData.userId;
    this.cibilCrifRemarksService.CrifCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksModel).subscribe((response) => {

      this.isSpinnerLoading = false;
      console.log("THS IS RESPONSE " + response);
    }
      , (error) => {
        this.isSpinnerLoading = false;
        console.log("ERROR OCCURED IN CRIF COMM GUARANTOR" + JSON.stringify(error));
      })
  }

  postOverdueRemark() {
    this.isSpinnerLoading = true;

    this.cibilCrifRemarksModel.referenceId = this.userModelData.referenceId;
    //  this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";
    this.cibilCrifRemarksModel.userId = this.userModelData.userId;
    this.cibilCrifRemarksService.CrifCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksModel).subscribe((response) => {

      this.isSpinnerLoading = false;
      console.log("THS IS RESPONSE " + response);
    }
      , (error:HttpErrorResponse) => {
        this.isSpinnerLoading = false;
        console.log("ERROR OCCURED IN CRIF COMM GUARANTOR" + JSON.stringify(error));
      })

  }

  postRejectRemark() {
    this.isSpinnerLoading = true;

    this.cibilCrifRemarksModel.referenceId = this.userModelData.referenceId;
    //  this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";
    this.cibilCrifRemarksModel.userId = this.userModelData.userId;
    this.cibilCrifRemarksService.CrifCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksModel).subscribe((response) => {

      this.isSpinnerLoading = false;
      if(response!=null){
        console.log("THS IS RESPONSE " + response);
        this.setRejectSubmit();
      }
     
    }
      , (error) => {
        this.isSpinnerLoading = false;
        console.log("ERROR OCCURED IN CRIF COMM GUARANTOR REJECT" + JSON.stringify(error));
      })
  }




  openVerticallyCentered(content: TemplateRef<any>) {
    this.modalService.open(content, {
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'md',
      centered: true,
    });
  }


  showOverdueRemarkField: string = "";

  onSubmitRemark(form: NgForm) {
    const crifGuarantorRemarkfield = form.controls['crifGuarantorRemarkfield'];
    console.log('Remarkfield errors:', crifGuarantorRemarkfield.errors);
    console.log('Form submitted:', form.submitted);

    if (form.invalid) {
      // Handle invalid form case
      console.log('Form is invalid');
      //  
    } else {
      // Handle valid form case
      console.log('Form is valid');
      this.postCommCrifGuarantorRemarks();
    }
  }

  onSubmitOverDue(form: NgForm) {
    const crifGuarantoroverdueRemarkfield = form.controls['crifGuarantoroverdueRemarkfield'];
    console.log('Overdue errors:', crifGuarantoroverdueRemarkfield.errors);
    console.log('Form submitted:', form.submitted);

    if (form.invalid) {
      // Handle invalid form case
      console.log('Form is invalid');
    } else {
      // Handle valid form case
      console.log('Form is valid');
      this.postOverdueRemark();

    }
  }


  toggleCollapse(guarantor: any) {
    guarantor.collapsed = !guarantor.collapsed
  }


  RemarksGuarantorsCommercialCrifSave() {
    //    alert("i have Benn caledd With"+JSON.stringify(this.cibilCrifRemarksModel));
    console.warn("Remark Save For Guarantor CRIF" + JSON.stringify(this.cibilCrifRemarksModel));
    this.cibilCrifRemarksModel.referenceId = this.userModelData.referenceId;
    // this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";
    this.isSpinnerLoading = true;
    this.cibilCrifRemarksService.CrifCommercialRemarksSaveOrUpdate(this.cibilCrifRemarksModel).subscribe(
      (response) => {
        if (response !== null) {
          console.log("ALL REMARKS OF CIBIL & CRIF  : ", JSON.stringify(response));
          if (this.routeToPage == 'financial') {
            this.router.navigate(['/carLoanV2/financial']);
          }
        } else {
          this.router.navigate(['/carLoanV2/individualcrif']);

        }
        this.isSpinnerLoading = false;
      }, (error :HttpErrorResponse) => {
        this.isSpinnerLoading = false;
        console.log("ERROR OCCURED IN CRIF COMM GUARANTOR" + JSON.stringify(error));
      }
    );
  }

  RemarksGuarantorsCommercialCrifGet() {
    this.cibilCrifRemarksModel.referenceId = this.userModelData.referenceId;
    // this.cibilCrifRemarksModel.referenceId="MGBGST@20240729735";
    this.isSpinnerLoading = true;
    this.cibilCrifRemarksService.getAllCibilCrifRemarks(this.cibilCrifRemarksModel.referenceId).subscribe(
      (response) => {
        if (response !== null) {
          this.cibilCrifRemarksModel = response;
          console.log("ALL REMARKS OF CIBIL & CRIF Get method : ", JSON.stringify(response));
        }
        this.isSpinnerLoading = false;
      }, (error:HttpErrorResponse) => {
        this.isSpinnerLoading = false;
        console.log("ERROR OCCURED IN CRIF COMM GUARANTOR" + JSON.stringify(error));
      }
    );
  }


  //Check Min Length Should Be 100


  characterCount: number = 0;
  overDueCount: number = 0;
  rejectCount: number = 0;
  suitFilkedCount: number = 0;
  settledCount: number = 0;
  writtenCount: number = 0;
  minLength: number = 100;
  isRemarkCountOk: boolean = false;
  isOverDueCountOk: boolean = false;
  isRejectCountOk: boolean = false;
  isSuitFilkedCountOk: boolean = false;
  isSettledCountOk: boolean = false;
  isWrittenCountOk: boolean = false;

  //First Page CRIF Remark
  updateRemarkCount() {
    this.characterCount = this.cibilCrifRemarksModel.commercialCrifRemark.trim().split(/\s+/).filter(Boolean).length;
    if (this.characterCount > 100) {
      this.isRemarkCountOk = true;
    }
  }


  //CRIF OverDue Remark
  updateOverDueRemarkCount() {
    this.overDueCount = this.cibilCrifRemarksModel.commercialCrifOverdueRemark.trim().split(/\s+/).filter(Boolean).length;
    if (this.overDueCount > 100) {
      this.isOverDueCountOk = true;
    }
  }
  //CRIF REJECT Remark
  updateRejectRemarkCount() {
    this.rejectCount = this.cibilCrifRemarksModel.commercialCrifRejectRemark.trim().split(/\s+/).filter(Boolean).length;
    if (this.rejectCount > 100) {
      this.isRejectCountOk = true;
    }
  }
  //CRIF SUITFILED Remark
  updateSuitfiledRemarkCount() {
    this.suitFilkedCount = this.cibilCrifRemarksModel.commercialCrifSuitFilledRemark.trim().split(/\s+/).filter(Boolean).length;
    if (this.suitFilkedCount > 100) {
      this.isSuitFilkedCountOk = true;
    }
  }
  //CRIF SETTLED Remark
  updateSettledRemarkCount() {
    this.settledCount = this.cibilCrifRemarksModel.commercialCrifAccountSettledRemark.trim().split(/\s+/).filter(Boolean).length;
    if (this.settledCount > 100) {
      this.isSettledCountOk = true;
    }
  }

  //CRIF SETTLED Remark
  updateWrittenOffRemarkCount() {
    this.writtenCount = this.cibilCrifRemarksModel.commercialCrifWrittenOffRemark.trim().split(/\s+/).filter(Boolean).length;
    if (this.writtenCount > 100) {
      this.isWrittenCountOk = true;
    }
  }




  // ============================================ Get Guarantors Count For Routing =============================================
  getguarantorsCount() {
    this.cibilCrifStatusService.getAllCibilCrifStatus(this.userModelData.referenceId).subscribe((response) => {
      this.cibilCrifStatusModel = response;
      if ((this.cibilCrifStatusModel.indvGurantorsCount === null || this.cibilCrifStatusModel.indvGurantorsCount === 0)) {
        //Go To financial Page
        this.routeToPage = 'financial'
      }
    });
  }
  userModelDataForApplicationList = {} as UserModelDataForApplicationList;

  //REJECT The Application
  setRejectSubmit(){

    this.userModelDataForApplicationList.branchCode=this.userModelData.brcode;
    this.userModelDataForApplicationList.custType=this.userModelData.custType;
    this.userModelDataForApplicationList.referenceId=this.userModelData.referenceId;
    this.userModelDataForApplicationList.regionName=this.userModelData.roname;
    this.userModelDataForApplicationList.userId=this.userModelData.userId;
    this.userModelDataForApplicationList.userLoc=this.userModelData.u_loc;
    this.userModelDataForApplicationList.userScale=this.userModelData.scale;
    this.userModelDataForApplicationList.userType=this.userModelData.u_type;
    this.modalService.dismissAll();

   
    this.appraisalNoteService
     .setReject(this.userModelDataForApplicationList)
     .subscribe(
        (response) => {
          this.isSpinnerLoading=false;
          console.log("In Reject On GST PAGE");
          if (response!=null) {
     
            console.log("Reject Application SuccessFully... ");
            this.router.navigate(['carLoanV2/'])
         //   alert(JSON.stringify(response))
          }
          else{
            this.toastr.info("Reject status could not be updated")           
          }
          
        },
         (error) => {
          this.isSpinnerLoading=false;
          console.log("ERROR OCCURED In Reject On CIBIL " + JSON.stringify(error));
         }
      );
  }
}




