import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrifCommGuarantorStepperComponent } from './crif-comm-guarantor-stepper.component';

describe('CrifCommGuarantorStepperComponent', () => {
  let component: CrifCommGuarantorStepperComponent;
  let fixture: ComponentFixture<CrifCommGuarantorStepperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CrifCommGuarantorStepperComponent]
    });
    fixture = TestBed.createComponent(CrifCommGuarantorStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
