import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItrVerifyCoapp1Component } from './itr-verify-coapp1.component';

describe('ItrVerifyCoapp1Component', () => {
  let component: ItrVerifyCoapp1Component;
  let fixture: ComponentFixture<ItrVerifyCoapp1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ItrVerifyCoapp1Component]
    });
    fixture = TestBed.createComponent(ItrVerifyCoapp1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
