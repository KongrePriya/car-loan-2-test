import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrifFirmFetchPageComponent } from './crif-firm-fetch-page.component';

describe('CrifFirmFetchPageComponent', () => {
  let component: CrifFirmFetchPageComponent;
  let fixture: ComponentFixture<CrifFirmFetchPageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CrifFirmFetchPageComponent]
    });
    fixture = TestBed.createComponent(CrifFirmFetchPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
