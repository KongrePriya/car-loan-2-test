import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { CibilCrifStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-STATUS.model';
import { FirmBorrowerDetailsModel } from 'src/app/MODELS/firmBorrowerDetails.model';
import { CibilCrifStatusService } from 'src/app/SERVICES/CIBIL-CRIF-STATUS/cibil-crif-status.service';
import { CorporateGuarantorService } from 'src/app/SERVICES/corporate-guarantor/corporate-guarantor.service';
import { CommercialCrifService } from 'src/app/SERVICES/CRIF-commercial-all/fetch-commercial-crif.service';
import { FirmService } from 'src/app/SERVICES/firmdetails/firm.service';

@Component({
  selector: 'app-crif-firm-fetch-page',
  templateUrl: './crif-firm-fetch-page.component.html',
  styleUrls: ['./crif-firm-fetch-page.component.css']
})
export class CrifFirmFetchPageComponent {

  ngOnInit(): void {
    const abc = sessionStorage.getItem("userModelData");
    this.userDataModel = JSON.parse(abc!);
    this.getFirmDetail();
  }


 //to assign fetched data fields also have additional fields
  firmDetailModel={} as FirmBorrowerDetailsModel;
  isSpinnerLoading:boolean = false;
  userDataModel = {} as UserModelData;
  disableProceedWithoutFlag:string='no';
  disableProceedWithFlag:string='no';
  cibilCrifStatusModel=  {} as CibilCrifStatusModel;
  isChecked: boolean = false;
  showCheckBox?:string;
   disableNext:string='yes';


  
 
  countYes:number=0;

  constructor(
    private modalService: NgbModal,
    private firmService: FirmService,
    private router: Router,
    private cibilCrifStatusService:CibilCrifStatusService,
    private toastr :ToastrService,
    private fetchCommercialCrifService:CommercialCrifService
  ) {}
  
  //****************************** GET FIRM DETAILS ******************************/

  getFirmDetail() {
    
    this.getCibilCrifFetchedStatus();

    this.firmService.getFirmDetails(this.userDataModel.referenceId).subscribe(
        (response) => {
        if(response!== null){
          this.firmDetailModel = response;
          this.disableNext='no';

        
          // if(response.crifCommFetched == 'no' && this.cibilCrifStatusModel.firmComCrifFetched ){ 
          //   if( this.cibilCrifStatusModel.firmComCrifFetched){ 
          //     this.disableProceedWithoutFlag = 'yes';
          // }
          // else if(response.crifCommFetched == 'yes' &&  this.cibilCrifStatusModel.firmComCrifFetched){
            // else if( this.cibilCrifStatusModel.firmComCrifFetched){
            //   this.countYes++;
            //   console.log("I AM IN COUNT" + this.countYes);
              
            // }
         
         if(this.firmDetailModel.crifCommFetched=='yes'){
          this.disableProceedWithoutFlag='yes';
          this.showCheckBox='yes';
        }
          this.isSpinnerLoading = false;
          
        }else{
          this.disableNext='yes';

        }
        this.isSpinnerLoading = false;
      },(error) => {
        this.isSpinnerLoading=false;
        console.log("ERROR OCCURED " + JSON.stringify(error));
      }
    ); }


    //*********************************************CRIF FETCHED STATUS************************************************* */
    getCibilCrifFetchedStatus(){
    this.cibilCrifStatusService.getAllCibilCrifStatus(this.userDataModel.referenceId).subscribe((res)=>{
    
     console.log("THIS IS CIBIL CRIF STATUYS " + JSON.stringify(res));
     
      this.cibilCrifStatusModel=res;
      if( this.cibilCrifStatusModel.firmComCrifFetched){    
        this.disableProceedWithoutFlag = 'yes';
    } else {
      this.countYes++;
      console.log("I AM IN COUNT" + this.countYes);
      this.disableProceedWithoutFlag = 'no';
      
    }
    });
  }



PostDataToGetCrifResponse(){
  this.isSpinnerLoading=true; 
  console.warn(this.firmDetailModel);

  this.fetchCommercialCrifService.responseFromCrif(this.firmDetailModel).subscribe((response) => {
  if(response!=null && response=='CRIF Data Successfully fetched and saved'){
      console.log("THIS IS CRIF RESPONSE " + response);
  
      this.setFirmCrifTrue();
      this.isSpinnerLoading=false;
      this.countYes=0;
      this.getFirmDetail();
      this.toastr.success("CRIF FETCHED SUCCESSFULLY");
    }else{
      this.isSpinnerLoading=false;
    }
    
  },(error )=> {
    console.log("ERROR OCCURED " + JSON.stringify(error));
    this.isSpinnerLoading=false
    
  })
}


    setFirmCrifTrue(){
      this.cibilCrifStatusService.firmCrifFetchedStatus(this.userDataModel.referenceId).subscribe(
        (response:CibilCrifStatusModel)=>
      {
          console.log(" On Firm CRIF FETCH PAGE, setFirmCrifTrue: "+ JSON.stringify(response));

       });
    }
   
    onCheckboxChange(event: any): void {
      this.isChecked = event.target.checked;
      if(this.isChecked==true){
        this.disableProceedWithoutFlag='no';
      }else{
        this.disableProceedWithoutFlag='yes';
      }
    }
}
