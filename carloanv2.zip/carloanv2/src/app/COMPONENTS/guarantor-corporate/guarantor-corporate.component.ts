import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';
import { CibilCrifStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-STATUS.model';
import { CorpGuarGSTNFetchedModel, CorporateGuarantorModel } from 'src/app/MODELS/corporateGuarantor.model';
import { CibilCrifStatusService } from 'src/app/SERVICES/CIBIL-CRIF-STATUS/cibil-crif-status.service';
import { CommercialCrifService } from 'src/app/SERVICES/CRIF-commercial-all/fetch-commercial-crif.service';
import { KycPanGstCommercialComponent } from '../kyc-pan-gst-commercial/kyc-pan-gst-commercial.component';
import { HttpErrorResponse } from '@angular/common/http';
import { CorporateGuarantorService } from 'src/app/SERVICES/corporate-guarantor/corporate-guarantor.service';
import { CommercialCibilService } from 'src/app/SERVICES/CIBIL-commercial-all/commercial-cibil.service';

@Component({
  selector: 'app-guarantor-corporate',
  templateUrl: './guarantor-corporate.component.html',
  styleUrls: ['./guarantor-corporate.component.css']
})
export class GuarantorCorporateComponent  implements OnInit{

corpGuarantorModel={} as CorporateGuarantorModel;
allCorporateGuarantorModel: CorporateGuarantorModel[] = [];
fetchedGstnData: any;  //to assign fetched data fields also have additional fields
verified: boolean = false;
editingMode: boolean = false;
showAddFormFlag: boolean = false;
editingIndex: number = -1; //-1 beacause array will have 0 index with values
userModelData = {} as UserModelData;
isSpinnerLoading:boolean = false;
cgtmse!:string;
noCorpGuarantor: boolean=true;
todaydate !: string;
cibilCrifStatusModel ={} as CibilCrifStatusModel;
todaysDateForCibil: Date = new Date();

constructor(
  private modalService: NgbModal,
  private CorpGuarService:CorporateGuarantorService,
  private router: Router,
  private toastr :ToastrService,
  private cibilCrifStatusService: CibilCrifStatusService,
  private commercialCrifService:CommercialCrifService,
  private commercialCibilService:CommercialCibilService
) {}

@ViewChild('corpGuarantorForm') corpGuarantorForm!: NgForm;


// ************************************ COMPONENT INITIALIZED ********************************* 

ngOnInit(): void { 
  this.isSpinnerLoading= true;
  
   const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  console.log("USER DATA MODEL :"+JSON.stringify(this.userModelData));

  this.corpGuarantorModel.branchCode=this.userModelData.brcode;
  console.log("BRANCH CODE: ",this.corpGuarantorModel.branchCode);
  this.corpGuarantorModel.userId=this.userModelData.userId;

  const today = new Date();
  this.todaydate= today.toISOString().split('T')[0];

  this.corpGuarantorGetAll();
  this.statusOfCibilCrif();
}

// ************************************ METHOD TO OPEN MODAL ********************* 

openPanGSTNVerificationModal() {
  const modalRef = this.modalService.open(KycPanGstCommercialComponent,
    {
      backdrop: 'static',
      keyboard: false,
      centered: true,
    });

  if (modalRef.componentInstance.fetchedGstnData) {
    modalRef.componentInstance.fetchedGstnData.subscribe((data: CorpGuarGSTNFetchedModel) => {
      // Received data from PAN GSTN verification comp which is of corpGuarGSTNFetchedModel type
      this.getfetchedGstnData(data);
      this.verified=true;
    });
  } else {
    console.error('fetchedGstnData is not available in the modal component');
  }
}

// ************************************ METHOD TO GET ALL THE CORPORATE GUARANTORS ********************* 

corpGuarantorGetAll() {
  this.isSpinnerLoading = true;
  this.CorpGuarService.getAllCorpGuarList(this.corpGuarantorModel.referenceId).subscribe(
    (response) => {
      if(response!== null){
        this.allCorporateGuarantorModel = response;
        console.log("CORPORATE GUARANTOR LIST: ", JSON.stringify(response));
        this.noCorpGuarantor=false;

      }else{
        this.noCorpGuarantor=true;
      }
      this.isSpinnerLoading = false;
    },(error : HttpErrorResponse) => {
      this.isSpinnerLoading=false;
      console.error("ERROR WHILE GETTING LIST OF CORPORATE GUSRANTORS : "+error)
    }
  );
}

// ********************************** SERVICE INTEGRATION TO SAVE/UPDATE CORP GUARANTOR  ********************* 
saveSingleCorpGuarantor() {
  this.isSpinnerLoading = true;
  this.corpGuarantorModel.roName= this.userModelData.roname
  this.corpGuarantorModel.corporateType='GUARANTOR';

  if (!this.corpGuarantorForm.valid) {
    console.log("Form is not valid!");
    this.toastr.info("Kindly Fill all the Required Fields to Save the details");
    this.isSpinnerLoading = false;
    return; // Exiting method if the form is not valid
  } 
  // Checking if we are in editing mode or adding new guarantor
  if (this.editingMode) {
    this.allCorporateGuarantorModel[this.editingIndex] = { ...this.corpGuarantorModel };
  } else {
    this.corpGuarantorModel.idDto=0; //while adding/saving new data the id should not hold old value
    this.allCorporateGuarantorModel.push({ ...this.corpGuarantorModel });
  }
  this.saveOrUpdateCorpGuarantorToDB();// Save or update the corporate guarantor in the backend
}
  //======================== ACTUAL SAVE ACTION IN DATABASE =====================//
  saveOrUpdateCorpGuarantorToDB() {
  this.corpGuarantorModel.branchCode=this.userModelData.brcode;
    
  this.CorpGuarService.saveOrUpdateSingleCorpGuar(this.corpGuarantorModel).subscribe(
    (response) => {
      console.log("Response from service: ", response);
      const result =JSON.stringify(response);

      // Reset form and fetch updated list only after successful save/update
      this.resetCorporateGuarantorForm();
      this.corpGuarantorGetAll();

      if (this.editingMode) {
        // this.toastr.success("Updated Successfully", "Corporate Guarantor Details", { timeOut: 1000 });
        this.toastr.success(result);
        this.editingMode = false;
        this.editingIndex = -1;
      } else {
        // this.toastr.success("Added Successfully", "New Corporate Guarantor", { timeOut: 1000 });
        this.toastr.success(result);

        this.verified= false;
      }

    },
  (error : HttpErrorResponse) => {
    this.isSpinnerLoading=false;
    console.error("ERROR WHILE SAVING AND FETCHING CORP GUAR CIBIL: "+error)
  }),
  this.showAddFormFlag = false; // Hide the form after successful operation
    
}

// ******************************************** METHOD TO RESET FORM  *******************************************

resetCorporateGuarantorForm(){
  this.corpGuarantorForm.resetForm(); // Reset the form using ViewChild  
}

// ********************************** SERVICE INTEGRATION TO DELETE SINGLE CORP GUARANTOR  ************************ 

confirmDeleteCorpGuarantor(pan: string,name:string) {
  console.log("INSIDE DELETE FROM BACKEND REF_ID: " + this.corpGuarantorModel.referenceId + " pan: " + pan);
  const confirmed = window.confirm('Are you sure you want to delete Corporate Guarantor : ' + name +' ?');

  if (confirmed) {
    this.CorpGuarService.deleteSingleCorpGuarantor(this.corpGuarantorModel.referenceId, pan)
      .subscribe(
        (response: string) => {
          console.log('Message from backend:', response);
         
          this.updateCrifDetailAndHistoryTables(this.corpGuarantorModel.referenceId, this.corpGuarantorModel.pan);
         
          this.corpGuarantorGetAll(); // get the updated list after deleting
          this.toastr.success('Corporate Guarantor Deleted Successfully...!', 'Deleted', { timeOut: 1000 });

          if(this.allCorporateGuarantorModel.length===0){
            this.verified =true;

          }
        }
      );
  }
}

// ***************************************** METHOD TO GET FETCHED GSTN DATA ***********************************

getfetchedGstnData(data: CorpGuarGSTNFetchedModel) {
  //retrieving the data here so that i can call it in ngOnInit to display as soon as comp loaded
  this.fetchedGstnData = data;
  console.log(
    'data from CORPORATE PAN & GSTN to corp gurantor component: ',
    JSON.stringify(data)
  );
  this.verified = true;
  this.setFetchedValues();
}


// ***************************************** METHOD TO GET FETCHED GSTN DATA ***********************************

setFetchedValues() {
  this.corpGuarantorModel = {
    idDto:0,
    gstin: this.fetchedGstnData.gstnVerificationResult.gstin,
    pan: this.fetchedGstnData.pan,
    // name: this.fetchedData.aadharVerificationResult.name,
    gstinStatus:this.fetchedGstnData.gstnVerificationResult.gstinStatus,
    constitutionOfBusiness:this.fetchedGstnData.gstnVerificationResult.constitutionOfBusiness,
    dateOfRegistration:this.fetchedGstnData.gstnVerificationResult.dateOfRegistration,
    principalPlaceOfBusinessAddress:this.fetchedGstnData.gstnVerificationResult.principalPlaceOfBusinessAddress,
    natureOfBusiness:this.fetchedGstnData.gstnVerificationResult.natureOfBusiness,
    stateJurisdictionCode:this.fetchedGstnData.gstnVerificationResult.stateJurisdictionCode,
    dateOfCancellation:this.fetchedGstnData.gstnVerificationResult.dateOfCancellation,
    centreJurisdictionCode:this.fetchedGstnData.gstnVerificationResult.centreJurisdictionCode,
    tradeName:this.fetchedGstnData.gstnVerificationResult.tradeName,
    lastUpdatedDate:this.fetchedGstnData.gstnVerificationResult.lastUpdatedDate,
    centreJurisdiction:this.fetchedGstnData.gstnVerificationResult.centreJurisdiction,
    taxpayerType:this.fetchedGstnData.gstnVerificationResult.taxpayerType,
    legalNameOfBusiness:this.fetchedGstnData.gstnVerificationResult.legalNameOfBusiness,
    additionalPlaceOfBusinessAddress:this.fetchedGstnData.gstnVerificationResult.additionalPlaceOfBusinessAddress,
    stateJurisdiction:this.fetchedGstnData.gstnVerificationResult.stateJurisdiction, 
  
    referenceId: this.userModelData.referenceId,
    userId: this.userModelData.userId,
    branchCode: this.userModelData.brcode,
    roName: this.userModelData.roname,
    branchName: '',
    corpGuarSalutation: '',
    corpGuarName: this.fetchedGstnData.gstnVerificationResult.legalNameOfBusiness,
    corpGuarCustomerType: '',
    corpGuarMobile: '',
    corpGuarBusinessSector: '',
    corpGuarEmail: '',
    corpGuarNatureOfBusiness: '',
    // corpGuarTypeOfBorrower: '',
    corpGuarEstablishmentDate:'',
    corpGuarRegisterAddress: '',
    corpGuarRegisterVillage: '',
    corpGuarRegisterBlock: '',
    corpGuarRegisterPin: '',
    corpGuarRegisterDistrict: '',
    corpGuarRegisterState: '',
    corpGuarCin: '',
    corpGuarUdyam: '',
    corpGuarTan: '',
    corpGuarLei: '',
    corpGuarDateOfCertificate: '',
    corpGuarUdin: '',
    corpGuarNetworth: '',
    corpGuarSourceOfNetWorth: '',
    corpGuarNetworthAsondate: '',
    corpGuarNameOfCa: '',
    corporateType: 'GUARANTOR'
  };
}

// ***************************************** METHOD TO CANCEL SAVING GUARANTOR ***********************************

cancelSavingGuarantor(){
  this.verified = false;
  this.editingMode = false;
}

// ***************************************** METHOD TO EDIT CORP GUARANTOR ***********************************

editCorpGuarantor(guarantor: CorporateGuarantorModel) {
    this.corpGuarantorModel = { ...guarantor }; // Cloning guarantor object to prevent direct modification
    this.editingIndex = this.allCorporateGuarantorModel.indexOf(guarantor);
    this.editingMode = true;
}


// ****************************************************************************************************

characterCount(event: Event) {
  const target = event.target as HTMLTextAreaElement;
    if (target.value.length > 200) {
      target.value = target.value.slice(0, 200); // Limit to 200 characters
      this.corpGuarantorModel.corpGuarRegisterAddress = target.value; 
    }
  }

// **************************************** CIBIL-CRIF STATUS FLAGS SERVICE INTEGRATION ************************************************************
statusOfCibilCrif(){
  this.cibilCrifStatusService.getAllCibilCrifStatus(this.corpGuarantorModel.referenceId).subscribe(
    (response) => {
      console.log("STATUS FLAGS CIBIL-CRIF: "+JSON.stringify(response));
      this.cibilCrifStatusModel=response;    
  })
}

// ******************************* REFETCH COMMERCIAL CIBIL FOR ALL GUARANTORS. ********************************************

refetchComCibilofAllGuarantors(){

  this.isSpinnerLoading=true;
console.warn("this.allCorporateGuarantorModel inside refetchCommCIBILofAllGuarantors: "+ JSON.stringify(this.allCorporateGuarantorModel));

  this.commercialCibilService.fetchComCibilAllGuarantors(this.allCorporateGuarantorModel)
  .subscribe(
    (response) => {
      console.log('response from fetchComCibilAllGuarantors method :', response);  
      // this.allCibilUptoDate = true; 
      // console.warn('Response Success allCibilUptoDate:', this.allCibilUptoDate);
      this.isSpinnerLoading=false;
      this.goNext();
    },
    (error) => {
      console.error('Error fetching CIBIL:', error);
      // this.allCibilUptoDate = false; 
      // console.warn('response error allCibilUptoDate:', this.allCibilUptoDate);
      this.toastr.error('Error fetching CIBIL...!');
      this.isSpinnerLoading=false;
    }
  );
} 
// set cibilUptodateFlag in backend so that next time when page refresh it can fetch value from backend.

// **************************************** UPDATE CRIF DETAILS AND HISTORY TABLES ************************************* 

updateCrifDetailAndHistoryTables(referenceId:string, pan:string){
  this.isSpinnerLoading= true;

  this.commercialCrifService.saveCrifinHistoryAfterDeletion(referenceId,pan).subscribe((response) => {
    console.log("CRIF DATA SAVED IN HISTORY"+response);
  })
  this.isSpinnerLoading= false;

}
// **************************************** REDIRECT TO PREVIOUS PAGE  ************************************* 
goBack() {
   this.router.navigate(['/carLoanV2/borrower-firm']);
}

// **************************************** REDIRECT TO NEXT PAGE  ************************************* 
goNext(){
  this.router.navigate(['/carLoanV2/cibil-commmercial-all']);
}

}