import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuarantorCorporateComponent } from './guarantor-corporate.component';

describe('GuarantorCorporateComponent', () => {
  let component: GuarantorCorporateComponent;
  let fixture: ComponentFixture<GuarantorCorporateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GuarantorCorporateComponent]
    });
    fixture = TestBed.createComponent(GuarantorCorporateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
