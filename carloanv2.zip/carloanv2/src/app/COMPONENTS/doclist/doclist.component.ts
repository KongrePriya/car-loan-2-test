import { Component, OnInit } from '@angular/core';
import { MatRadioChange } from '@angular/material/radio';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';

@Component({
  selector: 'app-doclist',
  templateUrl: './doclist.component.html',
  styleUrls: ['./doclist.component.css'],
  preserveWhitespaces: true,
})
export class DoclistComponent implements OnInit {
  
  userModelData={} as UserModelData;

 constructor(
  private router: Router,
  private toastr: ToastrService,) {}

  ngOnInit(){
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  console.log("USER DATA MODEL :"+JSON.stringify(this.userModelData));
  
  }

  selectedValue: string = 'salaried';

  isValid: boolean = true;

  onRadioChange(valid: boolean) {
    this.isValid = valid;
  }

  mandatoryItems: string[] = [
    'Duly signed request letter from customer/company',
    'Proof of identity ( Aadhar card, PAN card)',
    'Proof of quotation from dealer',
    'Due diligence report , visit report, score model',
  ];
  optionalItems: string[] = [
    'Proof of Identity(Voter ID, Passport, Driving Licence)',
    'Proof of residence(Recent telephone/Electric bill)',
    'Existing loan account statement.',
    'Closed loan NOC',
  ];

  mandatoryextrapensionerItems: string[] = [
    'Latest two year Form 16/ITR with computation',
    'Latest three month salary-slip/Pension-slip',
    'Latest six month bank account statement of salaried account',
  ];
  mandatoryextrabusinessItems: string[] = [
    'Business Licenses/Certifications/Clearances ',
    'Latest two year ITR with computation',
    'Balance-sheet and profit-loss statement',
    'Proof of business activity',
  ];

  goNext(){
    alert("CUSTOMER TYPE : "+this.userModelData.custType);
    
    if(this.userModelData.custType === "individual"){
     this.router.navigate(['/carLoanV2/borrower-individual']);
  }else if(this.userModelData.custType === "corporate"){
   this.router.navigate(['/carLoanV2/borrower-firm']);
  }
}



}
