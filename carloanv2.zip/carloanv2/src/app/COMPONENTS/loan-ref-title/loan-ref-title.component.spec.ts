import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanRefTitleComponent } from './loan-ref-title.component';

describe('LoanRefTitleComponent', () => {
  let component: LoanRefTitleComponent;
  let fixture: ComponentFixture<LoanRefTitleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LoanRefTitleComponent]
    });
    fixture = TestBed.createComponent(LoanRefTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
