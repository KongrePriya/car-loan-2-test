import { Component, OnInit } from '@angular/core';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';

@Component({
  selector: 'app-loan-ref-title',
  templateUrl: './loan-ref-title.component.html',
  styleUrls: ['./loan-ref-title.component.css']
})



export class LoanRefTitleComponent implements OnInit {
  referenceId!:String;
  userModelData={} as UserModelData;


  ngOnInit(): void {
  const abc = sessionStorage.getItem('userModelData');
  this.userModelData = JSON.parse(abc!);
  this.referenceId=this.userModelData.referenceId;
  }
}
