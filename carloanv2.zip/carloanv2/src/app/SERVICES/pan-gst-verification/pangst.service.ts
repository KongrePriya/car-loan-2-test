import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { Observable, of } from 'rxjs';
import { GSTInfoModel } from 'src/app/MODELS/firmBorrowerDetails.model';
import { PANverifyResponseModel } from 'src/app/MODELS/panAadharModel.model';

@Injectable({
  providedIn: 'root'
})
// // //++++++++++++++++++++++ PRODUCTION SERVICES +++++++++++++++++++++++++++//

// export class PangstService {

//   constructor(private http: HttpClient, private ipService: IPAddressService) {}

//   private baseUrl = 'http://' + this.ipService.getItrKycIPAddress() +'/api/v2/kyc/pan-gst'; // PAN Verification ApiURL

//   headers = new HttpHeaders({
//     'Content-Type': 'application/json',
//   });
//   options = { headers: this.headers };


//   //************************ PAN VERIFICATION WITHOUT OTP ****************************** */
//   postPANData(panNumber: any): Observable<any> {

//   //   console.log("Pan Number In Service"+panNumber);
//   //  const json={
//   //   'pan':panNumber
//   //  }
//     return this.http.post<any>(`${this.baseUrl}/all-data-by-pan`, panNumber, this.options);
//   }

// //************************ GSTN VERIFICATION WITHOUT OTP ****************************** */

//    //This Methode Will Post The GST to the database and in response get the Dealers Info
//    getGSTData(gstNumber: any): Observable<GSTInfoModel> {
//     return this.http.get<GSTInfoModel>(`${this.baseUrl}/gst-data/`+gstNumber);
//   }
  
// }


// ===========================================DUMMY DATA============================================//
export class PangstService {

  constructor(private http: HttpClient, private ipService: IPAddressService) {}

  private baseUrl = 'http://' + this.ipService.getItrKycIPAddress() +'/api/v2/kyc'; // PAN Verification ApiURL

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
  });
  options = { headers: this.headers };


  //************************ PAN VERIFICATION WITHOUT OTP ****************************** */
  postPANData(panNumber: any): Observable<any> {

      const PanDummyData:PANverifyResponseModel={
          id: 123,
          loanRefNo: 'ABCD1234', 
          referenceId: 'XYZ456',
          responseMessage: 'PAN VERIFIED...', 
          responseCode: 'SRC001',
          data: {
            id: 1,
            fullName: 'firm',
            pan: 'EWMPK6314R',
            panStatus: 'ACTIVE',
            }
        };
        return of(PanDummyData);
  }

//************************ GSTN VERIFICATION WITHOUT OTP ****************************** */

   //This Methode Will Post The GST to the database and in response get the Dealers Info
   getGSTData(gstNumber: any): Observable<GSTInfoModel> {
      const gstData:GSTInfoModel={
        gstinStatus: 'Active',
        constitutionOfBusiness: "Proprietorship",
        dateOfRegistration: "19/09/2018",
        principalPlaceOfBusinessAddress: "01  BODKE MAIN ROAD AT POST JAHOOR TQ MUKHED DIST NANDED Maharashtra 431715",
        natureOfBusiness: "[Retail Business]",
        stateJurisdictionCode: "MHCG0887",
        gstin: "27DDQPB5915M1Z2",
        dateOfCancellation:  "01/09/2018",
        centreJurisdictionCode: "VJ0402",
        tradeName: "SHIVSHANKAR CEMENT AGENCY",
        lastUpdatedDate: "07/09/2019",
        centreJurisdiction: "RANGE NANDED RURAL",
        taxpayerType: "Regular",
        legalNameOfBusiness: "MANGAL UMAKANT BODKE",
        pan: "DDQPB5915M",
        additionalPlaceOfBusinessAddress: "additional Place Of Business Address ",
        stateJurisdiction: "NAIGAON_701"
        };
        return of(gstData);   

      }
}
