import { TestBed } from '@angular/core/testing';

import { PangstService } from './pangst.service';

describe('PangstService', () => {
  let service: PangstService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PangstService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
