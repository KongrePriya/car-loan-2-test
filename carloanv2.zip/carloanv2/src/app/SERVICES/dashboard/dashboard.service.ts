// upload.service.ts
import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpEventType,
  HttpHeaders,
  HttpRequest,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { IPAddressService } from '../Login/ip.service';
import { DashBoardModel } from 'src/app/MODELS/dashboard.model';
import { UserModelDataForApplicationList } from 'src/app/MODELS/application-list/application-list-data-get.model';
import { UserModelData } from 'src/app/AUTH/login/model/user.model';

@Injectable({
  providedIn: 'root',
})
export class DashBoardService {
  
  constructor(private http: HttpClient, private ipService: IPAddressService) {
  
  }
 
  // url =
  // 'http://localhost:8044/v1/api/dashboard-count';
  // pieUrl =
  // 'http://localhost:8044/v1/api/dashboard-count-current';

  // barUrl =
  // 'http://localhost:8044/v1/api/dashboard-count-quarter';




  url =
  'http://' + this.ipService.getIPAddress() + '/v1/api/dashboard-count';
  pieUrl =
  'http://' + this.ipService.getIPAddress() + '/v1/api/dashboard-count-current';

  barUrl =
  'http://' + this.ipService.getIPAddress() + '/v1/api/dashboard-count-quarter';


  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*', // Adjust this based on your server configuration
    // Add other necessary headers
  });

  getDashBoardCount(
   userDataModel:UserModelDataForApplicationList
  ): Observable<DashBoardModel> {
   // alert(JSON.stringify(userDataModel))
    return this.http.post<DashBoardModel>(
      this.url,userDataModel
    );
  }

  getDashBoardPie(userDataModel:UserModelDataForApplicationList) {
    return this.http.post<DashBoardModel>(
      this.pieUrl, userDataModel,
      { headers: this.headers }
    );
  }
  getDashBoardbar(
    userDataModel:UserModelDataForApplicationList
  ) {
    return this.http.post<any>(
      this.barUrl ,userDataModel,
      { headers: this.headers }
    );
  }
  
  
}
