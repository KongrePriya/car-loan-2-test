import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IPAddressService } from '../Login/ip.service';
import { ReferenceIdModel } from 'src/app/MODELS/referenceid.model';

@Injectable({
  providedIn: 'root'
})
export class RefidGenerationService {

  constructor(private http:HttpClient, private ipService: IPAddressService) { }

  
 private apiUrl ='http://' + this.ipService.getIPAddress() + '/api/v1/ref-id';

//   generateReferenceId(data:any){
//   return this.http.post(`${this.apiUrl}/generation` , data,{
//      responseType: 'text' as 'json',
//   });

// }
// getReferenceId(data:any): Observable<any>{
//   return this.http.get<any>(`${this.apiUrl}/get/`+data,{responseType:'text' as 'json'});
// }

  //*************************************************************************************************//
  //API CONFIG. TO GET OR CREATE NEW REFERENCE ID
  generateReferenceId(data:ReferenceIdModel): Observable<ReferenceIdModel> {
  console.log('TO GET OR CREATE NEW REFERENCE ID service called:', JSON.stringify(data));
  const postUrl=this.apiUrl + '/create'
  return this.http.post<ReferenceIdModel>(postUrl, data);
  } 
  
  // //*************************************************************************************************// 
  //API CONFIG. TO GET REFERENCE ID DATA
  getReferenceId(referenceId: string): Observable<ReferenceIdModel> {
  const getUrl = `${this.apiUrl}/search/${referenceId}`;
  return this.http.get<ReferenceIdModel>(getUrl);

  }

  
}
  
