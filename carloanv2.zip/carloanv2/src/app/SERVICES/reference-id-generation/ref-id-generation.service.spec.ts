import { TestBed } from '@angular/core/testing';

import { RefidGenerationService } from './ref-id-generation.service';

describe('RefIdGenerationService', () => {
  let service: RefidGenerationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RefidGenerationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
