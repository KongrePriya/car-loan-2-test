import { TestBed } from '@angular/core/testing';

import { DecisionStatusService } from './decision-status.service';

describe('DecisionStatusService', () => {
  let service: DecisionStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DecisionStatusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
