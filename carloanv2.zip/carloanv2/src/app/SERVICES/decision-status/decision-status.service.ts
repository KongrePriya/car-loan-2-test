import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DecisionStatusUserInfoDTO } from 'src/app/MODELS/decision-status-all.model';
import { IPAddressService } from '../Login/ip.service';

@Injectable({
  providedIn: 'root'
})
export class DecisionStatusService {

  constructor(private http: HttpClient,
    private ipService:IPAddressService) { }

    private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v2';
  

  getFinalSubmitStatusNew(referenceId: string, userLocation: string, brcode:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/get-final-submit-status/${referenceId}/${userLocation}/${brcode}`, {responseType: 'text' as 'json'});
  }

  updateFinalSubmitStatus(referenceId: string, userId: string):Observable<String>{
      return this.http.put<String>(`${this.baseUrl}/update-final-submit/${referenceId}/${userId}`, {
      responseType : 'text' as 'json'
    });
  }

  checkCanLoggedInUserSAnction(data:DecisionStatusUserInfoDTO):Observable<String>{
    return this.http.post<String>(`${this.baseUrl}/can-user-sanction` , data, {
      responseType : 'text' as 'json'
    })
  }

  checkIsActionTakenByPreviousAuthority(data:DecisionStatusUserInfoDTO):Observable<String>{
    return this.http.post<String>(`${this.baseUrl}/previous-action` , data, {
      responseType : 'text' as 'json'
    })
  }


  buttonActionRecommend(data:DecisionStatusUserInfoDTO):Observable<String>{
    return this.http.post<String>(`${this.baseUrl}/action/recommended` , data, {
      responseType : 'text' as 'json'
    })
  }

  buttonActionReturn(data:DecisionStatusUserInfoDTO):Observable<String>{
    return this.http.post<String>(`${this.baseUrl}/action/return` , data, {
      responseType : 'text' as 'json'
    })
  }

  buttonActionReject(data:DecisionStatusUserInfoDTO):Observable<String>{
    return this.http.post<String>(`${this.baseUrl}/action/reject` , data, {
      responseType : 'text' as 'json'
    })
  }

  buttonActionSanction(data:DecisionStatusUserInfoDTO):Observable<String>{
    return this.http.post<String>(`${this.baseUrl}/action/sanction` , data, {
      responseType : 'text' as 'json'
    })
  }


  getRejectSanctionStatus(referenceId: string):Observable<any>{
    return this.http.get(`${this.baseUrl}/get-rej-san-status/${referenceId}`, {responseType: 'text' as 'json'});
  }

}
