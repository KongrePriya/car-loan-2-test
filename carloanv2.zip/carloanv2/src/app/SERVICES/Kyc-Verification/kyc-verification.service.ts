import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { AadharResponseModel, AuthorizeOtpAadharReponse, AuthorizeOtpAadharRequest, GenerateOtpRequestModel, OTPresponseModel, PANverifyRequestModel, PANverifyResponseModel } from 'src/app/MODELS/panAadharModel.model';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
// //++++++++++++++++++++++ PRODUCTION SERVICES +++++++++++++++++++++++++++//

// export class PanVerificationService {

//   constructor(private http: HttpClient , private ipService:IPAddressService) {}


//   private baseUrl = 'http://'+ this.ipService.getItrKycIPAddress()+'/api/v2/kyc/pan';
  
//   //API CONFIG. TO VERIFY PAN NUMBER 
//   verifyPAN(data:PANverifyRequestModel): Observable<PANverifyResponseModel> {
    
//     const panVerify = this.baseUrl+'/verify';
        
//     return this.http.post<PANverifyResponseModel>(panVerify,data);
//   }
// }

// //************************* CLASS FOR AADHAR APIs *********************//
  
// @Injectable({
//   providedIn: 'root',
// })

// export class AADHARverifyService {
   
//     constructor(private http: HttpClient , private ipService:IPAddressService) {}

//   private baseAadharUrl = 'http://'+ this.ipService.getItrKycIPAddress()+'/api/v2/kyc';
  
// //***********************************************************************************************************************
//   //API CONFIG. TO SEND/get OTP TO THE ENTERED AADHAR NUMBER
//   generateAadharOTP(data:GenerateOtpRequestModel): Observable<OTPresponseModel>{

//     const generateOtp = this.baseAadharUrl+'/aadhar/send-otp';
//     console.log("AADHAR OTP SEND/GENERATE API: ", generateOtp);
    
//     return this.http.post<OTPresponseModel>(generateOtp,data);

// }
// //*********************************************************************************************************************** */
//   //API CONFIG. TO AUTHORIZE THE OTP AND GET THE AADHAR DETAILS IN RESPONSE
//   // authorizeAadharOTP(data:AuthorizeOtpAadharRequest): Observable<AuthorizeOtpAadharReponse>{

//   //   const authorizeOtp = this.baseAadharUrl+'/aadhar-otp/verify';
//   //   console.log("OTP AUTHORIZE/VERIFY API: ", authorizeOtp);
//   //   return this.http.post<AuthorizeOtpAadharReponse>(authorizeOtp,data);
    
//   // }
  
// //***********************************************************************************************************************
//  //API CONFIG. TO AUTHORIZE THE OTP AND GET THE AADHAR DETAILS IN RESPONSE
//  authorizeAadharOTP(data:any): Observable<any>{

//   const authorizeOtp = this.baseAadharUrl+'/aadhar-otp/verify';
//   console.log("OTP AUTHORIZE/VERIFY API: ", authorizeOtp);
//   return this.http.post<AuthorizeOtpAadharReponse>(authorizeOtp,data);
// }

// //***********************************************************************************************************************
// }


// // //++++++++++++++++++++++ SERVICES WITH DUMMY DATA +++++++++++++++++++++++++++//


export class PanVerificationService {

  constructor(private http: HttpClient , private ipService:IPAddressService) {}


  private baseUrl = 'http://'+ this.ipService.getItrKycIPAddress()+'/api/v2/kyc/pan';
  
  //API CONFIG. TO VERIFY PAN NUMBER 
  verifyPAN(data:PANverifyRequestModel): Observable<PANverifyResponseModel> {
    
    const panVerify = this.baseUrl+'/verify';
        
    // return this.http.post<PANverifyResponseModel>(panVerify,data);

       const PanDummyData:PANverifyResponseModel={
        id: 123,
        loanRefNo: 'ABCD1234', 
        referenceId: 'XYZ456',
        responseMessage: 'PAN VERIFIED...', 
        responseCode: 'SRC001',
        data: {
          id: 1,
          fullName: 'PRIYA KONGRE',
          pan: 'EWMPK6314R',
          panStatus: 'ACTIVE',
          }
      };
      return of(PanDummyData);
  }
}



//************************* CLASS FOR AADHAR APIs *********************//
  
@Injectable({
  providedIn: 'root',
})

export class AADHARverifyService {
   
    constructor(private http: HttpClient , private ipService:IPAddressService) {}

  private baseAadharUrl = 'http://'+ this.ipService.getItrKycIPAddress()+'/api/v2/kyc';
  
//***********************************************************************************************************************
  //API CONFIG. TO SEND/get OTP TO THE ENTERED AADHAR NUMBER
  generateAadharOTP(data:GenerateOtpRequestModel): Observable<OTPresponseModel>{

    const generateOtp = this.baseAadharUrl+'/aadhar/send-otp';
    console.log("AADHAR OTP SEND/GENERATE API: ", generateOtp);
    
    // return this.http.post<OTPresponseModel>(generateOtp,data);

    const dummydata:any={
      loanRefNo: 'loanRefNo',
    referenceId: 'REFID',
    responseMessage: 'DUMMY OTP 11111',
    responseCode: 'SRC001',
  }
  return of(dummydata);
}
//*********************************************************************************************************************** */
  //API CONFIG. TO AUTHORIZE THE OTP AND GET THE AADHAR DETAILS IN RESPONSE
  // authorizeAadharOTP(data:AuthorizeOtpAadharRequest): Observable<AuthorizeOtpAadharReponse>{

  //   const authorizeOtp = this.baseAadharUrl+'/aadhar-otp/verify';
  //   console.log("OTP AUTHORIZE/VERIFY API: ", authorizeOtp);
  //   return this.http.post<AuthorizeOtpAadharReponse>(authorizeOtp,data);
    
  // }
  
//***********************************************************************************************************************
 //API CONFIG. TO AUTHORIZE THE OTP AND GET THE AADHAR DETAILS IN RESPONSE
 authorizeAadharOTP(data:any): Observable<any>{

  const authorizeOtp = this.baseAadharUrl+'/aadhar-otp/verify';
  console.log("OTP AUTHORIZE/VERIFY API: ", authorizeOtp);
  // return this.http.post<AuthorizeOtpAadharReponse>(authorizeOtp,data);
    const dummydata:any={
      id: 0,
      loanRefNo: 'loanRefNo',
      referenceId: 'REFID',
      responseMessage: 'aadhar verified',
      responseCode: 'SRC001',
      data:{
     id: 0,
     documentType: 'AADHAR',
     name: 'PRIYA D KONGRE',
    //  dateOfBirth: '1997-04-18',
     dateOfBirth: '2004-04-18',
     gender: 'FEMALE',
     careOf: 'D/O DEEPAK KONGRE',
     house: 'NO. 12',
     street: 'GOKUL NAGAR WARD',
     district: 'CHANDRAPUR',
     subDistrict: 'BALLARPUR',
     landmark: 'NEAR PAPERMILL RAM MANDIR',
     locality: 'BALLARPUR',
     postOfficeName: 'BALLARPUR',
     state: 'MH',
     pincode: '442701',
     country: 'INDIA',
     vtcName: 'Priya',
     mobile: '1236547896',
     email: 'kongrepriya@dafdahgw',
     photoBase64: 'Priyaphoto',
     xmlBase64: 'Priya53135',
   }
  }

  return of(dummydata);
}

//***********************************************************************************************************************
}