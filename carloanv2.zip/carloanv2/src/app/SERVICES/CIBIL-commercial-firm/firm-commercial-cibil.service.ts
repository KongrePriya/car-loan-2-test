// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { IPAddressService } from '../Login/ip.service';
// import { Observable } from 'rxjs';
// import { CibilCommercialBasicDetailsModel, CibilCommercialHistoryDetailsModel, CibilCommercialSummaryDetailsModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-commercial.model';

// @Injectable({
//   providedIn: 'root'
// })
// export class FirmCommercialCibilService {

//   constructor(private http: HttpClient,
//     private ipService:IPAddressService) {}

//     private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/com-cibil/firm';

// //*************************************************************************************************// 
//   //API CONFIG. TO GET BASIC DETAILS of FIRM CIBIL :- we are receiving array because we are using same commerical services for list of guarantors and firm.

//   getFirmBasicDetailsList(refId: string): Observable<CibilCommercialBasicDetailsModel> {
//     const getUrl = this.baseUrl + '/basic/';
//     return this.http.get<CibilCommercialBasicDetailsModel>(getUrl+refId);
//   }

// //*************************************************************************************************// 
//   //API CONFIG. TO GET ALL History Details

//   getFirmHistoryDetailsList(refId: string): Observable<CibilCommercialHistoryDetailsModel[]> {
//     const getUrl = this.baseUrl + '/history/';
//     return this.http.get<CibilCommercialHistoryDetailsModel[]>(getUrl+refId);
//   }
 
// //*************************************************************************************************// 
//   //API CONFIG. TO GET SUMMARY OF FIRM CIBIL

//   getFirmSummaryDetailsList(refId: string): Observable<CibilCommercialSummaryDetailsModel> {
//     const getUrl = this.baseUrl + '/summary/';
//     return this.http.get<CibilCommercialSummaryDetailsModel>(getUrl+refId);
//   }
// //*************************************************************************************************//

// }
