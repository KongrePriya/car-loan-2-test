import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { IPAddressService } from "../Login/ip.service";
import { Observable, catchError, throwError } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class FirmService {
  constructor(private http: HttpClient, private ipService: IPAddressService) {}

  private firmDetailsURL =
    "http://" + this.ipService.getIPAddress() + "/v1/api/firmdetails";

    private firmDetailsWithoutCibilURL =
    "http://" + this.ipService.getIPAddress() + "/v1/api/firmdetails/save-firm-without-cibil";

    // private firmDetailsURLcibil ="http://10.16.237.70:8282/commercial-cibil/fetch/firm";


    
  headers = new HttpHeaders({
    "Header-Name": "Header-Value",
  });

  saveFirmDetailsAndFetchCibil(data: any): Observable<any> {

    const headersForCibil = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });

    return this.http.post<any>(`${this.firmDetailsURL}`, data,{headers:headersForCibil})
  }

  saveFirmDetailswithoutCibil(data: any): Observable<any> {
    return this.http.post<any>(`${this.firmDetailsWithoutCibilURL}`, data).pipe(
      catchError((error) => {
        console.error("Error in Backend:", error);
        return throwError(error);
      })
    );
  }

  getFirmDetails(referenceNumber: string): Observable<any> {
    return this.http.get<any>(this.firmDetailsURL + "/" + referenceNumber);
  }
}
