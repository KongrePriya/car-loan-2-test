// data.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { IPAddressService } from './ip.service';

@Injectable({
  providedIn: 'root',
})
export class ApiService {

  constructor(private http: HttpClient, private ipservice: IPAddressService) {}

  // private getUserApi = 'http://' + this.ipservice.getIPAddress() + '/api/v1/hrms/get';

  // private getUserApiFromMSSO =
  //   'http://' + this.ipservice.getIPAddress() + '/api/v1/hrms/check-user'; // first userId ,password  // msso password

  // private getUserApiFromMSSO =
  // 'http://10.16.237.83:8099/v1/api/login/get-user'; // first userId ,password  // msso password
  // private getDefaultUser =
  // 'http://10.16.237.83:8099/v1/api/login/get-default-user'; // first userId ,password  // msso password


  // private getUserApiFromMSSO =
  // 'http://10.15.51.23:8099/v1/api/login/get-user'; // first userId ,password  // msso password
  // private getDefaultUser =
  // 'http://10.15.51.23:8099/v1/api/login/get-default-user'; // first userId ,password  // msso password

  private getUserApiFromMSSO =
  'http://desktop-ha58tif:8099/v1/api/login/get-user'; // first userId ,password  // msso password
  private getDefaultUser =
  'http://desktop-ha58tif:8099/v1/api/login/get-default-user'; // first userId ,password  // msso password


  getUserData(userId: string): Observable<any> {
    // console.log('Called GetUser Service' + userId);
    const params=new HttpParams()
    .set('userId',userId);
     return this.http.get<any>(`${this.getDefaultUser}` ,{params});
  }
  getUserDataFromMSSO(userId: string, pwd: string): Observable<any> {
   
    // const params=new HttpParams()
    // .set('uid',userId)
    // .set('pwd',password);
    // return this.http.get<any>(
    //   this.getUserApiFromMSSO,{params}
    // );
    const body = { userId, pwd };
    return this.http.post<any>(
      this.getUserApiFromMSSO, body);

  }

  private apiUrl = 'http://'+this.ipservice.getIPAddress()+'/api/files';  // Update to your backend API URL

  // uploadFiles(formData: FormData): Observable<any> {
  //   return this.http.post<any>(this.apiUrl, formData);
  // }

  // Fetch previously uploaded files
  // getFiles(): Observable<any[]> {
  //   return this.http.get<any[]>('http://localhost:8080/api/files/history');
  // }

  getFiles(userId: any): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${userId}`,{responseType:'json'});
  }

  // Upload the file to the server
  uploadFile(formData: FormData): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/upload`, formData, {
      headers: new HttpHeaders(),
      responseType:'json'
    });
  }


  getPdfFile(fileName:string,brcode:string):Observable<Blob>{
    
    
    const formData = new FormData();
    formData.append('filename', fileName);
    formData.append('branchCode', brcode);
   

    return this.http.post(`${this.apiUrl+"/download-pdf"}`,formData, {
      headers: new HttpHeaders({
        'Accept': 'application/octet-stream'
      }),
      responseType: 'blob' // Make sure the response is of type Blob
    });
  }
}
