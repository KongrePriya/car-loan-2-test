// data.service.ts

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class IPAddressService {
  constructor() {}

  setIpAddress(): void {
     sessionStorage.setItem('ipAddress', 'localhost:8039');
    
  //  sessionStorage.setItem('ipAddress', 'desktop-ha58tif:8086');
  }
  
  removeIpAddress(): void {
    sessionStorage.removeItem('ipAddress');
    sessionStorage.removeItem('indvcrifipAddress');
    sessionStorage.removeItem('commcrifipAddress');
    sessionStorage.removeItem('itrKycIpAddress');
    sessionStorage.removeItem('cibilIpAddress');

  }
  ipAddress: string = '';

  getIPAddress(): any {
    this.setIpAddress();
    const ipAddressa = sessionStorage.getItem('ipAddress');
    return ipAddressa ? ipAddressa : null;
  }


  //SETUP FOR CRIF INDIVIDUAL API
  setIndvCrifIpAddress(): void {
    sessionStorage.setItem('indvcrifipAddress', 'localhost:8084');
    // sessionStorage.setItem('indvcrifipAddress', 'desktop-ha58tif:8084');
  }

  getIndvCrifIPAddress(): any {
    this.setIndvCrifIpAddress();
    const indvCrifipAddress = sessionStorage.getItem('indvcrifipAddress');
    return indvCrifipAddress ? indvCrifipAddress : null;
  }

  //*************** SETUP FOR ITR & KYC PROJECT IP ***************//
  setItrKycIpAddress(): void {
    sessionStorage.setItem('itrKycIpAddress', 'localhost:8888');
    // sessionStorage.setItem('itrKycIpAddress', 'desktop-ha58tif:8888');

  }
  getItrKycIPAddress(): any {
    this.setItrKycIpAddress();
    const itrKycIpAddress = sessionStorage.getItem('itrKycIpAddress');
    return itrKycIpAddress ? itrKycIpAddress : null;
  }
//********************************************************************/
 //*************** SETUP FOR CIBIL(ALL) PROJECT IP ***************//
 setCibilIpAddress(): void {
  sessionStorage.setItem('cibilIpAddress', 'localhost:8282');
  // sessionStorage.setItem('cibilIpAddress', 'desktop-ha58tif:8282');

}
getCibilAddress(): any {
  this.setCibilIpAddress();
  const cibilIpAddress = sessionStorage.getItem('cibilIpAddress');
  return cibilIpAddress ? cibilIpAddress : null;
}
//********************************************************************/

  //SETUP FOR CRIF COMMERCIAL API
  setCommCrifIpAddress(): void {
    // sessionStorage.setItem('commcrifipAddress', 'localhost:8085');
    sessionStorage.setItem('commcrifipAddress', 'desktop-ha58tif:8085');

  }

  getCommCrifIPAddress(): any {
    this.setCommCrifIpAddress();
    const indvCrifipAddress = sessionStorage.getItem('commcrifipAddress');
    return indvCrifipAddress ? indvCrifipAddress : null;
  }
}
