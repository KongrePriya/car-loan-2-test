import { TestBed } from '@angular/core/testing';

import { CommercialCibilService } from './commercial-cibil.service';

describe('CommercialCibilService', () => {
  let service: CommercialCibilService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommercialCibilService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
