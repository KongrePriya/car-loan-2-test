import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IPAddressService } from '../Login/ip.service';
import { CibilCommercialBasicDetailsModel, CibilCommercialNewHistoryDetailsModel, CibilCommercialSummaryDetailsModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-commercial.model';
import { CorporateGuarantorModel } from 'src/app/MODELS/corporateGuarantor.model';

@Injectable({
  providedIn: 'root'
})
export class CommercialCibilService {

  constructor(private http: HttpClient,
    private ipService:IPAddressService) {}

    private baseUrl = 'http://'+ this.ipService.getCibilAddress()+'/commercial-cibil/combined';

//*************************************************************************************************// 
  //API CONFIG. TO GET LIST OF BASIC DETAILS

  getAllBasicDetailsList(refId: string): Observable<CibilCommercialBasicDetailsModel[]> {
    const getUrl = this.baseUrl + '/basic-details/';
    return this.http.get<CibilCommercialBasicDetailsModel[]>(getUrl+refId);
  }

//*************************************************************************************************// 
//  // API CONFIG. TO GET ALL History Details as a list (USED FOR FIRM)

//   getSingleHistoryDetailsList(refId: string): Observable<CibilCommercialHistoryDetailsModel[]> {
//     const getUrl = this.baseUrl + '/history/';
//     return this.http.get<CibilCommercialHistoryDetailsModel[]>(getUrl+refId);
//   }
//*************************************************************************************************// 
  //API CONFIG. TO GET ALL History Details As a Object for each guarantor

  getAllHistoryDetailsList(refId: string): Observable<CibilCommercialNewHistoryDetailsModel[]> {
    const getUrl = this.baseUrl + '/history-details/';
    return this.http.get<CibilCommercialNewHistoryDetailsModel[]>(getUrl+refId);
  }
  //*************************************************************************************************// 
  //API CONFIG. TO GET ALL 

  getAllSummaryDetailsList(refId: string): Observable<CibilCommercialSummaryDetailsModel[]> {
    const getUrl = this.baseUrl + '/summary-details/';
    return this.http.get<CibilCommercialSummaryDetailsModel[]>(getUrl+refId);
  }


//*************************************************************************************************//
//API CONFIG.TO FETCH CIBIL OF List of Corporate Guarantors

fetchComCibilAllGuarantors(corpGuarantorModelList: CorporateGuarantorModel[]): Observable<string> {
  console.log('FETCH CIBIL OF List of Corporate Guarantors service called:', JSON.stringify(corpGuarantorModelList));
  
  const postUrl = `${this.baseUrl}/guarantors-list`;
  // Create headers including Content-Type and Accept
  const headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  });

  return this.http.post<string>(postUrl, corpGuarantorModelList, {
    responseType: 'text' as 'json', 
    headers: headers
  })
}
//*************************************************************************************************//  
}
