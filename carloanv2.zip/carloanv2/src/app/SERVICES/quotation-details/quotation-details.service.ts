import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IPAddressService } from '../Login/ip.service';
import { Productdetails, QuotationDetailsModel } from 'src/app/MODELS/quotation-details.model';

@Injectable({
  providedIn: 'root'
})
export class QuotationDetailsService {


  constructor(private http:HttpClient, private ipService: IPAddressService) { }

  
  private apiUrl =
  'http://' + this.ipService.getIPAddress() + '/api/v1/quotation-details';

  
  // ------------------------------------ Other Required Details -----------------------------------------
  postQuotationDetails(data: any):Observable<any> {
    return this.http.post(`${this.apiUrl}/save-quotation-details`, data, {
      responseType: 'text' as 'json',
    });
  }

  getQuotationDetails(referenceId: any):Observable<QuotationDetailsModel> {
     const getUrl = `${this.apiUrl}/fetch-quotation-details/${referenceId}`;
    return this.http.get<QuotationDetailsModel>(getUrl);
  }

  // ------------------------------------ Get Documentation Charges -----------------------------------------
  getDocumentationCharges():Observable<any> {
      return this.http.get(`${this.apiUrl}/documentation-charges`);
  }

  // ------------------------------------ Get Processing Charges -----------------------------------------
  getProcessingCharges():Observable<any> {
    return this.http.get(`${this.apiUrl}/processing-charges`);
}

 // ------------------------------------ Get All Product-Codes -----------------------------------------
 getAllProductCodes(): Observable<Productdetails[]> {
    const getUrl = `${this.apiUrl}/product-codes`;
    return this.http.get<Productdetails[]>(getUrl);
  }

 // ------------------------------------ Get Rate-Of-Interest -----------------------------------------
 getRateOfInterest(productCode: any):Observable<any> {
  return this.http.get(`${this.apiUrl}/rate-of-interest/${productCode}`);
}

// ------------------------------------ Get Product Description -----------------------------------------
getProductDescription(productCode: any):Observable<any> {
  return this.http.get(`${this.apiUrl}/product-desc/${productCode}`);
}
}
