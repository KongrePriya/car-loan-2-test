import { TestBed } from '@angular/core/testing';

import { QuotationDetailsService } from './quotation-details.service';

describe('QuotationDetailsService', () => {
  let service: QuotationDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(QuotationDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
