import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommercialCrifService {

  constructor(private http:HttpClient, private ipService: IPAddressService) { }

  private apiUrl =
  'http://' + this.ipService.getCommCrifIPAddress() + '/v1/api/crif-commercial';


  //Add TO the Database
  responseFromCrif(data:any):Observable<any>{
    return this.http.post(`${this.apiUrl}/individual` , data, {
      responseType: 'text' as 'json'
    });
  }   

  
  //Add TO the Database
  responseFromCrifGuarantor(data:any):Observable<any>{
    // alert(JSON.stringify(data));
    return this.http.post(`${this.apiUrl}/guarantor` , data, {
      responseType: 'text' as 'json'
    });
  }
  // Get all Commercial Guarantors Details
   
  getCommCrifFirmData(referenceId:string,commCrifFetchedFor:string):Observable<any>{
    return this.http.get<any>(`${this.apiUrl}/details/${referenceId}/${commCrifFetchedFor}`)

  }
  
  // Get all Commercial History Details 
  getCommCrifFirmHistoryData(referenceId:string,commCrifFetchedFor:string):Observable<any>{
    
     return this.http.get<any>(`${this.apiUrl}/history/${referenceId}/${commCrifFetchedFor}`)
    // return this.http.get<any>(`${this.apiUrl}/history/MGBGST20241203hdfj8/${commCrifFetchedFor}`)
    
  }
  // Get all Commercial Summary Details 
  getCommCrifFirmSummaryData(referenceId:string,commCrifFetchedFor:string):Observable<any>{
    return this.http.get<any>(`${this.apiUrl}/summary-data/${referenceId}/${commCrifFetchedFor}`)

  }
    //Update CRIF Details and History Tables After Guarantor is Deleted
    saveCrifinHistoryAfterDeletion(referenceId: string, panNumber: string):Observable<any>{
    return this.http.post<any>(`${this.apiUrl}/remove-guarantor/${referenceId}/${panNumber}`,{})
  }
 
}
