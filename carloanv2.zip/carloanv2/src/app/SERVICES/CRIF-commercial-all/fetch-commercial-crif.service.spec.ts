import { TestBed } from '@angular/core/testing';

import { FetchCommercialCrifService } from './fetch-commercial-crif.service';

describe('FetchCommercialCrifService', () => {
  let service: FetchCommercialCrifService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FetchCommercialCrifService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
