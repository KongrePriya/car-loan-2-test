import { TestBed } from '@angular/core/testing';

import { CorporateGuarantorService } from './corporate-guarantor.service';

describe('CorporateGuarantorService', () => {
  let service: CorporateGuarantorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CorporateGuarantorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
