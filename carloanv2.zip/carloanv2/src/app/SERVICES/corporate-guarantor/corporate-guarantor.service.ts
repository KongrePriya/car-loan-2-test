import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { Observable } from 'rxjs';
import { CorporateGuarantorModel } from 'src/app/MODELS/corporateGuarantor.model';

@Injectable({
  providedIn: 'root'
})
export class CorporateGuarantorService {

  constructor(private http: HttpClient,
    private ipService:IPAddressService) {}

private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/corporate';
 
//*************************************************************************************************//
//API CONFIG. TO GET SAVE OR UPDATE CORPORATE GUARANTOR DETAILS
saveOrUpdateSingleCorpGuar(corpGuarantorModel: CorporateGuarantorModel): Observable<String> {
console.log('save all immovable security service called:', JSON.stringify(corpGuarantorModel));
const postUrl=this.baseUrl + '/save-or-update'
return this.http.post<String>(postUrl, corpGuarantorModel, {responseType: 'text' as 'json'});
} 

//*************************************************************************************************// 
//API CONFIG. TO GET ALL CORPORATE GUARANTORS/LIST
getAllCorpGuarList(refId: string): Observable<CorporateGuarantorModel[]> {
const getUrl = this.baseUrl + '/retrieve/';
return this.http.get<CorporateGuarantorModel[]>(getUrl+refId);
}

//*************************************************************************************************//
//API CONFIG. TO MARK CORPORATE GUARANTOR DELETED
deleteSingleCorpGuarantor(refId:string, pan:string): Observable<string>{
const deleteUrl= `${this.baseUrl}/remove/${refId}/${pan}`;
return this.http.put<string>(deleteUrl,{},{
responseType: 'text' as 'json'})
}
//*************************************************************************************************//   



}