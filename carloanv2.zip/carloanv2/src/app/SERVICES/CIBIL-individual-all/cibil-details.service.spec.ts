import { TestBed } from '@angular/core/testing';

import { IndividualCibilAllDetailsService } from './cibil-details.service';

describe('CibilDetailsService', () => {
  let service: IndividualCibilAllDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IndividualCibilAllDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
