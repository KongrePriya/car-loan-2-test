import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { CibilFetchStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-fetch-status.model';
import { Observable } from 'rxjs';
import { CibilIndividualBasicDetailsModel, CibilIndividualNewHistoryDetailsModel, CibilIndividualSummaryDetailsModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-Individual.model';

//================ CIBIL DETAILS SERVICE CLASS ======================//

@Injectable({
  providedIn: 'root'
})
export class IndividualCibilFetchDetailsService {


  constructor(private http: HttpClient,
    private ipService:IPAddressService) {}

    private baseUrl = 'http://'+ this.ipService.getCibilAddress()+'/personal-cibil';
   
//*************************************************************************************************// 
  //API CONFIG. TO GET LIST OF BASIC DETAILS

  getAllBasicDetailsIndividualCibil(refId: string): Observable<CibilIndividualBasicDetailsModel[]> {
    // console.log("CIBIL IP: "+this.baseUrl);
    const getUrl = this.baseUrl + '/basic-details/';
    return this.http.get<CibilIndividualBasicDetailsModel[]>(getUrl+refId);
  }

//*************************************************************************************************// 
  //API CONFIG. TO GET ALL History Details As a Object for each guarantor

  getAllHistoryDetailsIndividualCibil(refId: string): Observable<CibilIndividualNewHistoryDetailsModel[]> {
    const getUrl = this.baseUrl + '/history-details/';
    return this.http.get<CibilIndividualNewHistoryDetailsModel[]>(getUrl+refId);
  }
  //*************************************************************************************************// 
  //API CONFIG. TO GET ALL 

  getAllSummaryDetailsIndividualCibil(refId: string): Observable<CibilIndividualSummaryDetailsModel[]> {
    const getUrl = this.baseUrl + '/summary-details/';
    return this.http.get<CibilIndividualSummaryDetailsModel[]>(getUrl+refId);
  }
//*************************************************************************************************//
//*************************************************************************************************//
}



//================ CIBIL FETCH STATUS FLAGS SERVICE CLASS ======================//

@Injectable({
  providedIn: 'root',
})

export class CibilFetchStatusService {
   
constructor(private http: HttpClient , private ipService:IPAddressService) {}

  private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/cibil-status';
  
//***********************************************************************************************************************
//API CONFIG. TO GET  CIBIL FETCH STATUS OF ALL
getCibilFetchStatusDetails(referenceId: string): Observable<CibilFetchStatusModel> {
  const getUrl = `${this.baseUrl}/${referenceId}`;
  return this.http.get<CibilFetchStatusModel>(getUrl);
  }
  
 
//***********************************************************************************************************************
}
