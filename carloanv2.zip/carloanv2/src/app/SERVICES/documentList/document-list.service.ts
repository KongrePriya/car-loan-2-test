import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DocumentListService {

   constructor(private http: HttpClient,
      private ipService:IPAddressService) {}
      
       private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/documents';
  
      // private baseUrl = 'http://localhost:8086/documents';
  
  
  //*************************************************************************************************// 
  //API CONFIG. TO GET Document List Model For Home Loan 
  // getDocumentListDetails(): Observable<DocumentListModel> {
  //   const getUrl = `${this.baseUrl}`;
  //   return this.http.get<DocumentListModel>(getUrl);
  //   }
   // Get all documents
   getDocuments(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  // Create a new document
  createDocument(document: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, document);
  }

  // Delete a document
  deleteDocument(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  // Get all subdocuments for a specific document
  getSubdocuments(documentId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/${documentId}/subdocuments`);
  }

  // Create a new subdocument for a specific document
  createSubdocument(documentId: number, subdocument: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/${documentId}/subdocuments`, subdocument);
  }

  // Update a subdocument
  updateSubdocument(id: number, subdocument: any): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/subdocuments/${id}`, subdocument);
  }

  // Delete a subdocument
  deleteSubdocument(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/subdocuments/${id}`);
  }


  private documentUploadUrl='http://' + this.ipService.getIPAddress() + '/api/files/upload';

  //For Uploading Document....
  uploadDocument(fileInputs:any,referenceId:string,brcode:string):Observable<any>{
    const formData = new FormData();
    formData.append('file', fileInputs.file!);
    formData.append('remark', fileInputs.remark);
    formData.append('fileType', fileInputs.fileType);
    formData.append('referenceID', referenceId);
    formData.append('branchCode', brcode);
    return this.http.post(this.documentUploadUrl,formData, { responseType: 'text' });

  }
  
  }
  