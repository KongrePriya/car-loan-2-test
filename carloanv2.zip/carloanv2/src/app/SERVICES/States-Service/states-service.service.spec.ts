import { TestBed } from '@angular/core/testing';

import { StatesServiceService } from './states-service.service';

describe('StatesServiceService', () => {
  let service: StatesServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StatesServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
