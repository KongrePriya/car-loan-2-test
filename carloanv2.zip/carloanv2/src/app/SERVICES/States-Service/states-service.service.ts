import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StatesServiceService {

  constructor(private http: HttpClient, 
    private ipService:IPAddressService) {}

private baseUrl = 'http://desktop-ha58tif:8083/v1/api/state-code';


  getStates(): Observable<any> {
    // return this.http.get<any[]>('../assets/statecode.json');
    return this.http.get<any>(this.baseUrl);
  }
}
