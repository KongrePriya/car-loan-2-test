import { TestBed } from '@angular/core/testing';

import { CoappGurantorPresentService } from './coapp-gurantor-present.service';

describe('CoappGurantorPresentService', () => {
  let service: CoappGurantorPresentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CoappGurantorPresentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
