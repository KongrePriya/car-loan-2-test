import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { HttpClient } from '@angular/common/http';
import { CoAppGuarantorModel, CoappGuaPresentStatus } from 'src/app/MODELS/coapp-gurantor-present.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CoappGurantorPresentService {

  constructor(private ipService: IPAddressService, private http: HttpClient,) { }

  private apiUrl = 'http://' + this.ipService.getIPAddress() + '/api/v1/coapp-guarantor/get/document-required';
  private cooappGuarStatusUrl = 'http://' + this.ipService.getIPAddress() + '/api/v1/coapp-guarantor/get/coappGuarantorStatus';
  getCoAppGurantorStatusForDocument(referenceId: string): Observable<CoAppGuarantorModel> {
    // console.log('${this.apiUrl}/${referenceId}');
    //const refere='MGBHOME@2025013047a';
    // return this.http.get<CoAppGuarantorModel>(`${this.apiUrl}/${referenceId}`);
    return this.http.get<CoAppGuarantorModel>(`${this.apiUrl}/${referenceId}`);
  }

  getCoapplicantGuaratorStatus(referenceId: string): Observable<CoappGuaPresentStatus> {
    // console.log('${this.apiUrl}/${referenceId}');
    //const refere='MGBHOME@2025013047a';
    // return this.http.get<CoAppGuarantorModel>(`${this.apiUrl}/${referenceId}`);
    return this.http.get<CoappGuaPresentStatus>(`${this.cooappGuarStatusUrl}/${referenceId}`);
  }
}
