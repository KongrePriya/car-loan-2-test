import { TestBed } from '@angular/core/testing';

import { AppraisalNoteService } from './appraisal-note.service';

describe('AppraisalNoteService', () => {
  let service: AppraisalNoteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppraisalNoteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
