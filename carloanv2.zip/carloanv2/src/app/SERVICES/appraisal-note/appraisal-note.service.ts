import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { Observable } from 'rxjs';
import { UserModelDataForApplicationList } from 'src/app/MODELS/application-list/application-list-data-get.model';

@Injectable({
  providedIn: 'root'
})
export class AppraisalNoteService {

  constructor(private http: HttpClient,
    private ipService:IPAddressService) {}

    private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/reference-id-validation';
    private appraisalStaticUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/appraisal-note/get/';



        //*************************************Get Appraisal Note Static Data********************************************** */
        
    getAppraisalNoteData(refId: string): Observable<any> {

      return this.http.get<any>(this.appraisalStaticUrl+refId);
    }
    //*************************************Get Appraisal Note Static Data End********************************************** */

   
    //*************************************Application Flow /Appraisal Button APIs********************************************** */




  //Final Submit Only For BRanch Officer and Manager
  
  // finalSubmitURL =
  // 'http://localhost:8044/v1/api/final-submit';

  finalSubmitURL =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/final-submit';

 
  //************************************************************************ */
  // sanctionPowerCheckurl =
  // 'http://localhost:8044/v1/api/check-sanction-under';
  sanctionPowerCheckurl =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/check-sanction-under';

  // checkFinalSubmitURL =
  // 'http://localhost:8044/v1/api/final-submit-check';
  checkFinalSubmitURL =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/final-submit-check';

  // pieUrl =
  // 'http://localhost:8044/v1/api/dashboard-count-current';
   pieUrl =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/dashboard-count-current';

  // barUrl =
  // 'http://localhost:8044/v1/api/dashboard-count-quarter';
  barUrl =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/dashboard-count-quarter';


  //Sanction
  
  // sanctionUrl =
  // 'http://localhost:8044/v1/api/sanction';
  sanctionUrl =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/sanction';


  //Recommended

  
// recommendedUrl =
//   'http://localhost:8044/v1/api/recommended';
recommendedUrl =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/recommended';


  //Reject


  // rejectUrl =
  // 'http://localhost:8044/v1/api/reject';
  rejectUrl =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/reject';

  //Return

  // returnUrl =
  // 'http://localhost:8044/v1/api/return';
  returnUrl =
  'http://'+ this.ipService.getIPAddress()+'/v1/api/return';



  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*', // Adjust this based on your server configuration
    // Add other necessary headers
  });


  checkAppSanctionPower(
   userDataModel:UserModelDataForApplicationList
  ): Observable<any> {
   // alert(JSON.stringify(userDataModel))
    return this.http.post<any>(
      this.sanctionPowerCheckurl,userDataModel
    );
  }
  
  checkFinalSubmissionFlag(userDataModel:UserModelDataForApplicationList): Observable<any> {
    // alert(JSON.stringify(userDataModel))
     return this.http.post<any>(
       this.checkFinalSubmitURL,userDataModel,{responseType:'text' as 'json'}
     );
   }

   setFinalsubmit(userDataModel:UserModelDataForApplicationList): Observable<any> {
    // alert(JSON.stringify(userDataModel))
     return this.http.post<any>(
       this.finalSubmitURL,userDataModel,{responseType:'text' as 'json'}
     );
   }

   setSanction(userDataModel:UserModelDataForApplicationList): Observable<any> {
    // alert(JSON.stringify(userDataModel))
     return this.http.post<any>(
       this.sanctionUrl,userDataModel,{responseType:'text' as 'json'}
     );
   }
   
   setReturn(userDataModel:UserModelDataForApplicationList): Observable<any> {
    // alert(JSON.stringify(userDataModel))
     return this.http.post<any>(
       this.returnUrl,userDataModel,{responseType:'text' as 'json'}
     );
   }
   
   setReject(userDataModel:UserModelDataForApplicationList): Observable<any> {
    // alert(JSON.stringify(userDataModel))
     return this.http.post<any>(
       this.rejectUrl,userDataModel,{responseType:'text' as 'json'}
     );
   }
   
   setRecommended(userDataModel:UserModelDataForApplicationList): Observable<any> {
    // alert(JSON.stringify(userDataModel))
     return this.http.post<any>(
       this.recommendedUrl,userDataModel,{responseType:'text' as 'json'}
     );
   }


   //Post AppraisalNote Data for Additional Conditions and Additional Remarks
   private apiUrl =
   'http://' + this.ipService.getIPAddress()+'/api/v1/appraisal-note';
   postAppraisalNoteRemarksAndConditions(data:any):Observable<any>{
    
      return this.http.post<any>(`${this.apiUrl}/save-or-update`,data,{responseType:'text' as 'json'})
    }


   }


   

