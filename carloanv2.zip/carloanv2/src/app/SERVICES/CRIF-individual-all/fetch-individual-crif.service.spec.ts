import { TestBed } from '@angular/core/testing';

import { FetchIndividualCrifService } from './fetch-individual-crif.service';

describe('FetchIndividualCrifService', () => {
  let service: FetchIndividualCrifService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FetchIndividualCrifService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
