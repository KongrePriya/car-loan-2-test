import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {  IndividualBasicDetailsModel } from 'src/app/MODELS/Individual-basic-details.model';
import { IPAddressService } from '../Login/ip.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FetchIndividualCrifService {

  
  constructor(private http:HttpClient, private ipService: IPAddressService) { }

  private apiUrl = 'http://' + this.ipService.getIPAddress() + '/api/v1';
  // private crifApiUrl = 'http://' + this.ipService.getIPAddress() + '/api/v1'; Change This Later to CrifUrl
  private crifExternalApiUrl = 'http://' + this.ipService.getIndvCrifIPAddress() + '/api/v1';
  private crifDisplayApiUrl = 'http://' + this.ipService.getIndvCrifIPAddress() + '/api/v1/standard';


   // ---------------------- Applicant/Co-Applicant/Guarantors-Details-Main-List -----------------------
   getCrifList(referenceId: string):Observable<IndividualBasicDetailsModel[]>{
    return this.http.get<IndividualBasicDetailsModel[]>(`${this.apiUrl}/crif-list/${referenceId}`);
  }


  // ------------------------------------ Get Response From CRIF External API-----------------------------------------
  responseFromCrif(data:any):Observable<any>{
    return this.http.post(`${this.crifExternalApiUrl}/crif-request` , data, {
      responseType: 'text' as 'json'
    });
  }


// --------------------- Get all Individual Guarantors Details ---------------------------------
  getAllIndGuardetailsList(referenceId: string): Observable<any> {
    return this.http.get<any>(`${this.crifDisplayApiUrl}/indv-crif-details/${referenceId}`)
    }
  
// ------------------- Get all Individual Guarantors History ------------------------------------
    getAllIndGuarhistoryList(referenceId: string): Observable<any> {
      return this.http.get<any>(`${this.crifDisplayApiUrl}/indv-crif-history/${referenceId}`)
      }
  
// ---------------------- Get all Individual Guarantors Summary ---------------------------------
    getAllIndGuarSummaryList(referenceId: string): Observable<any> {
      return this.http.get<any>(`${this.crifDisplayApiUrl}/indv-crif-summary/${referenceId}`)
      }

// ----------------------- Remove Crif Data if Guarantor Is Deleted -----------------------------
    removeIndividualCrifData(referenceId: string,panNumber: string): Observable<any>{
        return this.http.post(`${this.crifDisplayApiUrl}/std-crif-remove/${referenceId}/${panNumber}` , {
          responseType: 'text' as 'json'
        });
      }

  // ----------------------- Update Crif Fetch Flag When Data is fetched Successfully -----------------------------
  updateCrifFlag(referenceId: string,panNumber: string, crifFlagStatus:string): Observable<String>{
    return this.http.put<String>(`${this.apiUrl}/crif-fetch-flag/${referenceId}/${panNumber}/${crifFlagStatus}`,{
      responseType : 'text' as 'json'
    });
  }

   // ----------------------- Reset Crif Fetch Flag When Data is fetched Successfully -----------------------------
   resetAllCrifFlagsMonthly(referenceId: string): Observable<String>{
    return this.http.put<String>(`${this.apiUrl}/crif-reset-flag/${referenceId}`,{
      responseType : 'text' as 'json'
    });
  }
}
