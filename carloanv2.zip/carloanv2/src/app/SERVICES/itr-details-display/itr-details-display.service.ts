import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { ItrFilingDetailsModel } from 'src/app/MODELS/itrFilingDetailsModel.model';
import { Observable } from 'rxjs';
import { ItrVerifiedRefIdResponse } from 'src/app/MODELS/itrVerificationModel.model';

@Injectable({
  providedIn: 'root'
})
export class ItrDetailsDisplayService {

  constructor(private http: HttpClient,
    private ipService:IPAddressService) {}
    
    private baseUrl = 'http://'+ this.ipService.getItrKycIPAddress()+'/api/v1/itr-details';


//*************************************************************************************************// 
//API CONFIG. TO GET ITR DETAILS OF BORROWER / GUARANTOR 
getITRFilingDetails(referenceIdLotus: string, customerType:string): Observable<ItrFilingDetailsModel> {
  const getUrl = `${this.baseUrl}/get/${referenceIdLotus}/${customerType}`;
  return this.http.get<ItrFilingDetailsModel>(getUrl);
  }

//*************************************************************************************************//  
//API CONFIG. TO GET ITR Verified Reference ID
getITRVerifiedReferenceIdDetails(referenceIdLotus: string, customerType:string): Observable<ItrVerifiedRefIdResponse> {
  const getUrl = `${this.baseUrl}/ref-id/${referenceIdLotus}/${customerType}`;
  return this.http.get<ItrVerifiedRefIdResponse>(getUrl);
  }
//*************************************************************************************************// 
//API CONFIG. TO SET ConsentProvided field in backend 
setITRConsentProvided(referenceIdLotus: string, customerType:string): Observable<String> {
  console.log(" Inside setITRConsentProvided :" ,referenceIdLotus, customerType);
  
  const getUrl = `${this.baseUrl}/consent/${referenceIdLotus}/${customerType}`;
  console.warn(" Inside setITRConsentProvided getUrl :" ,getUrl);

  return this.http.get<String>(getUrl, {
    responseType: 'text' as 'json'});
  }
//*************************************************************************************************// 

}
