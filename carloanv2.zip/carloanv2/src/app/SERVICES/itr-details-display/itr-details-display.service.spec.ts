import { TestBed } from '@angular/core/testing';

import { ItrDetailsDisplayService } from './itr-details-display.service';

describe('ItrDetailsDisplayService', () => {
  let service: ItrDetailsDisplayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ItrDetailsDisplayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
