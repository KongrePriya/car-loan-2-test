import { TestBed } from '@angular/core/testing';

import { ItrVerificationService } from './itr-verification.service';

describe('ItrVerificationService', () => {
  let service: ItrVerificationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ItrVerificationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
