import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { ItrRequestDataLotus, itrVerificationRequestModel, itrVerificationResponseModel } from 'src/app/MODELS/itrVerificationModel.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ItrVerificationService {

 
  constructor(private http: HttpClient,
    private ipService:IPAddressService) {}
  
  private baseUrl = 'http://'+ this.ipService.getItrKycIPAddress()+'/api/v1/itr';

  //*************************************************************************************************//
  // STEP-1 :: API CONFIG. TO GENERATE REF-ID FOR ITR VERIFICATION 
  generateRefIdForVerification(itrVerificationRequestModel: itrVerificationRequestModel): Observable<itrVerificationResponseModel> {
    console.log('Itr: ref-id generation service called:', JSON.stringify(itrVerificationRequestModel));
    const postUrl=this.baseUrl + '/request-email'
    return this.http.post<itrVerificationResponseModel>(postUrl, itrVerificationRequestModel);
    } 
    
 //*************************************************************************************************//
  // STEP-1 :: API CONFIG. TO FETCH ITR DETAILS FROM GENERATED REF-ID
 fetchDetailsFromRefId(itrRequestDataLotus:ItrRequestDataLotus): Observable<String> {
    console.log('ITR: fetch ITR details from ref-id service called:', JSON.stringify(itrRequestDataLotus));
    const postUrl=this.baseUrl+'/url-response-email';
    return this.http.post<String>(postUrl, itrRequestDataLotus, {responseType: 'text' as 'json'});
    } 
    
//*************************************************************************************************//
// fetchDetailsFromRefId(itrRefId:string): Observable<String> {
//   console.log('ITR: fetch ITR details from ref-id service called:', JSON.stringify(itrRefId));
//   const postUrl=`${this.baseUrl}/url-response-email/${itrRefId}`;
//   return this.http.post<String>(postUrl, String, {responseType: 'text' as 'json'});
//   } 
  
}
