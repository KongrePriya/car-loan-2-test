import { TestBed } from '@angular/core/testing';

import { IncomeDetailsAllService } from './income-details-all.service';

describe('IncomeDetailsAllService', () => {
  let service: IncomeDetailsAllService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IncomeDetailsAllService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
