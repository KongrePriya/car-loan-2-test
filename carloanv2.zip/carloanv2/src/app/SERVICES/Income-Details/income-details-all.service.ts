import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IPAddressService } from '../Login/ip.service';
import { IncomeDetailsListModel } from 'src/app/MODELS/income-list.model';

@Injectable({
  providedIn: 'root'
})
export class IncomeDetailsForAllService {

  constructor(private http:HttpClient, private ipService: IPAddressService) { }

  
  private apiUrlSalaried =
  'http://' + this.ipService.getIPAddress() + '/api/v1/income-salary';
  private apiUrlPensioner =
  'http://' + this.ipService.getIPAddress() + '/api/v1/income-pension';
  private apiUrlBusiness =
  'http://' + this.ipService.getIPAddress() + '/api/v1/income-business';

  private apiUrl = 'http://' + this.ipService.getIPAddress() + '/api/v1';


  // ------------------------------------ Income API for salaried Details -----------------------------------------
  postIncomeDetailsSalaried(data: any):Observable<any> {
    return this.http.post(`${this.apiUrlSalaried}/add`, data, {
      responseType: 'text' as 'json',
    });
  }

  getIncomeDetailsSalaried(referenceId: any,panNumber:any):Observable<any> {
    const params = new HttpParams()
    .set('referenceId', referenceId)
    .set('panNumber', panNumber);
    return this.http.get(`${this.apiUrlSalaried}/fetch`, { params });
    
  }


// ------------------------------------ Income API for PENSIONER Details -----------------------------------------
postIncomeDetailsPensioner(data: any):Observable<any> {
  return this.http.post(`${this.apiUrlPensioner}/add`, data, {
    responseType: 'text' as 'json',
  });
}

getIncomeDetailsPensioner(referenceId: any,panNumber:any):Observable<any> {
  const params = new HttpParams()
  .set('referenceId', referenceId)
  .set('panNumber', panNumber);
  console.log('inside get pension   '+referenceId+' '+panNumber);
  return this.http.get(`${this.apiUrlPensioner}/fetch`, { params });
  
}


  // ------------------------------------ Income-Details-Main-List -----------------------------------------
  getIncomeListMain(referenceId: string):Observable<IncomeDetailsListModel[]>{
    return this.http.get<IncomeDetailsListModel[]>(`${this.apiUrl}/income-list/${referenceId}`);
  }


  getIncomeCount(referenceId: string):Observable<string>{
    return this.http.get<string>(`${this.apiUrl}/income-count/${referenceId}`,{
      responseType: 'text' as 'json'
    });
  }

  /////////////******************************income api for Business **************************** */
  getIncomeDetailsBusiness(referenceId: any,panNumber:any):Observable<any> {
    const params = new HttpParams()
    .set('referenceId', referenceId)
    .set('panNumber', panNumber);
    console.log('inside get service business  '+referenceId+' '+panNumber);
    
    return this.http.get(`${this.apiUrlBusiness}/fetch`, { params });
    
  }

  postIncomeDetailsBusiness(data: any):Observable<any> {
    return this.http.post(`${this.apiUrlBusiness}/add`, data, {
      responseType: 'text' as 'json',
    });
  }
}
