import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CibilCrifStatusModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-STATUS.model';
import { IPAddressService } from '../Login/ip.service';

@Injectable({
  providedIn: 'root'
})
export class CibilCrifStatusService {

  constructor(private http: HttpClient,
    private ipService:IPAddressService) {}

    private statusUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/cibil-crif-status';

//*************************************************************************************************// 
//API CONFIG. TO CHECK STATUS OF CIBIL & CRIF

  getAllCibilCrifStatus(refId: string): Observable<CibilCrifStatusModel> {
    const getUrl = this.statusUrl + '/get/';
    return this.http.get<CibilCrifStatusModel>(getUrl+refId);
  }
//*************************************************************************************************// 
//API CONFIG. TO CHECK STATUS OF CIBIL & CRIF

crifRequiredStatus(refId:string, loanAmt: number): Observable<CibilCrifStatusModel>{
  const crifUrl= `${this.statusUrl}/update-crif-required/${refId}/${loanAmt}`;
  return this.http.patch<CibilCrifStatusModel>(crifUrl,{});
}

//*************************************************************************************************// 
//API CONFIG. TO GET COUNT OF CRIF FETCHED for both Individual Guarantors & Corporate Guarantors

individualCRIFCount(refId:string): Observable<CibilCrifStatusModel>{
  const getUrl= this.statusUrl + '/get-crif-count-both/';
  return this.http.get<CibilCrifStatusModel>(getUrl+refId);
}

//*************************************************************************************************// 
//API CONFIG. TO Change Status of Firm CRIF (When FIRM CRIF fetched successfully: true, in other cases: false)

// firmCrifFetchedStatus(refId:string, status:string): Observable<CibilCrifStatusModel>{
//   const firmUrl= `${this.statusUrl}/update-firm-crif/${refId}/${status}`;
//   return this.http.patch<CibilCrifStatusModel>(firmUrl,{});
// }

firmCrifFetchedStatus(refId:string): Observable<CibilCrifStatusModel>{
  // const firmUrl= `${this.statusUrl}/update-firm-crif/${refId}`;
  const firmUrl= this.statusUrl + '/update-firm-crif/';
  return this.http.get<CibilCrifStatusModel>(firmUrl+refId);
}
}
