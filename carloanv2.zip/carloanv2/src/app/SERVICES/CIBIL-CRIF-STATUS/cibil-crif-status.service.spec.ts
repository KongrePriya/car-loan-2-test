import { TestBed } from '@angular/core/testing';

import { CibilCrifStatusService } from './cibil-crif-status.service';

describe('CibilCrifStatusserviceService', () => {
  let service: CibilCrifStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CibilCrifStatusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
