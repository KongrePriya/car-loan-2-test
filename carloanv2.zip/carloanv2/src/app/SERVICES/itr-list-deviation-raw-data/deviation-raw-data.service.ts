import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RawDataForDeviationModel } from 'src/app/MODELS/deviation-data-model';
import { IPAddressService } from '../Login/ip.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class DeviationRawDataRedirectService {

  constructor(private http: HttpClient,
    private ipService:IPAddressService,
    private router: Router) {}
    
    private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/deviation';


//*************************************************************************************************// 
//API CONFIG. TO GET DEVIATION RAW-DATA ENTITY
getDeviationRawData(referenceId: string): Observable<RawDataForDeviationModel> {
  const getUrl = `${this.baseUrl}/raw-data/${referenceId}`;
  return this.http.get<RawDataForDeviationModel>(getUrl);
  }

//*************************************************************************************************//

//API CONFIG. TO REDIRECT TO PARTICULAR ITR PAGES BASED ON RAW DATA SET
redirectToItrUsingRawData(referenceId: string, customerType: string):void{
   
    this.getDeviationRawData(referenceId).subscribe(
      (rawData: RawDataForDeviationModel) => {
        // Once the data is received, redirect to verification page based on cust-type
        if (rawData.applicantITRPresent === 'Yes' && customerType === 'APPLICANT') {
          this.router.navigate(['/carLoanV2/applicant-itr-verify']);
        } else
         if (rawData.coapplicantOneITRPresent === 'Yes'  && customerType === 'COAPPLICANT1') {
          this.router.navigate(['/carLoanV2/coapp-one-itr-verify']);
        } else 
        if (rawData.coapplicantTwoITRPresent === 'Yes'  && customerType === 'COAPPLICANT2') {
          this.router.navigate(['/carLoanV2/coapp-two-itr-verify']);
        } else
        {
          //if no one has ITR
          this.router.navigate(['/carLoanV2/income-main-list']);
        }
      },
      (error) => {
        console.error('Error fetching raw data', error);
      }
    );
}
//*************************************************************************************************//

//API CONFIG. TO REDIRECT TO PARTICULAR ITR PAGES BASED ON RAW DATA SET
redirectToItrView(referenceId: string, customerType: string):void{ 
  this.getDeviationRawData(referenceId).subscribe(
    (rawData: RawDataForDeviationModel) => {
      // Once the data is received, redirect to display page based on cust-type
      if (rawData.applicantITRPresent === 'Yes' && customerType === 'APPLICANT') {
        this.router.navigate(['/carLoanV2/applicant-itr-display']);
      } else
       if (rawData.coapplicantOneITRPresent === 'Yes'  && customerType === 'COAPPLICANT1') {
        this.router.navigate(['/carLoanV2/coapp-one-itr-display']);
      } else 
      if (rawData.coapplicantTwoITRPresent === 'Yes'  && customerType === 'COAPPLICANT2') {
        this.router.navigate(['/carLoanV2/coapp-two-itr-display']);
      } else {
        //if no one has ITR
        this.router.navigate(['/carLoanV2/income-main-list']);
      }
    },
    (error) => {
      console.error('Error fetching raw data', error);
    }
  );
}

//*************************************************************************************************//
}
