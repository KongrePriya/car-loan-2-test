import { TestBed } from '@angular/core/testing';

import { DeviationRawDataService } from './deviation-raw-data.service';

describe('DeviationRawDataService', () => {
  let service: DeviationRawDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DeviationRawDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
