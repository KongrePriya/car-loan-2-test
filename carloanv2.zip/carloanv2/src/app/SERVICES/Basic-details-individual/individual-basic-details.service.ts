import { Injectable } from '@angular/core';
import { catchError, map, Observable, throwError } from 'rxjs';
import { IPAddressService } from '../Login/ip.service';
import { HttpClient } from '@angular/common/http';
import { IndividualBasicDetailsModel, IndividualCoapplicantGuarantorBasicDetails } from 'src/app/MODELS/Individual-basic-details.model';

@Injectable({
  providedIn: 'root'
})
export class IndividualBasicDetailsService {

  constructor(private http: HttpClient,
  private ipService:IPAddressService) {}
  
  private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/individual';
    
  //*************************************************************************************************//
  //API CONFIG. TO GET SAVE OR UPDATE BORROWER / GUARANTOR DETAILS
  saveOrUpdateDetails(applicantBasicDetailsModel: IndividualBasicDetailsModel): Observable<String> {
  console.log('save APPLICANT/CO-APPLICANT/GUARANTOR DETAILS service called:', JSON.stringify(applicantBasicDetailsModel));
  const postUrl=this.baseUrl + '/save-or-update'
  return this.http.post<String>(postUrl, applicantBasicDetailsModel, {responseType: 'text' as 'json'});
  } 
  
  // //*************************************************************************************************// 
  //API CONFIG. TO GET ALL BORROWER / GUARANTOR 
  getBorrowerOrGuarantorDetails(referenceId: string, customerType:string): Observable<IndividualBasicDetailsModel> {
  const getUrl = `${this.baseUrl}/retrieve/${referenceId}/${customerType}`;
  return this.http.get<IndividualBasicDetailsModel>(getUrl);
  }
  
  //*************************************************************************************************//
  //API CONFIG. DELETE APLLICANT  
  deleteBorrowerOrGuarantor(referenceId:string, customerType:string,pan:string, userId:string): Observable<string>{
  const deleteUrl = `${this.baseUrl}/delete?referenceId=${referenceId}&customerType=${customerType}&pan=${pan}&deletedBy=${userId}`;
        return this.http.delete<string>(deleteUrl, {
            responseType: 'text' as 'json'});
  }

  //*************************************************************************************************//
  //API CONFIG. TO GET SAVE OR UPDATE APLLICANT DETAILS AND REFETCH CIBIL
  updateDetailsAndRefetchCIBIL(applicantBasicDetailsModel: IndividualBasicDetailsModel): Observable<String> {
    console.log('Refetch CIBIL & Update APPLICANT/CO-APPLICANT/GUARANTOR DETAILS service called:', JSON.stringify(applicantBasicDetailsModel));
   
     const postUrl=this.baseUrl + '/cibil-refetch'

    return this.http.post<String>(postUrl, applicantBasicDetailsModel, {responseType: 'text' as 'json'});
    } 

  //*************************************************************************************************//
  //API CONFIG. TO REFETCH CIBIL FOR ALL 
  RefetchCIBILForAll(referenceId:string): Observable<String> {
    console.log('Refetch CIBIL for all service called:', JSON.stringify(referenceId));
    const postUrl=this.baseUrl + '/cibil-refetch-all'
    return this.http.post<String>(postUrl, referenceId, {responseType: 'text' as 'json'});
  } 
   

//*************************************************************************************************// 
//API CONFIG. TO GET ALL CO-APPLICANT LIST
getAllcoappList(refId: string): Observable<IndividualCoapplicantGuarantorBasicDetails[]> {
const getUrl = this.baseUrl + '/get/all-coapplicant/';

console.log('all coapplicant list api called')

return this.http.get<IndividualCoapplicantGuarantorBasicDetails[]>(getUrl+refId);

}

 // //*************************************************************************************************// 
  // API CONFIG. TO GET COUNT OF COAPPLICANTS CONTRIUTING IN INCOME
  getCoapplicantIncomeConsider(referenceId: string): Observable<string[]> {
    const getUrl = `${this.baseUrl}/get/income-consider-or-not/${referenceId}`;
    
    return this.http.get<string[]>(getUrl).pipe(
      map((response: string[]) => {
        if (response && response.length > 0) {
          return response;
        } else {
          // If empty array, just return it
          return [];
        }
      }),
      catchError((error) => {
        console.error('Error in getCoapplicantIncomeConsider:', error);
        return throwError('Failed to fetch data from the server');
      })
    );
  }
  
  // //*************************************************************************************************// 

  //API CONFIG. TO GET COUNT OF COAPPLICANTS CONTRIUTING IN INCOME
  getCoappIncomeConsiderCount(referenceId: string): Observable<number> {
    const getUrl = `${this.baseUrl}/get-income-count/${referenceId}`;
    return this.http.get<number>(getUrl);

  }
  // //*************************************************************************************************// 

  //API CONFIG. TO GET ALLOWED CUST TYPE WHEN INCOME IS CONSIDERED
  getAllowedCustType(referenceId: string, consideringIncome:string): Observable<any> {
    const getUrl = `${this.baseUrl}/get-cust-type/${referenceId}`;
    return this.http.get<any>(getUrl,{responseType: 'text' as 'json'});

  }
  

   // //*************************************************************************************************// 
  //API CONFIG. TO GET ALL BORROWER / GUARANTOR
  // getCoapplicantIncomeConsider(referenceId: string): Observable<string[]> {
  //   const getUrl = `${this.baseUrl}/get/income-consider-or-not/${referenceId}`;
    
  //   return this.http.get<string[]>(getUrl).pipe(
  //     map((response: string[]) => {
  //       if (response && response.length > 0) {
  //         return response;
  //       } else {
  //         // If empty array, just return it
  //         return [];
  //       }
  //     }),
  //     catchError((error) => {
  //       console.error('Error in getCoapplicantIncomeConsider:', error);
  //       return throwError('Failed to fetch data from the server');
  //     })
  //   );
  // }
  

  //****************************************************************************************** */

  //API CONFIG. TO GET ALL CO-APPLICANT LIST
  getCoapplicantData(refId: string,aadhar:string,pan:string): Observable<IndividualCoapplicantGuarantorBasicDetails> {

    const getUrl = `${this.baseUrl}/get/coapplicant-data/${refId}/${aadhar}/${pan}`;
     console.log("GET URL :"+getUrl);

      return this.http.get<IndividualCoapplicantGuarantorBasicDetails>(getUrl);
    }
      

  //****************************************************************************************** */

  //API CONFIG. TO GET ALL CO-APPLICANT LIST
getAllGuarantorList(refId: string): Observable<IndividualCoapplicantGuarantorBasicDetails[]> {
  const getUrl = this.baseUrl + '/get/all-guarantor/';

  return this.http.get<IndividualCoapplicantGuarantorBasicDetails[]>(getUrl+refId);
}

  //****************************************************************************************** */



  }
  
