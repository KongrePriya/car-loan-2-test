import { TestBed } from '@angular/core/testing';

import { IndividualBasicDetailsService } from './individual-basic-details.service';

describe('ApplicantCoapplicantGuarantorBasicDetailsService', () => {
  let service: IndividualBasicDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IndividualBasicDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
