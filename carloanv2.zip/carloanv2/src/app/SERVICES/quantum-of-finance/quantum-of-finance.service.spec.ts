import { TestBed } from '@angular/core/testing';

import { QuantumOfFinanceService } from './quantum-of-finance.service';

describe('QuantumOfFinanceService', () => {
  let service: QuantumOfFinanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(QuantumOfFinanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
