import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { Observable } from 'rxjs';
import { QuantamOfFinanceModel } from 'src/app/MODELS/quantam-of-finance.model';

@Injectable({
  providedIn: 'root'
})
export class QuantumOfFinanceService {

  constructor(private http: HttpClient, private ipService: IPAddressService) {}

  getCalculationSummary(referenceId: string): Observable<QuantamOfFinanceModel> {

    const getUrl=`http://` + this.ipService.getIPAddress() +`/api/v1/calculation/get/` +referenceId;

    return this.http.get<QuantamOfFinanceModel>(getUrl);
  }
  
}
