import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { Observable } from 'rxjs';
import { DeviationFlagModel } from 'src/app/MODELS/deviation-data-model';

@Injectable({
  providedIn: 'root'
})
export class DeviationService {
  
  headers = new HttpHeaders({
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*' });

  constructor(private http: HttpClient, private ipService:IPAddressService) {}
    
  private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/deviation';


//*************************************************************************************************// 
//API CONFIG. TO GET DEVIATION DATA 
getDeviationFlagData(referenceId: string): Observable<DeviationFlagModel> {
  const getUrl = `${this.baseUrl}/${referenceId}`;
  return this.http.get<DeviationFlagModel>(getUrl);
  }

}