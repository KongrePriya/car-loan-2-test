import { TestBed } from '@angular/core/testing';

import { DocumentsAndRemarksService } from './documents-and-remarks.service';

describe('DocumentsAndRemarksService', () => {
  let service: DocumentsAndRemarksService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DocumentsAndRemarksService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
