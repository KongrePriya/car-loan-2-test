import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DocumentsAndRemarksModel, MandatoryDocumentsModel, SingleDocumentRemarkDetailsModel } from 'src/app/MODELS/documents-and-remarks.model';

@Injectable({
  providedIn: 'root'
})
export class DocumentsAndRemarksService {

 
   constructor(private http: HttpClient, private ipService:IPAddressService) {}
 
   private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/document-and-remark';


  //************************ upload  file ************************//
  uploadFile( file:File, data: SingleDocumentRemarkDetailsModel): Observable<any> {
    const formData=new FormData();
    const jsonBlob=new Blob ([JSON.stringify(data)], {
      type:'application/json'
    });
    formData.append('data',jsonBlob);
    formData.append('file',file);

  return this.http.post(`${this.baseUrl}/upload`, formData, 
      {   responseType: 'text' as 'json'});
  }
  //************************ Preview file ************************//
  previewFile(refId: string, fileType:string ): Observable<Blob> {
    const url = `${this.baseUrl}/preview/${refId}/${fileType}`;
    return this.http.get(url, { responseType: 'blob' });
  }
  
  //************************ Download Document file *****************************//
  downloadFile(refId: string, fileType:string): Observable<HttpResponse<Blob>> {
    const url = `${this.baseUrl}/download/${refId}/${fileType}`;
    return this.http.get(url, { responseType: 'blob', observe: 'response' });
  }

//************************ get all remarks and Document file names *****************************//
  getAllDocumentRemarkData(refId: string): Observable<DocumentsAndRemarksModel> {
    const url = `${this.baseUrl}/get-all/${refId}`;
    return this.http.get<DocumentsAndRemarksModel>(url);
  }

  // ***************** get all remarks and Document file names *****************************//
getAllMandatoryDocumentData(refId: string): Observable<MandatoryDocumentsModel> {
  const url = `${this.baseUrl}/mandatory/${refId}`;
  return this.http.get<MandatoryDocumentsModel>(url);
}
  
}
