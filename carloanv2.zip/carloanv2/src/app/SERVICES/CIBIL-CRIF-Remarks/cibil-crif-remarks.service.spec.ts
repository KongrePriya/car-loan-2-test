import { TestBed } from '@angular/core/testing';

import { CibilCrifRemarksFinalService } from './cibil-crif-remarks.service';

describe('CibilCrifRemarksService', () => {
  let service: CibilCrifRemarksFinalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CibilCrifRemarksFinalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
