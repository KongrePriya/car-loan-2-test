import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPAddressService } from '../Login/ip.service';
import { Observable } from 'rxjs';
import { CibilCrifRemarksFinalModel } from 'src/app/MODELS/CIBIL-CRIF-ALL/CIBIL-CRIF-final-Remark.model';

@Injectable({
  providedIn: 'root'
})
export class CibilCrifRemarksFinalService {

  constructor(private http: HttpClient, private ipService:IPAddressService) {}

  private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/remark';
    

//*************************************************************************************************// 
  //API CONFIG. TO GET ALL THE REMARKS OF CIBIL & CRIF
  getAllCibilCrifRemarks(refId: string): Observable<CibilCrifRemarksFinalModel> {
    const getUrl = this.baseUrl + '/get-all/';
    return this.http.get<CibilCrifRemarksFinalModel>(getUrl+refId);
  }

//*************************************************************************************************// 
  //API CONFIG. TO POST/SAVE THE REMARKS OF CIBIL & CRIF
  CibilPersonalRemarksSaveOrUpdate(remarksModel: CibilCrifRemarksFinalModel): Observable<String> {
    console.log("CibilPersonalRemarksSaveOrUpdate SERVICE CALLED: "+ JSON.stringify(remarksModel));
    const postUrl=this.baseUrl + '/personal-cibil-save'
    return this.http.post<String>(postUrl, remarksModel, {responseType: 'text' as 'json'});
    } 

//*************************************************************************************************// 
  //API CONFIG. TO POST/SAVE THE REMARKS OF CIBIL & CRIF
  CibilCommercialRemarksSaveOrUpdate(remarksModel: CibilCrifRemarksFinalModel): Observable<String> {
    console.log("CibilCommercialRemarksSaveOrUpdate SERVICE CALLED: "+ JSON.stringify(remarksModel));
    const postUrl=this.baseUrl + '/commercial-cibil-save'
    return this.http.post<String>(postUrl, remarksModel, {responseType: 'text' as 'json'});
    } 

//*************************************************************************************************// 
  //API CONFIG. TO POST/SAVE THE REMARKS OF CIBIL & CRIF
  CrifPersonalRemarksSaveOrUpdate(remarksModel: CibilCrifRemarksFinalModel): Observable<String> {
    console.log("CrifPersonalRemarksSaveOrUpdate SERVICE CALLED: "+ JSON.stringify(remarksModel));
    const postUrl=this.baseUrl + '/personal-crif-save'
    return this.http.post<String>(postUrl, remarksModel, {responseType: 'text' as 'json'});
    } 

//*************************************************************************************************// 
  //API CONFIG. TO POST/SAVE THE REMARKS OF CIBIL & CRIF
  CrifCommercialRemarksSaveOrUpdate(remarksModel: CibilCrifRemarksFinalModel): Observable<String> {
    console.log("CrifCommercialRemarksSaveOrUpdate SERVICE CALLED: "+ JSON.stringify(remarksModel));
    const postUrl=this.baseUrl + '/commercial-crif-save'
    return this.http.post<String>(postUrl, remarksModel, {responseType: 'text' as 'json'});
    } 

//*************************************************************************************************// 
  //API CONFIG. TO REJECT DUE TO CIBIL & CRIF
  rejectDueToCibilCrif(remarksModel: CibilCrifRemarksFinalModel): Observable<String> {
    console.log("rejectDueToCibilCrif SERVICE CALLED: "+ JSON.stringify(remarksModel));
    const rejectUrl=this.baseUrl + '/reject'
    return this.http.put<String>(rejectUrl, remarksModel, {responseType: 'text' as 'json'});
    } 

//*************************************************************************************************//
//************************ upload  file ************************//
  uploadFile(refId: string, userId: string , formData: FormData): Observable<any> {

  return this.http.post(`${this.baseUrl}/upload/${refId}/${userId}`, formData, 
     {   responseType: 'text' as 'json'});
}
//************************ Preview file ************************//
previewFile(refId: string ): Observable<Blob> {
  const url = `${this.baseUrl}/preview/${refId}`;
  return this.http.get(url, { responseType: 'blob' });
}

//************************ Download Document file *****************************//
downloadFile(refId: string): Observable<HttpResponse<Blob>> {
  const url = `${this.baseUrl}/download/${refId}`;
  return this.http.get(url, { responseType: 'blob', observe: 'response' });
}


}




// export class CibilCrifRemarksService {

//   constructor(private http: HttpClient,
//     private ipService:IPAddressService) {}

//     private baseUrl = 'http://'+ this.ipService.getIPAddress()+'/api/v1/cibil-crif-remark';
    

// //*************************************************************************************************// 
//   //API CONFIG. TO GET ALL THE REMARKS OF CIBIL & CRIF

//   getAllCibilCrifRemarks(refId: string): Observable<CibilCrifRemarksModel> {
//     const getUrl = this.baseUrl + '/get/';
//     return this.http.get<CibilCrifRemarksModel>(getUrl+refId);
//   }

// //*************************************************************************************************// 
//   //API CONFIG. TO POST/SAVE THE REMARKS OF CIBIL & CRIF

//   saveOrUpdateCibilCrifRemarks(remarksModel: CibilCrifRemarksModel): Observable<String> {

//     console.log("CIBI/CRIF REMARKS SERVICE CALLED: "+ JSON.stringify(remarksModel));
//     const postUrl=this.baseUrl + '/save-or-update'
//     return this.http.post<String>(postUrl, remarksModel, {responseType: 'text' as 'json'});
//     } 


// //*************************************************************************************************//
// }
