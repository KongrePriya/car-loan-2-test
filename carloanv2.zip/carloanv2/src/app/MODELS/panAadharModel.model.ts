export interface PANverifyRequestModel
{
// id: number;
loanRefNo: string;
pan: string;
}

export interface PANverifyResponseModel
{
id: number;
loanRefNo: string; 
referenceId: string; 
responseMessage: string; 
responseCode: string; 
data: PANresponseData
}

export interface PANresponseData{
id: number;
fullName: string; 
pan: string; 
panStatus: string; 
}

export interface GenerateOtpRequestModel{
    // id: number;
    loanRefNo: string; 
    aadhaar_number: string; 
}

export interface OTPresponseModel{
    loanRefNo: string;
    referenceId: string;
    responseMessage: string;
    responseCode: string;
}

export interface AuthorizeOtpAadharRequest{
    loanRefNo : string;
    otp : string;
    aadhaar_number:string;
}

export interface AuthorizeOtpAadharReponse{
id : number;
loanRefNo : string;
referenceId : string;
responseMessage : string;
responseCode : string;
data:AadharResponseModel
}

export interface AadharResponseModel
{
id: number;
documentType: string; 
name: string|""; 
dateOfBirth: string; 
gender: string; 
careOf: string; 
house: string; 
street: string;
district: string;
subDistrict: string;
landmark: string; 
locality: string; 
postOfficeName: string; 
state: string; 
pincode: string; 
country: string; 
vtcName: string; 
mobile: string; 
email: string; 
photoBase64?: string; 
xmlBase64?: string; 
}


export interface AllKycInfoModel{
    pan:string;
    aadhar:string;
    kycData:AuthorizeOtpAadharReponse
}