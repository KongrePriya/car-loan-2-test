export interface DeviationFlagModel {

  referenceId: string;
  branchCode: string;
  loanType:string;
  applicantName: string;
  applicantPan: string;

  //AGE DEVIATION
  applicantAgeDeviation: string;
  coapplicantOneAgeDeviation: string;
  coapplicantTwoAgeDeviation: string;

  //CIBIL-ALL
  cibilScoreDeviation: string;
  cibilOverdueDeviation: string;
  cibilWrittenOffDeviation: string;
  cibilSettledDeviation: string;
  cibilDeviation: string; //after comparing above 4 fields

  //LOAN METRICS
  processingChargeDeviation: string;
  documentationChargeDeviation: string;
  maxLoanTenureAllowedDeviation: string;
  repaymentAgeDeviation: string;

  //WORK EXPERIENCE
  applicantWorkExperienceDeviation: string;
  coapplicantOneWorkExperienceDeviation: string;
  coapplicantTwoWorkExperienceDeviation: string;

  //ITR-FORM16 DEVIATION
  applicantItrForm16Deviation: string;
  coapplicantOneItrForm16Deviation: string;
  coapplicantTwoItrForm16Deviation: string;

  //LOAN ELIGIBILITY DEVIATION
  loanEligibleDeductionDeviation: string;
  loanEligibleMarginDeviation: string;

  //INCOME DEVIATION
  incomeDeviationCombined: string;

  ageServiceItrDeviationCombined: string;
  relationWithApplicantDeviation:string;

  anyDeviationPresent: string;

}

export interface RawDataForDeviationModel {
  id: number;
  referenceId: string;
  branchCode: string;
  regionName: string;

  // applicant
  applicantName: string;
  applicantAgeInMonths: number;
  applicantIncomeSource: string;
  applicantIncomeConsider: string;
  applicantITRPresent: string;
  appItrOrForm16Deviation: string;
  applicantItrVerified: string;
  applicantPan:string;

  // coapp one
  coapplicantOneName: string;
  coapplicantOneAgeInMonths: number;
  coapplicantOneIncomeSource: string;
  coapplicantOneIncomeConsider: string;
  coapplicantOneITRPresent: string;
  coappOneItrOrForm16Deviation: string;
  coappOneItrVerified: string;
  coapplicantOnePan:string;
  
  // coapp two
  coapplicantTwoName: string;
  coapplicantTwoAgeInMonths: number;
  coapplicantTwoIncomeSource: string;
  coapplicantTwoIncomeConsider: string;
  coapplicantTwoITRPresent: string;
  coappTwoItrOrForm16Deviation: string;
  coappTwoItrVerified: string;
  coapplicantTwoPan:string;


  //ITR Required & Verified Count
  numberOfPersonHaveItr: number;
  numberOfItrFetched: number;
  allItrFetched: boolean;

  countOfCorrectItrFetched:number;
  allFetchedItrAreCorrect:boolean;

}
