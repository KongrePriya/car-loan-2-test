export interface IncomeDetailsListModel{
    fullName:string;
    referenceId:string;
    customerType:string;
    pan:string;
    consideringIncome:string;
    incomeSourceType:string;
}