//FOR APPLICANT
export interface IndividualBasicDetailsModel {
   idDto: number;
  referenceId:string;
  branchCode:string;
  userId:string;
  title: string;
  fatherName: string;
  pan: string;
  aadhar: string;
  voterIdCard: string;
  drivingLicence: string;
  passportNum: string;
  rationCardNumber: string;
  qualification: string;
  permanentAddress: string;
  residenceOwnership: string; 
  cif: string;
  netWorth:string;
  presentAddress: string;
  alternateEmail: string;
  altMobile:  string;
  tempAddressLine1: string;
  // tempAddressLine2: string;
  tempAddressLandmark: string;
  tempAddressSubDist: string;
  tempAddressDist: string;
  tempAddressState: string;
  tempAddressPincode:string;
  customerType:string;
  timestamp:string;
  //fetched fields
  fullName: string;
  gender: string;
  email: string; 
  dateOfBirth: string; 
  mobileNumber: string;
  careOf:string,
  house: string,
  street: string,
  district: string,
  subDistrict: string,
  landmark: string,
  locality: string,
  postOfficeName: string,
  state: string,
  pincode: string,
  country: string,
  vtcName: string,
  mobile: string,
  aadharAddress:string,
  consideringIncome:string,
  incomeSourceType:string,
  itrFilledForAnyYear:string,
  form16Available:string,
  occupation:string

}


//FOR CO-APPLICANT AND GUARANTOR

export interface IndividualCoapplicantGuarantorBasicDetails {
referenceId:string;
branchCode:string;
userId:string;
idDto: number;

title: string;

fatherName: string;
pan: string;
aadhar: string;
voterIdCard: string;
drivingLicence: string;
passportNum: string;

rationCardNumber: string;
qualification: string;

permanentAddress: string;
residenceOwnership: string; 
cif: string;
netWorth:string;

presentAddress: string;
alternateEmail: string;
altMobile:  string;

tempAddressLine1: string;
// tempAddressLine2: string;
tempAddressLandmark: string;
tempAddressSubDist: string;
tempAddressDist: string;
tempAddressState: string;

tempAddressPincode:string;
pfNomineeAge:string;
customerType:string;
timestamp:string;

//fetched fields
fullName: string;
gender: string;
email: string; 
dateOfBirth: string; 
mobileNumber: string;
careOf:string,
house: string,
street: string,
district: string,
subDistrict: string,
landmark: string,
locality: string,
postOfficeName: string,
state: string,
pincode: string,
country: string,
vtcName: string,
mobile: string,
aadharAddress:string,

//15102024
occupation:string,

// earningMember:string,
// incomeSourceType:string

consideringIncome:string,
incomeSourceType:string,
itrFilledForAnyYear:string
form16Available:string;

relationWithApplicant:string;
relationWithApplicantOther:string 

}
