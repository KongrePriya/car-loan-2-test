export interface ReferenceIdModel{

     panNumber :string,
     borrowerType :string,
     referenceId :string,
     loanType :string,
     applicationStatus :string,
     refIdFlag :string,
     applicationCreatedDate :string,
     userId :string,
     u_type :string,
     brcode :string,
     roname :string,
     u_status :string,
     u_loc :string,
     u_name :string,
     scale :string,
     sourceType:string,
     dsaNumber:string,
     brname:string,
     shortBorrowerType:string;
     custType:string;
     u_id: string;
    shortLoanType:string;

}

export interface ReferenceIdResponseModel{
    message:string,
    referenceId:string;
    referenceIdFlag:string;
    applicationCreatedDate:string;
    panNumber:string;
}


export interface LoanType{
    loanType:string;
}