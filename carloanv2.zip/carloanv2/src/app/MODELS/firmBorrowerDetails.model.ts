export interface FirmBorrowerDetailsModel {
  firmEstablishmentDate:string;
  firmSalutation: string;
  firmLegalNameOfBusiness: string;
  firmTradeName: string;
  firmCustomerType: string;
  firmMobile: string;
  firmBusinessSector: string;
  firmEmail: string;
  firmNatureOfBusiness: string;
  firmTypeOfBorrower: string;
  firmBranchCode: string;
  firmBranchName: string;
  firmRoName: string;
  firmRegisterAddress: string;
  firmRegisterVillage: string;
  firmRegisterBlock: string;
  firmRegisterPin: string;
  firmRegisterDistrict: string;
  firmRegisterState: string;
  firmOtherAddress: string;
  firmOtherVillage: string;
  firmOtherBlock: string;
  firmOtherPin: string;
  firmOtherDistrict: string;
  firmOtherState: string;
  firmReferenceId: string;
  firmCin: string;
  firmPan: string;
  firmGstn: string;
  firmUdyam: string;
  firmTan: string;
  firmLei: string;
  firmDateOfCertificate: string;
  firmUdin: string;
  firmNetWorth: number;
  firmSourceOfNetWorth: string;
  firmNetWorthAsOnDate: string;
  firmNameOfCa: string;

  //Newly Added By Siddhant on 16/07/2024
  firmGstinStatus: string;
  firmConstitutionOfBusiness: string;
  firmDateOfRegistration: string;
  firmPrincipalPlaceOfBusinessAddress: string;
  firmStateJurisdictionCode: string;
  firmDateOfCancellation: string;
  firmCentreJurisdictionCode: string;
  firmLastUpdatedDate: string;
  firmCentreJurisdiction: string;
  firmTaxpayerType: string;
  firmAdditionalPlaceOfBusinessAddress: string;
  firmStateJurisdiction: string;
  userId:string;
  commCrifFetchedFor:string;
  crifCommFetched:string;
  corporateType:string;
  bankingwithus:string;
 
}

export interface PANmodel {
  pan: string;
}
export interface GSTInfoModel {
  gstinStatus: string;
  constitutionOfBusiness: string;
  dateOfRegistration: string;
  principalPlaceOfBusinessAddress: string;
  natureOfBusiness: string;
  stateJurisdictionCode: string;
  gstin: string;
  dateOfCancellation: string;
  centreJurisdictionCode: string;
  tradeName: string;
  lastUpdatedDate: string;
  centreJurisdiction: string;
  taxpayerType: string;
  legalNameOfBusiness: string;
  pan: string;
  additionalPlaceOfBusinessAddress: string;
  stateJurisdiction: string;
}

export interface ErrorModel {
  timestamp: string;
  statusCode: number;
  status: string;
  message: string;
}