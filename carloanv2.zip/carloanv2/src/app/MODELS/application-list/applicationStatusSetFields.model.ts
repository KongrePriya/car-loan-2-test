export class ApplicationStatusSetModel {
    referenceId:string="";
    referenceIdCrr:string="";
    branchCode:string="";
    branchName:string="";
    regionName:string="";
    appliedLoanAmt:number=0.0;
    userId:string="";
    userType:string="";
    userLoc:string="";
    userName:string="";
    userScale:string="";
}