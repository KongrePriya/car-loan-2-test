
//List To Get THe Application Data
export interface UserModelDataForApplicationList{
  userId: string;
  userType: string;
  branchCode: string;
  regionName: string;
  ustatus: string;
  userLoc: string;
  username: string;
  userScale: string;
  custType:string;
  referenceId:string;
  referenceIdCrr:string;
  cgtmse:string;
  listdisplayAction:string;
  fundedExposure:number;
  nonFundedExposure:number;
  totalExposure:number;
  status:string;
  userName:string;

}
