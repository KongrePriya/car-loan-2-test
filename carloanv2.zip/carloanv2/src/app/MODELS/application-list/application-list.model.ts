//List To Get THe Application Data
export interface ApplicationListDataModel{

  referenceId:string
  referenceIdCrr:string
  branchCode:string;
  branchName:string;
  regionName:string;
  applicantName:string;
  applicationCreationDate:string;
  appliedLoanAmt:string;
  statusDate:string;
  statusBy:string;
 }


 export interface AllApplicationStatusModel{
  
    id: string ,
    firmTradeName: string,
    firmCustomerType: string ,
    cgtmseCoverage: string ,
    recommendedAmt: number ,
    applicationCreationDate: string,
    referenceId: string,
    referenceIdCrr: string ,
    roname: string ,
    userLoc: string ,
    userType: string ,
    branchCode: number,
    firmPan: string ,
    firmGstn: string ,
    finalActionAuthorityScale: string ,
    finalActionAuthorityUserType: string ,
    finalSubmitBy: string ,
    finalSubmitByBranch: string ,
    finalSubmitDate: string,
    applnStatusMain: string ,
    applnStatusBranchOfficer: string ,
    applnListStatusBranchOfficer: string ,
    applnStatusBranchManager: string ,
    applnListStatusBranchManager: string ,
    returnBy: string ,
    returnUserId: string ,
    returnDate: string,
    rejectBy: string ,
    rejectUserId: string ,
    rejectDate: string ,
    recommendBy: string ,
    recommendUserId: string ,
    recommendDate: string,
    sanctionBy: string ,
    sanctionUserId: string ,
    sanctionDate: string ,
    applnStatusCpcOfficer: string ,
    applnListStatusCpcOfficer: string ,
    applnStatusCpcHead: string ,
    applnListStatusCpcHead: string ,
    applnStatusRegionalManager: string ,
    applnListStatusRegionalManager: string ,
    applnStatusHoOfficer: string ,
    applnListStatusHoOfficer: string ,
    applnStatusChiefManager: string ,
    applnListStatusChiefManager: string ,
    applnStatusGeneralManager: string ,
    applnListStatusGeneralManager: string ,
    applnStatusChairman: string ,
    applnListStatusChairman: string 
     isActionTakenByBM: string,
     isActionTakenByCPCOF: string,
     isActionTakenByCPCHEAD: string,
     isActionTakenByRM: string,
     isActionTakenByHOOF: string,
     isActionTakenByCM: string,
 }