export interface ApplicationListButtonDataModel {
    referenceNumber: string
    uid: string
    authority: string[]
  }
  