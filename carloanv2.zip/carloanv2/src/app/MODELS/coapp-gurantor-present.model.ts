
export interface CoAppGuarantorModel{
   coapplicantPresent: false;
   applicantItrForm16Required:false;
   coApplicantItrForm16Required:false;
   applicantSalarySlipRequired:false;
   coApplicantSalarySlipRequired:false;

}
export interface CoappGuaPresentStatus{
 coapplicantPresent:false;
}