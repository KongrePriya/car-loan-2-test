export interface DashBoardModel {
    branchCode: string;
    statusSanctioned: number;
    statusRecommended: number;
    statusPending: number;
    statusReject: number;
    statusReturn: number;
    statusDeviation: number;
  }
  