export interface ItrFilingDetailsModel {

    id: number; 
    referenceIdLotus: string;
    customerName: string;
    customerPan: string;
    customerType: string;
    branchCode:string;
    year1: string;
    year2: string;
  
    // ITR Filing Details: Year 1
    itrTypeYear1: string;
    originalOrRevisedYear1: string;
    acknowledgementNumberYear1: string;
    originalReturnFilingDateYear1: string; 
    revisedReturnFilingDateYear1: string; 
  
    // ITR Filing Details: Year 2
    itrTypeYear2: string;
    originalOrRevisedYear2: string;
    acknowledgementNumberYear2: string;
    originalReturnFilingDateYear2: string; 
    revisedReturnFilingDateYear2: string;
  
    // Income Details From All Sources: Year 1
    grossIncomeFromSalaryYear1: number;
    incomeFromHousePropertyYear1: number;
    capitalGainTotalYear1: number;
    incomeFromOtherSourcesYear1: number;
    totalIncomeByAddingAllYear1: number;
    profitGainsFromBusinessOrProfYear1: number;
  
    // Income Details From All Sources: Year 2
    grossIncomeFromSalaryYear2: number;
    incomeFromHousePropertyYear2: number;
    capitalGainTotalYear2: number;
    incomeFromOtherSourcesYear2: number;
    totalIncomeByAddingAllYear2: number;
    profitGainsFromBusinessOrProfYear2: number;
  
    // Income As Per ITR: Year 1
    grossTotalIncomeYear1: number;
    totalTaxableIncomeYear1: number;
  
    // Income As Per ITR: Year 2
    grossTotalIncomeYear2: number;
    totalTaxableIncomeYear2: number;
  
    // Deduction & Liability Details As Per ITR: Year 1
    deductionUnder6aYear1: number;
    otherDeductionsTotalYear1: number; // incomeExcludingTotalIncomeYear1 + deductionUnder10aaYear1
    netTaxLiabilityYear1: number;
  
    // Deduction & Liability Details As Per ITR: Year 2
    deductionUnder6aYear2: number;
    otherDeductionsTotalYear2: number; // incomeExcludingTotalIncomeYear2 + deductionUnder10aaYear2
    netTaxLiabilityYear2: number;
}
  
  

