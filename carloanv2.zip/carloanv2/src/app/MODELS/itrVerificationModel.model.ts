export interface itrVerificationRequestModel {
  // email:string;
  // notificationEmail:string;

  //NEW REQUEST MODEL

  email:string;
  notificationEmail:string;
  // referenceIdItr:string;
  referenceIdLotus:string;
  fetchedBy:string;
  branchCode:string;
  customerType:string;//to store borrower or guarantor or nominee
  fetchDate:string;
}


export interface itrVerificationResponseModel {
  id: string;
  responseMessage:string;
  responseCode:string;
  data: ItrResponseDataChild;
}

export interface ItrResponseDataChild {
  id: string;
  referenceId:string;
}


export interface ItrRequestDataLotus {
  referenceIdItr:string;
  referenceIdLotus:string;
  fetchedBy:string;
  branchCode:string;
  customerType:string; //to store borrower or guarantor or nominee
  fetchDate:string;
}


export interface ItrVerifiedRefIdResponse {
  referenceIdItr:string;
  referenceIdLotus:string;
  fetchedBy:string;
  branchCode:string;
  customerType:string; //to store borrower or guarantor or nominee
  fetchDate:string;
  userEmailId:string;
  consentProvided:string;
}
