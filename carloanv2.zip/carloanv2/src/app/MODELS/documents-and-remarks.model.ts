export interface DocumentsAndRemarksModel{

    referenceId: string ;

    //applicant due diligence
    applicantDueDiligenceRemark: string ;
    applicantDueDiligenceFileDate: string ;
    applicantDueDiligenceFileName: string ;
    applicantDueDiligenceUploadedBy: string ;

    //co-app due diligence : optional
    coAppDueDiligenceRemark: string ;
    coAppDueDiligenceFileDate: string ;
    coAppDueDiligenceFileName: string ;
    coAppDueDiligenceUploadedBy: string ;


    //guarantor due diligence
    guarantorDueDiligenceRemark: string ;
    guarantorDueDiligenceFileDate: string ;
    guarantorDueDiligenceFileName: string ;
    guarantorDueDiligenceUploadedBy: string ;

    //quotation
    quotationFileRemark: string ;
    quotationFileDate: string ;
    quotationFileName: string ;
    quotationFileUploadedBy: string ;

    //Visit report
    visitReportRemark: string ;
    visitReportFileDate: string ;
    visitReportFileName: string ;
    visitReportUploadedBy: string ;

    //applicant ITR form 16
    applicantITRForm16Remark: string ;
    applicantITRForm16FileDate: string ;
    applicantITRForm16FileName: string ;
    applicantITRForm16UploadedBy: string ;

    //co-applicant ITR form 16
    coAppITRForm16Remark: string ;
    coAppITRForm16FileDate: string ;
    coAppITRForm16FileName: string ;
    coAppITRForm16UploadedBy: string ;

    //guarantor ITR form 16
    guarantorITRForm16Remark: string ;
    guarantorITRForm16FileDate: string ;
    guarantorITRForm16FileName: string ;
    guarantorITRForm16UploadedBy: string ;

    //applicant KYC
    applicantKYCRemark: string ;
    applicantKYCFileDate: string ;
    applicantKYCFileName: string ;
    applicantKYCUploadedBy: string ;

    //co-applicant KYC
    coAppKYCRemark: string ;
    coAppKYCFileDate: string ;
    coAppKYCFileName: string ;
    coAppKYCUploadedBy: string ;

    //guarantor KYC
    guarantorKYCRemark: string ;
    guarantorKYCFileDate: string ;
    guarantorKYCFileName: string ;
    guarantorKYCUploadedBy: string ;

    //Applicant Bank Statement
    applicantBankStatementRemark: string ;
    applicantBankStatementFileDate: string ;
    applicantBankStatementFileName: string ;
    applicantBankStatementUploadedBy: string ;

    //Applicant business/employment proof
    employmentOrBusinessProofRemark: string ;
    employmentOrBusinessProofFileDate: string ;
    employmentOrBusinessProofFileName: string ;
    employmentOrBusinessProofUploadedBy: string ;

    
    //applicant salary
    applicantSalaryPensionRemark: string ;
    applicantSalaryPensionFileDate: string ;
    applicantSalaryPensionFileName: string ;
    applicantSalaryPensionUploadedBy: string ;

    //co-applicant salary
    coAppSalaryPensionRemark: string ;
    coAppSalaryPensionFileDate: string ;
    coAppSalaryPensionFileName: string ;
    coAppSalaryPensionUploadedBy: string ;


    //guarantor salary
    guarantorSalaryPensionRemark: string ;
    guarantorSalaryPensionFileDate: string ;
    guarantorSalaryPensionFileName: string ;
    guarantorSalaryPensionUploadedBy: string ;

    //applicant passport
    applicantPassportRemark: string ;
    applicantPassportFileDate: string ;
    applicantPassportFileName: string ;
    applicantPassportUploadedBy: string ;

    //other Remark
    otherRemark: string ;
    otherFileDate: string ;
    otherFileName: string ;
    otherFileUploadedBy: string ;

    // OVERDUE CLEARANCE
    overdueClearanceCertificateName: string ;
    overdueClearanceCertificateUploadedBy: string ;
    overdueClearanceCertificateDate: string ;

    // Deviation Approval Sanction
    deviationSanctionLetterRemark: string ;
    deviationSanctionLetterFileName: string ;
    deviationSanctionLetterUploadedBy: string ;
    deviationSanctionLetterNumber: string ;
    deviationSanctionLetterDate: string ;
    deviationDeclarationCheck: boolean; //for sanction

}

export interface SingleDocumentRemarkDetailsModel{
    referenceId: string ;
    fileType: string ;
    userId: string ;
    remark: string ;
    deviationSanctionLetterNumber?:string;
    declarationCheck?:boolean;
}

export interface MandatoryDocumentsModel{
    referenceId: string ;
    loanType: string ;
    borrowerType: string ;
    shortLoanType: string ;
    shortBorrowerType: string ;

    // due diligence: taken in both cases (individual or corporate)
    applicantDueDiligence: string ; //ALWAYS YES
    coAppDueDiligence: string ;
    guarantorDueDiligence: string ;

    // ITR form 16 : taken in both cases (individual or corporate)
    applicantITRForm16: string ; //ALWAYS YES
    coAppITRForm16: string ;
    guarantorITRForm16: string ;

    //salary/pension slip : when Individual
    applicantSalaryPensionSlip: string ;
    coAppSalaryPensionSlip: string ;
    guarantorSalaryPensionSlip: string ;

    //KYC : taken in both cases (individual or corporate)
    applicantKyc: string ; //ALWAYS YES
    coAppKyc: string ;
    guarantorKyc: string ;

    //quotation
    quotationFile: string ; //ALWAYS YES
    //Visit report
    visitReport: string ; //ALWAYS YES

    applicantBankStatement: string ; //ALWAYS YES
    employmentOrBusinessProof: string ; //COMBINED FIELD  //ALWAYS YES
    applicantPassport: string ; //In case of NRI/PIO
    
    //other Remark
    otherDocuments: string ;
}