export interface IncomePensionerModel{



    referenceId:string,
    userId:string,
    branchCode:string,
    organisationType:string,
    employerName:string,
    designationOnRetirement:string,
    departmentOnRetirement:string,
    customerType:string;  //new field
    panNumber:string;//new field
    
    addressOfEmployment:string,
    monthOneTitle:string,
    monthTwoTitle:string,
    monthThreeTitle:string,
    monthOneSalary:number,
    monthTwoSalary:number,
    monthThreeSalary:number,
    incomeDetailOption:string,
    selectedFirstYear:string,
    selectedSecondYear:string,
    netIncomeFirstYear:number,
    netIncomeSecondYear:number,
    grossIncomeFirstYear:number,
    grossIncomeSecondYear:number,
    currentEmiDeduction:number,
    incomeTaxDeduction:number,
    pensionSlipDeduction:number,
    otherDeduction:number,
    totalCurrentDeduction:number,
    incomeAvailableFor:string;
    customerName:string; //New Addition
    incomeType:string; //New Addition

}

