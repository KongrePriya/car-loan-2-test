export interface QuotationDetailsModel{
    referenceId:string;
    branchCode:string;
    region:string;
    userId:string;
    companyName:string;
    modelName:string;
    dateOfQuotation:string;
    productCode:string;
    productDescription:string;
    rateOfInterest:number;
    margin:number | 0;
    loanTenure:number | 0;
    processingCharges:number | 0;
    documentCharges:number | 0;
    showroomPrice:number;
    rtoCharges:number;
    carInsuranceCharges:number;
    totalCostToConsider:number;
    loanAppliedAmount:string;
    kotakKliOptions:string;
    kotakKliPremiumAmount:number;
    kotakKliFundedAmount:number;
    carScore:string;
    submitDate:string;
    dealerPan:string;
    gstnNumber:string;
    dealerTradeName:string;
    dealergstn:string,
    legalName:string,
    tradeName:string,
    dealerAddress:string,

    eligibleForROIRelaxation : string,
    applicableROI :number  | null //original roi, new ROI is taken in ROI field so that calculation not get affected
}


 export interface Productdetails {
        id :number, 
        insertedDate:string,
        productCode:string, 
        productDescription:string, 
        rateOfInterest:number,
        srno:string, 
        loanType:string,
        borrowerType:string

        
      };
