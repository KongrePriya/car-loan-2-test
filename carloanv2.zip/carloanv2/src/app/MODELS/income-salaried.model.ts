export interface IncomeSalariedModel{



    referenceId:string,
    userId:string,
    branchCode:string,
    customerType:string;  //new field
    organisationType:string,
    panNumber:string;//new field
    employerName:string,
    designation:string,
    department:string,
    currentOrgExperienceYears:number | null,
    currentOrgExperienceMonths:number | null,
    currentOrgExperienceMonthsFrontEnd:number | null,
    totalWorkExperienceYears:number | null,
    totalWorkExperienceMonths:number | null,
    totalWorkExperienceMonthsFrontEnd:number | null,
    retirementAge:string,
    retirementAgeInMonths:string,
    addressOfEmployment:string,
    monthOneTitle:string,
    monthTwoTitle:string,
    monthThreeTitle:string,
    monthOneSalary:number,
    monthTwoSalary:number,
    monthThreeSalary:number,
    incomeDetailOption:string,
    selectedFirstYear:string,
    selectedSecondYear:string,
    netIncomeFirstYear:number,
    netIncomeSecondYear:number,
    grossIncomeFirstYear:number,
    grossIncomeSecondYear:number,
    currentEmiDeduction:number,
    incomeTaxDeduction:number,
    salarySlipDeduction:number,
    otherDeduction:number,
    totalCurrentDeduction:number,
    incomeAvailableFor:string;
    customerName:string; //New Addition
    incomeType:string; //New Addition
  

}


  
  