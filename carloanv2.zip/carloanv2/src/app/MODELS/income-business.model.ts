export interface IncomeBusinessMainModel{
    referenceId: string;
    userId: string;
    branchCode: string;
    panNumber: string;
    customerType: string;
    selectedFirstYear: string;
    selectedSecondYear: string;
    netIncomeFirstYear: number;
    netIncomeSecondYear: number;
    businessIncomeFirstYear: number;
    businessIncomeSecondYear: number;
    depreciationFirstYear: number;
    depreciationSecondYear: number;
    housePropertyIncomeFirstYear: number;
    housePropertyIncomeSecondYear: number;
    otherIncomeFirstYear: number;
    otherIncomeSecondYear: number;
    currentEmiDeduction: number;
    incomeTaxDeduction: number;
    otherDeduction: number;
    totalCurrentDeduction: number;
    incomeAvailableFor:string;
    customerName:string; //New Addition
    incomeType:string; //New Addition
    businessStandingInYears: number; //New Addition
    businessStandingInMonths: number; //New Addition
    incomeBusinessDetailModel: IncomeBusinessDetailModel[];


   
}
export interface IncomeBusinessDetailModel{

   
  nameOfConstitution: string;
  natureOfBusiness:string;
  nameOfBusiness: string;
  businessSector: string;
  businessActivityDetail: string;
  businessAddress: string;
  businessPan: string;
  businessGstin: string;
  incorporationDate: string;
  customerName:string; //New Addition
}