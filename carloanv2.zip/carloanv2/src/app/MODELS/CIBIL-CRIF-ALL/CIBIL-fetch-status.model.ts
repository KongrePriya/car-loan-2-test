export interface CibilFetchStatusModel{
    id: number;
    referenceId: string;
  
    // count
    guarantorsCount: number;
    coappIncomeCount: number;
    coappNonIncomeCount: number;
    crifRequired: boolean;

    // APPLICANT CIBIL & CRIF
    applicantCibilFetched: boolean;
    applicantCrifFetched: boolean;
    applicantCibilUpdatedDate: Date | null;
    applicantCrifUpdatedDate: Date | null;

    // Coapplicants-Income Considered CIBIL
    coappIncomeCibilCount: number;
    coappIncomeCibilFetched: boolean;
    coappIncomeCibilUpdatedDate: Date | null;

    // Coapplicants-Income CRIF
    coappIncomeCrifCount: number;
    coappIncomeCrifFetched: boolean;
    coappIncomeCrifUpdatedDate: Date | null;

    // Coapplicants-Non Income CIBIL
    coappNonIncomeCibilCount: number;
    coappNonIncomeCibilFetched: boolean;
    coappNonIncomeCibilUpdatedDate: Date | null;

    // Coapplicants-Non Income CRIF
    coappNonIncomeCrifCount: number;
    coappNonIncomeCrifFetched: boolean;
    coappNonIncomeCrifUpdatedDate: Date | null;

    // Guarantor CIBIL
    guarantorCibilCount: number;
    guarantorCibilFetched: boolean;
    guarantorCibilUpdatedDate: Date | null;

    // Guarantor CRIF
    guarantorCrifCount: number;
    guarantorCrifFetched: boolean;
    guarantorCrifUpdatedDate: Date | null;

    // To compare CIBIL and CRIF of respective customer-type
    applicantCibilCrifCountMatching: boolean;
    coappCibilCrifCountMatching: boolean;
    guarantorCibilCrifCountMatching: boolean;

    // All flags combined
    allCibilFetched: boolean;
    allCrifFetched: boolean;
    allCibilCrifUptodate: boolean;

    lastResetDate: Date | null;

}

