
export interface CibilCrifStatusModel{
 id: number;

referenceId:string;
  // count
  corpGurantorsCount:number;
  indvGurantorsCount:number;
  crifRequired: boolean;  // Default initialized to false

  // firm Commercial CIBIL
  firmComCibilUptoDate: boolean;
  firmComCrifFetched: boolean;
 firmComCibilUpdatedDate:string;


  // corp guarantor CIBIL
  corpGuarantorCibilCount: number;
  corpGuarantorComCibilUptoDate: boolean;  //default true IN BACKEND
 corpGuarantorCibilUpdatedDate:string;

  // individual guarantor CIBIL
  indvGuarantorCibilCount: number;
  indvGuarantorCibilUptoDate : boolean;//default true IN BACKEND
 indvGuarantorCibilUpdatedDate:string;

  // corp guarantor - commercial CRIF
  corpGuarantorCrifCount: number;
  corpGuarantorCrifUptoDate: boolean;//default true IN BACKEND
 corpGuarantorCrifUpdatedDate:string;

  // individual guarantor - Individual CRIF
  indvGuarantorCrifCount: number;
  indvGuarantorCrifUptoDate : boolean;//default true IN BACKEND
 indvGuarantorCrifUpdatedDate:string;

  //to compare cibil and crif of respective type of guarantors
  corpGuarCibilCrifCountMatching: boolean;
  indvGuarCibilCrifCountMatching: boolean;

  // all flags combined
  allCibilCrifUptodate: boolean;
  allGuarCibilCrifCountMatching: boolean;
}

// cibilCrifStatusModel.corpGuarantorCibilUpdatedDate === this means flag is true on frontend