export interface IndvCrifDetailsModel{
    customerName:string;
    customerScore:string;
    totalAccounts:string;
    activeAccounts:string;
    overdueAccounts:string;
    overdueAmount:string;
}

export interface IndvCrifHistoryMainModel{
    gstLosreferenceId:string,
    customerName:string,
    collapsed?: boolean| false;
    historyList:[{
        nameOfCustomer:string,
        facilityType:string,
        ownership:string,
        bank:string,
        sanctionDate:string,
        sanctionAmount:string,
        amountOutstanding:string,
        overdue:string,
        accountStatus:string,
        gstLosreferenceId:string,
        gstLosBranchCode:string,
        gstLosUserId:string,
        individualPan:string,
    }
    ]
}


export interface IndvCrifSummaryModel{
    customerName:string;
    writtenOffAccounts:string;
    settledAccounts:string;
    overdueAccounts:string;
    gstLosreferenceId:string;
    gstLosBranchCode:string;
    gstLosUserId:string;
    individualPan:string;
}

export interface  IndvCrifHistoryModel{
         nameOfCustomer:string,
            facilityType:string,
            ownership:string,
            bank:string,
            sanctionDate:string,
            sanctionAmount:string,
            amountOutstanding:string,
            overdue:string,
            accountStatus:string,
            gstLosreferenceId:string,
            gstLosBranchCode:string,
            gstLosUserId:string,
            individualPan:string,
        }