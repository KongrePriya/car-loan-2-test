export interface CommCrifDetailsModel{
   
    borrowerName:string;
    totalAccountCount:string;
    regularAccountCount:string;
    overdueAccountCount:string;
    zeroAccountCount:string;
    referenceId:string;
    userId:string;
    pan:string;
    commCrifFetchedFor:string;
    // individualPan:string;
}

// export interface IndvCrifDetailsModelList{
//     indvCrifDetailsModelList:IndvCrifDetailsModel[];
// }

export interface CommCrifHistoryModel{
  
    borrowerName:string;
    facilityType:string;
    ownerShip:string;
    bank:string;
    sanctionDate:string;
    sanctionAmount:string;
    amountOutStanding:string;
    overdueAmount:string;
    status:string;
    assetClassification:string;
    userId:string;
    pan:string;
    commCrifFetchedFor:string;
    referenceId:string;

}

export interface CommCrifHistoryModel{
  
    borrowerName:string;
    overdueStatus:string;
    settledStatus:string;
    writtenOffStatus:string;
    suitFiledStatus:string;
    referenceId:string;
    pan:string;
    commCrifFetchedFor:string;
    userId:string;
    highlighted?:  boolean| false;


}


// models.ts

// Interface for the individual history item
export interface HistoryItem {
    borrowerName: string;
    facilityType: string;
    ownerShip: string;
    referenceId: string;
    bank: string;
    sanctionDate: string;
    sanctionAmount: string;
    amountOutStanding: string;
    overdueAmount: string;
    status: string;
    assetClassification: string;
    created_date: string[]; // Assuming these are date strings
    userId: string;
    pan: string;
    commCrifFetchedFor: string;
  }
  
  // Interface for the main data structure
  export interface CrifCommercialHistoryData {
    gstLosreferenceId: string;
    customerName: string;
    collapsed?:boolean |false;
    historyList: [{ borrowerName: string;
        facilityType: string;
        ownerShip: string;
        referenceId: string;
        bank: string;
        sanctionDate: string;
        sanctionAmount: string;
        amountOutStanding: string;
        overdueAmount: string;
        status: string;
        assetClassification: string;
        created_date: string[]; // Assuming these are date strings
        userId: string;
        pan: string;
        commCrifFetchedFor: string;}];
  }
  