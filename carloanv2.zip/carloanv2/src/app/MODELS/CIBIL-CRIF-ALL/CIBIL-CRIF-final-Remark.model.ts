export interface CibilCrifRemarksFinalModel{

   id:number;
   referenceId :string ;
   userId:string ;
   userType:string ;

    //--------------- PERSONAL CIBIL REMARKS COMBINED --------------//
  
   personalCibilRemark:string ;
   personalCibilOverdueRemark:string ;
   personalCibilRejectRemark:string ;
    //additional
   personalCibilWrittenOffRemark:string ;
   personalCibilAccountSettledRemark:string ;
   personalCibilSuitFilledRemark:string ;
   personalCibilSubmitDate:string ;

    //--------------- COMMERCIAL CIBIL REMARKS COMBINED --------------//
  
   commercialCibilRemark:string ;
   commercialCibilOverdueRemark:string ;
   commercialCibilRejectRemark:string ;
    //additional
   commercialCibilWrittenOffRemark:string ;
   commercialCibilAccountSettledRemark:string ;
   commercialCibilSuitFilledRemark:string ;
   commercialCibilSubmitDate:string ;

    //--------------- PERSONAL CRIF REMARKS COMBINED --------------//
  
   personalCrifRemark:string ;
   personalCrifOverdueRemark:string ;
   personalCrifRejectRemark:string ;
    //additional
  
   personalCrifWrittenOffRemark:string ;
   personalCrifAccountSettledRemark:string ;
   personalCrifSuitFilledRemark:string ;
   personalCrifSubmitDate:string ;

    //--------------- COMMERCIAL CRIF REMARKS COMBINED --------------//
  
   commercialCrifRemark:string ;
   commercialCrifOverdueRemark:string ;
   commercialCrifRejectRemark:string ;
    //additional
   commercialCrifWrittenOffRemark:string ;
   commercialCrifAccountSettledRemark:string ;
   commercialCrifSuitFilledRemark:string ;
   commercialCrifSubmitDate:string ;

    //--------------- STATUS --------------//
   remarkStatus:string ;
   rejectedStatus:string ;
   statusDate:string ;

   //--------------OVERDUE CLEARANCE ---------//
    overdueClearanceCertificateName:string ;
    overdueClearanceCertificateUploadedBy:string ;
    overdueClearanceCertificateDate:string ;
}