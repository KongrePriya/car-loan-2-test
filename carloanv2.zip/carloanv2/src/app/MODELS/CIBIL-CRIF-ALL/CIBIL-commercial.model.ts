export interface CibilCommercialBasicDetailsModel{
    referenceId : string ;
    customerName : string ;
    reportOrderNumber : string ;
    customerPan : string ;
    rankName : string ;
    rankNumber : string ;
    rankingReasons : string ;
    totalCfAccounts : string ;
    regularAccounts : string ;
    overdueAccounts : string ;
    zeroBalanceAccount : string ;
    corporateType : string ;
}


//USED IN FIRM CIBIL DETAILS (corporateType= BORROWER)
export interface CibilCommercialHistoryDetailsModel{
    referenceId : string ;
    customerName : string ;
    customerPan : string ;
    
    facilityType : string ;
    ownership : string ;
    bankerName : string ;
    sanctionDate : string ;
    sanctionAmount : string ;
    amountOutstanding : string ;
    overdueAmount : string ;
    facilityStatus : string ;
    assetClassification : string ;
    corporateType : string ;
    oldRecord: string ;
}




export interface CibilCommercialNewHistoryDetailsModel{
    referenceId : string ;
    customerName : string ;
    customerPan : string ;
    collapsed?: boolean| false;
    highlighted?:  boolean| false; // Add the highlighted property as optional

    historyEntries:[{
    facilityType : string ;
    ownership : string ;
    bankerName : string ;
    sanctionDate : string ;
    sanctionAmount : string ;
    amountOutstanding : string ;
    overdueAmount : string ;
    facilityStatus : string ;
    assetClassification : string ;
    corporateType : string ;
    oldRecord: string ;
    }]
}

export interface CibilCommercialSummaryDetailsModel{
    referenceId: string ;
    customerName: string ;
    customerPan: string ;
    rankStatusSummary: string ;
    accountWrittenOffSummary: string ;
    accountSettledSummary: string ;
    accountOverdueSummary: string ;
    suitFilledSummary: string ;
    corporateType: string ;

    highlighted?:  boolean| false;

}