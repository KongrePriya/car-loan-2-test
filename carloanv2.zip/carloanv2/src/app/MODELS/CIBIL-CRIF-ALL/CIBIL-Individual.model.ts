export interface CibilIndividualBasicDetailsModel{

    customerName:string;
    customerPan:string;
    referenceId:string;

    //to display BASIC DETAILS
    cibilScore:string;
    personalScore: string;
    totalAccounts:number;
    regularAccounts:number;
    overdueAccounts:number;
    zeroBalanceAccount:number;

    //additional field to update old entries
    oldRecord:string;
   refetchedDate:string;

   individualType:string;
}

export interface CibilIndividualNewHistoryDetailsModel{
    referenceId : string ;
    customerName : string ;
    customerPan : string ;
    collapsed?: boolean| false;
    highlighted?:  boolean| false; // Add the highlighted property as optional
    individualType:string;
    
    historyEntries:[{
    referenceId : string ;
    customerName : string ;
    customerPan : string ;
    dateOfFetching: string ;
    branchCode: string ;
    userId: string ;
    facilityType : string ;
    ownership : string ;
    bankerName : string ;
    sanctionDate : string ;
    sanctionAmount : string ;
    amountOutstanding : string ;
    emiAmount: string;
    overdueAmount : string ;
    facilityStatus : string ;
    oldRecord: string ;
    refetchedDate:string;
  

    }]
}

export interface CibilIndividualSummaryDetailsModel{
    referenceId: string ;
    customerName: string ;
    customerPan: string ;
    scoreStatusSummary: string ;
    accountWrittenOffSummary: string ;
    accountSettledSummary: string ;
    accountOverdueSummary: string ;
    individualType:string;


    highlighted?:  boolean| false;

}