
export interface AppraisalNoteRemarksAndConditions{

//Reference Id
referenceId:string,

//Appraisal-Note Additional Conditions
 makerAdditionalCondition:string,

 branchManagerAdditionalCondition:string,

 cpcOfficerAdditionalCondition:string,

 cpcHeadAdditionalCondition:string,

 rmAdditionalCondition:string,

 hoOfficerAdditionalCondition:string,

 hodAdditionalCondition:string,

 gmAdditionalCondition:string,

 chairmanAdditionalCondition:string,


//Appraisal-Note Additional Remarks

 makerAppraisalRemarks:string,

 branchManagerAppraisalRemarks:string,

 cpcOfficerAppraisalRemarks:string,

 cpcHeadAppraisalRemarks:string,

 rmAppraisalRemarks:string,

 hoOfficerAppraisalRemarks:string,

 hodAppraisalRemarks:string,

 gmAppraisalRemarks:string,

 chairmanAppraisalRemarks:string,


 applicationReturnRemarks:string,
 sanctionAuthorityRejectRemarks:string,
 applicationSanctionRemarks:string,
 borrowerBriefHistory:string


}