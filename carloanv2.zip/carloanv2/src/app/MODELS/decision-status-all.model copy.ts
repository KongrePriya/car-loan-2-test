
// ---NOTE : THIS FILE CONTAINS ALL MODELS REQUIRED FOR DECISION STATUS--


export interface DecisionStatusUserInfoDTO{
    referenceId:string;
    userId:string;
    userScale:string;
    userType:string;
    userLocation:string;
    userRegion:string;
    branchCode:string;
    loanType:string;
    loanAmount:number;
    loanAmountTopUp:number;
}
