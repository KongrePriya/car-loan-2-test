export interface CorpGuarantorPANmodel{
    pan:string;
}
export interface CorpGuarantorGSTInfoModel{
    gstinStatus:string,
    constitutionOfBusiness:string,
    dateOfRegistration:string,
    principalPlaceOfBusinessAddress:string,
    natureOfBusiness:string,
    stateJurisdictionCode:string,
    gstin:string,
    dateOfCancellation:string,
    centreJurisdictionCode:string,
    tradeName:string,
    lastUpdatedDate:string,
    centreJurisdiction:string,
    taxpayerType:string,
    legalNameOfBusiness:string,
    pan:string,
    additionalPlaceOfBusinessAddress:string,
    stateJurisdiction:string,
}