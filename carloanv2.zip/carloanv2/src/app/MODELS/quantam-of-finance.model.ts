export interface QuantamOfFinanceModel {
   
  referenceId:string;
  loanType:string;
  applicantName:string;
  borrowerType:string;

  loanTenure:number;
  rateOfInterest:number;
  kliFundedAmount:number;

  //as per eligibility
  finalEligibleLoanWithKLI:number;
  finalEligibleLoanWithoutKLI:number;
  emiAsPerEligibleLoan:number;
  //as per applied
  appliedLoanWithKLI:number;
  appliedLoanWithoutKLI:number;
  emiAsPerAppliedLoan:number;

  deductionPercentage:number;
}