import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { UserModelData } from './model/user.model';

import { catchError, throwError } from 'rxjs';
import { AuthService } from '../auth.service';

import { ApiService } from 'src/app/SERVICES/Login/api.service';
import { IPAddressService } from 'src/app/SERVICES/Login/ip.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  //create variable that hold data

  constructor(
    private apiService: ApiService,
    private auth: AuthService,
    private ipService: IPAddressService,
   
  ) {}

  // showSnackbar(
  //   message: string,
  //   action: string = 'Close',
  //   duration: number = 2000,
  //   verticalPosition: MatSnackBarVerticalPosition = 'top',
  //   horizontalPosition: MatSnackBarHorizontalPosition = 'end'
  // ): void {
  //   this.snackBar.open(message, action, {
  //     duration: duration,
  //     verticalPosition: verticalPosition,
  //     horizontalPosition: horizontalPosition,
  //   });
  // }
  ngOnInit(): void {
    this.ipService.setIpAddress();
  }

  //spinner
  //spinner Loading
  isSpinnerLoading = false;
  userModel = {} as UserModelData;
  errorMessage: string = '';

  loginData = {
    username: '',
    password: '',
  };

  onSubmit() {
    //    console.log('Login Data:', this.loginData); // Handle login logic here
    // Add your login logic: authenticate user, redirect, etc.
  }

  async onValidate() {
    this.ipService.setIpAddress();
    this.isSpinnerLoading = true;
    console.log('LoginComponent Called');
    this.auth
      .login(this.loginData.username, this.loginData.password)
      .then(() => {
        console.log('AuthService Called');
        this.apiService
                  // .getUserDataFromMSSO(this.loginData.username,this.loginData.password)
            .getUserData(this.loginData.username)
          .pipe(
            catchError(this.handleError)
          )
          .subscribe({
            next: (response) => {
              //   console.log('Response Called' + JSON.stringify(response));
              this.userModel = response;
              this.userModel.userId=response.u_id;
              sessionStorage.setItem('userModelData', JSON.stringify(this.userModel));
              console.log("response :"+JSON.stringify(response));
              sessionStorage.setItem('userId', response.u_id);

              this.isSpinnerLoading = false;
             console.log(" this.userModel on LOGIN PAGE: "+JSON.stringify(this.userModel));
              this.auth.redirectAfterLogin();
            },
            error: (error) => {
              // console.log('Error Called' + error);
              this.isSpinnerLoading = false;
              alert('User ID/Password Not matched');
              //    this.showSnackbar('User Id Not Found/Invalid');
            },
            complete: () => {
              console.log('Process Is Complete');
            //  this.snackBar.open('Login Successfully');
            },
          });

        //   this.auth.redirectAfterLogin();
      })
      .catch(this.handleError);
  }

  private handleError(error: HttpErrorResponse) {
    this.isSpinnerLoading=false;
    // Log the error to the console (you can also send it to a logging service)
    console.error('An error occurred:', error.message);
    
    // Optionally, return a user-friendly message or observable
    return throwError('Something went wrong; please try again later.');
  }
}
