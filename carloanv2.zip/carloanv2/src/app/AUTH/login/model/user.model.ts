export interface UserModelData {

  // u_id: string;
  userId:string;
  u_type: string;
  brcode: string;
  brname: string;
  roname: string;
  u_status: string;
  u_loc: string;
  u_name: string;
  scale: string;
  loanType:string;
  shortLoanType:string;
  borrowerType:string;
  shortBorrowerType:string;
  referenceId:string;
  sourceType:string;
  dsaNumber:string;
  panNumber:string;
  appliedLoanAmount:number;
  custType:string;
  
}


