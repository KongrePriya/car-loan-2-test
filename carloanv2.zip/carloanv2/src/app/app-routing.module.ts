import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './AUTH/login/login.component';
import { PagenotfoundComponent } from './COMPONENTS/pagenotfound/pagenotfound.component';
import { SidenavListComponent } from './COMPONENTS/sidenav-list/sidenav-list.component';
import { CrifListComponent } from './COMPONENTS/crif-list/crif-list.component';
import { CrifFirmFetchPageComponent } from './COMPONENTS/crif-firm-fetch-page/crif-firm-fetch-page.component';
import { CrifFirmDisplayStepperComponent } from './COMPONENTS/crif-firm-display-stepper/crif-firm-display-stepper.component';
import { CrifCommGuarantorListComponent } from './COMPONENTS/crif-comm-guarantor-list/crif-comm-guarantor-list.component';
import { CrifCommGuarantorStepperComponent } from './COMPONENTS/crif-comm-guarantor-stepper/crif-comm-guarantor-stepper.component';
import { DashboardComponent } from './COMPONENTS/dashboard/dashboard.component';
import { AuthGuard } from './AUTH/auth.guard';
import { IncomeSalaryComponent } from './COMPONENTS/income-salary/income-salary.component';
import { IncomePensionComponent } from './COMPONENTS/income-pension/income-pension.component';
import { IncomeBusinessComponent } from './COMPONENTS/income-business/income-business.component';
import { ReferenceIdGenerationComponent } from './COMPONENTS/reference-id-generation/reference-id-generation.component';
import { DoclistComponent } from './COMPONENTS/doclist/doclist.component';
import { ApplicationSearchComponent } from './COMPONENTS/application-search/application-search.component';
import { AppraisalNoteComponent } from './COMPONENTS/appraisal-note/appraisal-note.component';
import { QuotationDetailsComponent } from './COMPONENTS/quotation-details/quotation-details.component';
import { BorrowerFirmComponent } from './COMPONENTS/borrower-firm/borrower-firm.component';
import { BorrowerIndividualComponent } from './COMPONENTS/borrower-individual/borrower-individual.component';
import { ItrDetailsListComponent } from './COMPONENTS/itr-details-list/itr-details-list.component';
import { GuarantorIndividualComponent } from './COMPONENTS/guarantor-individual/guarantor-individual.component';
import { GuarantorCorporateComponent } from './COMPONENTS/guarantor-corporate/guarantor-corporate.component';
import { CibilIndividualAllComponent } from './COMPONENTS/cibil-individual-all/cibil-individual-all.component';
import { CibilCommercialAllComponent } from './COMPONENTS/cibil-commercial-all/cibil-commercial-all.component';
import { CoappIndividualComponent } from './COMPONENTS/coapp-individual/coapp-individual.component';
import { IncomeMainListComponent } from './COMPONENTS/income-main-list/income-main-list.component';
import { QuantumOfFinanceComponent } from './COMPONENTS/quantum-of-finance/quantum-of-finance.component';
import { DeviationDisplayComponent } from './COMPONENTS/deviation-display/deviation-display.component';
import { DeviationApprovalComponent } from './COMPONENTS/deviation-approval/deviation-approval.component';
import { ItrVerificationApplicantComponent } from './COMPONENTS/itr-verification-applicant/itr-verification-applicant.component';
import { ItrDisplayApplicantComponent } from './COMPONENTS/itr-display-applicant/itr-display-applicant.component';
import { ItrVerifyCoapp1Component } from './COMPONENTS/itr-verify-coapp1/itr-verify-coapp1.component';
import { ItrDisplayCoapp1Component } from './COMPONENTS/itr-display-coapp1/itr-display-coapp1.component';
import { ItrVerifyCoapp2Component } from './COMPONENTS/itr-verify-coapp2/itr-verify-coapp2.component';
import { ItrDisplayCoapp2Component } from './COMPONENTS/itr-display-coapp2/itr-display-coapp2.component';
import { DocumentsAndRemarksComponent } from './COMPONENTS/documents-and-remarks/documents-and-remarks.component';


const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    //Lazy loading
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'carLoanV2',
    component: SidenavListComponent,
    // canActivate: [AuthGuard],
    children: [
 
      {
        path: 'appraisalnote',
        component: AppraisalNoteComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'search',
        component: ApplicationSearchComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'doc-list',
        component: DoclistComponent,
        canActivate: [AuthGuard],
      },
      {
        path: '',
        component: DashboardComponent,
        //   canActivate: [AuthGuard],
      },
      {
        path: 'crif-list',
        component: CrifListComponent,
        //   canActivate: [AuthGuard],
      },
      {
        path: 'firmcrif',
        component: CrifFirmFetchPageComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'firmcrifstepper',
        component: CrifFirmDisplayStepperComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'guarantorcrif',
        component: CrifCommGuarantorListComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'guarantorcrifstepper',
        component: CrifCommGuarantorStepperComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'income-main-list',
        component: IncomeMainListComponent,
        //     canActivate: [AuthGuard],
      },

      {
        path: 'income-salaried',
        component: IncomeSalaryComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'income-pensioner',
        component: IncomePensionComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'income-business',
        component: IncomeBusinessComponent,
        //     canActivate: [AuthGuard],
      },
       {
        path: 'calculation',
        component: QuantumOfFinanceComponent,
        //     canActivate: [AuthGuard],
      },

      {
        path: 'id-generation',
        component: ReferenceIdGenerationComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'quotation-details',
        component: QuotationDetailsComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'borrower-firm',
        component: BorrowerFirmComponent,
        //     canActivate: [AuthGuard],
      },

      {
        path: 'borrower-individual',
         component: BorrowerIndividualComponent,
        //     canActivate: [AuthGuard],
      },

      {
        path: 'coapp-individual',
         component: CoappIndividualComponent,
        //     canActivate: [AuthGuard],
      },

{
        path: 'guarantor-corporate',
        component: GuarantorCorporateComponent,
        //     canActivate: [AuthGuard],
      },

      {
        path: 'guarantor-individual',
         component: GuarantorIndividualComponent,
        //     canActivate: [AuthGuard],
      },

       {
        path: 'cibil-individual-all',
         component: CibilIndividualAllComponent,
        //     canActivate: [AuthGuard],
      },
    {
        path: 'cibil-commmercial-all',
         component: CibilCommercialAllComponent,
        //     canActivate: [AuthGuard],
      },
     {
        path: 'itr-list',
         component: ItrDetailsListComponent,
        //     canActivate: [AuthGuard],
      },

      {
        path: 'applicant-itr-verify',
        component: ItrVerificationApplicantComponent,
        //   canActivate: [AuthGuard],
      },
      {
        path: 'applicant-itr-display',
        component: ItrDisplayApplicantComponent,
        //   canActivate: [AuthGuard],
      },
      {
        path: 'coapp-one-itr-verify',
        component: ItrVerifyCoapp1Component,
        //   canActivate: [AuthGuard],
      },
      {
        path: 'coapp-one-itr-display',
        component: ItrDisplayCoapp1Component,
        //   canActivate: [AuthGuard],
      },
      {
        path: 'coapp-two-itr-verify',
        component: ItrVerifyCoapp2Component,
        //   canActivate: [AuthGuard],
      },
      {
        path: 'coapp-two-itr-display',
        component: ItrDisplayCoapp2Component,
        //   canActivate: [AuthGuard],
      },
      {
        path: 'deviation-approval',
         component: DeviationApprovalComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'deviation-display',
        component: DeviationDisplayComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: 'documents-upload',
        component: DocumentsAndRemarksComponent,
        //     canActivate: [AuthGuard],
      },
      {
        path: '**',
        component: PagenotfoundComponent,
        //     canActivate: [AuthGuard],
      },
    
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
