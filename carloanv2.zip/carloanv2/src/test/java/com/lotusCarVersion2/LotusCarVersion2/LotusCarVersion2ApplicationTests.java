package com.lotusCarVersion2.LotusCarVersion2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LotusCarVersion2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
