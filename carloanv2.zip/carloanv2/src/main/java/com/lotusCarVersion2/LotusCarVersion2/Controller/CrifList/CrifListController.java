package com.lotusCarVersion2.LotusCarVersion2.Controller.CrifList;


import com.lotusCarVersion2.LotusCarVersion2.Models.CrifIndividualRequest.StandardCrifIndvRequest;
import com.lotusCarVersion2.LotusCarVersion2.Services.CrifList.CrifListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/v1")
@CrossOrigin(origins = "*")
public class CrifListController {

    @Autowired
    private CrifListService crifListService;

    @GetMapping("/crif-list/{referenceId}")
    public ResponseEntity<List<StandardCrifIndvRequest>> getAllApplicantCoAppGuarantors(@PathVariable String referenceId){

        List<StandardCrifIndvRequest> crifIndvRequestsList = crifListService.getAllApplicantCoAppGuarantor(referenceId);
        return new ResponseEntity<>(crifIndvRequestsList, HttpStatus.OK);
    }

//    --------------------------- Set CRIF FETCH Flag When Data is Obtained Successfully (Individual) ----------

    @PutMapping("crif-fetch-flag/{referenceId}/{panNumber}/{crifFlagStatus}")
    public ResponseEntity<Map<String, String>> updateCrifFlag(@PathVariable("referenceId") String referenceId, @PathVariable("panNumber") String panNumber,  @PathVariable("crifFlagStatus") String crifFlagStatus){
        Map<String,String> response = new HashMap<>();
        String  crifFetchFlagUpdateResponse = crifListService.updateCrifFetchedFlag(referenceId,panNumber,crifFlagStatus);
        response.put("message" , crifFetchFlagUpdateResponse);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

//    ------------------------------ Set CRIF FETCH Flag After 10th of Every Month -----------------------------
    @PutMapping("crif-reset-flag/{referenceId}")
    public ResponseEntity<Map<String, String>> resetCrifFlagMonthly(@PathVariable("referenceId") String referenceId){
        Map<String,String> response = new HashMap<>();
        String  crifFetchFlagUpdateResponse = crifListService.resetAllCrifFlagEveryMonth(referenceId);
        response.put("message" , crifFetchFlagUpdateResponse);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
