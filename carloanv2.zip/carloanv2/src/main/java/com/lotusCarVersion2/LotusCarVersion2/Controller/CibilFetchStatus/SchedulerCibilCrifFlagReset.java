package com.lotusCarVersion2.LotusCarVersion2.Controller.CibilFetchStatus;

import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.SchedulerService;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@Transactional
@AllArgsConstructor
public class SchedulerCibilCrifFlagReset {

    private final SchedulerService schedulerService;

//    @Scheduled(cron = "00 00 12 10 * ?") // Runs at 12 AM on the 10th day of every month
//    @Scheduled(cron = "0/30 * * * * ?")

    @Scheduled(cron = "0 0 0 * * ?") // Runs every day at 12 AM
    @Async
    @Transactional
    public void resetFlagsOn10th() throws InterruptedException {
        System.out.println(" INSIDE resetFlagsOn10th ");
        Thread.sleep(5000); // 5 seconds delay

        try {
            String result = schedulerService.ResetFlagsOfCibilAndCrif();
            System.out.println("Flag reset result: " + result);
        } catch (Exception e) {
            System.err.println("Exception in resetFlagsOn10th:");
            e.printStackTrace();
        }
    }
}
