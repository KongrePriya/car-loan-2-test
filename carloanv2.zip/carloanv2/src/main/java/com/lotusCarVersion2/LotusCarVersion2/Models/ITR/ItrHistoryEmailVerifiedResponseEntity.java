package com.lotusCarVersion2.LotusCarVersion2.Models.ITR;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "itr_email_ref_id_generated_response_history")
//// THE ACTUAL DATA IS PRESENT IN THE kyc_itr SCHEMA , this is just a entity used to delete and move data when borrower/guarantor deleted

public class ItrHistoryEmailVerifiedResponseEntity {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;
   private String referenceIdItr;
   private String referenceIdLotus;
   private String fetchedBy;
   private String branchCode;
   private String customerType;//to store borrower or guarantor or nominee
   private LocalDateTime fetchDate;
   private String userEmailId;
   private String consentProvided;

   //extra
   private LocalDateTime refetchedAt;
   private String refetchedBy;
}
