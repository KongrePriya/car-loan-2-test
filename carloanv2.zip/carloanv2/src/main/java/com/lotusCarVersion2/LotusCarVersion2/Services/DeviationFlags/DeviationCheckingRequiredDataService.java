package com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags;

import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.RawDataForDeviationCheckingEntity;

public interface DeviationCheckingRequiredDataService {

    RawDataForDeviationCheckingEntity checkOrCreateDeviationRequiredData(String referenceId);

    RawDataForDeviationCheckingEntity getDeviationRawData(String referenceId);

    RawDataForDeviationCheckingEntity RetrieveAndSaveBasicDetailsOfAll(String referenceId);

    String updateItrForm16Deviation(String referenceId);

    //    setAllRequiredItrVerified()

    RawDataForDeviationCheckingEntity updateItrFetchedStatus(String referenceId);
}