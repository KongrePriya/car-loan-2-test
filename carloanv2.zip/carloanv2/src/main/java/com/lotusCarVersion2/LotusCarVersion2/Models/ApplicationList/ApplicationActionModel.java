package com.lotusCarVersion2.LotusCarVersion2.Models.ApplicationList;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationActionModel {

    private String referenceId;
    private String branchCode;
    private String userId;
    private String regionName;
    private String userLoc;
    private String userType;
    private String userScale;
    private String loanType; // NEW ADDITION 31/01/2025
    private BigDecimal loanAmount; // NEW ADDITION 01/02/2025
    private String action;
}
