package com.lotusCarVersion2.LotusCarVersion2.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CibilCrifFetchedStatusDto {

    private Long id;

    private String referenceId;

    // count
    private Integer guarantorsCount=0;
    private Integer coappIncomeCount=0;
    private Integer coappNonIncomeCount=0;
    private boolean crifRequired;  // Default initialized to false

    // APPLICANT CIBIL & CRIF
    private boolean applicantCibilFetched; // need to be false by default to fetch cibil
    private boolean applicantCrifFetched; // need to be false by default to fetch crif
    private LocalDateTime applicantCibilUpdatedDate;
    private LocalDateTime applicantCrifUpdatedDate;

    // Coapplicants-Income Considered CIBIL
    private Integer coappIncomeCibilCount=0;
    private boolean coappIncomeCibilFetched;
    private LocalDateTime coappIncomeCibilUpdatedDate;

    //Coapplicants- Income CRIF
    private Integer coappIncomeCrifCount=0;
    private boolean coappIncomeCrifFetched;
    private LocalDateTime coappIncomeCrifUpdatedDate;


    // Coapplicants-Non Income CIBIL
    private Integer coappNonIncomeCibilCount=0;
    private boolean coappNonIncomeCibilFetched;
    private LocalDateTime coappNonIncomeCibilUpdatedDate;

    //Coapplicants-Non Income CRIF
    private Integer coappNonIncomeCrifCount=0;
    private boolean coappNonIncomeCrifFetched;
    private LocalDateTime coappNonIncomeCrifUpdatedDate;

    //guarantor CIBIL
    private Integer guarantorCibilCount=0;
    private boolean guarantorCibilFetched;
    private LocalDateTime guarantorCibilUpdatedDate;

    //  guarantor CRIF
    private Integer guarantorCrifCount=0;
    private boolean guarantorCrifFetched;
    private LocalDateTime guarantorCrifUpdatedDate;

    //to compare cibil and crif of respective customer-type
    private boolean applicantCibilCrifCountMatching;
    private boolean coappCibilCrifCountMatching;
    private boolean guarantorCibilCrifCountMatching;

    // all flags combined
    private boolean allCibilFetched;
    private boolean allCrifFetched;
    private boolean allCibilCrifUptodate; //applicant+coapplicant+guarantor


    //for Status table : ITR-flag
    private boolean allItrFetched;

    private LocalDateTime lastResetDate;



    //FROM GST PROJECT
    // count
    private Integer corpGurantorsCount=0;
    private Integer indvGurantorsCount=0;

    // firm Commercial CIBIL
    private boolean firmComCibilUptoDate; // need to be false by default to fetch cibil
    private boolean firmComCrifFetched;
    private LocalDateTime firmComCibilUpdatedDate;
    private LocalDateTime firmComCrifUpdatedDate;


    // corp guarantor CIBIL
    private Integer corpGuarantorCibilCount=0;
    //    private boolean corpGuarantorComCibilUptoDate=true; // Default initialized to true
    private boolean corpGuarantorComCibilUptoDate;
    private LocalDateTime corpGuarantorCibilUpdatedDate;

    // individual guarantor CIBIL
    private Integer indvGuarantorCibilCount=0;
    //    private boolean indvGuarantorCibilUptoDate =true;
    private boolean indvGuarantorCibilUptoDate;
    private LocalDateTime indvGuarantorCibilUpdatedDate;

    // corp guarantor - commercial CRIF
    private Integer corpGuarantorCrifCount=0;
    //    private boolean corpGuarantorCrifUptoDate=true;
    private boolean corpGuarantorCrifUptoDate;
    private LocalDateTime corpGuarantorCrifUpdatedDate;

    // individual guarantor - Individual CRIF
    private Integer indvGuarantorCrifCount=0;
    //    private boolean indvGuarantorCrifUptoDate =true;
    private boolean indvGuarantorCrifUptoDate;
    private LocalDateTime indvGuarantorCrifUpdatedDate;

    //to compare cibil and crif of respective type of guarantors
    private boolean firmCibilCrifCountMatching;
    private boolean corpGuarCibilCrifCountMatching;
    private boolean indvGuarCibilCrifCountMatching;

    // all flags combined
    private boolean allGuarCibilCrifCountMatching; //corpguar+indguar - only guarantors

}
