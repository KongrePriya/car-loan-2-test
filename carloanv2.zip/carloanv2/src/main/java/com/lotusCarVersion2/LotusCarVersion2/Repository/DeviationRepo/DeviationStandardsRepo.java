package com.lotusCarVersion2.LotusCarVersion2.Repository.DeviationRepo;

import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.DeviationStandardEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;

public interface DeviationStandardsRepo extends JpaRepository<DeviationStandardEntity, Long> {

    @Query(value = "SELECT processing_charge FROM los_housing.deviation_standards_table;", nativeQuery = true)
    BigDecimal getProcessingCharges();


}

