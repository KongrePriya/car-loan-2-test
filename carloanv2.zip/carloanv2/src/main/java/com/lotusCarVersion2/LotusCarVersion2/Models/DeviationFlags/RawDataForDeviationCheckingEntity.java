package com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "deviation_raw_data_table")
@AllArgsConstructor
@NoArgsConstructor
public class RawDataForDeviationCheckingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String referenceId;
    private String branchCode;
    private String regionName;
    private String loanType;

    //applicant
    private String applicantName;
    private Integer applicantAgeInMonths;
    private String applicantIncomeSource;
    private String applicantIncomeConsider;
    private String applicantITRPresent;
    private String applicantForm16Present;
    private String appItrOrForm16Deviation;
    private String applicantItrVerified;
    private String applicantPan;

    //coapp one
    private String coapplicantOneName;
    private Integer coapplicantOneAgeInMonths;
    private String coapplicantOneIncomeSource;
    private String coapplicantOneIncomeConsider;
    private String coapplicantOneITRPresent;
    private String coapplicantOneForm16Present;
    private String coappOneItrOrForm16Deviation;
    private String coappOneItrVerified;
    private String coapplicantOnePan;

    //coapp two
    private String coapplicantTwoName;
    private Integer coapplicantTwoAgeInMonths;
    private String coapplicantTwoIncomeSource;
    private String coapplicantTwoIncomeConsider;
    private String coapplicantTwoITRPresent;
    private String coapplicantTwoForm16Present;
    private String coappTwoItrOrForm16Deviation;
    private String coappTwoItrVerified;
    private String coapplicantTwoPan;


    //eldest member age
    private Integer highestAgeOfEarningMemberInMonths=0;

    //ITR Required & Verified Count
    private Integer numberOfPersonHaveItr=0;
    private Integer numberOfItrFetched=0;
    private Integer countOfCorrectItrFetched=0;
    private boolean allItrFetched=false;
    private boolean allFetchedItrAreCorrect=false;

}

