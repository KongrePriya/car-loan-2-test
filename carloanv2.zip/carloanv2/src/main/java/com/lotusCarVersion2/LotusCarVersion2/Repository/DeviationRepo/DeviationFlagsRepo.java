package com.lotusCarVersion2.LotusCarVersion2.Repository.DeviationRepo;

import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.DeviationFlagsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeviationFlagsRepo extends JpaRepository<DeviationFlagsEntity, Long> {

    DeviationFlagsEntity findByReferenceId(String referenceId);

}
