package com.lotusCarVersion2.LotusCarVersion2.Models.CrifIndividualRequest;


import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
//@Entity
public class CrifFetchList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    private String referenceId;
    private String individualPan;
    private String crifFetched;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getIndividualPan() {
        return individualPan;
    }

    public void setIndividualPan(String individualPan) {
        this.individualPan = individualPan;
    }

    public String getCrifFetched() {
        return crifFetched;
    }

    public void setCrifFetched(String crifFetched) {
        this.crifFetched = crifFetched;
    }
}
