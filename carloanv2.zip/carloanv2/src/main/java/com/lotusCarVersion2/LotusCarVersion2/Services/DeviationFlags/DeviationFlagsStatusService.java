package com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags;

import com.lotusCarVersion2.LotusCarVersion2.DTO.DeviationDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.IndividualBasicDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.Calculation.CalculationDataEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.DeviationFlagsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.DeviationStandardEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsModel;


public interface DeviationFlagsStatusService {

    DeviationFlagsEntity checkOrCreateDeviationEntity(String referenceId);

    DeviationStandardEntity retrieveStandardDeviationEntity();

    DeviationDetailsDto getAllDeviationFlags(String referenceId);

    //step-1 : ENTRY AGE DEVIATION
    String updateAgeDeviationCommon(IndividualBasicDetailsDto detailsBasicDto);

    //step-2: CIBIL DEVIATION FOR ALL
    String updateCibilDeviationCommon(String referenceId);

    //step-3a: Income Deviation - SALARIED
    String updateSalariedServiceIncomeDeviation(IncomeSalaryModel incomeSalaryModel);

    //step-3b: Income Deviation - BUSINESS
    String updateBusinessStandingIncomeDeviation(IncomeBusinessMainModel incomeBusinessModel);

    //step-4: Processing Fees, Documentation, ROI DEVIATION,LOCATION
    String updateRoiProcessingDocumentationTenureDeviation(QuotationDetailsModel loanFinancialMetricsModel);

    //step-5 : Repayment period eligibility and Deviation
    String updateRepaymentAgeDeviation(QuotationDetailsModel quotationDetailsModel);

    //step-6 : COMBINED AGE & SERVICE DEVIATION FOR SEPARATE TABLE SHOW-HIDE
    String combinedAgeServiceItrDeviation(String referenceId);


    //step-7 : relation With applicant deviation for contributing members
    String relationWithApplicantDeviation(String referenceId);

    //step-8 : loan eligibility deviation - as per margin, deduction
    //Calling this function after all the calculations.
    String updateLoanEligibilityDeviation(CalculationDataEntity calculationData);


    //STEP-FINAL : CALLING ALL DEVIATION FUNCTIONS
    String allDeviationFunctionsCall(String referenceId);


    //CALLING inside updateLoanEligibilityDeviation()
 //PRIYA   String plotLoanEligibilityDeviation(CalculationDataEntity calculationData);
//*****************************************************************************************************************************//

}
