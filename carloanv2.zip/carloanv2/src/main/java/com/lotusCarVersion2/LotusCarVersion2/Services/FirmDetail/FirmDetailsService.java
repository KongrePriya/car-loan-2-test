package com.lotusCarVersion2.LotusCarVersion2.Services.FirmDetail;


import com.lotusCarVersion2.LotusCarVersion2.DTO.FirmDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.FirmDetailsDtoHistory;
import com.lotusCarVersion2.LotusCarVersion2.Models.FirmDetail.FirmDetailsEntity;

import java.io.IOException;

public interface FirmDetailsService {

    String saveFirmDetails(FirmDetailsDto FirmDetailsDtoList) throws IOException;

    FirmDetailsDto getFirmDetails(String ref_id);
    String createFirmDetailsHistory(FirmDetailsEntity ref_id, FirmDetailsEntity toSavedAsNew);

    FirmDetailsDtoHistory getFirmDetailHistory(String ref_id);
}
