package com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService;

import com.lotusCarVersion2.LotusCarVersion2.DTO.CibilCrifFetchedStatusDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifStatus.CibilCrifFetchStatusEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifFetchStatus.CibilCrifFetchStatusRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CorporateGuarantorRepo.CorporateGuarantorRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import jakarta.transaction.Transactional;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
@Transactional
public class CibilCrifFetchStatusServiceImpl implements CibilCrifFetchStatusService {

    private final CibilCrifFetchStatusRepo cibilCrifFetchStatusRepo;
    private final IndividualBasicDetailsRepo applicantCoappGuarantorRepo;
    private ModelMapper modelMapper;
    private final CorporateGuarantorRepo corporateGuarantorRepo;

//*************************************************************************************************************//
    @Override
    public CibilCrifFetchedStatusDto getFetchStatusCibilCrif(String referenceId) {

        CibilCrifFetchStatusEntity fetchStatusEntity=cibilCrifFetchStatusRepo.findByReferenceId(referenceId);
        return modelMapper.map(fetchStatusEntity,CibilCrifFetchedStatusDto.class);
    }

//*************************************************************************************************************//
    // to check if entry is already present in cibilCrifstatus table against the reference id
    @Override
    public CibilCrifFetchStatusEntity checkOrCreateCibilCrifEntity(String refId) {
        // Check if data already present from refId
        CibilCrifFetchStatusEntity entityPresent = cibilCrifFetchStatusRepo.findByReferenceId(refId);

        if (entityPresent == null) {
            CibilCrifFetchStatusEntity newEntity = new CibilCrifFetchStatusEntity();
            newEntity.setReferenceId(refId);
            System.out.println("EXISTING Entity NOT PRESENT , NEW CibilCrifFetchStatusEntity CREATED ");
            return newEntity;
        } else {
//            System.out.println("EXISTING ENTRY PRESENT CibilCrifFetchStatusEntity ");
            return entityPresent;
        }
    }
//*************************************************************************************************************//
// to set Applicant CIBIL Fetched Status to TRUE: by default false
    @Override
    public String setApplicantCibilFetched(String referenceId) {
        // Check if data already present from refId
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        Integer isApplicantCibilFetched= cibilCrifFetchStatusRepo.isApplicantCibilDetailsPresent(referenceId);

        if(isApplicantCibilFetched != 0) {
            if (isApplicantCibilFetched == 1) {
                entityPresent.setApplicantCibilFetched(true);
            } else {
                System.out.println("isApplicantCibilFetched has MORE THAN 1 ENTRY.");
                entityPresent.setApplicantCibilFetched(false);
            }
            entityPresent.setApplicantCibilUpdatedDate(LocalDateTime.now());
        }else{
            entityPresent.setApplicantCibilFetched(false);
            entityPresent.setApplicantCibilUpdatedDate(LocalDateTime.now());

        }
        cibilCrifFetchStatusRepo.save(entityPresent);
        System.out.println("Step 1 : CIBIL-CRIF-STATUS: APPLICANT CIBIL Fetched Status(ApplicantCibilFetched) Set Successfully to : "+entityPresent.isApplicantCibilFetched());
        return "Applicant Cibil Fetched Status Set Successfully.";
    }
//*************************************************************************************************************//
    @Override
    public String setIncomeCoappCountAndCibil(String referenceId) {
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        Integer incomeCoappCount= cibilCrifFetchStatusRepo.calculateEarningCoappCount(referenceId);
        Integer incomeCoappCibilCount = cibilCrifFetchStatusRepo.calculateEarningCoappCibilCount(referenceId);

        System.out.printf("INCOME Considered for : %d Co-applicants out of which CIBIL Fetched for : %d \n", incomeCoappCount, incomeCoappCibilCount);
        entityPresent.setCoappIncomeCount(incomeCoappCount);
        entityPresent.setCoappIncomeCibilCount(incomeCoappCibilCount);
        entityPresent.setCoappIncomeCibilUpdatedDate(LocalDateTime.now());

        if(incomeCoappCount == incomeCoappCibilCount){
            entityPresent.setCoappIncomeCibilFetched(true);

        }else{
            entityPresent.setCoappIncomeCibilFetched(false);
        }
        cibilCrifFetchStatusRepo.save(entityPresent);
        System.out.println("Step 2 : CIBIL-CRIF-STATUS: Income- coapplicant Cibil Fetched Status(CoappIncomeCibilFetched) Set Successfully to : "+entityPresent.isCoappIncomeCibilFetched());
        return "Income- coapplicant Cibil Fetched Status Set Successfully.";
    }
//*************************************************************************************************************//
    @Override
    public String setNonIncomeCoappCountAndCibil(String referenceId) {
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        Integer nonIncomeCoappCount= cibilCrifFetchStatusRepo.calculateNonEarningCoappCount(referenceId);
        Integer nonIncomeCoappCibilCount = cibilCrifFetchStatusRepo.calculateNonEarningCoappCibilCount(referenceId);

        System.out.printf("NON-INCOME Considered for : %d Co-applicants out of which CIBIL Fetched for : %d \n", nonIncomeCoappCount, nonIncomeCoappCibilCount);
        entityPresent.setCoappNonIncomeCount(nonIncomeCoappCount);
        entityPresent.setCoappNonIncomeCibilCount(nonIncomeCoappCibilCount);
        entityPresent.setCoappNonIncomeCibilUpdatedDate(LocalDateTime.now());

        if(nonIncomeCoappCount == nonIncomeCoappCibilCount){
            entityPresent.setCoappNonIncomeCibilFetched(true);
        }else{
            entityPresent.setCoappNonIncomeCibilFetched(false);
        }
        cibilCrifFetchStatusRepo.save(entityPresent);
        System.out.println("Step 3 : CIBIL-CRIF-STATUS: Non Income- coapplicant Cibil Fetched Status(CoappNonIncomeCibilFetched) Set Successfully to : "+entityPresent.isCoappNonIncomeCibilFetched());
        return "Non-Income- coapplicant Cibil Fetched Status Set Successfully.";
    }
//*************************************************************************************************************//
    @Override
    public String setGuarantorCountAndCibil(String referenceId) {
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        Integer guarantorCount = cibilCrifFetchStatusRepo.calculateGuarantorsCount(referenceId);
        Integer guarantorCibilCount = cibilCrifFetchStatusRepo.calculateGuarantorsCibilCount(referenceId);

        System.out.printf("Number of Guarantors added is : %d, out of which CIBIL Fetched for : %d \n", guarantorCount, guarantorCibilCount);
        entityPresent.setGuarantorsCount(guarantorCount);
        entityPresent.setGuarantorCibilCount(guarantorCibilCount);
        entityPresent.setGuarantorCibilUpdatedDate(LocalDateTime.now());

        if(guarantorCount == guarantorCibilCount){
            entityPresent.setGuarantorCibilFetched(true);
        }else{
            entityPresent.setGuarantorCibilFetched(false);
        }
        cibilCrifFetchStatusRepo.save(entityPresent);
        System.out.println("Step 4 : CIBIL-CRIF-STATUS: Guarantors Cibil Fetched(guarantorCibilFetched) Status Set Successfully to : "+entityPresent.isGuarantorCibilFetched());
        return "Guarantors Cibil Fetched Status Set Successfully.";
    }


//---------------------------------------- :::: SET CRIF STATUS FLAGS :::: -------------------------------------------
//*************************************************************************************************************//
// to set Applicant CRIF Fetched Status to TRUE: by default false
@Override
public String setApplicantCrifFetched(String referenceId) {
    // Check if data already present from refId
    CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

    Integer isApplicantCrifFetched= cibilCrifFetchStatusRepo.getApplicantCrifFetchedStatus(referenceId);

    if(isApplicantCrifFetched != 0) {
        if (isApplicantCrifFetched == 1) {
            System.out.println("inside app crif "+isApplicantCrifFetched);
            entityPresent.setApplicantCrifFetched(true);
        } else {
            System.out.println("isApplicantCrifFetched has MORE THAN 1 ENTRY.");
            entityPresent.setApplicantCrifFetched(false);
        }
        entityPresent.setApplicantCrifUpdatedDate(LocalDateTime.now());
    }else{
        entityPresent.setApplicantCrifFetched(false);
        entityPresent.setApplicantCrifUpdatedDate(LocalDateTime.now());

    }
    cibilCrifFetchStatusRepo.save(entityPresent);

    System.out.println("CIBIL-CRIF-STATUS: 1)Applicant Crif Fetched Status(ApplicantCrifFetched) Set Successfully to : "+entityPresent.isApplicantCrifFetched());
    return "Applicant Crif Fetched Status Set Successfully.";
}
//*************************************************************************************************************//
    @Override
    public String setIncomeCoappCountAndCrif(String referenceId) {
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        Integer incomeCoappCount= cibilCrifFetchStatusRepo.calculateEarningCoappCount(referenceId);
        Integer incomeCoappCrifCount = cibilCrifFetchStatusRepo.getEarningCoAppCrifFetchedStatus(referenceId);

        System.out.printf("INCOME Considered for : %d Co-applicants out of which Crif Fetched for : %d \n", incomeCoappCount, incomeCoappCrifCount);
        entityPresent.setCoappIncomeCount(incomeCoappCount);
        entityPresent.setCoappIncomeCrifCount(incomeCoappCrifCount);
        entityPresent.setCoappIncomeCrifUpdatedDate(LocalDateTime.now());

        if(incomeCoappCount == incomeCoappCrifCount){
            entityPresent.setCoappIncomeCrifFetched(true);

        }else{
            entityPresent.setCoappIncomeCrifFetched(false);
        }
        cibilCrifFetchStatusRepo.save(entityPresent);
        System.out.println("CIBIL-CRIF-STATUS: 2) Income- coapplicant Crif Fetched Status(CoappIncomeCrifFetched) Set Successfully to : "+entityPresent.isCoappIncomeCrifFetched());
        return "Income- coapplicant Crif Fetched Status Set Successfully.";
    }
//*************************************************************************************************************//
    @Override
    public String setNonIncomeCoappCountAndCrif(String referenceId) {
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        Integer nonIncomeCoappCount= cibilCrifFetchStatusRepo.calculateNonEarningCoappCount(referenceId);
        Integer nonIncomeCoappCrifCount = cibilCrifFetchStatusRepo.getNonEarningCoAppCrifFetchedStatus(referenceId);

        System.out.printf("NON-INCOME Considered for : %d Co-applicants out of which CIBIL Fetched for : %d \n", nonIncomeCoappCount, nonIncomeCoappCrifCount);
        entityPresent.setCoappNonIncomeCount(nonIncomeCoappCount);
        entityPresent.setCoappNonIncomeCrifCount(nonIncomeCoappCrifCount);
        entityPresent.setCoappNonIncomeCrifUpdatedDate(LocalDateTime.now());

        if(nonIncomeCoappCount == nonIncomeCoappCrifCount){
            entityPresent.setCoappNonIncomeCrifFetched(true);
        }else{
            entityPresent.setCoappNonIncomeCrifFetched(false);
        }
        cibilCrifFetchStatusRepo.save(entityPresent);
        System.out.println("CIBIL-CRIF-STATUS: 3) Non Income- coapplicant Crif Fetched Status(CoappNonIncomeCibilFetched) Set Successfully to : "+entityPresent.isCoappNonIncomeCrifFetched());
        return "Non-Income- coapplicant Crif Fetched Status Set Successfully.";
    }
//*************************************************************************************************************//
    @Override
    public String setGuarantorCountAndCrif(String referenceId) {
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        Integer guarantorCount = cibilCrifFetchStatusRepo.calculateGuarantorsCount(referenceId);
        Integer guarantorCrifCount = cibilCrifFetchStatusRepo.getGuarantorsCrifFetchedStatus(referenceId);

        System.out.printf("Number of Guarantors added is : %d, out of which CIBIL Fetched for : %d \n", guarantorCount, guarantorCrifCount);
        entityPresent.setGuarantorsCount(guarantorCount);
        entityPresent.setGuarantorCrifCount(guarantorCrifCount);
        entityPresent.setGuarantorCrifUpdatedDate(LocalDateTime.now());

        if(guarantorCount == guarantorCrifCount){
            entityPresent.setGuarantorCrifFetched(true);
        }else{
            entityPresent.setGuarantorCrifFetched(false);
        }
        cibilCrifFetchStatusRepo.save(entityPresent);
        System.out.println("CIBIL-CRIF-STATUS: 4) Guarantors Crif Fetched(guarantorCibilFetched) Status Set Successfully to : "+entityPresent.isGuarantorCrifFetched());
        return "Guarantors Crif Fetched Status Set Successfully.";
    }

//*************************************************************************************************************//
//*************************************************************************************************************//
/*
13052025 : MOVED TO SEPARATE SCHEDULER SERVICE
@Override
public String ResetFlagsOfCibilAndCrif() {

    System.out.println("//----------------------------------- INSIDE CIBIL-CRIF FLAG RESET SERVICE METHOD. -------------------------------------//");
    LocalDate today = LocalDate.now();
    System.out.println("TODAY'S DATE IS: "+today);
    // Check if today is the 10th
    if (today.getDayOfMonth() == 10) {
        List<CibilCrifFetchStatusEntity> allEntities;
        // Fetch all records
        try {
            allEntities = cibilCrifFetchStatusRepo.getAllCibilCrifFlagResetEntities();
            System.out.println("COUNT OF ALL RETRIEVED STATUS ENTITY WHICH WILL BE RESET :"+allEntities.size());
        }catch (Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE RETRIEVING LIST OF CibilCrifFetchStatusEntity TO RESET FLAGS :"+e.getMessage());
            throw new RuntimeException("ERROR WHILE RETRIEVING LIST OF CibilCrifFetchStatusEntity TO RESET FLAGS :"+e.getMessage());
        }
        for (CibilCrifFetchStatusEntity entity : allEntities) {
            //CIBIL FLAGS
            entity.setApplicantCibilFetched(false);
            entity.setCoappIncomeCibilFetched(false);
            entity.setCoappNonIncomeCibilFetched(false);
            entity.setGuarantorCibilFetched(false);

            //CRIF FLAGS
            entity.setApplicantCrifFetched(false);
            entity.setCoappIncomeCrifFetched(false);
            entity.setCoappNonIncomeCrifFetched(false);
            entity.setGuarantorCrifFetched(false);

            //otherFlags
            entity.setAllCibilFetched(false);
            entity.setAllCrifFetched(false);
            entity.setAllCibilCrifUptodate(false);


            // Update last reset date
            entity.setLastResetDate(LocalDateTime.now());
            cibilCrifFetchStatusRepo.save(entity);
        }
        System.out.println("//------------------------------------ CIBIL CRIF FLAG RESET:Flags have been reset to default values. -----------------------------------------------//");
        return "CIBIL CRIF FLAG RESET:Flags have been reset to default values.";
    }
    System.out.println("//------------------------------------ CIBIL CRIF FLAG RESET:Reset can only be performed on the 10th of the month. ------------------------------------//");
    return "CIBIL CRIF FLAG RESET:Reset can only be performed on the 10th of the month.";
}*/
//*************************************************************************************************************//
@Override
public CibilCrifFetchedStatusDto callAllStatusFunctions(String referenceId) {

    System.out.println("//------------------------------------------------------ INSIDE CIBIL-CRIF STATUS FLAGS SERVICE-----------------------------------------------//");
//    ----------------- CIBIL ---------------
    System.out.println("//------------------------- CIBIL FLAGS STARTED --------------------------//");
    setApplicantCibilFetched(referenceId);
    setIncomeCoappCountAndCibil(referenceId);
    setNonIncomeCoappCountAndCibil(referenceId);
    setGuarantorCountAndCibil(referenceId);
    System.out.println("//------------------------- CIBIL FLAGS ENDED --------------------------//");

//    ----------------- CRIF -----------------
    System.out.println("//------------------------- CRIF FLAGS STARTED --------------------------//");

    setApplicantCrifFetched(referenceId);
    setIncomeCoappCountAndCrif(referenceId);
    setNonIncomeCoappCountAndCrif(referenceId);
    setGuarantorCountAndCrif(referenceId);
    System.out.println("//------------------------- CRIF FLAGS STARTED --------------------------//");



    CibilCrifFetchStatusEntity cibilCrifFetchStatus=cibilCrifFetchStatusRepo.findByReferenceId(referenceId);


    //-------------------------ALL CIBIL-CRIF UPTO DATE ----------------------------//
    if(cibilCrifFetchStatus.isAllCibilFetched() && cibilCrifFetchStatus.isAllCrifFetched()){
        cibilCrifFetchStatus.setAllCibilCrifUptodate(true);
    }else{
        cibilCrifFetchStatus.setAllCibilCrifUptodate(false);
    }

    cibilCrifFetchStatusRepo.save(cibilCrifFetchStatus);
    System.out.println("Cibil Crif Status Entity:" +cibilCrifFetchStatus);
    return  modelMapper.map(cibilCrifFetchStatus, CibilCrifFetchedStatusDto.class);
}


//*************************************************************************************************************//
//FROM GST PROJECT

    // to set firm Commercial Cibil Upto Date Status True after fetching CIBIl successfully: by default false
    @Override
    public String firmComCibilFetchedStatus(String referenceId) {
        // Check if data already present from refId
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);


        Integer firmCibilFetchedOrNot= cibilCrifFetchStatusRepo.firmCibilFetchedOrNot(referenceId);

        if(firmCibilFetchedOrNot != 0) {
            if (firmCibilFetchedOrNot == 1) {
                entityPresent.setFirmComCibilUptoDate(true);
            } else {
                System.out.println("firmCrifFetched has MORE THAN 1 ENTRY.");
                entityPresent.setFirmComCrifFetched(false);
            }
        }else{
            entityPresent.setFirmComCrifFetched(false);
        }
        return "Firm Cibil Fetched Status Set Successfully.";
    }
//*************************************************************************************************************//
    // to set FIRM COMMERCIAL CRIF FETCHED STATUS TO TRUE
//    @Override
//    public CibilCrifStatusDto firmComCrifFetchedStatus(String referenceId, String status) {
//        // Check if data already present from refId
//        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);
//
//        entityPresent.setFirmComCrifFetched(Boolean.parseBoolean(status));
//        cibilCrifFetchStatusRepo.save(entityPresent);
//        return modelMapper.map(entityPresent, CibilCrifStatusDto.class);
//    }

    @Override
    public CibilCrifFetchedStatusDto firmComCrifFetchedStatus(String referenceId) {
        // Check if data already present from refId
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        Integer firmCrifFetchedOrNot= cibilCrifFetchStatusRepo.firmCrifFetchedOrNot(referenceId);

        if(firmCrifFetchedOrNot != 0) {
            if (firmCrifFetchedOrNot == 1) {
                entityPresent.setFirmComCrifFetched(true);
                entityPresent.setFirmComCrifUpdatedDate(LocalDateTime.now());
            } else {
                System.out.println("firmCrifFetched has MORE THAN 1 ENTRY.");
                entityPresent.setFirmComCrifFetched(false);
            }
        }else{
            entityPresent.setFirmComCrifFetched(false);
        }

        cibilCrifFetchStatusRepo.save(entityPresent);
        return modelMapper.map(entityPresent, CibilCrifFetchedStatusDto.class);
    }

    //*************************************************************************************************************//
// to compare FIRM COMMERCIAL CIBIL & CRIF FETCHED STATUS TO TRUE
    @Override
    public String compareFirmCibilCrifCountMatching(String referenceId) {

        CibilCrifFetchStatusEntity entity=checkOrCreateCibilCrifEntity(referenceId);
//        System.out.println("IS CRIF REQUIRED: "+entity.isCrifRequired());
        if(entity.isCrifRequired()){ //true
            if (entity.isFirmComCibilUptoDate() && entity.isFirmComCrifFetched()) {
                entity.setFirmCibilCrifCountMatching(true);
                cibilCrifFetchStatusRepo.save(entity);
            }else{
                entity.setFirmCibilCrifCountMatching(false);
                cibilCrifFetchStatusRepo.save(entity);
            }
        }else{ //false
            if (entity.isFirmComCibilUptoDate()){
                entity.setFirmCibilCrifCountMatching(true);
                cibilCrifFetchStatusRepo.save(entity);
            } else{
                entity.setFirmCibilCrifCountMatching(false);
                cibilCrifFetchStatusRepo.save(entity);
            }
        }
        return "";
    }
    //*************************************************************************************************************//
//    @Override
//    public CibilCrifStatusDto corpGuarCibilCrifCountMatching(String referenceId) {
//
//        CibilCrifFetchStatusEntity entity=checkOrCreateCibilCrifEntity(referenceId);
//
//            if (entity.getCorpGuarantorCibilCount().equals(entity.getCorpGuarantorCrifCount())) {
//
//                entity.setCorpGuarCibilCrifCountMatching(true);
//                cibilCrifFetchStatusRepo.save(entity);
//
//            }
//        System.out.println("corpGuarCibilCrifCountMatching SET" );
//        return null;
//    }
    @Override
    public CibilCrifFetchedStatusDto corpGuarCibilCrifCountMatching(String referenceId) {

        CibilCrifFetchStatusEntity entity=checkOrCreateCibilCrifEntity(referenceId);
//    System.out.println("IS CRIF REQUIRED: "+entity.isCrifRequired());
        if(entity.isCrifRequired()){ //true-crif not required
            if (entity.getCorpGuarantorCibilCount().equals(entity.getCorpGuarantorCrifCount())) {
                entity.setCorpGuarCibilCrifCountMatching(true);
                cibilCrifFetchStatusRepo.save(entity);
            }else{
                entity.setCorpGuarCibilCrifCountMatching(false);
                cibilCrifFetchStatusRepo.save(entity);
            }
        }else { //false- crif not required
            if (entity.getCorpGuarantorCibilCount().equals(entity.getCorpGurantorsCount())) {
                entity.setCorpGuarCibilCrifCountMatching(true);
                cibilCrifFetchStatusRepo.save(entity);
            }else{
                entity.setCorpGuarCibilCrifCountMatching(false);
                cibilCrifFetchStatusRepo.save(entity);
            }
        }
        System.out.println("corpGuarCibilCrifCountMatching SET" );
        return null;
    }
    //*************************************************************************************************************//
    @Override
    public CibilCrifFetchedStatusDto indvGuarCibilCrifCountMatching(String referenceId) {
        CibilCrifFetchStatusEntity entity=checkOrCreateCibilCrifEntity(referenceId);
//        System.out.println("IS CRIF REQUIRED: "+entity.isCrifRequired());
        if(entity.isCrifRequired()) { //true- CRIF required
            if (entity.getIndvGuarantorCibilCount().equals(entity.getIndvGuarantorCrifCount())) {
                entity.setIndvGuarCibilCrifCountMatching(true);
                cibilCrifFetchStatusRepo.save(entity);
            }else{
                entity.setIndvGuarCibilCrifCountMatching(false);
                cibilCrifFetchStatusRepo.save(entity);
            }
        }else { //false- CRIF not required
            if (entity.getIndvGuarantorCibilCount().equals(entity.getIndvGurantorsCount())) {
                entity.setIndvGuarCibilCrifCountMatching(true);
                cibilCrifFetchStatusRepo.save(entity);
            }else{
                entity.setIndvGuarCibilCrifCountMatching(false);
                cibilCrifFetchStatusRepo.save(entity);
            }
        }
        System.out.println("indvGuarCibilCrifCountMatching SET" );

        return null;
    }

    //*************************************************************************************************************//
    //individual guarantors count :- need to update when guarantor added , updated or deleted.
    @Override
    public String indvGuarCountStatus(String referenceIdGst) {
        List<IndividualBasicDetailsEntity> indGuarantorList= applicantCoappGuarantorRepo.findAllGuarantorByReferenceId(referenceIdGst);

        Integer indGuarantorCount=indGuarantorList.size();

        // Check if data already present from refId
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceIdGst);

        entityPresent.setIndvGurantorsCount(indGuarantorCount);
        cibilCrifFetchStatusRepo.save(entityPresent);

        indvGuarCrifFetchedCountStatus(referenceIdGst);

        indGuarCibilFecthedCountStatus(referenceIdGst);

        System.out.println("indvGurantorsCount COUNT SET IN CibilCrifFetchStatusEntity & COUNT IS : "+indGuarantorCount);

        return "indvGurantorsCount COUNT SET IN CibilCrifFetchStatusEntity";
    }
    //*************************************************************************************************************//
    //Individual guarantor cibil uptodate and crif uptodate
    @Override
    public String indvGuarCibilAndCrifUptodate(String referenceIdGst) {

        // Check if data already present from refId
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceIdGst);

        //cibil
        if(entityPresent.getIndvGurantorsCount().equals(entityPresent.getIndvGuarantorCibilCount())){
            entityPresent.setIndvGuarantorCibilUptoDate(true);
            cibilCrifFetchStatusRepo.save(entityPresent);
        }else{
            entityPresent.setIndvGuarantorCibilUptoDate(false);
            cibilCrifFetchStatusRepo.save(entityPresent);
        }

        //CRIF
        if(entityPresent.isCrifRequired()) {
            if (entityPresent.getIndvGurantorsCount().equals(entityPresent.getIndvGuarantorCrifCount())) {
                entityPresent.setIndvGuarantorCrifUptoDate(true);
                cibilCrifFetchStatusRepo.save(entityPresent);
            } else {
                entityPresent.setIndvGuarantorCrifUptoDate(false);
                cibilCrifFetchStatusRepo.save(entityPresent);
            }
        }else{
            entityPresent.setIndvGuarantorCrifUptoDate(true);
            cibilCrifFetchStatusRepo.save(entityPresent);
        }

        return "Individual guarantor cibil uptodate and crif uptodate";

    }



    //*************************************************************************************************************//
//Corporate guarantor cibil uptodate and crif uptodate
    @Override
    public String corpGuarCibilAndCrifUptodate(String referenceId) {

        // Check if data already present from refId
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);

        //cibil
        if(entityPresent.getCorpGurantorsCount().equals(entityPresent.getCorpGuarantorCibilCount())){
            entityPresent.setCorpGuarantorComCibilUptoDate(true);
            cibilCrifFetchStatusRepo.save(entityPresent);
        }else{
            entityPresent.setCorpGuarantorComCibilUptoDate(false);
            cibilCrifFetchStatusRepo.save(entityPresent);
        }

        //CRIF
        if(entityPresent.isCrifRequired()) {
            if (entityPresent.getCorpGurantorsCount().equals(entityPresent.getCorpGuarantorCrifCount())) {
                entityPresent.setCorpGuarantorCrifUptoDate(true);
                cibilCrifFetchStatusRepo.save(entityPresent);
            } else {
                entityPresent.setCorpGuarantorCrifUptoDate(false);
                cibilCrifFetchStatusRepo.save(entityPresent);
            }
        }else{
            entityPresent.setCorpGuarantorCrifUptoDate(true);
            cibilCrifFetchStatusRepo.save(entityPresent);
        }

        return "Corporate guarantor cibil uptodate and crif uptodate";

    }


    //*************************************************************************************************************//
//Corporate guarantors count :- need to update when guarantor added , updated or deleted.
    @Override
    public String corpGuarCountStatus(String referenceId) {
        Integer corpGuarantorCount= corporateGuarantorRepo.countCorpGuarByReferenceId(referenceId);

        // Check if data already present from refId
        CibilCrifFetchStatusEntity entityPresent=checkOrCreateCibilCrifEntity(referenceId);
        entityPresent.setCorpGurantorsCount(corpGuarantorCount);
        cibilCrifFetchStatusRepo.save(entityPresent);

        corpGuarCibilFetchedCountStatus(referenceId);
        corpGuarCrifFetchedCountStatus(referenceId);

        System.out.println("corpGurantorsCount COUNT SET IN CibilCrifFetchStatusEntity & COUNT IS : "+corpGuarantorCount);

        return "corpGurantorsCount COUNT SET IN CibilCrifFetchStatusEntity";
    }

    //*************************************************************************************************************//
    // Corporate guarantors CIBIL fetched count
    @Override
    public String corpGuarCibilFetchedCountStatus(String referenceId) {

        Integer corpGuarCibilCountPresent= cibilCrifFetchStatusRepo.calculateCorpGuarCibilCount(referenceId);
        CibilCrifFetchStatusEntity ccStatusEntity=checkOrCreateCibilCrifEntity(referenceId);
        ccStatusEntity.setCorpGuarantorCibilCount(corpGuarCibilCountPresent);
        ccStatusEntity.setCorpGuarantorCibilUpdatedDate(LocalDateTime.now());
        cibilCrifFetchStatusRepo.save(ccStatusEntity);

        //to set corp guar cibil /crif uptodate flags
        corpGuarCibilAndCrifUptodate(referenceId);

        //to match cibil-crif count
        corpGuarCibilCrifCountMatching(referenceId);

        return "CorpGuarantor CibilCount set in Cibil-crif Status table";
    }

    //*************************************************************************************************************//
    // Corporate guarantors CRIF fetched count : need to call when corp guarantor CRIF fetched
    @Override
    public String corpGuarCrifFetchedCountStatus(String referenceId) {
        Integer corpGuarCRIFCount= cibilCrifFetchStatusRepo.calculateCorpGuarCrifCount(referenceId);
        System.out.println("corporate crif count:"+corpGuarCRIFCount);

        CibilCrifFetchStatusEntity ccStatusEntity=checkOrCreateCibilCrifEntity(referenceId);
        ccStatusEntity.setCorpGuarantorCrifCount(corpGuarCRIFCount);
        ccStatusEntity.setCorpGuarantorCrifUpdatedDate(LocalDateTime.now());
        cibilCrifFetchStatusRepo.save(ccStatusEntity);

        //to set corp guar cibil /crif uptodate flags
        corpGuarCibilAndCrifUptodate(referenceId);

        //to match cibil-crif count
        corpGuarCibilCrifCountMatching(referenceId);

        return "corp guar CRIF Count set in Cibil-crif Status table";
    }

    //*************************************************************************************************************//
    // Individual guarantors CRIF fetched count //need to call this on page after crif is fetched
    @Override
    public CibilCrifFetchedStatusDto indvGuarCrifFetchedCountStatus(String referenceId) {

        Integer indvGuarCrifFetched= cibilCrifFetchStatusRepo.calculateIndvGuarCrifCount(referenceId);
        System.out.println("ind crif count:"+indvGuarCrifFetched);
        CibilCrifFetchStatusEntity ccStatusEntity=checkOrCreateCibilCrifEntity(referenceId);
        ccStatusEntity.setIndvGuarantorCrifCount(indvGuarCrifFetched);
        ccStatusEntity.setIndvGuarantorCrifUpdatedDate(LocalDateTime.now());
        cibilCrifFetchStatusRepo.save(ccStatusEntity);
        //Corp guarantors CRIF fetched status.
        String corpCrifResult= corpGuarCrifFetchedCountStatus(referenceId);
        System.out.println(corpCrifResult);

        //to set Ind guar CIBIL-CRIF status uptodate flag
        indvGuarCibilAndCrifUptodate(referenceId);
        //TO SET indvGuarCibilCrifCountMatching
        indvGuarCibilCrifCountMatching(referenceId);

        return modelMapper.map(ccStatusEntity, CibilCrifFetchedStatusDto.class);

//        return "IndvGuarantorCrifCount set in Cibil-crif Status table";
    }

    //*************************************************************************************************************//
//Method to update count of Individual guarantors cibil fetched.
    @Override
    public String indGuarCibilFecthedCountStatus(String referenceId) {
        Integer indGuarCibilCountPresent= cibilCrifFetchStatusRepo.calculateIndividualGuarCibilCount(referenceId);
        CibilCrifFetchStatusEntity ccStatusEntity=checkOrCreateCibilCrifEntity(referenceId);
        ccStatusEntity.setIndvGuarantorCibilCount(indGuarCibilCountPresent);
        ccStatusEntity.setIndvGuarantorCibilUpdatedDate(LocalDateTime.now());
        cibilCrifFetchStatusRepo.save(ccStatusEntity);

        //to set Ind guar CIBIL-CRIF status uptodate flag
        indvGuarCibilAndCrifUptodate(referenceId);
        //TO SET indvGuarCibilCrifCountMatching
        indvGuarCibilCrifCountMatching(referenceId);

        return "Individual Guarantors Cibil-fetched-Count set in Cibil-crif Status table";

    }

    //*************************************************************************************************************//
    //Crif required or not flag //need to call it while saving CC limit data by passing loanAmount
    @Override
    public CibilCrifFetchedStatusDto CrifRequiredStatus(String referenceId, @NotNull BigDecimal recommendedLoanAmt) {
        System.out.println("CrifRequiredStatus Called With Recommended amt" + recommendedLoanAmt + referenceId);
        //    recommended_amt from CC limit page
        BigDecimal crifLimit = new BigDecimal("10000000"); //1 Crore

        CibilCrifFetchStatusEntity ccStatusEntity = checkOrCreateCibilCrifEntity(referenceId);;
        if (recommendedLoanAmt.compareTo(crifLimit) >= 0) {

            ccStatusEntity = checkOrCreateCibilCrifEntity(referenceId);
            ccStatusEntity.setCrifRequired(true); //setting to true when amount is greater than or equal 1 Crore
            cibilCrifFetchStatusRepo.save(ccStatusEntity);
            callAllFunctionsAtLast(referenceId);
            return modelMapper.map(ccStatusEntity, CibilCrifFetchedStatusDto.class);
//            return "CRIF required, Recommended loan amount is greater than 1 crore.";
        } else {

            ccStatusEntity.setCrifRequired(false); //setting to false when amount is less than 1 Crore
            cibilCrifFetchStatusRepo.save(ccStatusEntity);
            callAllFunctionsAtLast(referenceId);

            return modelMapper.map(ccStatusEntity, CibilCrifFetchedStatusDto.class);
//            return "Recommended loan amount is less than 1 crore, CRIF not required.";
        }
    }

    //*************************************************************************************************************//
//*************************************************************************************************************//
    // UPDATE ALL-CIBIL-CRIF-UP-TO-DATE FLAG TO ""true"" WHEN COUNT IS MATCHING
    @Override
    public CibilCrifFetchedStatusDto compareAndUpdateAllGuarCibilCrifUptodate(String referenceId) {

        CibilCrifFetchStatusEntity statusEntity= cibilCrifFetchStatusRepo.findByReferenceId(referenceId);
        if(statusEntity.isIndvGuarCibilCrifCountMatching() && statusEntity.isCorpGuarCibilCrifCountMatching()){
//            statusEntity.setAllCibilCrifUptodate(true);
            statusEntity.setAllGuarCibilCrifCountMatching(true);
            cibilCrifFetchStatusRepo.save(statusEntity);

            System.out.println(" ALL THE COUNT OF CIBIL AND CRIF OF INDIVIDUAL GUARANTOR AND CORPORATE GUARANTOR MATCHING ACCORDINGLY, FLAG SET TO true.");
        }else{
            statusEntity.setAllGuarCibilCrifCountMatching(false);
            cibilCrifFetchStatusRepo.save(statusEntity);
        }
//        if(statusEntity.getCorpGuarCibilCrifCountMatching() && statusEntity.isCorpGuarCibilCrifCountMatching()){
//            statusEntity.setAllCibilCrifUptodate(true);
//            System.out.println(" ALL THE COUNT OF CIBIL AND CRIF OF INDIVIDUAL GUARANTOR AND CORPORATE GUARANTOR MATCHING ACCORDINGLY, FLAG SET TO true.");
//        }
        return modelMapper.map(statusEntity, CibilCrifFetchedStatusDto.class);
    }
    //*************************************************************************************************************//
    //all- firm+corpguar+indguar
    @Override
    public CibilCrifFetchedStatusDto allCibilCrifUptodate(String referenceId) {
        CibilCrifFetchStatusEntity statusEntity= cibilCrifFetchStatusRepo.findByReferenceId(referenceId);

        System.out.println("statusEntity: "+statusEntity);
        if(statusEntity.isFirmCibilCrifCountMatching() && statusEntity.isAllGuarCibilCrifCountMatching()){

            statusEntity.setAllCibilCrifUptodate(true);
            cibilCrifFetchStatusRepo.save(statusEntity);

            System.out.println(" ALL THE COUNT OF CIBIL AND CRIF OF ALL GUARANTOR AND FIRM MATCHING, FLAG SET TO true.");
        }else {

            statusEntity.setAllCibilCrifUptodate(false);
            cibilCrifFetchStatusRepo.save(statusEntity);
        }
        return modelMapper.map(statusEntity, CibilCrifFetchedStatusDto.class);
    }


//*************************************************************************************************************//

    public String ResetFlagsOfCibilCrif() {

        System.out.println("//---------------------------- INSIDE CIBIL CRIF FLAG RESET SERVICE METHOD. ---------------------------//");
        LocalDate today = LocalDate.now();
        System.out.println("TODAY'S DATE IS: "+today);
        // Check if today is the 10th
        if (today.getDayOfMonth() == 10) {
            // Fetch all records
            List<CibilCrifFetchStatusEntity> allEntities = cibilCrifFetchStatusRepo.getAllCibilCrifFlagResetEntities();

            System.out.println("COUNT OF ENTITIES TO RESET FLAGS : "+allEntities.size());
            for (CibilCrifFetchStatusEntity entity : allEntities) {
                // Reset the flags- count can not be reset as we are counting it on save/update button.
                entity.setFirmComCibilUptoDate(false);
                entity.setFirmComCrifFetched(false);

                entity.setCorpGuarantorComCibilUptoDate(false);
                entity.setCorpGuarantorCrifUptoDate(false);

                entity.setIndvGuarantorCibilUptoDate(false);
                entity.setIndvGuarantorCrifUptoDate(false);

                entity.setAllCibilCrifUptodate(false);

                // Update last reset date
                entity.setLastResetDate(LocalDateTime.now());
                cibilCrifFetchStatusRepo.save(entity);
            }
            System.out.println("//--------------------------- CIBIL CRIF FLAG:Flags have been reset to default values. ---------------------------//");
            return "CIBIL CRIF FLAG:Flags have been reset to default values.";
        }
        System.out.println("//--------------------------- CIBIL CRIF FLAG:Reset can only be performed on the 10th of the month. ---------------------------//");
        return "CIBIL CRIF FLAG:Reset can only be performed on the 10th of the month.";
    }
//*************************************************************************************************************//

    @Override
    public String callAllFunctionsAtLast(String referenceId) {

        //count method
        indGuarCibilFecthedCountStatus(referenceId);
        indvGuarCrifFetchedCountStatus(referenceId);
        corpGuarCrifFetchedCountStatus(referenceId);
        corpGuarCibilFetchedCountStatus(referenceId);


        //firm
        firmComCrifFetchedStatus(referenceId);
        firmComCibilFetchedStatus(referenceId);

        //boolean flags
        compareFirmCibilCrifCountMatching(referenceId);
        indvGuarCibilCrifCountMatching(referenceId);
        corpGuarCibilCrifCountMatching(referenceId);
        compareAndUpdateAllGuarCibilCrifUptodate(referenceId);
        allCibilCrifUptodate(referenceId);

        return "callAllFunctionsAtLast";
    }
//*************************************************************************************************************//




}
