package com.lotusCarVersion2.LotusCarVersion2.Services.ITRDetails;

import com.lotusCarVersion2.LotusCarVersion2.DTO.ITRDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessMain.IncomeBusinessMainRepo;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@AllArgsConstructor
public class ITRDetailsSavingServiceImpl implements ITRService{

    private final IncomeBusinessMainRepo incomeBusinessMainRepo;

    @Override
    public String SaveItrDetailsBusinessmen(ITRDetailsDto itrDetailsDto){

        System.out.println("ITR DETAILS DTO :"+itrDetailsDto);
        IncomeBusinessMainModel incomeBusinessEntity =incomeBusinessMainRepo.findByReferenceIdAndPanNumber(itrDetailsDto.getReferenceIdLotus(), itrDetailsDto.getCustomerPan());
        if(incomeBusinessEntity == null) {
            incomeBusinessEntity = new IncomeBusinessMainModel();
            incomeBusinessEntity.setReferenceId(itrDetailsDto.getReferenceIdLotus());
            incomeBusinessEntity.setCustomerName(itrDetailsDto.getCustomerName());
            incomeBusinessEntity.setPanNumber(itrDetailsDto.getCustomerPan());
            incomeBusinessEntity.setCustomerType(itrDetailsDto.getCustomerType());
            System.out.println("New Income Business Entity Created, to save ITR details. ");
           }

            //YEAR
            incomeBusinessEntity.setSelectedFirstYear(itrDetailsDto.getYear1());
            incomeBusinessEntity.setSelectedSecondYear(itrDetailsDto.getYear2());

            //NET INCOME
            incomeBusinessEntity.setNetIncomeFirstYear(BigDecimal.valueOf(itrDetailsDto.getTotalTaxableIncomeYear1()));
            incomeBusinessEntity.setNetIncomeSecondYear(BigDecimal.valueOf(itrDetailsDto.getTotalTaxableIncomeYear2()));

            //GROSS INCOME
            incomeBusinessEntity.setBusinessIncomeFirstYear(BigDecimal.valueOf(itrDetailsDto.getGrossTotalIncomeYear1()));
            incomeBusinessEntity.setBusinessIncomeSecondYear(BigDecimal.valueOf(itrDetailsDto.getGrossTotalIncomeYear2()));

            //ITR AVAILABLE FOR HOW MANY YEARS  // One Year,Two Year ,Not Available
            if(!itrDetailsDto.getYear1().isEmpty() && !itrDetailsDto.getYear2().isEmpty()){
                incomeBusinessEntity.setIncomeAvailableFor("Two Year");
            }else{
                if(!itrDetailsDto.getYear1().isEmpty() || !itrDetailsDto.getYear2().isEmpty()) {
                    incomeBusinessEntity.setIncomeAvailableFor("One Year");
                }else{
                    incomeBusinessEntity.setIncomeAvailableFor("Not Available");
                }
            }

            try {
                incomeBusinessMainRepo.save(incomeBusinessEntity);
                System.out.println("ITR DETAILS SAVED FOR BUSINESS  " + itrDetailsDto.getCustomerType() + " FOR reference-ID : " + itrDetailsDto.getReferenceIdLotus());
                return "ITR DETAILS SAVED FOR BUSINESS  "+itrDetailsDto.getCustomerType() +" FOR reference-ID : "+itrDetailsDto.getReferenceIdLotus();

            }catch (Exception e){
                System.err.println("ERROR WHILE SAVING ITR DETAILS IN BUSINESS MODEL FOR :"+ itrDetailsDto.getCustomerType() +
                        " FOR reference-ID : " + itrDetailsDto.getReferenceIdLotus() +"\n ERROR DETAILS : "+e.getMessage());

                throw new RuntimeException("ERROR WHILE SAVING ITR DETAILS IN BUSINESS MODEL FOR :"+ itrDetailsDto.getCustomerType() +
                        " FOR reference-ID : " + itrDetailsDto.getReferenceIdLotus() +"\n ERROR DETAILS : "+e.getMessage());
            }
    }


}
