package com.lotusCarVersion2.LotusCarVersion2.Controller.ApplicantCoappGuarantors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lotusCarVersion2.LotusCarVersion2.DTO.CoappGuaPresentStatusDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.IndividualBasicDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusService;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilDetailsPersonal.PersonalCibilFetchService;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationFlagsStatusService;
import com.lotusCarVersion2.LotusCarVersion2.Services.IndividualBasicDetails.HistoryIndividualBasicDetailsService;
import com.lotusCarVersion2.LotusCarVersion2.Services.IndividualBasicDetails.IndividualBasicDetailsServiceImpl;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.apache.coyote.BadRequestException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin("*")
@AllArgsConstructor
@RequestMapping("/api/v1/individual")
public class IndividualBasicDetailsController {

    private final IndividualBasicDetailsServiceImpl individualBasicDetailsService;
    private final PersonalCibilFetchService personalCibilFetchService ;
    private final HistoryIndividualBasicDetailsService historyindividualBasicDetailsService ;
    private final DeviationFlagsStatusService deviationFlagsStatusService ;
    private final CibilCrifFetchStatusService cibilFetchStatusService ;

//*************************************************************************************************************************************//
// to perform upsert(update or insert ) operation for APPLICANT/COAPP/GUARANTOR
@PostMapping("/save-or-update")
@Transactional
public ResponseEntity<String> saveOrUpdateIndividualGuarantor(@Valid @RequestBody IndividualBasicDetailsDto saveUpdateDto) throws Exception {
    System.out.println("saveUpdateDto ID: " + saveUpdateDto.getId());
    System.out.println("saveUpdateDto : " + saveUpdateDto);


    IndividualBasicDetailsDto alreadySavedDto = new IndividualBasicDetailsDto();

//    if(saveUpdateDto.getCustomerType().equalsIgnoreCase("GUARANTOR") || saveUpdateDto.getCustomerType().equalsIgnoreCase("COAPPLICANT") ){
//        System.out.println("saveUpdateDto.getCustomerType() : "+saveUpdateDto.getCustomerType());
 //        alreadySavedDto=individualBasicDetailsService.retreiveDetailsOfGuarantors(saveUpdateDto.getReferenceId(),saveUpdateDto.getCustomerType(), saveUpdateDto.getPan());
//    }else {
//         alreadySavedDto=individualBasicDetailsService.retreiveDetailsOfIndividuals(saveUpdateDto.getReferenceId(),saveUpdateDto.getCustomerType());
//    }
    System.out.println("alreadySavedDto: "+alreadySavedDto);

    //update existing individual
    if (saveUpdateDto.getId() != null && saveUpdateDto.getId() != 0 && alreadySavedDto !=null) {
        System.out.println(" Id of APPLICANT/COAPP/GUARANTOR to update: " + saveUpdateDto.getIdDto());
        IndividualBasicDetailsDto updateDetailsDto = individualBasicDetailsService.updateIndividualsDetails(saveUpdateDto);
        if(updateDetailsDto != null) {
//TEMPORARILY ADDED- START
           /*  //to fetch PERSONAL CIBIL
            System.out.println("APPLICANT/COAPP/GUARANTOR DATA SENT TO FETCH CIBIL... WAITING FOR RESULT ");
            try {
                String cibilFetchStatus = String.valueOf(personalCibilFetchService.fetchPersonalCibilSingleIndividual(updateDetailsDto));
                System.out.println("CibilFetchStatus : " + cibilFetchStatus);
            }catch (Exception e){
                e.printStackTrace();
                System.err.println("ERROR WHILE FETCHING CIBIL : "+e.getMessage());
                throw new RuntimeException("ERROR WHILE FETCHING CIBIL : "+e.getMessage());
            }
            System.out.println("AFTER FETCHING BORROWER/ GUARANTOR PERSONAL CIBIL..  ");*/
//TEMPORARILY ADDED -END*/

          /*  //to set CIBIL-Deviation
            try{
                String cibilDeviation= deviationFlagsStatusService.updateCibilDeviationCommon(saveUpdateDto.getReferenceId());
                System.out.println("Inside Save APPLICANT/COAPP/GUARANTOR : "+cibilDeviation);
            }catch (Exception er){
                er.printStackTrace();
                System.err.println("Inside Save APPLICANT/COAPP/GUARANTOR, CIBIL DEVIATION ERROR : "+er.getMessage());
                throw new RuntimeException("ERROR WHILE SETTING CIBIL DEVIATION : "+er.getMessage());
            }*/
            return new ResponseEntity<String>("APPLICANT/COAPP/GUARANTOR WITH REFERENCE_ID: " + updateDetailsDto.getReferenceId() + "  WITH ID: " + updateDetailsDto.getIdDto() + " UPDATED SUCCESSFULLY.", HttpStatus.OK);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update Borrower/Guarantor.");
        }
    } else {
        //insert new Individual
        IndividualBasicDetailsDto saveDetailsDto   = individualBasicDetailsService.saveIndividualsDetails(saveUpdateDto);

    if(saveDetailsDto != null) {
        //to fetch PERSONAL CIBIL
        System.out.println("APPLICANT/COAPP/GUARANTOR DATA SENT TO FETCH CIBIL... WAITING FOR RESULT ");
      /* PRIYA try {
        String cibilFetchStatus = String.valueOf(personalCibilFetchService.fetchPersonalCibilSingleIndividual(saveDetailsDto));
            System.out.println("CibilFetchStatus : " + cibilFetchStatus);
        }catch (Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE FETCHING CIBIL : "+e.getMessage());
            throw new RuntimeException("ERROR WHILE FETCHING CIBIL : "+e.getMessage());
        }*/

        //to set CIBIL-Deviation
       try{
           String cibilDeviation= deviationFlagsStatusService.updateCibilDeviationCommon(saveUpdateDto.getReferenceId());
            System.out.println("Inside Save APPLICANT/COAPP/GUARANTOR : "+cibilDeviation);
        }catch (Exception er){
            er.printStackTrace();
            System.err.println("Inside Save APPLICANT/COAPP/GUARANTOR, CIBIL DEVIATION ERROR : "+er.getMessage());
            throw new RuntimeException("ERROR WHILE SETTING CIBIL DEVIATION : "+er.getMessage());
        }

        System.out.println("AFTER FETCHING BORROWER/ GUARANTOR PERSONAL CIBIL..  ");
        return new ResponseEntity<String>("NEW BORROWER/ GUARANTOR ADDED FOR REFERENCE_ID: " + saveDetailsDto.getReferenceId() + " WITH ID: " + saveDetailsDto.getIdDto(), HttpStatus.CREATED);
    } else {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add Details of BORROWER/ GUARANTOR.");
    }
}
}

//*************************************************************************************************************************************//
//Api to get APPLICANT  from reference Id & Customer Type
@GetMapping("/retrieve/{referenceId}/{customerType}")
public ResponseEntity<IndividualBasicDetailsDto> getDetailsOfBorrowerOrGuarantorList(@PathVariable("referenceId") String referenceId,@PathVariable("customerType") String customerType) {
IndividualBasicDetailsDto retrievedDetailsDto = individualBasicDetailsService.retreiveDetailsOfIndividuals(referenceId, customerType);
System.out.println("retrievedDetailsDto present :"+retrievedDetailsDto);
if (retrievedDetailsDto != null) {
    return new ResponseEntity<>(retrievedDetailsDto, HttpStatus.OK);
} else {
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
}
}
//*************************************************************************************************************************************//
@DeleteMapping("/delete")
public ResponseEntity<String> deleteIndividualData( @RequestParam String referenceId,@RequestParam String customerType,
                                                @RequestParam String pan,
                                                @RequestParam String deletedBy) {
try {
    String result = historyindividualBasicDetailsService.deleteDetailsAndSaveToHistory(referenceId, customerType,pan, deletedBy);
    System.out.println(result);
    return ResponseEntity.ok("DETAILS OF "+customerType+" FOR REFERENCE-ID : "+referenceId+ " DELETED SUCCESSFULLY...!!!");
} catch (RuntimeException e) {
    return ResponseEntity.status(500).body("Error: " + e.getMessage());
} catch (Exception e) {
    throw new RuntimeException(e);
}
}
//*************************************************************************************************************************************//
//refetch single CIBIL
@PostMapping("/cibil-refetch")
public ResponseEntity<String> updateAndRefetchSingleCibil(@RequestBody IndividualBasicDetailsDto updateDto) throws IOException {
    //update existing details
    System.out.println(" Id of APPLICANT/COAPP/GUARANTOR to update: " + updateDto.getIdDto());
IndividualBasicDetailsDto updateDetailsDto = individualBasicDetailsService.updateIndividualsDetails(updateDto);
    if(updateDetailsDto != null) {
        //to fetch PERSONAL CIBIL
        System.out.println("APPLICANT/COAPP/GUARANTOR DATA SENT TO RE-FETCH CIBIL... WAITING FOR RESULT ");
       /*PRIYA try {
            String cibilFetchStatus = String.valueOf(personalCibilFetchService.fetchPersonalCibilSingleIndividual(updateDetailsDto));
            System.out.println("CibilFetchStatus : " + cibilFetchStatus);
        }catch (Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE RE-FETCHING CIBIL : "+e.getMessage());
            throw new RuntimeException("ERROR WHILE RE-FETCHING CIBIL : "+e.getMessage());
        }*/
        System.out.println("AFTER RE-FETCHING BORROWER/ GUARANTOR PERSONAL CIBIL..  ");
        return new ResponseEntity<String>("CIBIL REFETCHED AND APPLICANT/COAPP/GUARANTOR WITH REFERENCE_ID: " + updateDetailsDto.getReferenceId() + "  WITH ID: " + updateDetailsDto.getIdDto() + " UPDATED SUCCESSFULLY.", HttpStatus.OK);
    } else {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to Re-fetch CIBIL and Update Borrower/Guarantor.");
    }
}
//*************************************************************************************************************************************//
//refetch all CIBIL
@PostMapping("/cibil-refetch-all")
public ResponseEntity<String> updateAndRefetchAllCibil(@RequestBody String referenceId) throws IOException {

try {
    return personalCibilFetchService.refetchPersonalCibilOfAll(referenceId);
} catch (Exception e) {
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
}
}
//*************************************************************************************************************************************//
//*************************************************************************************************************************************//
//Api to get CO-APPLICANT from reference Id
@GetMapping("/get/all-coapplicant/{referenceId}")
public ResponseEntity<?> getAllCoapplicantList(@PathVariable String referenceId){
List<IndividualBasicDetailsDto> coapplicantList = individualBasicDetailsService.getAllCoapplicantList(referenceId);
if(coapplicantList != null && coapplicantList.size() > 0){

    return new ResponseEntity<>(coapplicantList, HttpStatus.OK );
}else {
    System.out.println("inside else of get all");
    String message = "Co-applicant not present for this Reference Id";
    return ResponseEntity.status(HttpStatus.NO_CONTENT).body(message);
}
}

//*************************************************************************************************************************************//
//Api to get CO-APPLICANT from reference Id
    @GetMapping("/get/coapplicant-data/{referenceId}/{aadhar}/{pan}")
    public ResponseEntity<?> getCoapplicantData(@PathVariable String referenceId,
                                                @PathVariable String aadhar,
                                                @PathVariable String pan){
        IndividualBasicDetailsDto coapplicantList = individualBasicDetailsService.getCoapplicantBasicData(referenceId,aadhar,pan);
        if(coapplicantList != null ){

            return new ResponseEntity<>(coapplicantList, HttpStatus.OK );
        }else {
            System.out.println("inside else of get all");
            String message = "Co-applicant not present for this Reference Id";
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(message);
        }
    }

//***************************************************************************************************************************
//Api to get GUARANTOR from reference Id
@GetMapping("/get/all-guarantor/{referenceId}")
    public ResponseEntity<?> getAllGuarantorList(@PathVariable String referenceId){
        List<IndividualBasicDetailsDto> guarantorList = individualBasicDetailsService.getAllGuarantorList(referenceId);
        if(guarantorList != null && guarantorList.size() > 0){

            return new ResponseEntity<>(guarantorList, HttpStatus.OK );
        }else {
            System.out.println("inside else of get all");
            String message = "Guarantors not present for this Reference Id";
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(message);
        }
    }


//*************************************************************************************************************************************//
//API to get allowed customer-type for income considered co-applicant
@GetMapping("/get-cust-type/{referenceId}/{consideringIncome}")
public String getNewCustomerTypeAllowed(@PathVariable("referenceId") String referenceId,@PathVariable("consideringIncome") String consideringIncome ) throws BadRequestException {
    String newCustType  = individualBasicDetailsService.getNewCustomerTypeAllowed(referenceId,consideringIncome);
    System.out.println("NewCustomerTypeAllowed :"+newCustType);
    return newCustType;
}
//**********************************************************************************************************************
//Api to get count of income considered to show hide block on UI
@GetMapping("/get-income-count/{referenceId}")
public Integer getIncomeConsideredCount(@PathVariable("referenceId") String referenceId )  {
    return individualBasicDetailsService.getIncomeConsideredCount(referenceId);
}
//**********************************************************************************************************************
//Api to get list of co-app considered in income
@GetMapping("/get/income-consider-or-not/{referenceId}")
public List<String> getCoapplicantIncomeConsiderOrNotList(@PathVariable String referenceId) throws JsonProcessingException {
    return individualBasicDetailsService.getCoapplicantIncomeConsiderOrNotList(referenceId);
}

//****************************************** API TO GET CO-APPLICANT AND GUARANTOR PRESENT OR NOT *******************************************************************************************//
@GetMapping("/get/coappGuarantorStatus/{referenceId}")
public ResponseEntity<CoappGuaPresentStatusDto> getCoapplicantGuaratorStatus(@PathVariable String referenceId){
    System.out.println("IN APPLICANT COAPPLICANT PRESENT STATUS CONTROLLER ");

    try {

        CoappGuaPresentStatusDto coapplicantGuarantorPresentStatus=individualBasicDetailsService.getApplicantCoapplicantStatus(referenceId);

        System.out.println("coapplicantGuarantorPresentStatus :"+coapplicantGuarantorPresentStatus);
        return new ResponseEntity<>(coapplicantGuarantorPresentStatus, HttpStatus.OK);

    }catch (Exception e) {
        throw new RuntimeException(e);
    }

}

}


