package com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain;


import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessDetail.IncomeBusinessDetailModel;
import jakarta.persistence.*;
//import jakarta.validation.constraints.NotEmpty;
//import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

//@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class IncomeBusinessMainModel {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long parent_id;

    private String referenceId;
    private String userId;
    private String branchCode;
    private String panNumber;  // New Addition
    private String customerType; // New Addition
    private String customerName; //New Addition
    private String incomeType; //New Addition
    private Integer businessStandingInYears; //New Addition
    private Integer businessStandingInMonths; //New Addition

    private String selectedFirstYear;
    private String selectedSecondYear; //Changed selectedSecondyear to selectedSecondYear

    private BigDecimal netIncomeFirstYear;
    private BigDecimal netIncomeSecondYear;

    private BigDecimal businessIncomeFirstYear;
    private BigDecimal businessIncomeSecondYear;

    private BigDecimal depreciationFirstYear;
    private BigDecimal depreciationSecondYear;

    private BigDecimal housePropertyIncomeFirstYear;
    private BigDecimal housePropertyIncomeSecondYear;

    private BigDecimal otherIncomeFirstYear;
    private BigDecimal otherIncomeSecondYear;


    private BigDecimal currentEmiDeduction;
    private BigDecimal incomeTaxDeduction;
    private BigDecimal otherDeduction;
    @NotNull(message = "Total Deduction Cannot Be Null")
    private BigDecimal totalCurrentDeduction;

    private String incomeAvailableFor; //New Addition

    private LocalDateTime createdDate;


    @NotEmpty(message = "Business Details Cannot be Empty")
    @OneToMany(mappedBy = "incomeBusinessMainModelMy",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<IncomeBusinessDetailModel> incomeBusinessDetailModel;

//    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JoinTable(
//            name = "one_side_many_side",
//            joinColumns = @JoinColumn(name = "parent_id"),
//            inverseJoinColumns = @JoinColumn(name = "id")
//    )
//    private List<IncomeBusinessDetailModel> incomeBusinessDetailModel;


    public Long getParent_id() {
        return parent_id;
    }

    public void setParent_id(Long parent_id) {
        this.parent_id = parent_id;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getPanNumber() {
        return panNumber;
    }

    public void setPanNumber(String panNumber) {
        this.panNumber = panNumber;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getIncomeType() {
        return incomeType;
    }

    public void setIncomeType(String incomeType) {
        this.incomeType = incomeType;
    }

    public Integer getBusinessStandingInYears() {
        return businessStandingInYears;
    }

    public void setBusinessStandingInYears(Integer businessStandingInYears) {
        this.businessStandingInYears = businessStandingInYears;
    }

    public Integer getBusinessStandingInMonths() {
        return businessStandingInMonths;
    }

    public void setBusinessStandingInMonths(Integer businessStandingInMonths) {
        this.businessStandingInMonths = businessStandingInMonths;
    }

    public String getSelectedFirstYear() {
        return selectedFirstYear;
    }

    public void setSelectedFirstYear(String selectedFirstYear) {
        this.selectedFirstYear = selectedFirstYear;
    }

    public String getSelectedSecondYear() {
        return selectedSecondYear;
    }

    public void setSelectedSecondYear(String selectedSecondYear) {
        this.selectedSecondYear = selectedSecondYear;
    }

    public BigDecimal getNetIncomeFirstYear() {
        return netIncomeFirstYear;
    }

    public void setNetIncomeFirstYear(BigDecimal netIncomeFirstYear) {
        this.netIncomeFirstYear = netIncomeFirstYear;
    }

    public BigDecimal getNetIncomeSecondYear() {
        return netIncomeSecondYear;
    }

    public void setNetIncomeSecondYear(BigDecimal netIncomeSecondYear) {
        this.netIncomeSecondYear = netIncomeSecondYear;
    }

    public BigDecimal getBusinessIncomeFirstYear() {
        return businessIncomeFirstYear;
    }

    public void setBusinessIncomeFirstYear(BigDecimal businessIncomeFirstYear) {
        this.businessIncomeFirstYear = businessIncomeFirstYear;
    }

    public BigDecimal getBusinessIncomeSecondYear() {
        return businessIncomeSecondYear;
    }

    public void setBusinessIncomeSecondYear(BigDecimal businessIncomeSecondYear) {
        this.businessIncomeSecondYear = businessIncomeSecondYear;
    }

    public BigDecimal getDepreciationFirstYear() {
        return depreciationFirstYear;
    }

    public void setDepreciationFirstYear(BigDecimal depreciationFirstYear) {
        this.depreciationFirstYear = depreciationFirstYear;
    }

    public BigDecimal getDepreciationSecondYear() {
        return depreciationSecondYear;
    }

    public void setDepreciationSecondYear(BigDecimal depreciationSecondYear) {
        this.depreciationSecondYear = depreciationSecondYear;
    }

    public BigDecimal getHousePropertyIncomeFirstYear() {
        return housePropertyIncomeFirstYear;
    }

    public void setHousePropertyIncomeFirstYear(BigDecimal housePropertyIncomeFirstYear) {
        this.housePropertyIncomeFirstYear = housePropertyIncomeFirstYear;
    }

    public BigDecimal getHousePropertyIncomeSecondYear() {
        return housePropertyIncomeSecondYear;
    }

    public void setHousePropertyIncomeSecondYear(BigDecimal housePropertyIncomeSecondYear) {
        this.housePropertyIncomeSecondYear = housePropertyIncomeSecondYear;
    }

    public BigDecimal getOtherIncomeFirstYear() {
        return otherIncomeFirstYear;
    }

    public void setOtherIncomeFirstYear(BigDecimal otherIncomeFirstYear) {
        this.otherIncomeFirstYear = otherIncomeFirstYear;
    }

    public BigDecimal getOtherIncomeSecondYear() {
        return otherIncomeSecondYear;
    }

    public void setOtherIncomeSecondYear(BigDecimal otherIncomeSecondYear) {
        this.otherIncomeSecondYear = otherIncomeSecondYear;
    }

    public BigDecimal getCurrentEmiDeduction() {
        return currentEmiDeduction;
    }

    public void setCurrentEmiDeduction(BigDecimal currentEmiDeduction) {
        this.currentEmiDeduction = currentEmiDeduction;
    }

    public BigDecimal getIncomeTaxDeduction() {
        return incomeTaxDeduction;
    }

    public void setIncomeTaxDeduction(BigDecimal incomeTaxDeduction) {
        this.incomeTaxDeduction = incomeTaxDeduction;
    }

    public BigDecimal getOtherDeduction() {
        return otherDeduction;
    }

    public void setOtherDeduction(BigDecimal otherDeduction) {
        this.otherDeduction = otherDeduction;
    }

    public @NotNull(message = "Total Deduction Cannot Be Null") BigDecimal getTotalCurrentDeduction() {
        return totalCurrentDeduction;
    }

    public void setTotalCurrentDeduction(@NotNull(message = "Total Deduction Cannot Be Null") BigDecimal totalCurrentDeduction) {
        this.totalCurrentDeduction = totalCurrentDeduction;
    }

    public String getIncomeAvailableFor() {
        return incomeAvailableFor;
    }

    public void setIncomeAvailableFor(String incomeAvailableFor) {
        this.incomeAvailableFor = incomeAvailableFor;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public @NotEmpty(message = "Business Details Cannot be Empty") List<IncomeBusinessDetailModel> getIncomeBusinessDetailModel() {
        return incomeBusinessDetailModel;
    }

    public void setIncomeBusinessDetailModel(@NotEmpty(message = "Business Details Cannot be Empty") List<IncomeBusinessDetailModel> incomeBusinessDetailModel) {
        this.incomeBusinessDetailModel = incomeBusinessDetailModel;
    }
}
