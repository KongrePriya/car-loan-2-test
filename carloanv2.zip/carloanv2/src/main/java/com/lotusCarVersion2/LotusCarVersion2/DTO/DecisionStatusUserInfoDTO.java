package com.lotusCarVersion2.LotusCarVersion2.DTO;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class DecisionStatusUserInfoDTO {

    @NotNull(message = "Reference Id cannot be null")
    private String referenceId;
    @NotNull(message = "User Id cannot be null")
    private String userId;
    @NotNull(message = "User Scale cannot be null")
    private String userScale;
    @NotNull(message = "User Type cannot be null")
    private String userType;
    @NotNull(message = "Loan Type cannot be null")
    private String userLocation;
    @NotNull(message = "User Region cannot be null")
    private String userRegion;
    @NotNull(message = "User Branch cannot be null")
    private String branchCode;
    @NotNull(message = "Loan Type cannot be null")
    private String loanType;
    @NotNull(message = "Loan Amount cannot be null")
    private BigDecimal loanAmount;

    private BigDecimal loanAmountTopUp;

}
