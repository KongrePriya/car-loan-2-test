package com.lotusCarVersion2.LotusCarVersion2.Repository.DeviationRepo;

import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.RawDataForDeviationCheckingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RawDataForDeviationCheckingRepo extends JpaRepository<RawDataForDeviationCheckingEntity, Long> {

    RawDataForDeviationCheckingEntity findByReferenceId(String referenceId);

}
