package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessMain;

import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface IncomeBusinessMainRepo extends JpaRepository<IncomeBusinessMainModel,Long> {

    boolean existsByReferenceIdAndPanNumber(String referenceId, String panNumber);
    IncomeBusinessMainModel findByReferenceIdAndPanNumber(String referenceId, String panNumber);

    @Query(value = "SELECT COUNT(*) FROM los_car_v2.income_business_main_model WHERE reference_id=:referenceId;",nativeQuery = true)
    Integer countIncomeBusiness (String referenceId);


    List<IncomeBusinessMainModel> findAllByReferenceId(String referenceId);
}
