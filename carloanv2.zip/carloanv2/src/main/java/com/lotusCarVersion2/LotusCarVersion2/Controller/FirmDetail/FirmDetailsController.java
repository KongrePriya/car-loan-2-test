package com.lotusCarVersion2.LotusCarVersion2.Controller.FirmDetail;

import com.lotusCarVersion2.LotusCarVersion2.DTO.FirmDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.FirmDetail.FirmDataSaveResponse;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilDetailsCommercial.FetchCommercialCibilService;
import com.lotusCarVersion2.LotusCarVersion2.Services.FirmDetail.FirmDetailsServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Objects;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/v1/api/firmdetails")
@AllArgsConstructor
public class FirmDetailsController {

    private final FirmDetailsServiceImpl firmDetailsService;
    private final FetchCommercialCibilService fetchCommercialCibilService;

//**************************** SAVE FIRM DETAILS AND PROCEED TO FETCH CIBIL COMMERCIAL ****************************************************//

    @PostMapping()
    public ResponseEntity<FirmDataSaveResponse> saveFirmDetails(@RequestBody FirmDetailsDto firmDetailsDto) throws IOException {
        //to fetch cibil
      /* PRIYA  try {
            System.out.println("INSIDE CIBIL FETCH try...");
            String cibilResponse = String.valueOf(fetchCommercialCibilService.fetchFirmCommercialCibil(firmDetailsDto));
            System.out.println("RESPONSE FROM FIRM CIBIL API:"+cibilResponse);
            if(cibilResponse.contains("FAILED")){
                throw new Exception("FIRM CIBIL: FAILED TO FETCH COMMERCIAL-CIBIL OF FIRM/BORROWER, FOR PAN :" + firmDetailsDto.getFirmPan());
            }
        } catch (Exception e) {
            System.err.println("FAILED TO FETCH COMMERCIAL-CIBIL(IN SERVICE saveFirmDetails) FOR PAN :" + firmDetailsDto.getFirmPan());
            throw new RuntimeException("FIRM CIBIL: FAILED TO FETCH COMMERCIAL-CIBIL OF FIRM/BORROWER, FOR PAN :" + firmDetailsDto.getFirmPan() +" ERROR DETAILS: "+e.getMessage());
        }*/
        try {
            String result = firmDetailsService.saveFirmDetails(firmDetailsDto);
            System.out.println(firmDetailsDto.getFirmReferenceId());
            if (Objects.equals(result, "Saved Success")) {
                return ResponseEntity.ok(FirmDataSaveResponse.builder()
                        .timestamp(LocalDateTime.now())
                        .message("FIRM CIBIL FETCHED AND DETAILS SAVED SUCCESSFULLY...!")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
            } else if (Objects.equals(result, "Update Successfully")) {
                return ResponseEntity.ok(FirmDataSaveResponse.builder()
                        .timestamp(LocalDateTime.now())
                        .message("Update Successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
            } else {
                return ResponseEntity.ok(FirmDataSaveResponse.builder()
                        .timestamp(LocalDateTime.now())
                        .message("Error Occur")
                        .status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .build());
            }
        } catch (IOException e) {
            throw new IOException(e);
        }
    }

//**************************** GET FIRM DETAILS ****************************************************//
        @GetMapping("/{referenceNumber}")
    public ResponseEntity<FirmDetailsDto> getFirmDetails(@PathVariable("referenceNumber") String referenceNumber){

        try{
            return ResponseEntity.ok(firmDetailsService.getFirmDetails(referenceNumber));
        }catch(Exception e){
            return  ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
    }
//**************************** UPDATE FIRM DETAILS (WITHOUT FETCHING CIBIL) ****************************************************//

    @PostMapping("/save-firm-without-cibil")
    public ResponseEntity<FirmDataSaveResponse> saveFirmDetailsWithoutCibil(@RequestBody FirmDetailsDto firmDetailsDto) throws IOException {

        try {
            String result = firmDetailsService.saveFirmDetails(firmDetailsDto);
            System.out.println(firmDetailsDto.getFirmReferenceId());
            if (Objects.equals(result, "Saved Success")) {
                return ResponseEntity.ok(FirmDataSaveResponse.builder()
                        .timestamp(LocalDateTime.now())
                        .message("Saved Successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
            } else if (Objects.equals(result, "Update Successfully")) {
                return ResponseEntity.ok(FirmDataSaveResponse.builder()
                        .timestamp(LocalDateTime.now())
                        .message("Update Successfully")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build());
            } else {
                return ResponseEntity.ok(FirmDataSaveResponse.builder()
                        .timestamp(LocalDateTime.now())
                        .message("Error Occur")
                        .status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .build());
            }
        } catch (IOException e) {
            throw new IOException(e);
        }
    }


}
