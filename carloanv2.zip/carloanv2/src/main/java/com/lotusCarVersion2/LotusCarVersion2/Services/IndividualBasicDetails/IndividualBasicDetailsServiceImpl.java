package com.lotusCarVersion2.LotusCarVersion2.Services.IndividualBasicDetails;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.DTO.CoappGuaPresentStatusDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.IndividualBasicDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.DecisionStatus.DecisionStatusModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksMandatoryEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.HistoryIndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsPersonal.CibilBasicAndSummaryDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsPersonal.CibilHistoryDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DecisionStatus.DecisionStatusRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DocumentUpload.DocumentsAndRemarksMandatoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusService;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationCheckingRequiredDataService;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationFlagsStatusService;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeMainList.IncomeMainListService;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.apache.coyote.BadRequestException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class IndividualBasicDetailsServiceImpl implements IndividualBasicDetailsService {

    private ModelMapper modelMapper;
    private final IndividualBasicDetailsRepo individualBasicDetailsRepo;
    private final CibilCrifFetchStatusService cibilFetchStatusService;
//    private final AppraisalNoteService appraisalNoteService;
    private final CibilBasicAndSummaryDetailsRepo cibilBasicAndSummaryDetailsRepo;
    private final CibilHistoryDetailsRepo cibilHistoryDetailsRepo;
    private final IncomeMainListService incomeMainListService;
    private final HistoryIndividualBasicDetailsService historyIndividualBasicDetailsService;
    private final DeviationCheckingRequiredDataService deviationCheckingRequiredDataService;
    private final DeviationFlagsStatusService deviationFlagsStatusService;
    private final DecisionStatusRepo decisionStatusRepo;

//************************************************************************************************//
@Override
@Transactional
public IndividualBasicDetailsDto saveIndividualsDetails(IndividualBasicDetailsDto saveDetailsDto) throws BadRequestException {
    System.out.println("APPLICANT/COAPP/GUARANTOR DETAILS : Inside SAVE Details method ");
    IndividualBasicDetailsEntity saveDetailsEntity = modelMapper.map(saveDetailsDto, IndividualBasicDetailsEntity.class);

    List<IndividualBasicDetailsEntity> entityAlreadyPresentList = individualBasicDetailsRepo.findAllByReferenceIdAndPan(saveDetailsDto.getReferenceId(), saveDetailsDto.getPan());
    System.out.println("entityAlreadyPresentList :"+entityAlreadyPresentList.size());

    if(entityAlreadyPresentList.size() !=0){
        //NOT ZERO MEANS DATA ALREADY PRESENT FOR THIS PAN IN REF-ID
        System.err.println("DATA WITH SAME PAN : "+saveDetailsDto.getPan()+" FOR REF-ID :"+saveDetailsDto.getReferenceId() +" IS ALREADY PRESENT, HENCE NOT ALLOWED TO ADD THE SAME DATA. KINDLY CHECK THE DATA.");
        throw new BadRequestException("DATA WITH SAME PAN : "+saveDetailsDto.getPan()+" FOR REF-ID :"+saveDetailsDto.getReferenceId() +" IS ALREADY PRESENT, HENCE NOT ALLOWED TO ADD THE SAME DATA. KINDLY CHECK THE DATA.");
    }

    try {
            IndividualBasicDetailsEntity entityAlreadyPresent = individualBasicDetailsRepo.findByReferenceIdAndPan(saveDetailsDto.getReferenceId(), saveDetailsDto.getPan());
            //checking if data already saved in table , if yes then replacing it and then saving
            System.err.println("entityAlreadyPresent: " + entityAlreadyPresent);
            if (entityAlreadyPresent != null) {
                System.out.println("entityAlreadyPresent :" + entityAlreadyPresent);
                IndividualBasicDetailsDto updateDto=updateIndividualsDetails(saveDetailsDto);
                saveDetailsEntity=modelMapper.map(updateDto, IndividualBasicDetailsEntity.class);
            } else {
                System.out.println("saving first time.");
                int ageInMonthsCalculated = CalculateAgeInMonthsFromDOB(saveDetailsDto.getDateOfBirth());
                String ageInYears = CalculateAgeInYearsFromDOB(saveDetailsDto.getDateOfBirth());
                saveDetailsEntity.setAgeInMonths(ageInMonthsCalculated);
                saveDetailsEntity.setAgeInYears(ageInYears);
                saveDetailsEntity.setTimestamp(LocalDateTime.now());
                if (saveDetailsDto.getConsideringIncome().isEmpty()) {
                    System.out.println("ConsideringIncome is null :");
                    saveDetailsEntity.setConsideringIncome("No");
                }
                if (saveDetailsDto.getCustomerType().equalsIgnoreCase("APPLICANT")) {
                    DecisionStatusModel decisionStatusModel = decisionStatusRepo.findByReferenceId(saveDetailsDto.getReferenceId());

                    if (decisionStatusModel != null) {
                        decisionStatusModel.setApplicantName(saveDetailsDto.getFullName());
                        decisionStatusModel.setApplicantPan(saveDetailsDto.getPan());
                        decisionStatusModel.setApplicantType("Applicant");
                        decisionStatusRepo.save(decisionStatusModel);
                    }
                }
                System.out.println("DATA SAVING FOR CUST-TYPE: " + saveDetailsDto.getCustomerType());
                saveDetailsEntity = individualBasicDetailsRepo.save(saveDetailsEntity);
            }

        try{
            //step-1 : to set fields in Raw data table of deviation
            deviationCheckingRequiredDataService.RetrieveAndSaveBasicDetailsOfAll(saveDetailsDto.getReferenceId());
            //step-2 : to update age deviation
            deviationFlagsStatusService.updateAgeDeviationCommon(saveDetailsDto);
        }catch (Exception e){
            System.err.println("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SETTING DEVIATION RAW DATA:"+e.getMessage());
            throw new RuntimeException("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SETTING DEVIATION RAW DATA:"+e.getMessage());
        }
    } catch (Exception e) {
    e.printStackTrace();
    System.err.println("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SAVING DATA..." + e.getMessage());
    throw new RuntimeException("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SAVING DATA..." + e.getMessage());
    }
  /*  //SETTING FIELDS IN APPRAISAL NOTE
    try{
        appraisalNoteService.updateAppraisalApplicant(saveDetailsDto.getReferenceId());
    }catch (Exception e){
        e.printStackTrace();
        System.err.println("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SAVING DATA IN APPRAISAL NOTE ..."+e.getMessage());
        throw new RuntimeException("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SAVING DATA IN APPRAISAL NOTE..."+e.getMessage());
    }*/
            return modelMapper.map(saveDetailsEntity, IndividualBasicDetailsDto.class);
    }

//********************************************************************************************************************//
@Override
public IndividualBasicDetailsDto updateIndividualsDetails(IndividualBasicDetailsDto updateDetailsDto) {
        System.out.println("APPLICANT/COAPP/GUARANTOR DETAILS :Inside UPDATE  Details method  ");
        IndividualBasicDetailsEntity updateDetailsEntity = modelMapper.map(updateDetailsDto, IndividualBasicDetailsEntity.class);
        updateDetailsEntity.setTimestamp(LocalDateTime.now());

        try {
            DecisionStatusModel decisionStatusModel=decisionStatusRepo.findByReferenceId(updateDetailsDto.getReferenceId());

            IndividualBasicDetailsEntity entityAlreadyPresent=individualBasicDetailsRepo.findByReferenceIdAndPan(updateDetailsDto.getReferenceId(),updateDetailsDto.getPan());

          //step-1: checking if data already saved in table , if yes then replacing it and then save
            if(entityAlreadyPresent !=null){
                entityAlreadyPresent= modelMapper.map(updateDetailsDto, IndividualBasicDetailsEntity.class);
            }
            if (updateDetailsEntity.getCustomerType().equalsIgnoreCase("APPLICANT")){
                if (decisionStatusModel != null) {
                    decisionStatusModel.setApplicantName(updateDetailsDto.getFullName());
                    decisionStatusModel.setApplicantPan(updateDetailsDto.getPan());
                    decisionStatusModel.setApplicantType("Applicant");
                    decisionStatusRepo.save(decisionStatusModel);
                }
            }
            updateDetailsEntity = individualBasicDetailsRepo.save(entityAlreadyPresent);

            //step-2 : If ITR Fetched field is changed then to delete the existing ITR details.
            if(updateDetailsDto.getItrFilledForAnyYear().equalsIgnoreCase("NO")){
                historyIndividualBasicDetailsService.deleteITRDetails(updateDetailsDto.getReferenceId(), updateDetailsDto.getCustomerType(), updateDetailsDto.getUserId());
            }

            //step-3: to update fields in Raw data table of deviation
            try{
                //step-1 : to set fields in Raw data table of deviation
                deviationCheckingRequiredDataService.RetrieveAndSaveBasicDetailsOfAll(updateDetailsDto.getReferenceId());
                //step-2 : to update age deviation
                deviationFlagsStatusService.updateAgeDeviationCommon(updateDetailsDto);
            }catch (Exception e){
                System.err.println("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SETTING DEVIATION RAW DATA:"+e.getMessage());
                throw new RuntimeException("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SETTING DEVIATION RAW DATA:"+e.getMessage());
            }

        }catch (Exception e){
            e.printStackTrace();
            System.err.println("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE UPDATING DATA..."+e.getMessage());
            throw new RuntimeException("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE UPDATING DATA..."+e.getMessage());
        }

      /*  //SETTING FIELDS IN APPRAISAL NOTE
        try{
            appraisalNoteService.updateAppraisalApplicant(updateDetailsDto.getReferenceId());
        }catch (Exception e){
            e.printStackTrace();
            System.err.println("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SAVING DATA IN APPRAISAL NOTE ..."+e.getMessage());
            throw new RuntimeException("APPLICANT/COAPP/GUARANTOR DETAILS : ERROR WHILE SAVING DATA IN APPRAISAL NOTE..."+e.getMessage());
        }*/
        String refId= updateDetailsEntity.getReferenceId();
        System.out.println("refId to update: "+refId);

        return modelMapper.map(updateDetailsEntity,IndividualBasicDetailsDto.class);
    }
//*******************************************************************************************************************************//
@Override
public IndividualBasicDetailsDto retreiveDetailsOfIndividuals(String referenceId, String customerType) {

        System.out.println("APPLICANT/COAPP/GUARANTOR DETAILS : Inside Retrieve Details method, Ref-ID: "+referenceId +" Customer-type: "+customerType);

        IndividualBasicDetailsEntity retrievedEntity = individualBasicDetailsRepo.findByReferenceIdAndCustomerType(referenceId, customerType);

        if(retrievedEntity !=null){
        return modelMapper.map(retrievedEntity, IndividualBasicDetailsDto.class);
        }else{
            return null;
        }
    }

//*******************************************************************************************************************************//
    @Override
    public IndividualBasicDetailsDto retreiveDetailsOfGuarantors(String referenceId, String customerType, String panNumber) {
        try{
            System.out.println("APPLICANT/COAPP/GUARANTOR DETAILS : Inside Retrieve Details method, Ref-ID: "+referenceId +" Customer-type: "+customerType);

            IndividualBasicDetailsEntity retrievedEntity = individualBasicDetailsRepo.findByReferenceIdAndCustomerTypeAndPan(referenceId, customerType,panNumber);

            if(retrievedEntity !=null){
                return modelMapper.map(retrievedEntity, IndividualBasicDetailsDto.class);
            }else{
                return null;
            }
        }catch(Exception e){
            throw new RuntimeException("Error While Getting Single Guarantor " + e);
        }
    }

//*******************************************************************************************************************************//
@Override
public int CalculateAgeInMonthsFromDOB(String dateOfBirth) {
        DateTimeFormatter f1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");  // "yyyy-MM-dd"

        DateTimeFormatter f2 = DateTimeFormatter.ofPattern("dd-MMM-yy", Locale.ENGLISH); // "dd-MMM-yy", "18-Apr-97"

        DateTimeFormatter f3 = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);

        LocalDate dob;

            try {
                dob = LocalDate.parse(dateOfBirth, f1);
             } catch (DateTimeParseException ex1) {
                try {
                    dob = LocalDate.parse(dateOfBirth, f2);
                } catch (DateTimeParseException ex2) {
                    try {
                        dob = LocalDate.parse(dateOfBirth, f3);
                    } catch (DateTimeParseException ex3) {
                        System.err.println("ERROR WHILE PARSING DATE-OF-BIRTH with both formats: " + ex2.getMessage());
                        throw new RuntimeException("ERROR WHILE PARSING DATE-OF-BIRTH. Input: " + dateOfBirth);
                    }
                }
          }
        LocalDate currentDate = LocalDate.now();
        Period period = Period.between(dob, currentDate);
        // age in months
        int ageInMonths = period.getYears() * 12 + period.getMonths();

        System.out.println("period.getYears() :" + period.getYears());
        System.out.println("For DOB :" + dateOfBirth + " Calculated AgeInMonths : " + ageInMonths);
        return ageInMonths;
    }

//*******************************************************************************************************************************//
@Override
public List<IndividualBasicDetailsDto> getAllCoapplicantList(String referenceId) {

    System.out.println("APPLICANT/COAPP/GUARANTOR DETAILS : Inside Retrieve Details method ");
    List<IndividualBasicDetailsEntity> coappList = individualBasicDetailsRepo.findAllCoappByReferenceId(referenceId);

    if(coappList !=null){


        List<IndividualBasicDetailsDto> coapplicantList=coappList.stream()
                .map(singleEntity -> modelMapper.map(singleEntity, IndividualBasicDetailsDto.class))
                .collect(Collectors.toList());

        return coapplicantList;

    }else{
        return null;
    }
}

//*******************************************************************************************************************************//
@Override
public IndividualBasicDetailsDto getCoapplicantBasicData(String referenceId, String aadhar,String pan) {

        System.out.println("COAPP DETAILS : Inside Retrieve Details method ");
        Optional<IndividualBasicDetailsEntity> retrievedEntity = individualBasicDetailsRepo.findByReferenceIdAndAadharAndPan(referenceId, aadhar,pan);

        System.out.println("***********");
        System.out.println(retrievedEntity);
        if(retrievedEntity !=null){
            return modelMapper.map(retrievedEntity, IndividualBasicDetailsDto.class);
        }else{
            return null;
        }
    }

//*******************************************************************************************************************************//
 @Override
 public List<IndividualBasicDetailsDto> getAllGuarantorList(String referenceId) {

        System.out.println("APPLICANT/COAPP/GUARANTOR DETAILS : Inside Retrieve Details method ");
        List<IndividualBasicDetailsEntity> guarantorList = individualBasicDetailsRepo.findAllGuarantorByReferenceId(referenceId);

        if(guarantorList !=null){


            List<IndividualBasicDetailsDto> allGuarantorList=guarantorList.stream()
                    .map(singleEntity -> modelMapper.map(singleEntity, IndividualBasicDetailsDto.class))
                    .collect(Collectors.toList());

            return allGuarantorList;

        }else{
            return null;
        }
    }
//*******************************************************************************************************************************//
@Override
public String getNewCustomerTypeAllowed(String referenceId, String consideringIncome) throws BadRequestException {

    System.out.println("INSIDE getNewCustomerTypeAllowed, referenceId: " + referenceId +
            " , consideringIncome: " + consideringIncome);

    String newCustomerType = "COAPPLICANT";  // default when income = No

    // If income is NOT being considered → always return "COAPPLICANT"
    if (!consideringIncome.equalsIgnoreCase("Yes")) {
        System.out.println("consideringIncome is NO → newCustomerType: COAPPLICANT");
        return newCustomerType;
    }

    // Income is YES → find how many already contributing
    Integer coapplicantIncomeConsiderCount =
            individualBasicDetailsRepo.countCoapplicantIncomeConsider(referenceId);

    List<String> earningCustTypeList =
            individualBasicDetailsRepo.listOfEarningCoappCustType(referenceId);

    System.out.println("incomeCount: " + coapplicantIncomeConsiderCount +
            ", earningList: " + earningCustTypeList);

    // No income-contributing coapplicants yet
    if (coapplicantIncomeConsiderCount == 0) {
        newCustomerType = "COAPPLICANT1";
    }

    // One coapplicant already contributing
    else if (coapplicantIncomeConsiderCount == 1) {

        if (earningCustTypeList.contains("COAPPLICANT1")) {
            newCustomerType = "COAPPLICANT2";
        } else {
            newCustomerType = "COAPPLICANT1";
        }
    }

    // Two already contributing → not allowed
    else if (coapplicantIncomeConsiderCount == 2) {
        System.err.println("Income Consideration Not Allowed For More than 2 Co-applicants");
        throw new BadRequestException("Income Consideration Not Allowed For More than 2 Co-applicants");
    }

    System.out.println("Returning newCustomerType : " + newCustomerType);
    return newCustomerType;
}

//*******************************************************************************************************************************//
@Override
public Integer getIncomeConsideredCount(String referenceId) {

    Integer coapplicantIncomeConsiderCount = individualBasicDetailsRepo.countCoapplicantIncomeConsider(referenceId);
    System.out.println("COAPPLICANT Income  Consider Count : "+coapplicantIncomeConsiderCount);
    return coapplicantIncomeConsiderCount;
}

//*******************************************************************************************************************************//
 public List<String> getCoapplicantIncomeConsiderOrNotList(String referenceId)   {
        System.out.println("IN getCoapplicantIncomeConsiderOrNot ******** SERVICE");

        // Fetch the list of coapplicants from the repository based on the referenceId
        List<IndividualBasicDetailsEntity> coapplicantIncomeConsiderCount = individualBasicDetailsRepo.getCoapplicantIncomeConsider(referenceId);
        System.out.println(coapplicantIncomeConsiderCount);

        // Transform the list of DTOs to a list of customerType values
        List<String> customerTypes = coapplicantIncomeConsiderCount.stream()
                .map(IndividualBasicDetailsEntity::getCustomerType)  // Assuming you have a getter for customerType
                .collect(Collectors.toList());

        // Return the list of customerType values
        return customerTypes;
    }

//*******************************************************************************************************************************//
    @Override
    public String deleteDetailsAndSaveToHistory(String referenceId, String customerType, String aadhar,String deletedBy) {
        System.out.println("aaa"+aadhar);
        System.out.println("INSIDE DELETE SERVICE");
        IndividualBasicDetailsEntity existingEntity = individualBasicDetailsRepo.findByReferenceIdAndCustomerTypeAndAadhar(referenceId, customerType,aadhar);

        System.out.println(existingEntity);
        if (existingEntity != null) {
            HistoryIndividualBasicDetailsEntity historyEntity = new HistoryIndividualBasicDetailsEntity();
            historyEntity.setDeletedBy(deletedBy);
            historyEntity.setDeletedAt(LocalDateTime.now());

            // Copy properties from entity to historyEntity
            try {
                modelMapper.map(existingEntity, historyEntity);
                System.out.println("historyEntity : "+historyEntity);
                System.out.println("DETAILS OF " + customerType + " EXISTING ENTITY MAPPED TO HISTORY-ENTITY.");


            } catch (Exception e) {
                System.err.println("ERROR WHILE MAPPING " + customerType + "  DETAILS TO HISTORY TABLE: " + e.getMessage());
                throw new RuntimeException("ERROR WHILE MAPPING  " + customerType + "  DETAILS TO HISTORY TABLE: " + e.getMessage());
            }


            String result= historyIndividualBasicDetailsService.saveToHistoryTable(historyEntity);
            System.out.println(existingEntity.getPan());
            System.out.println(cibilBasicAndSummaryDetailsRepo.getCountOfCibilForReferenceId(referenceId));

            // step-3 : deleting CIBIL entries for that PAN against ref-id
            try {

                // Update CIBIL status :- MUST CALL THIS AFTER DEVIATION SERVICES CALLED AS AFTER THIS THE CIBIL DETAILS WILL BE REMOVED
                int basicDetailsRowsAffected = cibilBasicAndSummaryDetailsRepo.updatePersonalCibilStatusOldWhenDeleted(existingEntity.getPan(), referenceId);
                System.out.println("basicDetailsRowsAffected "+basicDetailsRowsAffected);
                int historyRowsAffected = cibilHistoryDetailsRepo.updatePersonalCibilStatusOldWhenDeleted(existingEntity.getPan(), referenceId);
                System.out.println("historyRowsAffected "+historyRowsAffected);

                System.out.println("CIBIL: Existing entries for deleted "+existingEntity.getCustomerType()+" set to old. FOR PAN:  "+existingEntity.getPan()+ "And ReferenceID : "+referenceId +
                        " basicDetailsRowsAffected: " + basicDetailsRowsAffected + ", historyRowsAffected: " + historyRowsAffected);

            } catch (Exception e) {
                System.err.println("ERROR WHILE UPDATING CIBIL STATUS: FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
                        " Error details: "+e.getMessage());
                throw new RuntimeException("ERROR WHILE UPDATING CIBIL STATUS: FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
                        " Error details: "+e.getMessage());
            }
//
//
//            // step-4 : update CIBIL deviation when Individual Deleted
//            try{
//                //DEVIATIONS FOR CIBIL
//                deviationFlagsStatusService.updateCibilDeviationCommon(existingEntity.getReferenceId());
//
//                //CIBIL-FETCHED STATUS FLAGS : after deleting entries from cibil schema
////                cibilFetchStatusService.updateCibilFetchedBorrowerGuarantorFlag(exitingMappedDto);
//            }catch (Exception e){
//                System.err.println("ERROR WHILE UPDATING DEVIATION FOR CIBIL : FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
//                        " Error details: "+e.getMessage());
//                throw new RuntimeException("ERROR WHILE UPDATING DEVIATION FOR CIBIL : FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
//                        " Error details: "+e.getMessage());
//            }
//
//
//            // step-5 : delete Income details based on Customer Type from income tables
//            try{
//                incomeMainListService.redirectToDeleteIncomeData(referenceId,existingEntity.getPan(), existingEntity.getIncomeSourceType());
//            }catch(Exception e){
//                System.err.println("ERROR WHILE DELETING INCOME DATA FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
//                        " Error details: "+e.getMessage());
//                throw new RuntimeException("ERROR WHILE DELETING INCOME DATA FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
//                        " Error details: "+e.getMessage());
//            }
//
//            // step- 6: DELETE ITR DETAILS from ITR Schema
//            try {
//                historyIndividualBasicDetailsService.deleteITRDetails(referenceId,customerType, deletedBy);
//            } catch (Exception e) {
//                System.err.println("ERROR WHILE REMOVING ITR DETAILS REMOVED FROM REF-ID RESPONSE TABLE & ITR-DETAILS TABLE FOR reference-Id: "
//                        +referenceId +" AND Customer-type :"+customerType+ " Error details: "+e.getMessage());
//                throw new RuntimeException("ERROR WHILE REMOVING ITR DETAILS REMOVED FROM REF-ID RESPONSE TABLE & ITR-DETAILS TABLE FOR reference-Id: "
//                        +referenceId +" AND Customer-type :"+customerType+ " Error details: "+e.getMessage());
//            }

            String result1= historyIndividualBasicDetailsService.deleteFromBaseTable(existingEntity);
            System.out.println(result1);

            return "DETAILS OF " + customerType + " FOR REFERENCE-ID: " + referenceId + " DELETED SUCCESSFULLY...!!!";
        } else {
            throw new RuntimeException("DETAILS OF " + customerType + " FOR REFERENCE-ID: " + referenceId + " NOT FOUND OR ALREADY DELETED...!!!");
        }
    }
//*******************************************************************************************************************************//
public CoappGuaPresentStatusDto getApplicantCoapplicantStatus(@PathVariable String referenceId) {

        System.out.println("IN APPLICANT CO-APPLICANT GUARANTOR PRESENT STATUS SERVICE");
        List<IndividualBasicDetailsDto> coapplicantList = getAllCoapplicantList(referenceId);

        CoappGuaPresentStatusDto coapplicantGuarantorPresentStatus = new CoappGuaPresentStatusDto();
        System.out.println("CO-APPLICANT :"+coapplicantList);
        if((coapplicantList != null && coapplicantList.size() > 0)){
            coapplicantGuarantorPresentStatus.coapplicantPresent=true;
        }
        else {
            coapplicantGuarantorPresentStatus.coapplicantPresent=false ;
        }

        List<IndividualBasicDetailsDto> guarantorList = getAllGuarantorList(referenceId);
        System.out.println("guarantorList :"+guarantorList.size());
        if(guarantorList != null && guarantorList.size() > 0){
            coapplicantGuarantorPresentStatus.guarantorPresent=true;
        }
        else {
            coapplicantGuarantorPresentStatus.guarantorPresent=false;
        }
        return coapplicantGuarantorPresentStatus;
    }


//*******************************************************************************************************************************//
    private String CalculateAgeInYearsFromDOB(String dateOfBirth) {

        DateTimeFormatter f1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter f2 = DateTimeFormatter.ofPattern("dd-MMM-yy", Locale.ENGLISH);
        DateTimeFormatter f3 = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);

        LocalDate dob;
        try {
            dob = LocalDate.parse(dateOfBirth, f1);
        } catch (DateTimeParseException ex1) {
            try {
                dob = LocalDate.parse(dateOfBirth, f2);
            } catch (DateTimeParseException ex2) {
                try {
                    dob = LocalDate.parse(dateOfBirth, f3);
                } catch (DateTimeParseException ex3) {
                    System.err.println("ERROR WHILE PARSING DATE-OF-BIRTH in YEARS. All formats failed. Input: " + dateOfBirth);
                    throw new RuntimeException("ERROR WHILE PARSING DATE-OF-BIRTH in YEARS. Input: " + dateOfBirth);
                }
            }
        }

        LocalDate currentDate = LocalDate.now();
        if (dob.isAfter(currentDate)) {
            System.err.println("DOB is in the future: " + dateOfBirth);
            throw new RuntimeException("Date of Birth cannot be in the future: " + dateOfBirth);
        }

        Period period = Period.between(dob, currentDate);
        int years = period.getYears();
        int months = period.getMonths();
        String finalAge = years + " Years " + months + " Months";
        System.out.println("Age in Years : " + finalAge);
        return finalAge;
    }
//---------------------------------------------------------------------------------------------------------------//


}
