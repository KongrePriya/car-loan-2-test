package com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.DTO.DeviationDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.IndividualBasicDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.Calculation.CalculationDataEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsIndividual.ScreenCibilSummaryBasicDetails;
import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.DeviationFlagsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.DeviationStandardEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CalculationRepo.CalculationDataRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsPersonal.CibilBasicAndSummaryDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DeviationRepo.DeviationFlagsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DeviationRepo.DeviationStandardsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DeviationRepo.RawDataForDeviationCheckingRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.QuotationDetails.QuotationDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo.RefIdGenerationRepo;
import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class DeviationFlagsStatusServiceImpl implements DeviationFlagsStatusService {

    private final DeviationFlagsRepo deviationFlagsRepo;
    private final DeviationStandardsRepo deviationStandardsRepo;
    private final RawDataForDeviationCheckingRepo rawDataForDeviationCheckingRepo;
    private final CibilBasicAndSummaryDetailsRepo cibilBasicAndSummaryDetailsRepo;
    private final CalculationDataRepo calculationRepo;
    private final QuotationDetailsRepo quotationDetailsRepo;
    private final RefIdGenerationRepo refNoVarificationRepo;
    private final IndividualBasicDetailsRepo applicantCoappGuarantorRepo;
    private ModelMapper modelMapper;

//----------------------------------------------------------------------------------------------------------------------------------------//
// to check if entry is already present in Deviation  table against the reference id
@Override
public DeviationFlagsEntity checkOrCreateDeviationEntity(String referenceId) {
    // Check if data already present from referenceId
    DeviationFlagsEntity entityPresent = deviationFlagsRepo.findByReferenceId(referenceId);

    if (entityPresent == null) {
        DeviationFlagsEntity newDevEntity = new DeviationFlagsEntity();
        newDevEntity.setReferenceId(referenceId);

        ReferenceIdGenerationEntity refNoData = refNoVarificationRepo.findByReferenceId(referenceId);
        newDevEntity.setLoanType(refNoData.getLoanType());
        newDevEntity.setBranchCode(refNoData.getBrcode());

        newDevEntity =deviationFlagsRepo.save(newDevEntity);

        System.out.println("EXISTING Entity NOT PRESENT , NEW DeviationFlagsEntity CREATED ");
        return newDevEntity;
    } else {
        System.out.println("EXISTING ENTRY PRESENT DeviationFlagsEntity ");
        return entityPresent;
    }
}

//----------------------------------------------------------------------------------------------------------------------------------------//
@Override
public DeviationStandardEntity retrieveStandardDeviationEntity() {
    List<DeviationStandardEntity> allEntities = deviationStandardsRepo.findAll();

    if (allEntities.isEmpty()) {
        throw new EntityNotFoundException("DEVIATION STANDARD ENTITY NOT FOUND...!!!");
    }

    DeviationStandardEntity stdDeviation = allEntities.get(0);
//        System.out.println("DEVIATION STANDARD ENTITY: " + stdDeviation);
    return stdDeviation;
}

//----------------------------------------------------------------------------------------------------------------------------------------//
@Override
public DeviationDetailsDto getAllDeviationFlags(String referenceId) {

    try {
        allDeviationFunctionsCall(referenceId);
    }catch (Exception e){
        e.printStackTrace();
        System.err.println("ERROR WHILE CALLING ALL FUNCTIONS :"+e.getMessage());
        throw new RuntimeException("ERROR WHILE CALLING ALL FUNCTIONS :"+e.getMessage());
    }

    DeviationFlagsEntity deviationFlagsEntity=deviationFlagsRepo.findByReferenceId(referenceId);
    if(deviationFlagsEntity != null){
        System.out.println("DEVIATION FLAG ENTITY : "+deviationFlagsEntity);
        DeviationDetailsDto detailsDto=modelMapper.map(deviationFlagsEntity,DeviationDetailsDto.class);
        return detailsDto;
    }else{
     return null;
    }
}

//----------------------------------------------------------------------------------------------------------------------------------------//
//AGE DEVIATION common function for all
@Override
public String updateAgeDeviationCommon(IndividualBasicDetailsDto detailsBasicDto) {

    DeviationFlagsEntity deviationEntity = checkOrCreateDeviationEntity(detailsBasicDto.getReferenceId());
    DeviationStandardEntity stdDeviation = retrieveStandardDeviationEntity();
    IndividualBasicDetailsEntity individualEntity = modelMapper.map(detailsBasicDto,IndividualBasicDetailsEntity.class);
    System.out.println("//--------------------------------------- DEVIATION SERVICE: Age Deviation Common --------------------------------//");

    //====================================  // 1) AGE DEVIATION ====================================//
    if (individualEntity != null) {

        //SET VALUES TO "NO" INITIALLY (In Model), IF CONDITIONS MATCHED THEN IT WILL UPDATED ACCORDINGLY

        System.out.println("AGE DEVIATION : "+individualEntity.getCustomerType()+" INCOME IS CONSIDERED, HENCE CHECKING FOR DEVIATION");

        int individualAgeInMonths = individualEntity.getAgeInMonths();
        int maxAgeMonths = 0;

        // Setting maxAge based on income type
        if ((AllStaticFields.salaried).equalsIgnoreCase(individualEntity.getIncomeSourceType())) {
            maxAgeMonths = stdDeviation.getEntryAgeMaxSalariedMonths();
        } else if ((AllStaticFields.business).equalsIgnoreCase(individualEntity.getIncomeSourceType())) {
            maxAgeMonths = stdDeviation.getEntryAgeMaxBusinessMonths();
        } else if ((AllStaticFields.pensioner).equalsIgnoreCase(individualEntity.getIncomeSourceType())) {
            maxAgeMonths = stdDeviation.getEntryAgeMaxPensionerMonths();
        }else if ((AllStaticFields.other).equalsIgnoreCase(individualEntity.getIncomeSourceType())) {
            maxAgeMonths = stdDeviation.getEntryAgeMaxBusinessMonths();
        }

        System.out.println("INSIDE AGE DEVIATION :for the customer Income Source type - " +individualEntity.getIncomeSourceType()+ " max age : "+maxAgeMonths);

    // Check for age deviation: Age should be less than the minimum or greater than the max age for that type
       if(individualEntity.getConsideringIncome().equalsIgnoreCase("Yes")) {
          if (individualAgeInMonths < stdDeviation.getAgeMinMonths() || individualAgeInMonths > maxAgeMonths) {

              switch (individualEntity.getCustomerType().toUpperCase()) {
                  case  "APPLICANT":
                      deviationEntity.setApplicantAgeDeviation("YES");
                      deviationEntity.setApplicantName(detailsBasicDto.getFullName());
                      deviationEntity.setApplicantPan(detailsBasicDto.getPan());
                      break;
                  case "COAPPLICANT1":
                      deviationEntity.setCoapplicantOneAgeDeviation("YES");
                      break;
                  case "COAPPLICANT2":
                      deviationEntity.setCoapplicantTwoAgeDeviation("YES");
                      break;
                  default:
                      System.out.println("DEVIATION SERVICE :CUSTOMER TYPE OTHER THAN APPLICANT/CO-APPLICANT 1 & 2");
                      break;
              }
              System.out.println("DEVIATION SERVICE : " + individualEntity.getCustomerType().toUpperCase() + " HAS AGE DEVIATION.");
          }
      }else{
        //resetting DEVIATION IF INCOME CONSIDERED IS REVISED TO "NO" OR do not have deviation
            switch (individualEntity.getCustomerType().toUpperCase()) {
                case "APPLICANT":
                    deviationEntity.setApplicantAgeDeviation("NO");
                    break;
                case "COAPPLICANT1":
                    deviationEntity.setCoapplicantOneAgeDeviation("NO");
                    break;
                case "COAPPLICANT2":
                    deviationEntity.setCoapplicantTwoAgeDeviation("NO");
                    break;
                default:
                    System.out.println("DEVIATION SERVICE :CUSTOMER TYPE OTHER THAN APPLICANT/CO-APPLICANT 1, 2, 3");
                    break;
            }
            System.out.println("DEVIATION SERVICE : "+individualEntity.getCustomerType().toUpperCase()+" AGE DEVIATION RESET .");
        }
    }

    deviationEntity.setBranchCode(detailsBasicDto.getBranchCode());
    deviationFlagsRepo.save(deviationEntity);
    System.out.println("DEVIATION SERVICE STEP-1 : AGE DEVIATION FUNCTION EXECUTED.");
    System.out.println("//----------------------------------------------------------------------------------------------------------------------------------------//");

    //for combined Deviation
    combinedAgeServiceItrDeviation(deviationEntity.getReferenceId());

    return "AGE DEVIATION FUNCTION EXECUTED.";
}

//----------------------------------------------------------------------------------------------------------------------------------------//
//CIBIL DEVIATION FOR ALL
@Override
public String updateCibilDeviationCommon(String referenceId) {
    System.out.println("//----------------------------------- DEVIATION SERVICE: CIBIL Deviation Common ----------------------------------//");

    System.out.println("DEVIATION SERVICE: INSIDE updateCibilDeviationCommon");

    DeviationFlagsEntity deviationEntity = checkOrCreateDeviationEntity(referenceId);
    DeviationStandardEntity stdDeviation = retrieveStandardDeviationEntity();
    System.out.println("DEVIATION SERVICE updateCibilDeviationCommon, Reference ID: " + referenceId);

    List<ScreenCibilSummaryBasicDetails> cibilDetailsList = cibilBasicAndSummaryDetailsRepo.getAllCibilDetailsForDeviationByRefId(referenceId);

    // Initialize deviation flags
    String cibilScoreDeviation = "NO";
    String cibilOverdueDeviation = "NO";
    String cibilWrittenOffDeviation = "NO";
    String cibilSettledDeviation = "NO";

    if (!cibilDetailsList.isEmpty()) {
        // 1. Check CIBIL Score Deviation across all rows
        for (ScreenCibilSummaryBasicDetails cibilDetails : cibilDetailsList) {
                if ("YES".equals(cibilDetails.getScoreStatusSummary())){
                    cibilScoreDeviation = "YES";
                    break;
                }
            }

        // 2. Check Account Overdue Summary Deviation across all rows
        for (ScreenCibilSummaryBasicDetails cibilDetails : cibilDetailsList) {
            if (!cibilDetails.getScoreStatusSummary().equals(cibilDetails.getAccountOverdueSummary())) {
                cibilOverdueDeviation = "YES";
                break;
            }
        }

        // 3. Check Account Written Off Summary Deviation across all rows
        for (ScreenCibilSummaryBasicDetails cibilDetails : cibilDetailsList) {
            if (!cibilDetails.getAccountWrittenOffSummary().equals(stdDeviation.getCibilWrittenOff())) {
                cibilWrittenOffDeviation = "YES";
                break;
            }
        }

        // 4. Check Account Settled Summary Deviation across all rows
        for (ScreenCibilSummaryBasicDetails cibilDetails : cibilDetailsList) {
            if (!cibilDetails.getAccountSettledSummary().equals(stdDeviation.getCibilSettled())) {
                cibilSettledDeviation = "YES";
                break;
            }
        }
    } else {
        System.out.println("IN DEVIATION SERVICE: CIBIL DETAILS ALREADY MARKED AS OLD, RESENDING DEVIATION FLAGS");
    }

    // Set the deviation flags on the entity :if list is null then default values
    deviationEntity.setCibilScoreDeviation(cibilScoreDeviation);
    deviationEntity.setCibilOverdueDeviation(cibilOverdueDeviation);
    deviationEntity.setCibilWrittenOffDeviation(cibilWrittenOffDeviation);
    deviationEntity.setCibilSettledDeviation(cibilSettledDeviation);

    // Set overall deviation flag
    if ("YES".equals(cibilScoreDeviation) || "YES".equals(cibilOverdueDeviation) ||
            "YES".equals(cibilWrittenOffDeviation) || "YES".equals(cibilSettledDeviation)) {
        deviationEntity.setCibilDeviation("YES");
        System.out.println("DEVIATION SERVICE:  CIBIL HAS DEVIATION.");
    } else {
        deviationEntity.setCibilDeviation("NO");
    }

    deviationFlagsRepo.save(deviationEntity);
    System.out.println("DEVIATION SERVICE STEP-2 : CIBIL DEVIATION FUNCTION EXECUTED FOR referenceId: "+referenceId);
    System.out.println("//----------------------------------------------------------------------------------------------------------------------------------------//");

    return "CIBIL DEVIATION FUNCTION EXECUTED FOR referenceId: "+referenceId;
}
//----------------------------------------------------------------------------------------------------------------------------------------//

@Override
public String updateSalariedServiceIncomeDeviation(IncomeSalaryModel incomeSalaryModel) {

    DeviationFlagsEntity deviationEntity = checkOrCreateDeviationEntity(incomeSalaryModel.getReferenceId());

    DeviationStandardEntity stdDeviation = retrieveStandardDeviationEntity();
    System.out.println("//---------------------------------------------- Salaried Individual- Experience Deviation -----------------------------------------//");

    //=========================== SALARIED WORK EXPERIENCE DEVIATION ================================//
    String isDeviationPresent="NO";
    System.out.println("SALARIED DEVIATION FUNCTION, CUSTOMER-TYPE : "+incomeSalaryModel.getCustomerType());


    /* Note :current exp, should be 1 year AND total of 1 year
    ex: (11 == 12 || 12 == 12) ==>  deviation as condition 1 fails i.e individual do not have 1 years of experience in current organisation */
    if(incomeSalaryModel.getCurrentOrgExperienceMonths() == stdDeviation.getCurrentExperienceMinInMonths() ||
            incomeSalaryModel.getTotalWorkExperienceMonths() == stdDeviation.getTotalExperienceMinInMonths()) {

        isDeviationPresent="YES";
    }
    switch (incomeSalaryModel.getCustomerType()){
        case "APPLICANT":
            deviationEntity.setApplicantWorkExperienceDeviation(isDeviationPresent);
            break;
        case "COAPPLICANT1":
            deviationEntity.setCoapplicantOneWorkExperienceDeviation(isDeviationPresent);
            break;
        case "COAPPLICANT2":
            deviationEntity.setCoapplicantTwoWorkExperienceDeviation(isDeviationPresent);
            break;
        default:
            System.out.println("DEVIATION SERVICE :CUSTOMER TYPE OTHER THAN APPLICANT/CO-APPLICANT 1, 2, 3");
            break;
    }
    deviationFlagsRepo.save(deviationEntity);
    System.out.println("DEVIATION SERVICE STEP-3a : DEVIATION METHOD EXECUTED FOR SALARIED "+incomeSalaryModel.getCustomerType());
    System.out.println("//----------------------------------------------------------------------------------------------------------------------------------------//");
    //for combined Deviation
    combinedAgeServiceItrDeviation(deviationEntity.getReferenceId());
    return "DEVIATION SERVICE : DEVIATION METHOD EXECUTED FOR SALARIED "+incomeSalaryModel.getCustomerType();
}

//----------------------------------------------------------------------------------------------------------------------------------------//

@Override
public String updateBusinessStandingIncomeDeviation(IncomeBusinessMainModel incomeBusinessModel) {

    DeviationFlagsEntity deviationEntity = checkOrCreateDeviationEntity(incomeBusinessModel.getReferenceId());

    DeviationStandardEntity stdDeviation = retrieveStandardDeviationEntity();
    System.out.println("//----------------------------- DEVIATION SERVICE: Business Standing Income Deviation ------------------------------------//");

    //=========================== BUSINESS WORK EXPERIENCE DEVIATION ================================//
    String isDeviationPresent="NO";
    System.out.println("BUSINESS DEVIATION FUNCTION, CUSTOMER-TYPE : "+incomeBusinessModel.getCustomerType());


    /* Note : Business should be standing/ incorporated for at least 2 years
     * ex: business standing since 20 months then it is less than 24 months (2 years) i.e. DEVIATION*/

    if(incomeBusinessModel.getBusinessStandingInMonths() < stdDeviation.getBusinessStandingExperienceMonths()) {

        isDeviationPresent="YES";
    }
    switch (incomeBusinessModel.getCustomerType()){
        case "APPLICANT":
            deviationEntity.setApplicantWorkExperienceDeviation(isDeviationPresent);
            break;
        case "COAPPLICANT1":
            deviationEntity.setCoapplicantOneWorkExperienceDeviation(isDeviationPresent);
            break;
        case "COAPPLICANT2":
            deviationEntity.setCoapplicantTwoWorkExperienceDeviation(isDeviationPresent);
            break;
        default:
            System.out.println("DEVIATION SERVICE :CUSTOMER TYPE OTHER THAN APPLICANT/CO-APPLICANT 1 & 2");
            break;
    }
    deviationFlagsRepo.save(deviationEntity);
    System.out.println("DEVIATION SERVICE STEP-3b : DEVIATION METHOD EXECUTED FOR BUSINESS "+incomeBusinessModel.getCustomerType());
    System.out.println("//----------------------------------------------------------------------------------------------------------------------------------------//");

    //for combined Deviation
    combinedAgeServiceItrDeviation(deviationEntity.getReferenceId());

    return "DEVIATION SERVICE : DEVIATION METHOD EXECUTED FOR BUSINESS "+incomeBusinessModel.getCustomerType();
}

//----------------------------------------------------------------------------------------------------------------------------------------//

@Override
public String combinedAgeServiceItrDeviation(String referenceId) {

    DeviationFlagsEntity deviationFlagsEntity=checkOrCreateDeviationEntity(referenceId);
    System.out.println("//---------------------------- DEVIATION SERVICE: Combined Age Service Deviation --------------------------------------------------//");

    String ageServiceItrDeviationCombined = (
            CheckIfYes(deviationFlagsEntity.getApplicantAgeDeviation()) ||
                    CheckIfYes(deviationFlagsEntity.getCoapplicantOneAgeDeviation()) ||
                    CheckIfYes(deviationFlagsEntity.getCoapplicantTwoAgeDeviation()) ||
                    CheckIfYes(deviationFlagsEntity.getApplicantWorkExperienceDeviation()) ||
                    CheckIfYes(deviationFlagsEntity.getCoapplicantOneWorkExperienceDeviation()) ||
                    CheckIfYes(deviationFlagsEntity.getCoapplicantTwoWorkExperienceDeviation()) ||
                    CheckIfYes(deviationFlagsEntity.getApplicantItrForm16Deviation()) ||
                    CheckIfYes(deviationFlagsEntity.getCoapplicantOneItrForm16Deviation()) ||
                    CheckIfYes(deviationFlagsEntity.getCoapplicantTwoItrForm16Deviation())
    ) ? "YES" : "NO";

    deviationFlagsEntity.setAgeServiceItrDeviationCombined(ageServiceItrDeviationCombined);
    deviationFlagsRepo.save(deviationFlagsEntity);

    System.out.println("DEVIATION SERVICE STEP- 9: combinedAgeServiceDeviation: ageServiceItrDeviationCombined is set as :"+ageServiceItrDeviationCombined);
    System.out.println("//----------------------------------------------------------------------------------------------------------------------------------------//");


    return  "DEVIATION SERVICE STEP -9: combinedAgeServiceDeviation: ageServiceItrDeviationCombined is set as :"+ageServiceItrDeviationCombined;
}

//METHOD TO CHECK EXISTING VALUE
private boolean CheckIfYes(String field) {
    return "YES".equalsIgnoreCase(field);
}
//----------------------------------------------------------------------------------------------------------------------------------------//
//PROCESSING FEES, DOCUMENTATION CHARGES & MAX LOAN TENURE
@Override
public String updateRoiProcessingDocumentationTenureDeviation(QuotationDetailsModel quotationDetailsModel) {

    DeviationFlagsEntity deviationEntity = checkOrCreateDeviationEntity(quotationDetailsModel.getReferenceId());

    DeviationStandardEntity stdDeviation = retrieveStandardDeviationEntity();
    System.out.println("//------------------------------- DEVIATION SERVICE: ROI, Processing-fees, Documentation,Allowed Tenure Deviation -----------------------//");

    System.out.println("INSIDE update RoiProcessingDocumentation Deviation, LoanFinancialMetricsModel: "+ quotationDetailsModel);

//=========================== 1) PROCESSING FEES DEVIATION ================================//
    System.out.println("//--------------------- 1) PROCESSING FEES DEVIATION -------------------------//");

    if(stdDeviation.getProcessingCharge().compareTo(quotationDetailsModel.getProcessingCharges()) != 0 ){
        // standard processing fees is not equals to entered value
        deviationEntity.setProcessingChargeDeviation("YES");
    }else{
        deviationEntity.setProcessingChargeDeviation("NO");
    }

//=========================== 2) DOCUMENTATION CHARGES DEVIATION ================================//
    System.out.println("//--------------------- 2) DOCUMENTATION CHARGES DEVIATION -------------------------//");

    System.out.println("Documentation Charge Deviation , input value :"+ quotationDetailsModel.getDocumentCharges());
    System.out.println("Applied loan Amount : "+ quotationDetailsModel.getLoanAppliedAmount());

    if (stdDeviation.getDocumentationCharge().compareTo(quotationDetailsModel.getDocumentCharges()) != 0) {
        // standard documentation charges is not equals to entered value
        deviationEntity.setDocumentationChargeDeviation("YES");
    } else {
        deviationEntity.setDocumentationChargeDeviation("NO");
    }


    deviationFlagsRepo.save(deviationEntity);
    System.out.println("DEVIATION SERVICE STEP -4 : PROCESSING FEES, DOCUMENTATION CHARGES, MAX LOAN TENURE  & ALLOWED LOAN AS PER LOCATION OF HOUSE DEVIATION FUNCTION EXECUTED");
    System.out.println("//----------------------------------------------------------------------------------------------------------------------------------------//");

    return "DEVIATION SERVICE : PROCESSING FEES, DOCUMENTATION CHARGES & MAX LOAN TENURE FUNCTION EXECUTED.";
}

//----------------------------------------------------------------------------------------------------------------------------------------//
//Repayment period eligibility and Deviation
@Override
public String updateRepaymentAgeDeviation(QuotationDetailsModel quotationDetailsModel) {

    List<IndividualBasicDetailsEntity> individualBasicDetailsEntityList =applicantCoappGuarantorRepo.getAllApplicantCoappConsiderIncome(quotationDetailsModel.getReferenceId());
    DeviationStandardEntity stdDeviation = retrieveStandardDeviationEntity();
    DeviationFlagsEntity deviationEntity = checkOrCreateDeviationEntity(quotationDetailsModel.getReferenceId());

    if(individualBasicDetailsEntityList.size()>0){

        Integer ageInMonthsMax =individualBasicDetailsEntityList.stream()
                .map( IndividualBasicDetailsEntity ::getAgeInMonths).filter(Objects::nonNull)
                .mapToInt(Integer :: intValue)
                .max().orElse(0);
        System.out.println("max ageInMonths for ref-id: "+quotationDetailsModel.getReferenceId()+", is : "+ageInMonthsMax);

        Integer maxAgePlusTenure=ageInMonthsMax + quotationDetailsModel.getLoanTenure();

        System.out.println("maxAgePlusTenure for ref-id: "+quotationDetailsModel.getReferenceId()+", is : "+maxAgePlusTenure);


        //Max Age Plus Tenure months should be less than or equal to allowed 840 months , if greater then Deviation
        if(maxAgePlusTenure.compareTo(stdDeviation.getRepaymentAgeMaxInMonths()) > 0){
            deviationEntity.setRepaymentAgeDeviation("YES");
        }else{
            deviationEntity.setRepaymentAgeDeviation("NO");
        }
    }else{
        System.out.println(" INSIDE RepaymentAgeDeviation , individualBasicDetailsEntityList IS NULL.");
    }

    return "Update Repayment Age Deviation SET";
}
//----------------------------------------------------------------------------------------------------------------------------------------//
@Override
public String relationWithApplicantDeviation(String referenceId) {

    List<IndividualBasicDetailsEntity> earningCoappList = applicantCoappGuarantorRepo.getAllApplicantCoappConsiderIncome(referenceId);

    DeviationFlagsEntity deviationFlags = checkOrCreateDeviationEntity(referenceId);

    System.out.println("//---------------------------- DEVIATION SERVICE: Relation With Applicant Deviation ------------------------------------------------------------//");

    String[] allowedRelationsWithApplicant = {"Spouse", "Father", "Mother", "Son", "Brother", "Sister", "Daughter", "Daughter in-law"};

    System.out.println(" earningCoappList  including Applicant : "+earningCoappList.size());

    if(earningCoappList != null || !earningCoappList.isEmpty()) {

        boolean isValidRelation = false;

        for (IndividualBasicDetailsEntity coapp : earningCoappList) {

            if (!coapp.getCustomerType().equalsIgnoreCase("APPLICANT")) {
                String relation = coapp.getRelationWithApplicant();

                for (String validRelation : allowedRelationsWithApplicant) {
                    if (relation.equalsIgnoreCase(validRelation)) {
                        isValidRelation = true;
                        System.out.println("validRelation :"+validRelation +" AND Relation Input :"+relation);
                        System.out.println(coapp.getCustomerType() + " DO HAVE VALID RELATION WITH APPLICANT, relation: " + relation);
                        break;  // Exit loop, if Invalid relation found , so that deviation can be marked
                    }
                }
                if(!isValidRelation){
                    System.err.println(coapp.getCustomerType() + " DO NOT HAVE VALID RELATION WITH APPLICANT, relation: " + relation);
                }
            }else{
                isValidRelation = true;
                System.out.println("NO NEED TO CHECK RELATION WITH APPLICANT DEVIATION FOR CUSTOMER-TYPE APPLICANT.");
            }
        }
        if (isValidRelation) {
            deviationFlags.setRelationWithApplicantDeviation("NO");
        }else{
            deviationFlags.setRelationWithApplicantDeviation("YES");
        }
        deviationFlagsRepo.save(deviationFlags);
    }
    System.out.println("//------------------------------------------------- Relation With Applicant Deviation Executed ---------------------------------------------------------------//");
    return "Relation with applicant for referenceId " + referenceId + " is invalid for " ;
}

//----------------------------------------------------------------------------------------------------------------------------------------//

@Override
public String updateLoanEligibilityDeviation(CalculationDataEntity calculationData) {

    DeviationFlagsEntity deviationEntity = checkOrCreateDeviationEntity(calculationData.getReferenceId());

    System.out.println("//------------------------------------------------ Loan Eligibility Deviation -------------------------------------------------------//");
    System.out.println("INSIDE loan eligibility deviation - as per margin, deduction , and LTV,    \n " +
            " calculationData : "+calculationData);

    deviationEntity.setLoanType(calculationData.getLoanType());
    try {
        //STEP-1 :APPLIED LOAN AMOUNT SHOULD BE less THAN or Equal to LOAN ELIGIBLE AS PER DEDUCTION: if greater,then deviation YES
        if (calculationData.getAppliedLoanWithoutKLI().compareTo(calculationData.getLoanEligibleAsPerDeductionFinal()) > 0) {
            deviationEntity.setLoanEligibleDeductionDeviation("YES");
            System.out.println(" DEVIATION OCCURRED FOR LOAN ELIGIBLE AS PER DEDUCTION.");
        } else {
            deviationEntity.setLoanEligibleDeductionDeviation("NO");
        }


        //STEP-2 :APPLIED LOAN AMOUNT SHOULD BE LESS THAN or Equal to LOAN ELIGIBLE AS PER MARGIN: if greater, then deviation YES
        //MARGIN AMOUNT IS 0 FOR OTHER LOAN-TYPES(TAKEOVER AND TOP-UPS)
        if (calculationData.getLoanEligibleAsPerMargin().compareTo(BigDecimal.ZERO) != 0) {
            if (calculationData.getAppliedLoanWithoutKLI().compareTo(calculationData.getLoanEligibleAsPerMargin()) > 0) {
                deviationEntity.setLoanEligibleMarginDeviation("YES");
                System.out.println(" DEVIATION OCCURRED FOR LOAN ELIGIBLE AS PER MARGIN.");
            } else {
                deviationEntity.setLoanEligibleMarginDeviation("NO");
            }
        }else {
            deviationEntity.setLoanEligibleMarginDeviation("NO");
        }

        deviationFlagsRepo.save(deviationEntity);
    } catch (Exception e){
        e.printStackTrace();
        System.err.println(" ERROR WHILE SETTING DEVIATION AS PER LOAN ELIGIBILITY AMOUNT."+e.getMessage());
        throw new RuntimeException(" ERROR WHILE SETTING DEVIATION AS PER LOAN ELIGIBILITY AMOUNT."+e.getMessage());
    }

    System.out.println(" DEVIATION SERVICE STEP -8: LOAN ELIGIBILITY DEVIATION SET.");
    System.out.println("//----------------------------------------------------------------------------------------------------------------------------------------//");

    return "DEVIATION SERVICE STEP -8: LOAN ELIGIBILITY DEVIATION SET.";
}

//----------------------------------------------------------------------------------------------------------------------------------------//

@Override
public String allDeviationFunctionsCall(String referenceId) {

    System.out.println("INSIDE METHOD TO CALL ALL FUNCTIONS.");
    QuotationDetailsModel quotationDetailsModel=quotationDetailsRepo.findByReferenceId(referenceId);
    CalculationDataEntity calculationData=calculationRepo.findByReferenceId(referenceId);

    //step-1 : ENTRY AGE DEVIATION : CALLED EVERYTIME WHILE SAVING INDIVIDUAL
    //  updateAgeDeviationCommon(ApplicantCoappGuarantorBasicDto detailsBasicDto);

    //step-2: CIBIL DEVIATION FOR ALL
    updateCibilDeviationCommon(referenceId);

    //step-3a: Income Deviation - SALARIED : CALLED EVERYTIME WHILE SAVING SALARIED INCOME
    // updateSalariedServiceIncomeDeviation(IncomeSalaryModel incomeSalaryModel);

    //step-3b: Income Deviation - BUSINESS : CALLED EVERYTIME WHILE SAVING BUSINESS INCOME
    // updateBusinessStandingIncomeDeviation(IncomeBusinessMainModel incomeBusinessModel);

    if(quotationDetailsModel != null) {
        //step-4: Processing Fees, Documentation, ROI DEVIATION,LOCATION
        updateRoiProcessingDocumentationTenureDeviation(quotationDetailsModel);

        //step-5 : loan eligibility deviation - as per margin, deduction
        //Calling this function after all the calculations.
        updateLoanEligibilityDeviation(calculationData);
    }
    //step-6 : COMBINED AGE & SERVICE & ITR DEVIATION FOR SEPARATE TABLE SHOW-HIDE
    combinedAgeServiceItrDeviation(referenceId);

    //step-7 : relation With applicant deviation for contributing members
    relationWithApplicantDeviation(referenceId);

    System.out.println("//--------------------------------------- ALL DEVIATION FUNCTIONS CALLED FOR REF-ID: "+referenceId+" -----------------------------------------------------//");
    return "ALL DEVIATION FUNCTIONS CALLED FOR REF-ID: "+referenceId;
}

//*************************************************************************************************************//
}
