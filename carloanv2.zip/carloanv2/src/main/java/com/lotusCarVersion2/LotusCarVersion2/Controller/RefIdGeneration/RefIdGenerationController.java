package com.lotusCarVersion2.LotusCarVersion2.Controller.RefIdGeneration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;
import com.lotusCarVersion2.LotusCarVersion2.Services.RefIdGenerationService.RefIdGenerationService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@AllArgsConstructor
@RequestMapping("/api/v1/ref-id")
public class RefIdGenerationController {

    private final RefIdGenerationService refIdGenerationService;


//------------------------------------------------- API TO CHECK AND GENERATE NEW API ------------------------------------------------//
    @PostMapping("/create")
    public ResponseEntity<ReferenceIdGenerationEntity> checkAnd(@RequestBody ReferenceIdGenerationEntity referenceIdEntity)  throws JsonProcessingException {

        System.out.println("IN REFERENCE ID CREATION METHOD, RECEIVED ENTITY: " + referenceIdEntity);

        try {
            ReferenceIdGenerationEntity generatedEntity = refIdGenerationService.checkAndGenerateReferenceIdByPan(referenceIdEntity);
            System.out.println("NEW/EXISTING REFERENCE ID ENTITY WITH REFERENCE ID :" +generatedEntity);
             return ResponseEntity.ok(generatedEntity);
        }catch (Exception e) {
            System.err.println("ERROR IN REFERENCE ID GENERATION, DETAILS: " +e.getMessage());
            throw new RuntimeException("ERROR IN REFERENCE ID GENERATION, DETAILS: " +e.getMessage());
        }
    }

//------------------------------------------------- API TO CHECK AND GENERATE NEW API ------------------------------------------------//

    @GetMapping("/search/{referenceId}")
    public ResponseEntity<ReferenceIdGenerationEntity> getReferenceIdDetails(@PathVariable String referenceId)  {
        System.out.println(" IN REFERENCE ID SEARCH ");
        ReferenceIdGenerationEntity refIdData = refIdGenerationService.getReferenceIdDetails(referenceId);
        System.out.println(" REFERENCE ID AVAILABLE DATA :"+ refIdData);
        if (refIdData ==null || refIdData.getReferenceId().isEmpty()) {
            System.out.println(" REFERENCE ID NOT GENERATED");
            return new ResponseEntity(" REFERENCE ID NOT GENERATED", HttpStatus.NO_CONTENT);
        } else {
            return ResponseEntity.ok(refIdData);
        }
    }
}
