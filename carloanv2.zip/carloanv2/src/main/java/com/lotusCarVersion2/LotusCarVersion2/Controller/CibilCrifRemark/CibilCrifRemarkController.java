package com.lotusCarVersion2.LotusCarVersion2.Controller.CibilCrifRemark;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.DTO.CibilAndCrifRemarkDto;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifRemarks.CibilCrifRemarkServiceImpl;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifRemarks.OverdueFileUploadDownloadService;
import lombok.AllArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin("*")
@AllArgsConstructor
@RequestMapping("/api/v1/remark")
public class CibilCrifRemarkController {

private final CibilCrifRemarkServiceImpl cibilCrifRemarkService;
private final OverdueFileUploadDownloadService overdueFileUploadDownloadService;

//----------------------------------------------------------------------------------------------------//
//Api to save personal-cibil remarks
@PostMapping("/personal-cibil-save")
public ResponseEntity<String> savePersonalCibilRemarks(@RequestBody CibilAndCrifRemarkDto cibilAndCrifRemarkDto) {

    String personalCibilSaveRemark = cibilCrifRemarkService.savePersonalCibilRemarks(cibilAndCrifRemarkDto);
    return new ResponseEntity<>(personalCibilSaveRemark, HttpStatus.OK);
}
//----------------------------------------------------------------------------------------------------//
//Api to save commercial-cibil remarks
@PostMapping("/commercial-cibil-save")
public ResponseEntity<String> saveCommercialCibilRemarks(@RequestBody CibilAndCrifRemarkDto cibilAndCrifRemarkDto) {

    String commercialCibilSaveRemark = cibilCrifRemarkService.saveCommercialCibilRemarks(cibilAndCrifRemarkDto);
    return new ResponseEntity<>(commercialCibilSaveRemark, HttpStatus.OK);
}
//----------------------------------------------------------------------------------------------------//
//Api to save personal-crif remarks
@PostMapping("/personal-crif-save")
public ResponseEntity<String> savePersonalCrifRemarks(@RequestBody CibilAndCrifRemarkDto cibilAndCrifRemarkDto) {

    String personalCrifSaveRemark = cibilCrifRemarkService.savePersonalCrifRemarks(cibilAndCrifRemarkDto);
    return new ResponseEntity<>(personalCrifSaveRemark, HttpStatus.OK);
}
//----------------------------------------------------------------------------------------------------//
//Api to save commercial-crif remarks
@PostMapping("/commercial-crif-save")
public ResponseEntity<String> saveCommercialCrifRemarks(@RequestBody CibilAndCrifRemarkDto cibilAndCrifRemarkDto) {

    String commercialCrifSaveRemark = cibilCrifRemarkService.saveCommercialCrifRemarks(cibilAndCrifRemarkDto);
    return new ResponseEntity<>(commercialCrifSaveRemark, HttpStatus.OK);
}

//----------------------------------------------------------------------------------------------------//
//Api to save commercial-cibil remarks
@GetMapping("/get-all/{referenceId}")
public ResponseEntity<CibilAndCrifRemarkDto> getAllCibilCrifRemarks(@PathVariable String referenceId) {

    CibilAndCrifRemarkDto allRemarks = cibilCrifRemarkService.getAllCibiCrifRemarks(referenceId);
    return new ResponseEntity<>(allRemarks, HttpStatus.OK);
}
//----------------------------------------------------------------------------------------------------//
//Api to update reject Status
@PostMapping("/reject")
public ResponseEntity<String> rejectDueToCibilCrif(@RequestBody CibilAndCrifRemarkDto cibilAndCrifRemarkDto) {

    String rejectRemarksStatus = cibilCrifRemarkService.rejectDueToCibilCrif(cibilAndCrifRemarkDto);
    return new ResponseEntity<>(rejectRemarksStatus, HttpStatus.OK);
}
//----------------------------------------------------------------------------------------------------//
//********************************************** OVERDUE CLEARANCE CERTIFICATE ****************************************//

@PostMapping("/upload/{referenceId}/{userId}")
public ResponseEntity<String> uploadFiles(
         @PathVariable("referenceId") String referenceId, @PathVariable("userId") String userId,
        @RequestParam(value = "overdueClearanceFile", required = false) MultipartFile overdueClearanceFile) {

        Map<String, String> filePaths = new HashMap<>();
         String overdueClearanceFileName = null;
        try {
            // Create the directory if it doesn't exist
            Path path = Paths.get(AllStaticFields.FILE_UPLOAD_DIR);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
            // Save appraisal note file if it is present
            if (overdueClearanceFile != null) {
                overdueClearanceFileName = overdueFileUploadDownloadService.saveFileToDirectory(overdueClearanceFile, referenceId);
                System.out.println("UPLOADED FILE NAME : "+overdueClearanceFileName);
            }
            // Update the metadata in the database with the final file names
            overdueFileUploadDownloadService.saveFileNamesInTable(referenceId, userId, overdueClearanceFileName);

            System.out.println("OVERDUE CLEARANCE FILE UPLOADED SUCCESSFULLY ...!!!");
            return new ResponseEntity<>("FILE UPLOADED SUCCESSFULLY ...!!!", HttpStatus.OK);

        } catch (IOException e) {
            System.err.println("Error uploading Overdue Clearance file: " + e.getMessage());
            throw new RuntimeException("Error uploading Overdue Clearance file: " + e.getMessage());
        }
    }

//*********************************************************************************************************//
//Preview File
    @GetMapping("/preview/{referenceId}")
    public ResponseEntity<Resource> previewFile(@PathVariable("referenceId") String referenceId) {
        return overdueFileUploadDownloadService.previewFile(referenceId);
    }

//*********************************************************************************************************//
// Download file
    @CrossOrigin(origins = "*", allowedHeaders = "*", exposedHeaders = "Content-Disposition")
    @GetMapping("/download/{referenceId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable("referenceId") String referenceId)  {
        return overdueFileUploadDownloadService.downloadFile(referenceId);
    }
//*********************************************************************************************************//
}