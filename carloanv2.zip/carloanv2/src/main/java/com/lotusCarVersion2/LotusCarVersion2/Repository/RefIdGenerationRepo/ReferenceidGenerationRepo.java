//package com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo;
//
//
//import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationModel;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface ReferenceidGenerationRepo extends JpaRepository<ReferenceIdGenerationModel,Long> {
//
//    boolean existsByAadharNumber(String aadharNumber);
//    ReferenceIdGenerationModel findByAadharNumber(String ReferenceId);
//    ReferenceIdGenerationModel findByReferenceId(String ReferenceId);
//
//
//}
