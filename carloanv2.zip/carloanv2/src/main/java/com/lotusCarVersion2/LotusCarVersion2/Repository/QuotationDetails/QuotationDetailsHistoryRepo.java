package com.lotusCarVersion2.LotusCarVersion2.Repository.QuotationDetails;

import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsHistoryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuotationDetailsHistoryRepo extends JpaRepository<QuotationDetailsHistoryModel, Long> {

    boolean existsByReferenceId(String referenceId);
    QuotationDetailsModel findByReferenceId(String referenceId);


}
