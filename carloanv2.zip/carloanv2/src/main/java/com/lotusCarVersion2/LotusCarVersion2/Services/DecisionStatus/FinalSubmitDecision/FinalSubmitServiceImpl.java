package com.lotusCarVersion2.LotusCarVersion2.Services.DecisionStatus.FinalSubmitDecision;

import com.lotusCarVersion2.LotusCarVersion2.DTO.DecisionStatusUserInfoDTO;
import com.lotusCarVersion2.LotusCarVersion2.Models.DecisionStatus.DecisionStatusModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.SanctionPowerModel.SanctionPowerModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DecisionStatus.DecisionStatusRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.SanctionPower.SanctionPowerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class FinalSubmitServiceImpl implements FinalSubmitService {

    @Autowired
    private DecisionStatusRepo decisionStatusRepo;
    @Autowired
    private SanctionPowerRepo sanctionPowerRepo;


    //    ---------------------------------------- Get Final Submit Status --------------------------------
    @Override
    public String getFinalSubmitStatusByBranch(String referenceId, String userLocation, String brcode) {

        DecisionStatusModel decisionStatusModel = decisionStatusRepo.findByReferenceId(referenceId);

        String isFinalSubmit = "";

        if(brcode.equalsIgnoreCase(decisionStatusModel.getBranchCode()) || userLocation.equalsIgnoreCase("RO") || userLocation.equalsIgnoreCase("HO")){
            if (decisionStatusModel.getApplnStatusMain() != null) {
                if (decisionStatusModel.getApplnStatusMain().equalsIgnoreCase("REJ") || decisionStatusModel.getApplnStatusMain().equalsIgnoreCase("SAN")) {
                    isFinalSubmit = "Application Is " + decisionStatusModel.getApplnStatusMain();
                    return isFinalSubmit;
                }
            }
            System.out.println("AFTER RETURN IN GET FINAL SUBMIT STATUS" );
            if (decisionStatusModel.getFinalSubmitByBranch() == null && userLocation.equalsIgnoreCase("BR")) {
                isFinalSubmit = "no";
            } else {
                isFinalSubmit = "yes";
            }
        }else {
            isFinalSubmit = "Branch Code Does Not Match";
        }


        return isFinalSubmit;
    }

    //------------------------------------- Update Final Submit Status ------------------------------------
    @Override
    public String postFinalSubmitByBranch(String referenceId, String userId) {
        try {
            DecisionStatusModel foundDecisionStatusModel = decisionStatusRepo.findByReferenceId(referenceId);
            if (foundDecisionStatusModel == null) {
                return "Decision Status Not Found";
            }
            foundDecisionStatusModel.setApplnStatusMain("PEN");
            foundDecisionStatusModel.setApplnStatusBranchManager("PEN");
            foundDecisionStatusModel.setApplnStatusBranchOfficer("PEN");
            foundDecisionStatusModel.setFinalSubmitBy(userId);
            foundDecisionStatusModel.setFinalSubmitDate(LocalDateTime.now());
            foundDecisionStatusModel.setFinalSubmitByBranch("yes");
            decisionStatusRepo.save(foundDecisionStatusModel);
        } catch (Exception e) {
            throw new RuntimeException("Error Occured In Setting Final Submit Status " + e);
        }

        return "Decision Status Upadated Successfully For Final Submit Status";
    }


    //------------------------- Can User See Sanction Or Reject Button ------------------------------------
    @Override
    public String canLoggedInUserSanction(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO) {
        String canUserSanctionFlag;
        String homeLoanTypeAsPerDatabase ="";
        List<SanctionPowerModel> getAllSanctionPowerFromMasterByLoanType = new ArrayList<>();

        DecisionStatusModel foundDecisionStatusModel = decisionStatusRepo.findByReferenceId(decisionStatusUserInfoDTO.getReferenceId());

        if(decisionStatusUserInfoDTO.getUserRegion().equalsIgnoreCase(foundDecisionStatusModel.getRoname()) || decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("HO") || decisionStatusUserInfoDTO.getBranchCode().equalsIgnoreCase(foundDecisionStatusModel.getBranchCode())){
            System.out.println("IN IF CAN LOGGED IN USER SANCTION" + decisionStatusUserInfoDTO.getLoanAmount());
            try {
                String homeLoanType = decisionStatusUserInfoDTO.getLoanType();
//        --------------------- List And Set For HOME_LOAN_GENERAL---------------
                List<String> generalHomeLoanType = Arrays.asList("Plot Purchase and Construction",
                        "Construction of New House", "Purchase of Under-Construction Flat/House",
                        "Purchase of Readymade House/Flat", "Additional Construction/Extension");
                Set<String> generalHome = new HashSet<>(generalHomeLoanType);

//        ---------------------- List And Set For HOME_LOAN_TAKEOVER---------------
                List<String> takeoverHomeLoanType = Arrays.asList("Takeover of Existing Housing");
                Set<String> takeoverHome = new HashSet<>(takeoverHomeLoanType);

//        ---------------------- List And Set For HOME_LOAN_REPAIR_(TopUp_ONLY)---------------
                List<String> repairHomeLoanType = Arrays.asList("Top-up Loan for Repair & Renovation to Standalone Borrower",
                        "Top-up Loan for Repair & Renovation to Existing Housing Loan Borrower");
                Set<String> topUpOnlyRepairHome = new HashSet<>(repairHomeLoanType);

//        ---------------------- List And Set For HOME_LOAN_TOPUP---------------
                List<String> topUpHomeLoanType = Arrays.asList("Top-up Loan for General Purpose to Existing Housing Loan Borrower");
                Set<String> topUpHome = new HashSet<>(topUpHomeLoanType);

//        ---------------------- List And Set For Higher Authority - Compare (HOME_LOAN_TAKEOVER and HOME_LOAN_REPAIR )---------------
                List<String> takeOverTopUpAndRepairHomeLoanType = Arrays.asList("Takeover Plus Top-up Loan for Repair & Renovation");
                Set<String> takeOverTopUpAndRepairHome = new HashSet<>(takeOverTopUpAndRepairHomeLoanType);

//        ---------------------- List And Set For Higher Authority - Compare (HOME_LOAN_TAKEOVER and HOME_LOAN_TOPUP )---------------
                List<String> takeOverTopUpAndGeneralHomeLoanType = Arrays.asList("Takeover Plus Top-up Loan for General Purpose");
                Set<String> takeOverTopUpAndGeneralHomeLoan = new HashSet<>(takeOverTopUpAndGeneralHomeLoanType);

//        -------NOTE :- ADD OTHER TYPE OF LOAN AS WELL LATER---------------

                System.out.println("LOAN AMOUNT " + decisionStatusUserInfoDTO.getLoanAmount());
                if (generalHome.contains(homeLoanType)) {
                    System.out.println("General Home Found" + homeLoanType + decisionStatusUserInfoDTO.getLoanAmount());
                    homeLoanTypeAsPerDatabase = "HOME_LOAN_GENERAL";
                    getAllSanctionPowerFromMasterByLoanType = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_GENERAL", decisionStatusUserInfoDTO.getLoanAmount());
                } else if (takeoverHome.contains(homeLoanType)) {
                    System.out.println("Takeover Home Found" + homeLoanType);
                    homeLoanTypeAsPerDatabase = "HOME_LOAN_TAKEOVER";
                    getAllSanctionPowerFromMasterByLoanType = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_TAKEOVER", decisionStatusUserInfoDTO.getLoanAmount());
                } else if(topUpOnlyRepairHome.contains(homeLoanType)){
                    homeLoanTypeAsPerDatabase = "HOME_LOAN_REPAIR";
                    getAllSanctionPowerFromMasterByLoanType = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_REPAIR", decisionStatusUserInfoDTO.getLoanAmountTopUp());
                } else if (topUpHome.contains(homeLoanType)) {
                    homeLoanTypeAsPerDatabase="HOME_LOAN_TOPUP";
                    getAllSanctionPowerFromMasterByLoanType = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_TOPUP", decisionStatusUserInfoDTO.getLoanAmountTopUp());
                } else if(takeOverTopUpAndRepairHome.contains(homeLoanType)){
                    homeLoanTypeAsPerDatabase="TAKEOVER_TOPUP_REPAIR";
                    getAllSanctionPowerFromMasterByLoanType=setSanctionForHigherAuthority(decisionStatusUserInfoDTO,"REPAIR");
                } else if (takeOverTopUpAndGeneralHomeLoan.contains(homeLoanType)) {
                    homeLoanTypeAsPerDatabase="TAKEOVER_TOPUP_GENERAL";
                    getAllSanctionPowerFromMasterByLoanType=setSanctionForHigherAuthority(decisionStatusUserInfoDTO,"TOPUP");

                } else {
                    System.out.println("Home Not Found: No Set Matched" + decisionStatusUserInfoDTO.getLoanType());
                }
                System.out.println( "Sanction User Array SIZE" + getAllSanctionPowerFromMasterByLoanType.size());

                canUserSanctionFlag = String.valueOf(getAllSanctionPowerFromMasterByLoanType.stream().anyMatch(loanAmountAndScale ->
                        loanAmountAndScale.getUserType().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserType()) &&
                                loanAmountAndScale.getScale().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserScale())));

                System.out.println("CAN USER SANCTION " + " " + canUserSanctionFlag);
            } catch (Exception e) {
                throw new RuntimeException("Error Occurred In Can User Sanction Service " + e);
            }
        }else {
            canUserSanctionFlag= "false";
        }

//        ------------------------------------------- GM And Chairman Sanction ------------------------------------------
        System.out.println("HOME LOAN AS PER DATA BASE FOR GM AND CHAIRMAN  : " +  homeLoanTypeAsPerDatabase);
        BigDecimal generalManagerSanctionAmount = BigDecimal.valueOf(0.0);
        BigDecimal chairmanSanctionAmount = BigDecimal.valueOf(0.0);
        BigDecimal generalMangerSanctionAmountTakeOverTopRepair = BigDecimal.valueOf(0.0);
        BigDecimal chairmanSanctionAmountTakeOverTopRepair = BigDecimal.valueOf(0.0);
//        BigDecimal generalMangerSanctionAmountTakeOverTopGeneral= BigDecimal.valueOf(0.0);
//        BigDecimal chairmanSanctionAmountTakeOverTopGeneral= BigDecimal.valueOf(0.0);


        if(decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CM") && canUserSanctionFlag.equals("false")){
            System.out.println("HERE NEW IF GM CHAIRMAN");
            System.out.println( "Sanction User Array SIZE GM CHAIRMAN" + getAllSanctionPowerFromMasterByLoanType);
            if(homeLoanTypeAsPerDatabase.equalsIgnoreCase("TAKEOVER_TOPUP_REPAIR")){
                generalManagerSanctionAmount = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman("HOME_LOAN_TAKEOVER","General Manager");
                generalMangerSanctionAmountTakeOverTopRepair = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman("HOME_LOAN_REPAIR","General Manager");
                chairmanSanctionAmount = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman("HOME_LOAN_TAKEOVER","Chairman");
                chairmanSanctionAmountTakeOverTopRepair = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman("HOME_LOAN_REPAIR","Chairman");
                if((decisionStatusUserInfoDTO.getLoanAmount().compareTo(generalManagerSanctionAmount) <= 0) && decisionStatusUserInfoDTO.getLoanAmountTopUp().compareTo(generalMangerSanctionAmountTakeOverTopRepair)<=0)  {
                    canUserSanctionFlag="General Manager";
                } else if ((decisionStatusUserInfoDTO.getLoanAmount().compareTo(chairmanSanctionAmount) <= 0) && decisionStatusUserInfoDTO.getLoanAmountTopUp().compareTo(chairmanSanctionAmountTakeOverTopRepair)<=0) {
                    canUserSanctionFlag="Chairman";
                }else {
                    canUserSanctionFlag="Sanction Power Not under CHAIRMAN. Loan Amount : ₹ " + decisionStatusUserInfoDTO.getLoanAmount();
                }

            } else if (homeLoanTypeAsPerDatabase.equalsIgnoreCase("TAKEOVER_TOPUP_GENERAL")) {
                generalManagerSanctionAmount = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman("HOME_LOAN_TAKEOVER","General Manager");
                chairmanSanctionAmount = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman("HOME_LOAN_TAKEOVER","Chairman");
                generalMangerSanctionAmountTakeOverTopRepair = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman("HOME_LOAN_TOPUP","General Manager");
                chairmanSanctionAmountTakeOverTopRepair = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman("HOME_LOAN_TOPUP","Chairman");

                if((decisionStatusUserInfoDTO.getLoanAmount().compareTo(generalManagerSanctionAmount) <= 0) && decisionStatusUserInfoDTO.getLoanAmountTopUp().compareTo(generalMangerSanctionAmountTakeOverTopRepair)<=0)  {
                    canUserSanctionFlag="General Manager";
                } else if ((decisionStatusUserInfoDTO.getLoanAmount().compareTo(chairmanSanctionAmount) <= 0) && decisionStatusUserInfoDTO.getLoanAmountTopUp().compareTo(chairmanSanctionAmountTakeOverTopRepair)<=0) {
                    canUserSanctionFlag="Chairman";
                }else {
                    canUserSanctionFlag="Sanction Power Not under CHAIRMAN. Loan Amount : ₹ " + decisionStatusUserInfoDTO.getLoanAmount();
                }

            }else {
                generalManagerSanctionAmount = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman(homeLoanTypeAsPerDatabase,"General Manager");
                chairmanSanctionAmount = sanctionPowerRepo.getSanctionPowerForGeneralManagerAndChariman(homeLoanTypeAsPerDatabase,"Chairman");
                if(decisionStatusUserInfoDTO.getLoanAmount().compareTo(generalManagerSanctionAmount) <= 0 ){
                    canUserSanctionFlag="General Manager";
                } else if (decisionStatusUserInfoDTO.getLoanAmount().compareTo(chairmanSanctionAmount) <= 0 ) {
                    canUserSanctionFlag="Chairman";
                }else {
                    canUserSanctionFlag="Sanction Power Not under CHAIRMAN. Loan Amount : ₹ " + decisionStatusUserInfoDTO.getLoanAmount();
                }
            }
        }
        System.out.println("Can User Sanction Final Flag " + canUserSanctionFlag);
        return canUserSanctionFlag;
    }

    @Override
    public String checkIsActionTakenByPreviousAuthority(DecisionStatusUserInfoDTO canLoggedUserSanctionDTO) {
        String isActionTakenByPreviousAuthority = "";
        DecisionStatusModel foundDecisionStatusModel = decisionStatusRepo.findByReferenceId(canLoggedUserSanctionDTO.getReferenceId());

        if((canLoggedUserSanctionDTO.getUserRegion().equalsIgnoreCase(foundDecisionStatusModel.getRoname())) || (canLoggedUserSanctionDTO.getBranchCode().equalsIgnoreCase(foundDecisionStatusModel.getBranchCode()) )  ||(canLoggedUserSanctionDTO.getUserLocation().equalsIgnoreCase("HO"))){
        try {
            DecisionStatusModel decisionStatusModel = decisionStatusRepo.findByReferenceId(canLoggedUserSanctionDTO.getReferenceId());

            if (canLoggedUserSanctionDTO.getUserType().equalsIgnoreCase("CPC_Officer")) {
                if (decisionStatusModel.getIsActionTakenByCPCOF() == null) {
                    isActionTakenByPreviousAuthority = decisionStatusModel.getIsActionTakenByBM();
                }
            } else if (canLoggedUserSanctionDTO.getUserType().equalsIgnoreCase("CPC_Head")) {
                if (decisionStatusModel.getIsActionTakenByCPCHEAD() == null) {
                    isActionTakenByPreviousAuthority = decisionStatusModel.getIsActionTakenByCPCOF();
                }
            } else if (canLoggedUserSanctionDTO.getUserType().equalsIgnoreCase("RM")) {
                if (decisionStatusModel.getIsActionTakenByRM() == null) {
                    isActionTakenByPreviousAuthority = decisionStatusModel.getIsActionTakenByCPCHEAD();
                }
            } else if (canLoggedUserSanctionDTO.getUserType().equalsIgnoreCase("HO_Credit_Officer")) {
                if (decisionStatusModel.getIsActionTakenByHOOF() == null) {
                    isActionTakenByPreviousAuthority = decisionStatusModel.getIsActionTakenByRM();
                }
            } else if (canLoggedUserSanctionDTO.getUserType().equalsIgnoreCase("CM")) {
                if (decisionStatusModel.getIsActionTakenByCM() == null) {
                    isActionTakenByPreviousAuthority = decisionStatusModel.getIsActionTakenByHOOF();
                }
            }else if (canLoggedUserSanctionDTO.getUserType().equalsIgnoreCase("General Manager")) {
                if (decisionStatusModel.getIsActionTakenByCM() == null) {
                    isActionTakenByPreviousAuthority = decisionStatusModel.getIsActionTakenByHOOF();
                }
            }else if (canLoggedUserSanctionDTO.getUserType().equalsIgnoreCase("Chairman")) {
                if (decisionStatusModel.getIsActionTakenByCM() == null) {
                    isActionTakenByPreviousAuthority = decisionStatusModel.getIsActionTakenByHOOF();
                }
            }
            else if (canLoggedUserSanctionDTO.getUserType().equalsIgnoreCase("BM")) {
                if (decisionStatusModel.getIsActionTakenByBM() != null) {
                    isActionTakenByPreviousAuthority = "no";
                } else {
                    isActionTakenByPreviousAuthority = "yes";
                }
            } else {
                isActionTakenByPreviousAuthority = "no";
            }
            if (Objects.equals(isActionTakenByPreviousAuthority, "") || isActionTakenByPreviousAuthority == null) {
                isActionTakenByPreviousAuthority = "no";
            }
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred While Checking Previous Authority Action Taken" + e);
        }
        }else{
            isActionTakenByPreviousAuthority = "no";
        }
        return isActionTakenByPreviousAuthority;
    }


    //------------------------- Sanction For GM & CHAIRMAN ------------------------------------
    @Override
    public String sanctionUnderGmOrChairman(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO) {
        String canUserSanctionFlag;
        try {
            String homeLoanType = decisionStatusUserInfoDTO.getLoanType();
//        ------- List And Set For HOME_LOAN_GENERAL---------------
            List<String> generalHomeLoanType = Arrays.asList("Plot Purchase and Construction", "Construction of New House/Purchase of Under Construction Flat", "Purchase of Readymade House/Flat(Resale Property)", "Purchase of Readymade House/Flat(New Property)", "Additional Construction/Extension");
            Set<String> generalHome = new HashSet<>(generalHomeLoanType);

//        ------- List And Set For HOME_LOAN_TAKEOVER---------------
            List<String> takeoverHomeLoanType = Arrays.asList("Takeover of Existing Housing");
            Set<String> takeoverHome = new HashSet<>(takeoverHomeLoanType);

//        -------NOTE :- ADD OTHER TYPE OF LOAN AS WELL LATER---------------
            List<SanctionPowerModel> getAllSanctionPowerFromMasterByLoanType = new ArrayList<>();
            if (generalHome.contains(homeLoanType)) {
                System.out.println("General Home Found" + homeLoanType);
                getAllSanctionPowerFromMasterByLoanType = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_GENERAL", decisionStatusUserInfoDTO.getLoanAmount());
            } else if (takeoverHome.contains(homeLoanType)) {
                System.out.println("Takeover Home Found" + homeLoanType);
                getAllSanctionPowerFromMasterByLoanType = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_TAKEOVER", decisionStatusUserInfoDTO.getLoanAmount());
            } else {
                System.out.println("Home Not Found: No Set Matched");
            }
            System.out.println(getAllSanctionPowerFromMasterByLoanType.size());

//            canUserSanctionFlag = getAllSanctionPowerFromMasterByLoanType.stream().anyMatch(loanAmountAndScale ->
//                    loanAmountAndScale.getUserType().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserType()) &&
//                            loanAmountAndScale.getScale().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserScale()));

//            System.out.println("CAN USER SANCTION " + " " + canUserSanctionFlag);
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred In Can User Sanction Service For GM & Chairman " + e);
        }

        return "GM AND CHAIRMAN SANCTION.THIS FUNCTION IS INCOMPLETE";
    }


    //------------------------- Check If Application is Rejected or Sanctioned To Hide All Buttons  ------------------------------------

    @Override
    public String checkRejectSanctionStatus(String referenceId) {
       DecisionStatusModel decisionStatusModel = decisionStatusRepo.findByReferenceId(referenceId);
       return decisionStatusModel.getApplnStatusMain();
    }

    @Override
    public String getFinalSubmitStatusForAppraisalEditButton(String referenceId) {
        String finalSubmitStatus="";
        DecisionStatusModel decisionStatusModel = decisionStatusRepo.findByReferenceId(referenceId);
        if(decisionStatusModel.getFinalSubmitByBranch()==null){
            finalSubmitStatus="no";
            return finalSubmitStatus;
        }else{
            if(decisionStatusModel.getFinalSubmitByBranch().equalsIgnoreCase("yes")||
                    decisionStatusModel.getApplnStatusMain().equalsIgnoreCase("REJ") ||
                    decisionStatusModel.getApplnStatusMain().equalsIgnoreCase("SAN") ||
                    decisionStatusModel.getApplnStatusMain().equalsIgnoreCase("REC")){
                finalSubmitStatus="yes";
            }
            else {
                finalSubmitStatus="no";
            }
        }

        return finalSubmitStatus;
    }


    public List<SanctionPowerModel> setSanctionForHigherAuthority(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO, String topUpType){
        List<SanctionPowerModel> sanctionListHigherAuthority =  new ArrayList<>();
        String canUserSanctionTakeOver = "";
        String canUserSanctionRepairOrTopup = "";
        List<SanctionPowerModel> getAllSanctionPowerFromMasterByLoanTypeTakeOver = new ArrayList<>();
        List<SanctionPowerModel> getAllSanctionPowerFromMasterByLoanTypeRepair = new ArrayList<>();

        getAllSanctionPowerFromMasterByLoanTypeTakeOver = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_TAKEOVER", decisionStatusUserInfoDTO.getLoanAmount());
//        System.out.println("TAKEOVER ARRAY SIZE " + getAllSanctionPowerFromMasterByLoanTypeTakeOver.size());

        canUserSanctionTakeOver = String.valueOf(getAllSanctionPowerFromMasterByLoanTypeTakeOver.stream().anyMatch(loanAmountAndScale ->
                loanAmountAndScale.getUserType().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserType()) &&
                        loanAmountAndScale.getScale().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserScale())));

        if(topUpType.equalsIgnoreCase("REPAIR")){
            getAllSanctionPowerFromMasterByLoanTypeRepair = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_REPAIR", decisionStatusUserInfoDTO.getLoanAmountTopUp());
            canUserSanctionRepairOrTopup = String.valueOf(getAllSanctionPowerFromMasterByLoanTypeRepair.stream().anyMatch(loanAmountAndScale ->
                    loanAmountAndScale.getUserType().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserType()) &&
                            loanAmountAndScale.getScale().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserScale())));
        }else if(topUpType.equalsIgnoreCase("TOPUP")){
            getAllSanctionPowerFromMasterByLoanTypeRepair = sanctionPowerRepo.getSanctionPowerForHomeLoanFromMaster("HOME_LOAN_TOPUP", decisionStatusUserInfoDTO.getLoanAmountTopUp());
            canUserSanctionRepairOrTopup = String.valueOf(getAllSanctionPowerFromMasterByLoanTypeRepair.stream().anyMatch(loanAmountAndScale ->
                    loanAmountAndScale.getUserType().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserType()) &&
                            loanAmountAndScale.getScale().equalsIgnoreCase(decisionStatusUserInfoDTO.getUserScale())));
        }


        System.out.println("HIGHER AUTHORITY FLAGS" +canUserSanctionTakeOver + " " + canUserSanctionRepairOrTopup);
        if(canUserSanctionTakeOver.equalsIgnoreCase("true") && canUserSanctionRepairOrTopup.equalsIgnoreCase("true")){

            SanctionPowerModel authority =new SanctionPowerModel();
            authority.setSrno(1);
            authority.setLoanType("HOME_LOAN_TAKEOVER"+"HOME_LOAN_REPAIR");
            authority.setUserType(decisionStatusUserInfoDTO.getUserType());
            authority.setScale(decisionStatusUserInfoDTO.getUserScale());
            authority.setSanctionPowerAmt(decisionStatusUserInfoDTO.getLoanAmount());
            authority.setUserId(decisionStatusUserInfoDTO.getUserId());
//          authority.setTimeStamp();
            authority.setStatus("ACTIVE");
            sanctionListHigherAuthority.add(authority);
        }
        System.out.println("HERE IS ARRAY FOR HIGHER AUTHORITY " + sanctionListHigherAuthority);
        return sanctionListHigherAuthority;
    }

}
