package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomePension;

import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomePension.IncomePensionHistoryModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncomePensionHistoryRepo extends JpaRepository<IncomePensionHistoryModel,Long> {
}
