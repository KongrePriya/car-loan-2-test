package com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeBusiness;



import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessDetail.IncomeBusinessDetailHistoryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessDetail.IncomeBusinessDetailModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainHistoryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessMain.IncomeBusinessMainHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessMain.IncomeBusinessMainRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationFlagsStatusService;
import jakarta.transaction.Transactional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class IncomeBusinessServiceImpl implements IncomeBusinessService{


    @Autowired
    private IncomeBusinessMainRepo incomeBusinessMainRepo;


    @Autowired
    private IncomeBusinessMainHistoryRepo incomeBusinessMainHistoryRepo;


    @Autowired
    private DeviationFlagsStatusService deviationFlagsStatusService;
//    @Autowired
//    private CalculationRawDataService calculationRawDataService;



    @Override
    @Transactional
    public String postIncomeBusiness(IncomeBusinessMainModel incomeBusinessMainModel) {

        if(incomeBusinessMainModel.getParent_id()!=null){
            incomeBusinessMainModel.setParent_id(null);
        }

        if(incomeBusinessMainRepo.existsByReferenceIdAndPanNumber(incomeBusinessMainModel.getReferenceId(),incomeBusinessMainModel.getPanNumber())){

                deleteIncomeBusinessAndSaveToHistory(incomeBusinessMainModel.getReferenceId(),incomeBusinessMainModel.getPanNumber());
        }


            Integer businessStandingInMonths = ((incomeBusinessMainModel.getBusinessStandingInYears())*12);
            incomeBusinessMainModel.setBusinessStandingInMonths(businessStandingInMonths);
            incomeBusinessMainModel.setCreatedDate(LocalDateTime.now());
            List<IncomeBusinessDetailModel> incomeBusinessDetailModels = incomeBusinessMainModel.getIncomeBusinessDetailModel();
            for(IncomeBusinessDetailModel incomeBusinessDetailModel :  incomeBusinessDetailModels){
                incomeBusinessDetailModel.setIncomeBusinessMainModelMy(incomeBusinessMainModel);
            }
            incomeBusinessMainModel.setIncomeBusinessDetailModel(incomeBusinessDetailModels);
            try{
                incomeBusinessMainRepo.save(incomeBusinessMainModel);
            }catch(Exception e){
                throw new RuntimeException("Error While Saving Income Business" + e);
            }

        //====================================== DEVIATION METHODS =====================================//
        //BUSINESS STANDING
        try{
            deviationFlagsStatusService.updateBusinessStandingIncomeDeviation(incomeBusinessMainModel);
        }catch(Exception e){
            System.err.println("ERROR WHILE SETTING DEVIATION FOR BUSINESS STANDING (MIN 2 YEARS) : " + e.getMessage());
            throw new RuntimeException("ERROR WHILE SETTING DEVIATION FOR BUSINESS STANDING (MIN 2 YEARS) : " + e.getMessage());
        }

        //====================================== INCOME DETAILS FOR CALCULATION =====================================//
        //05032025: directly called in calculation page
        try{
//            calculationRawDataService.redirectToSaveIncomeData(incomeBusinessMainModel.getReferenceId());
        }catch(Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE SETTING Income Details For Business :"+incomeBusinessMainModel.getCustomerType()+"\n ERROR DETAILS : " + e.getMessage());
            throw new RuntimeException("ERROR WHILE SETTING Income Details For Business :"+incomeBusinessMainModel.getCustomerType()+"\n ERROR DETAILS : " + e.getMessage());
        }
        //========================================================================================================//

        return "Income Business Saved Successfully";
    }

    @Override
    public IncomeBusinessMainModel getIncomeBusiness(String referenceId, String panNumber) {

//        System.out.println("IN GET");
        try{
            return incomeBusinessMainRepo.findByReferenceIdAndPanNumber(referenceId,panNumber);
        }catch (Exception e){
            throw new RuntimeException("Error Occurred WHile Getting Income Business" + e);
        }

    }


    //---------------------------------------- Saving Business Detail History ---------------------------------//
    private List<IncomeBusinessDetailHistoryModel> saveBusinessDetailToHistory(List<IncomeBusinessDetailModel> foundBusinessDetails){

//        foundBusinessDetails.forEach(item -> {
//            System.out.println(item);
//            if(item.getId()!=null) {
//                item.setId(null);
//            }
//        });

        List<IncomeBusinessDetailHistoryModel> incomeBusinessDetailHistoryModelArray= new ArrayList<>();
        for(IncomeBusinessDetailModel foundIncomeBusinessDetailModel : foundBusinessDetails){
            foundIncomeBusinessDetailModel.setId(null);
            IncomeBusinessDetailHistoryModel incomeBusinessDetailHistoryModel = new IncomeBusinessDetailHistoryModel();
            incomeBusinessDetailHistoryModel.setUpdatedDate(LocalDateTime.now());
            BeanUtils.copyProperties(foundIncomeBusinessDetailModel,incomeBusinessDetailHistoryModel,"id");
            incomeBusinessDetailHistoryModelArray.add(incomeBusinessDetailHistoryModel);

        }

        return incomeBusinessDetailHistoryModelArray;
    }

    //    ------------------------ Delete Income Business And Save To History -------------------------

    @Override
    @Transactional
    public void deleteIncomeBusinessAndSaveToHistory(String referenceId, String panNumber) {
        IncomeBusinessMainModel foundRecord = incomeBusinessMainRepo.findByReferenceIdAndPanNumber(referenceId,panNumber);

        if (foundRecord != null) {

            IncomeBusinessMainHistoryModel incomeBusinessMainHistoryModel = new IncomeBusinessMainHistoryModel();
            incomeBusinessMainHistoryModel.setUpdatedDate(LocalDateTime.now());
            try {
                List<IncomeBusinessDetailModel> foundBusinessDetailsSave = foundRecord.getIncomeBusinessDetailModel();

                incomeBusinessMainHistoryModel.setIncomeBusinessDetailHistoryModels(saveBusinessDetailToHistory(foundBusinessDetailsSave));

                BeanUtils.copyProperties(foundRecord, incomeBusinessMainHistoryModel, "updatedDate", "id");


                List<IncomeBusinessDetailHistoryModel> incomeBusinessDetailHistoryModels = incomeBusinessMainHistoryModel.getIncomeBusinessDetailHistoryModels();
                for (IncomeBusinessDetailHistoryModel incomeBusinessDetailHistoryModel : incomeBusinessDetailHistoryModels) {
                    incomeBusinessDetailHistoryModel.setIncomeBusinessMainHistoryModel(incomeBusinessMainHistoryModel);
                }

                incomeBusinessMainHistoryModel.setIncomeBusinessDetailHistoryModels(incomeBusinessDetailHistoryModels);

                incomeBusinessMainHistoryRepo.save(incomeBusinessMainHistoryModel);
            } catch (Exception e) {
                throw new RuntimeException("Error Occurred While Saving History Income Business " + e);
            }

            try {
                incomeBusinessMainRepo.delete(foundRecord);
            } catch (Exception e) {
                throw new RuntimeException("Error While Deleting Income Business Model" + e);
            }
        }
}}
