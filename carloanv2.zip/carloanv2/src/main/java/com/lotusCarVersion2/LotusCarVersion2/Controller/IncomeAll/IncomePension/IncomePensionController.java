package com.lotusCarVersion2.LotusCarVersion2.Controller.IncomeAll.IncomePension;



import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomePension.IncomePensionModel;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomePension.IncomePensionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/income-pension")
@CrossOrigin(origins = "*")
public class IncomePensionController {

    @Autowired
    private IncomePensionService incomePensionService;

    @PostMapping("add")
    public ResponseEntity<String> postIncomePensionDetails(@RequestBody IncomePensionModel incomePensionModel){
        String incomePensionResponse = incomePensionService.postIncomePension(incomePensionModel);
        return new ResponseEntity<>(incomePensionResponse, HttpStatus.OK);
    }

    @GetMapping("fetch")
    public ResponseEntity<IncomePensionModel> getIncomePensionDetails(@RequestParam String referenceId, @RequestParam String panNumber){
        IncomePensionModel getIncomePensionResponse = incomePensionService.getIncomePension(referenceId,panNumber);
        if(getIncomePensionResponse != null){
            return new ResponseEntity<>(getIncomePensionResponse,HttpStatus.OK);
        }else {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }
}
