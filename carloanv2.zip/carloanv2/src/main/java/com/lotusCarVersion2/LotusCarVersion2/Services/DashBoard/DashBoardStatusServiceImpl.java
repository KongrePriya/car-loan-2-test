package com.lotusCarVersion2.LotusCarVersion2.Services.DashBoard;


import com.lotusCarVersion2.LotusCarVersion2.Models.ApplicationList.UserModelDashBoard;
import com.lotusCarVersion2.LotusCarVersion2.Models.Dashboard.DashBoardStatusModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.DecisionStatus.DecisionStatusModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DecisionStatus.DecisionStatusRepo;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
@AllArgsConstructor
public class DashBoardStatusServiceImpl implements DashBoardStatusService {

    private static final Logger log = LoggerFactory.getLogger(DashBoardStatusServiceImpl.class);

    @Autowired
    private DecisionStatusRepo decisionStatusRepo;


    @Override
    public DashBoardStatusModel getDashBoardCount(UserModelDashBoard userModelDataModel) {
        //check From Where User Comes BR/HO/RO
        //Then Count the application List using Branch code for Branches and for Ro by Region Name and For Ho
        long statusRecommended = 0;
        long statusPending = 0;
        long statusSanctioned = 0;
        long statusReturn = 0;
        long statusReject = 0;
        long statusDeviation = 0;


        if (userModelDataModel.getUserLoc().equalsIgnoreCase("BR")) {

            if (userModelDataModel.getUserType().equalsIgnoreCase("BM")) {
                statusRecommended = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "REC").size();
                statusPending = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "PEN").size();
                statusSanctioned = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "SAN").size();
                statusReturn = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "RET").size();
                statusReject = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "REJ").size();
                statusDeviation = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "DEV").size();
            } else if (userModelDataModel.getUserType().equalsIgnoreCase("OF")) {
//                System.out.println("SIze Of Application"+decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc("4340","PEN"));
                statusRecommended = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "REC").size();
                statusPending = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "PEN").size();
                statusSanctioned = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "SAN").size();
                statusReturn = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "RET").size();
                statusReject = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "REJ").size();
                statusDeviation = decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "DEV").size();
            }


        }
        else if (userModelDataModel.getUserLoc().equalsIgnoreCase("RO")) {
            if (userModelDataModel.getUserType().equalsIgnoreCase("CPC_officer")) {
                statusRecommended = decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REC").size();
                statusPending = decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "PEN").size();
                statusSanctioned = decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "SAN").size();
                statusReturn = decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "RET").size();
                statusReject = decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REJ").size();
                statusDeviation = decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "DEV").size();

            }
            else if (userModelDataModel.getUserType().equalsIgnoreCase("CPC_head")) {
                statusRecommended = decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REC").size();
                statusPending = decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "PEN").size();
                statusSanctioned = decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "SAN").size();
                statusReturn = decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "RET").size();
                statusReject = decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REJ").size();
                statusDeviation = decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "DEV").size();

            }
            else if (userModelDataModel.getUserType().equalsIgnoreCase("RM")) {
                decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "DEV").size();
                statusRecommended = decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REC").size();
                statusPending = decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "PEN").size();
                statusSanctioned = decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "SAN").size();
                statusReturn = decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "RET").size();
                statusReject = decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REJ").size();
                statusDeviation = decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "DEV").size();

            }
        }
        else if (userModelDataModel.getUserLoc().equalsIgnoreCase("HO")) {
            if (userModelDataModel.getUserType().equalsIgnoreCase("HO_Credit_Officer")) {

                statusRecommended = decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "REC").size();
                statusPending = decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "PEN").size();
                statusSanctioned = decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "SAN").size();
                statusReturn = decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "RET").size();
                statusReject = decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "REJ").size();
                statusDeviation = decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "DEV").size();

            } else if (userModelDataModel.getUserType().equalsIgnoreCase("CM") && userModelDataModel.getRegionName().equalsIgnoreCase("CREDIT")) {

                statusRecommended = decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "REC").size();
                statusPending = decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "PEN").size();
                statusSanctioned = decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "SAN").size();
                statusReturn = decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "RET").size();
                statusReject = decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "REJ").size();
                statusDeviation = decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "DEV").size();

            }
        }

        DashBoardStatusModel dashboard = new DashBoardStatusModel();
        dashboard.setBranchCode(userModelDataModel.getBranchCode());
        dashboard.setStatusPending(String.valueOf(statusPending));
        dashboard.setStatusSanctioned(String.valueOf(statusSanctioned));
        dashboard.setStatusRecommended(String.valueOf(statusRecommended));
        dashboard.setStatusReject(String.valueOf(statusReject));
        dashboard.setStatusReturn(String.valueOf(statusReturn));
        dashboard.setStatusDeviation(String.valueOf(statusDeviation));
        return dashboard;
    }

    @Override
    public DashBoardStatusModel getDashBoardCountCurrent(UserModelDashBoard userModelDataModel) {
        long statusRecommended = 0;
        long statusPending = 0;
        long statusSanctioned = 0;
        long statusReturn = 0;
        long statusReject = 0;
        long statusDeviation = 0;

        if (userModelDataModel.getUserLoc().equalsIgnoreCase("BR")) {

            if (userModelDataModel.getUserType().equalsIgnoreCase("BM")) {

                statusRecommended = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "REC"), "BM").size();
                statusPending = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "PEN"), "BM").size();
                statusSanctioned = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "SAN"), "BM").size();
                statusReturn = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "RET"), "BM").size();
                statusReject = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "REJ"), "BM").size();
                statusDeviation = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "DEV"), "BM").size();
            } else if (userModelDataModel.getUserType().equalsIgnoreCase("OF")) {
                statusRecommended = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "REC"), "OF").size();
                statusPending = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "PEN"), "OF").size();
                statusSanctioned = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "SAN"),"BM").size();
                statusReturn = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "RET"),"BM").size();
                statusReject = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "REJ"),"BM").size();
                statusDeviation = getAllForCurrentMonth(decisionStatusRepo.findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode(), "DEV"), "OF").size();
            }

        } else if (userModelDataModel.getUserLoc().equalsIgnoreCase("RO")) {
            if (userModelDataModel.getUserType().equalsIgnoreCase("CPC_officer")) {
                statusRecommended = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REC"), "CPC_OFFICER").size();
                statusPending = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "PEN"), "CPC_OFFICER").size();
                statusSanctioned = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "SAN"), "CPC_OFFICER").size();
                statusReturn = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "RET"), "CPC_OFFICER").size();
                statusReject = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REJ"), "CPC_OFFICER").size();
                statusDeviation = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "DEV"), "CPC_OFFICER").size();

            } else if (userModelDataModel.getUserType().equalsIgnoreCase("CPC_head")) {
                statusRecommended = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REC"), "CPC_HEAD").size();
                statusPending = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "PEN"), "CPC_HEAD").size();
                statusSanctioned = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "SAN"), "CPC_HEAD").size();
                statusReturn = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "RET"), "CPC_HEAD").size();
                statusReject = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REJ"), "CPC_HEAD").size();
                statusDeviation = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "DEV"), "CPC_HEAD").size();

            } else if (userModelDataModel.getUserType().equalsIgnoreCase("RM")) {

                statusRecommended = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REC"), "RM").size();
                statusPending = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "PEN"), "RM").size();
                statusSanctioned = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "SAN"), "RM").size();
                statusReturn = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "RET"), "RM").size();
                statusReject = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "REJ"), "RM").size();
                statusDeviation = getAllForCurrentMonth(decisionStatusRepo.findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName(), "DEV"), "RM").size();

            }
        } else if (userModelDataModel.getUserLoc().equalsIgnoreCase("HO")) {

            if (userModelDataModel.getUserType().equalsIgnoreCase("HO_Credit_Officer")) {
              statusRecommended = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "REC"), "HO_Credit_Officer").size();
                statusPending = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "PEN"), "HO_Credit_Officer").size();
                statusSanctioned = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "SAN"), "HO_Credit_Officer").size();
                statusReturn = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "RET"), "HO_Credit_Officer").size();
                statusReject = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "REJ"), "HO_Credit_Officer").size();
                statusDeviation = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc( "DEV"), "HO_Credit_Officer").size();

            } else if (userModelDataModel.getUserType().equalsIgnoreCase("CM") && userModelDataModel.getRegionName().equalsIgnoreCase("CREDIT")) {
               statusRecommended = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "REC"), "CM").size();
                statusPending = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "PEN"), "CM").size();
                statusSanctioned = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "SAN"), "CM").size();
                statusReturn = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "RET"), "CM").size();
                statusReject = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "REJ"), "CM").size();
                statusDeviation = getAllForCurrentMonth(decisionStatusRepo.findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc( "DEV"), "CM").size();
            }
        }
        DashBoardStatusModel dashboard = new DashBoardStatusModel();
        dashboard.setBranchCode(userModelDataModel.getBranchCode());
        dashboard.setStatusPending(String.valueOf(statusPending));
        dashboard.setStatusSanctioned(String.valueOf(statusSanctioned));
        dashboard.setStatusRecommended(String.valueOf(statusRecommended));
        dashboard.setStatusReject(String.valueOf(statusReject));
        dashboard.setStatusReturn(String.valueOf(statusReturn));
        dashboard.setStatusDeviation(String.valueOf(statusDeviation));
        return dashboard;
    }
//------------------------------------------------------------------------------------------------------------------------//

@Override
public DashBoardStatusModel getDashBoardCountQuarter(UserModelDashBoard applicationActionModel) {
    return null;
}

//------------------------------------------------------------------------------------------------------------------------//
//Get Current Month Data
public List<DecisionStatusModel> getAllForCurrentMonth(List<DecisionStatusModel> allRecords, String userType) {

        // Get the current date and start of the month
        LocalDate today = LocalDate.now();
        LocalDate startOfMonth = today.withDayOfMonth(1);
        LocalDate endOfMonth = today.withDayOfMonth(today.lengthOfMonth());

        String statusTocheck = "";
        switch (userType) {
            case "BM":

                return allRecords.stream()
                        .filter(e -> {
                            // Convert timestamp to LocalDate
                            LocalDateTime dateToCheck = null;
                            // Determine which date field to use based on status
                            if (e.getApplnStatusBranchManager().equalsIgnoreCase("REJ")) {
                                dateToCheck = e.getRejectDate();
                            } else if (e.getApplnStatusBranchManager().equalsIgnoreCase("SAN")) {
                                dateToCheck = e.getSanctionDate();
                            } else if (e.getApplnStatusBranchManager().equalsIgnoreCase("RET")) {
                                dateToCheck = e.getReturnDate();
                            } else if (e.getApplnStatusBranchManager().equalsIgnoreCase("REC")) {
                                dateToCheck = e.getRecommendDate();
                            } else if (e.getApplnStatusBranchManager().equalsIgnoreCase("PEN")) {
                                dateToCheck = e.getApplicationCreationDate();
                            }

                            // Check if the determined date is within the current month
                          LocalDate localDateToCheck = dateToCheck != null ? dateToCheck.toLocalDate() : null;
                            // Check if the determined date is within the current month
                            return localDateToCheck != null && !localDateToCheck.isBefore(startOfMonth) && !localDateToCheck.isAfter(endOfMonth);
                        })
                        .collect(Collectors.toList());

            case "OF":
                // Filter records to keep only those within the current month
                return allRecords.stream()
                        .filter(e -> {
                            // Convert timestamp to LocalDate
                            LocalDateTime dateToCheck = null;
                            // Determine which date field to use based on status
                            if (e.getApplnStatusBranchOfficer().equalsIgnoreCase("REJ")) {
                                // dateToCheck = e.getRejectDate().atZone(ZoneId.systemDefault()).toLocalDate();
                            } else if (e.getApplnStatusMain().equalsIgnoreCase("SAN")) {
                                //      dateToCheck = e.getSanctionDate().atZone(ZoneId.systemDefault()).toLocalDate();
                            } else if (e.getApplnStatusBranchOfficer().equalsIgnoreCase("RET")) {
                                //       dateToCheck = e.getReturnDate().atZone(ZoneId.systemDefault()).toLocalDate();
                            } else if (e.getApplnStatusBranchOfficer().equalsIgnoreCase("REC")) {
                                //      dateToCheck = e.getRecommendDate().atZone(ZoneId.systemDefault()).toLocalDate();
                            } else {
                                dateToCheck = e.getApplicationCreationDate();//.atZone(ZoneId.systemDefault()).toLocalDate();

                            }
                            // Check if the determined date is within the current month
                           LocalDate localDateToCheck = dateToCheck != null ? dateToCheck.toLocalDate() : null;
                            // Check if the determined date is within the current month
                            return localDateToCheck != null && !localDateToCheck.isBefore(startOfMonth) && !localDateToCheck.isAfter(endOfMonth);

                        })
                        .collect(Collectors.toList());
            case "CPC_HEAD":
                return allRecords.stream()
                        .filter(e -> {
                            // Convert timestamp to LocalDate
                            LocalDateTime dateToCheck = null;
                            // Determine which date field to use based on status
                            if (e.getApplnStatusCpcHead().equalsIgnoreCase("REJ")) {
                                dateToCheck = e.getRejectDate();
                            } else if (e.getApplnStatusCpcHead().equalsIgnoreCase("SAN")) {
                                dateToCheck = e.getSanctionDate();
                            } else if (e.getApplnStatusCpcHead().equalsIgnoreCase("RET")) {
                                dateToCheck = e.getReturnDate();
                            } else if (e.getApplnStatusCpcHead().equalsIgnoreCase("REC")) {
                                dateToCheck = e.getRecommendDate();
                            } else if (e.getApplnStatusCpcHead().equalsIgnoreCase("PEN")) {
                                dateToCheck = e.getApplicationCreationDate();
                            }

                            // Check if the determined date is within the current month
                            LocalDate localDateToCheck = dateToCheck != null ? dateToCheck.toLocalDate() : null;
                            // Check if the determined date is within the current month
                            return localDateToCheck != null && !localDateToCheck.isBefore(startOfMonth) && !localDateToCheck.isAfter(endOfMonth);
                        })
                        .collect(Collectors.toList());
            case "CPC_OFFICER":
                return allRecords.stream()
                        .filter(e -> {
                            // Convert timestamp to LocalDate
                            LocalDateTime dateToCheck = null;
                            // Determine which date field to use based on status
                            if (e.getApplnStatusCpcOfficer().equalsIgnoreCase("REJ")) {
                                dateToCheck = e.getRejectDate();
                            } else if (e.getApplnStatusCpcOfficer().equalsIgnoreCase("SAN")) {
                                dateToCheck = e.getSanctionDate();
                            } else if (e.getApplnStatusCpcOfficer().equalsIgnoreCase("RET")) {
                                dateToCheck = e.getReturnDate();
                            } else if (e.getApplnStatusCpcOfficer().equalsIgnoreCase("REC")) {
                                dateToCheck = e.getRecommendDate();
                            } else if (e.getApplnStatusCpcOfficer().equalsIgnoreCase("PEN")) {
                                dateToCheck = e.getApplicationCreationDate();
                            }
                            // Check if the determined date is within the current month
                             LocalDate localDateToCheck = dateToCheck != null ? dateToCheck.toLocalDate() : null;
                            // Check if the determined date is within the current month
                            return localDateToCheck != null && !localDateToCheck.isBefore(startOfMonth) && !localDateToCheck.isAfter(endOfMonth);

                        })
                        .collect(Collectors.toList());
            case "RM":
                return allRecords.stream()
                        .filter(e -> {
                            // Convert timestamp to LocalDate
                            LocalDateTime dateToCheck = null;
                            // Determine which date field to use based on status
                            if (e.getApplnStatusRegionalManager().equalsIgnoreCase("REJ")) {
                                dateToCheck = e.getRejectDate();
                            } else if (e.getApplnStatusRegionalManager().equalsIgnoreCase("SAN")) {
                                dateToCheck = e.getSanctionDate();
                            } else if (e.getApplnStatusRegionalManager().equalsIgnoreCase("RET")) {
                                dateToCheck = e.getReturnDate();
                            } else if (e.getApplnStatusRegionalManager().equalsIgnoreCase("REC")) {
                                dateToCheck = e.getRecommendDate();
                            } else if (e.getApplnStatusRegionalManager().equalsIgnoreCase("PEN")) {
                                dateToCheck = e.getApplicationCreationDate();
                            }

                            // Check if the determined date is within the current month
                           LocalDate localDateToCheck = dateToCheck != null ? dateToCheck.toLocalDate() : null;
                            // Check if the determined date is within the current month
                            return localDateToCheck != null && !localDateToCheck.isBefore(startOfMonth) && !localDateToCheck.isAfter(endOfMonth);
                        })
                        .collect(Collectors.toList());
            case "HO_Credit_Officer":
                return allRecords.stream()
                        .filter(e -> {
                            // Convert timestamp to LocalDate
                            LocalDateTime dateToCheck = null;
                            // Determine which date field to use based on status
                            if (e.getApplnStatusHoOfficer().equalsIgnoreCase("REJ")) {
                                dateToCheck = e.getRejectDate();
                            } else if (e.getApplnStatusHoOfficer().equalsIgnoreCase("SAN")) {
                                dateToCheck = e.getSanctionDate();
                            } else if (e.getApplnStatusHoOfficer().equalsIgnoreCase("RET")) {
                                dateToCheck = e.getReturnDate();
                            } else if (e.getApplnStatusHoOfficer().equalsIgnoreCase("REC")) {
                                dateToCheck = e.getRecommendDate();
                            } else if (e.getApplnStatusHoOfficer().equalsIgnoreCase("PEN")) {
                                dateToCheck = e.getApplicationCreationDate();
                            }

                            // Check if the determined date is within the current month
                           LocalDate localDateToCheck = dateToCheck != null ? dateToCheck.toLocalDate() : null;
                            // Check if the determined date is within the current month
                            return localDateToCheck != null && !localDateToCheck.isBefore(startOfMonth) && !localDateToCheck.isAfter(endOfMonth);

                        })
                        .collect(Collectors.toList());
            case "CM":
                return allRecords.stream()
                        .filter(e -> {
                            // Convert timestamp to LocalDate
                            LocalDateTime dateToCheck = null;
                            // Determine which date field to use based on status
                            if (e.getApplnStatusChiefManager().equalsIgnoreCase("REJ")) {
                                dateToCheck = e.getRejectDate();
                            } else if (e.getApplnStatusChiefManager().equalsIgnoreCase("SAN")) {
                                dateToCheck = e.getSanctionDate();
                            } else if (e.getApplnStatusChiefManager().equalsIgnoreCase("RET")) {
                                dateToCheck = e.getReturnDate();
                            } else if (e.getApplnStatusChiefManager().equalsIgnoreCase("REC")) {
                                dateToCheck = e.getRecommendDate();
                            } else if (e.getApplnStatusChiefManager().equalsIgnoreCase("PEN")) {
                                dateToCheck = e.getApplicationCreationDate();
                            }

                            LocalDate localDateToCheck = dateToCheck != null ? dateToCheck.toLocalDate() : null;
                            // Check if the determined date is within the current month
                            return localDateToCheck != null && !localDateToCheck.isBefore(startOfMonth) && !localDateToCheck.isAfter(endOfMonth);

                        })
                        .collect(Collectors.toList());
                  }
        return null;
    }
//------------------------------------------------------------------------------------------------------------------------//
//Get Quarter Base Data For
public List<Map<String, Long>> getTransactionCountsByQuarterAndStatus(UserModelDashBoard userModelDataModel) {
        List<DecisionStatusModel> transactions = List.of();
        if (userModelDataModel.getUserLoc().equalsIgnoreCase("BR")) {
            transactions = decisionStatusRepo.findByBranchCodeOrderByApplicationCreationDateDesc(userModelDataModel.getBranchCode());
        }
        else if (userModelDataModel.getUserLoc().equalsIgnoreCase("RO")) {

            transactions = decisionStatusRepo.findByRonameOrderByApplicationCreationDateDesc(userModelDataModel.getRegionName());
        } else if (userModelDataModel.getUserLoc().equalsIgnoreCase("HO")) {

            transactions = decisionStatusRepo.findAll();
        }

        List<Map<String, Long>> result = new ArrayList<>();

         Map<String, Map<String, Long>> counts = transactions.stream()
                .collect(Collectors.groupingBy(this::getQuarter,
                        Collectors.groupingBy(transaction -> StatusMapper.mapStatus(transaction.getApplnStatusMain()), Collectors.counting())));

        List<String> statuses = List.of("statusReject", "statusRecommended", "statusSanctioned", "statusReturn","statusPending","statusDeviation");

        // Define quarters
        List<String> quarters = List.of("Q1", "Q2", "Q3", "Q4");
        for (String quarter : quarters) {
            Map<String, Long> statusCounts = new HashMap<>();
            for (String status : statuses) {
                 statusCounts.put(status, counts.getOrDefault(quarter, new HashMap<>()).getOrDefault(status, 0L));
            }
            result.add(statusCounts);
        }
        return result;
    }
//------------------------------------------------------------------------------------------------------------------------//

private String getQuarter(DecisionStatusModel transaction) {
        LocalDateTime timestamp = transaction.getApplicationCreationDate();
        if(timestamp==null){
           return "";// throw  new RuntimeException("ApplicationDate is Null");
        }else{
        int month = timestamp.getMonthValue();

        if (month >= 4 && month <= 6) {
            return "Q1";
        } else if (month >= 7 && month <= 9) {
            return "Q2";
        } else if (month >= 10) {
            return "Q3";
        } else {
            return "Q4";
        }
     }
    }
//------------------------------------------------------------------------------------------------------------------------//

}
