package com.lotusCarVersion2.LotusCarVersion2.Controller.DocumentsAndRemarks;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.DTO.DocumentAndRemarkSingleDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.DocumentsAndRemarksDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksMandatoryEntity;
import com.lotusCarVersion2.LotusCarVersion2.Services.DocumentUpload.DocumentUploadCommonService;
import lombok.AllArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@CrossOrigin("*")
@AllArgsConstructor
@RequestMapping("/api/v1/document-and-remark")
public class DocumentAndRemarksController {

 private final DocumentUploadCommonService documentUploadCommonService;

//*********************************************************************************************************//

@PostMapping("/upload")
public ResponseEntity<String> uploadFiles(@RequestPart("file") MultipartFile file, @RequestPart("data") DocumentAndRemarkSingleDto singleDto) {

    System.out.println("INSIDE UPLOAD FILE , file : "+file+" DATA: "+singleDto);
    try {
        // Create the directory if it doesn't exist
        Path path = Paths.get(AllStaticFields.FILE_UPLOAD_DIR);
        if (!Files.exists(path)) {
            Files.createDirectories(path);
        }
        // Save appraisal note file if it is present
        try {
        if (file != null && singleDto.getRemark() !=null) {
                String result = documentUploadCommonService.saveFileDetailsInTable(file,singleDto);
                System.out.println(" Result from Upload Service : " + result);
                return new ResponseEntity<>("FILE UPLOADED SUCCESSFULLY ...!!!", HttpStatus.OK);
         }else{
            throw new RuntimeException("Either File Not Selected or Remarks Missing: "+singleDto);
        }
        }catch (Exception e){
            System.err.println("ERROR WHILE SAVING FILE :"+e.getMessage());
            return new ResponseEntity<>("Error Uploading File : "+e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    } catch (IOException e) {
        e.printStackTrace();
        System.err.println("Error in file uploading Controller: " + e.getMessage());
        return new ResponseEntity<>("Error Uploading File",HttpStatus.BAD_REQUEST);
    }
}

//*********************************************************************************************************//
//Preview File
@GetMapping("/preview/{referenceId}/{fileType}")
public ResponseEntity<Resource> previewFile(@PathVariable("referenceId") String referenceId,@PathVariable("fileType") String fileType) {
    return documentUploadCommonService.previewFile(referenceId,fileType);
}

//*********************************************************************************************************//
// Download file
@CrossOrigin(origins = "*", allowedHeaders = "*", exposedHeaders = "Content-Disposition")
@GetMapping("/download/{referenceId}/{fileType}")
public ResponseEntity<Resource> downloadFile(@PathVariable("referenceId") String referenceId, @PathVariable("fileType") String fileType)  {
    return documentUploadCommonService.downloadFile(referenceId,fileType);
}

//*********************************************************************************************************//
@GetMapping("/get-all/{referenceId}")
public ResponseEntity<DocumentsAndRemarksDto> getCalculationDisplaySummary(@PathVariable String referenceId){
    DocumentsAndRemarksDto documentsAndRemarksDto=documentUploadCommonService.getAllDocumentsAndRemarks(referenceId);
    if(documentsAndRemarksDto != null){
        System.out.println(" DOCUMENTS AND REMARKS DATA FOR REF-ID: "+documentsAndRemarksDto);
        return ResponseEntity.ok(documentsAndRemarksDto);
    }else{
        System.out.println("DOCUMENTS AND REMARKS DATA NOT FOUND.");
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

//*********************************************************************************************************//
@GetMapping("/mandatory/{referenceId}")
public ResponseEntity<DocumentsAndRemarksMandatoryEntity> getMandatoryDocuments(@PathVariable String referenceId){
    DocumentsAndRemarksMandatoryEntity mandatoryEntity=documentUploadCommonService.getMandatoryDocumentsForReferenceId(referenceId);
    if(mandatoryEntity != null){
        System.out.println(" MANDATORY DOCUMENTS FOR referenceId is: "+mandatoryEntity);
        return ResponseEntity.ok(mandatoryEntity);
    }else{
        System.out.println("MANDATORY DOCUMENTS FOR referenceId NOT FOUND. ");
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
//*********************************************************************************************************//

}