package com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "deviation_standards_table")
public class DeviationStandardEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //age
    private int ageMinMonths; //21*12 =252
    private int entryAgeMaxSalariedMonths; //70*12 =840
    private int entryAgeMaxBusinessMonths; //70*12 =840
    private int entryAgeMaxPensionerMonths; //70*12 =840

    //experience
    private int totalExperienceMinInMonths; //1 years =12 months
    private int currentExperienceMinInMonths; //1 years=12 months
    private int businessStandingExperienceMonths; //2 years=24 months

    //repayment max
    private int repaymentAgeMaxInMonths; //70*12 =840
    private int repaymentTenureMaxInMonths; //7 years*12 =84

    //loan metrics
    private BigDecimal processingCharge; //0.25%
    private BigDecimal documentationCharge; //0.20%

    //CIBIL
    private String cibilScoreStatus; //NO
    private String cibilOverdue; //NO
    private String cibilWrittenOff; //NO
    private String cibilSettled; //NO

    private BigDecimal maxLoanEligible; //500 lakhs/5 crore


//===========================================//=======================================//=======================================//
/*
    INSERT INTO los_car_v2.deviation_standards_table(
    age_min_months, business_standing_experience_months, cibil_overdue, cibil_score_status,
    cibil_settled, cibil_written_off, current_experience_min_in_months, documentation_charge, entry_age_max_business_months,
    entry_age_max_pensioner_months, entry_age_max_salaried_months, excess_roi_allowed, loan_amount_two_lakhs,
    margin_minimum, processing_charge, repayment_age_max_in_months, repayment_tenure_max_in_months,
    total_experience_min_in_months)
    VALUES ('252', '24', 'NO', 'NO', 'NO', 'NO', '12', '0.20', '780', '840', '720', '2', '200000.00', '15', '15',
    '900', '84','24');*/


}
