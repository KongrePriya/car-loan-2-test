package com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
public class QuotationDetailsModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String referenceId;
    private String branchCode;
    private String region;
    private String userId;
    private String companyName;
    private String modelName;
    private String dealerPan;
    private String gstnNumber;
    private String dealerName;
    private LocalDate dateOfQuotation;
    private String productCode;
    private String productDescription;
    private BigDecimal rateOfInterest;
    private BigDecimal margin;
    private Integer loanTenure;
    private BigDecimal processingCharges;
    private BigDecimal documentCharges;
    private BigDecimal showroomPrice;
    private BigDecimal rtoCharges;
    private BigDecimal carInsuranceCharges;
    private BigDecimal totalCostToConsider;
    private BigDecimal loanAppliedAmount;
    private String kotakKliOptions;
    private BigDecimal kotakKliPremiumAmount;
    private BigDecimal kotakKliFundedAmount;
    private BigDecimal carScore;
    private LocalDateTime submitDate;
    private String eligibleForROIRelaxation;

}
