package com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "deviation_flag_table")
public class DeviationFlagsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String referenceId;
    private String branchCode;
    private String loanType;
    private String applicantName;
    private String applicantPan;

    //AGE DEVIATION
    private String applicantAgeDeviation="NO";
    private String coapplicantOneAgeDeviation="NO";
    private String coapplicantTwoAgeDeviation="NO";

    //CIBIL-ALL
    private String cibilScoreDeviation="NO";
    private String cibilOverdueDeviation="NO";
    private String cibilWrittenOffDeviation="NO";
    private String cibilSettledDeviation="NO";
    private String CibilDeviation="NO"; //after comparing above 4 fields

    //LOAN METRICS
//    private String roiDeviation="NO"; // AS ROI IS DISABLED ON UI
    private String processingChargeDeviation="NO"; //0.25
    private String documentationChargeDeviation="NO"; //0.20
//    private String maxLoanTenureAllowedDeviation="NO"; // AS 84 MAX IS SET ON UI
    private String repaymentAgeDeviation="NO";

    //WORK EXPERIENCE
    private String applicantWorkExperienceDeviation="NO";
    private String coapplicantOneWorkExperienceDeviation="NO";
    private String coapplicantTwoWorkExperienceDeviation="NO";

    //ITR-FORM16 DEVIATION
    private String applicantItrForm16Deviation="NO";
    private String coapplicantOneItrForm16Deviation="NO";
    private String coapplicantTwoItrForm16Deviation="NO";


    //LOAN ELIGIBILITY DEVIATION
    private String loanEligibleDeductionDeviation="NO";
    private String loanEligibleMarginDeviation="NO";

    private String ageServiceItrDeviationCombined="NO";//COMBINED AGE & SERVICE DEVIATION FOR SEPARATE TABLE SHOW-HIDE

    private String relationWithApplicantDeviation="NO"; //ADDED ON 26032025

    private String anyDeviationPresent="NO";  //NORMAL DEVIATION ONLY


    @PrePersist
    @PreUpdate
    private void updateAnyDeviationPresent() {
        anyDeviationPresent = (
                CheckIfYes(applicantAgeDeviation) ||
                        CheckIfYes(coapplicantOneAgeDeviation) ||
                        CheckIfYes(coapplicantTwoAgeDeviation) ||
//                        CheckIfYes(cibilScoreDeviation) || NOT INCLUDING CIBIL AS DEVIATION APPROVAL NOT NEEDED FOR CIBIL
//                        CheckIfYes(cibilOverdueDeviation) ||
//                        CheckIfYes(cibilWrittenOffDeviation) ||
//                        CheckIfYes(cibilSettledDeviation) ||
                        CheckIfYes(processingChargeDeviation) ||
                        CheckIfYes(documentationChargeDeviation) ||
                        CheckIfYes(repaymentAgeDeviation) ||
                        CheckIfYes(applicantWorkExperienceDeviation) ||
                        CheckIfYes(coapplicantOneWorkExperienceDeviation) ||
                        CheckIfYes(coapplicantTwoWorkExperienceDeviation) ||
                        CheckIfYes(applicantItrForm16Deviation) ||
                        CheckIfYes(coapplicantOneItrForm16Deviation) ||
                        CheckIfYes(coapplicantTwoItrForm16Deviation) ||
                        CheckIfYes(loanEligibleDeductionDeviation) ||
                        CheckIfYes(loanEligibleMarginDeviation) ||
                        CheckIfYes(relationWithApplicantDeviation)
                ) ? "YES" : "NO";

    }


    private boolean CheckIfYes(String field) {
        return "YES".equalsIgnoreCase(field);
    }
}
