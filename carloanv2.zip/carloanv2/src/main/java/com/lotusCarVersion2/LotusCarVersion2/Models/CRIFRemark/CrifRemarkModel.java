package com.lotusCarVersion2.LotusCarVersion2.Models.CRIFRemark;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

//@Getter
//@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "crif_remark")
public class CrifRemarkModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Long id;
    private String referenceId;
    private String userId;
    private String userType;
    @Column(columnDefinition = "TEXT")
    private String crifRemark;
    @Column(columnDefinition = "TEXT")
    private String crifOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String crifRejectRemark;
    private LocalDateTime crifSubmitDate;
    @Column(columnDefinition = "TEXT")
    private String crifWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String crifAccountSettledRemark;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getCrifRemark() {
        return crifRemark;
    }

    public void setCrifRemark(String crifRemark) {
        this.crifRemark = crifRemark;
    }

    public String getCrifOverdueRemark() {
        return crifOverdueRemark;
    }

    public void setCrifOverdueRemark(String crifOverdueRemark) {
        this.crifOverdueRemark = crifOverdueRemark;
    }

    public String getCrifRejectRemark() {
        return crifRejectRemark;
    }

    public void setCrifRejectRemark(String crifRejectRemark) {
        this.crifRejectRemark = crifRejectRemark;
    }

    public LocalDateTime getCrifSubmitDate() {
        return crifSubmitDate;
    }

    public void setCrifSubmitDate(LocalDateTime crifSubmitDate) {
        this.crifSubmitDate = crifSubmitDate;
    }

    public String getCrifWrittenOffRemark() {
        return crifWrittenOffRemark;
    }

    public void setCrifWrittenOffRemark(String crifWrittenOffRemark) {
        this.crifWrittenOffRemark = crifWrittenOffRemark;
    }

    public String getCrifAccountSettledRemark() {
        return crifAccountSettledRemark;
    }

    public void setCrifAccountSettledRemark(String crifAccountSettledRemark) {
        this.crifAccountSettledRemark = crifAccountSettledRemark;
    }
}

