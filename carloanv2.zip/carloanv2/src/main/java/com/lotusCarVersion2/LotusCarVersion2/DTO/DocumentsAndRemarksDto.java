package com.lotusCarVersion2.LotusCarVersion2.DTO;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Data
public class DocumentsAndRemarksDto {

    private String referenceId;

    //applicant due diligence
    private String applicantDueDiligenceRemark;
    private LocalDateTime applicantDueDiligenceFileDate;
    private String applicantDueDiligenceFileName;
    private String applicantDueDiligenceUploadedBy;

    //co-app due diligence : optional
    private String coAppDueDiligenceRemark;
    private LocalDateTime coAppDueDiligenceFileDate;
    private String coAppDueDiligenceFileName;
    private String coAppDueDiligenceUploadedBy;


    //guarantor due diligence
    private String guarantorDueDiligenceRemark;
    private LocalDateTime guarantorDueDiligenceFileDate;
    private String guarantorDueDiligenceFileName;
    private String guarantorDueDiligenceUploadedBy;

    //quotation
    private String quotationFileRemark;
    private LocalDateTime quotationFileDate;
    private String quotationFileName;
    private String quotationFileUploadedBy;

    //Visit report
    private String visitReportRemark;
    private LocalDateTime visitReportFileDate;
    private String visitReportFileName;
    private String visitReportUploadedBy;

    //applicant ITR form 16
    private String applicantITRForm16Remark;
    private LocalDateTime applicantITRForm16FileDate;
    private String applicantITRForm16FileName;
    private String applicantITRForm16UploadedBy;

    //co-applicant ITR form 16
    private String coAppITRForm16Remark;
    private LocalDateTime coAppITRForm16FileDate;
    private String coAppITRForm16FileName;
    private String coAppITRForm16UploadedBy;

    //guarantor ITR form 16
    private String guarantorITRForm16Remark;
    private LocalDateTime guarantorITRForm16FileDate;
    private String guarantorITRForm16FileName;
    private String guarantorITRForm16UploadedBy;

    //applicant KYC
    private String applicantKYCRemark;
    private LocalDateTime applicantKYCFileDate;
    private String applicantKYCFileName;
    private String applicantKYCUploadedBy;

    //co-applicant KYC
    private String coAppKYCRemark;
    private LocalDateTime coAppKYCFileDate;
    private String coAppKYCFileName;
    private String coAppKYCUploadedBy;

    //guarantor KYC
    private String guarantorKYCRemark;
    private LocalDateTime guarantorKYCFileDate;
    private String guarantorKYCFileName;
    private String guarantorKYCUploadedBy;

    //Applicant Bank Statement
    private String applicantBankStatementRemark;
    private LocalDateTime applicantBankStatementFileDate;
    private String applicantBankStatementFileName;
    private String applicantBankStatementUploadedBy;

    //Applicant business/employment proof
    private String employmentOrBusinessProofRemark;
    private LocalDateTime employmentOrBusinessProofFileDate;
    private String employmentOrBusinessProofFileName;
    private String employmentOrBusinessProofUploadedBy;

    //applicant salary
    private String applicantSalaryPensionRemark;
    private LocalDateTime applicantSalaryPensionFileDate;
    private String applicantSalaryPensionFileName;
    private String applicantSalaryPensionUploadedBy;

    //co-applicant salary
    private String coAppSalaryPensionRemark;
    private LocalDateTime coAppSalaryPensionFileDate;
    private String coAppSalaryPensionFileName;
    private String coAppSalaryPensionUploadedBy;

    //guarantor salary
    private String guarantorSalaryPensionRemark;
    private LocalDateTime guarantorSalaryPensionFileDate;
    private String guarantorSalaryPensionFileName;
    private String guarantorSalaryPensionUploadedBy;

    //applicant passport
    private String applicantPassportRemark;
    private LocalDateTime applicantPassportFileDate;
    private String applicantPassportFileName;
    private String applicantPassportUploadedBy;

    //other Remark
    private String otherRemark;
    private LocalDateTime otherFileDate;
    private String otherFileName;
    private String otherFileUploadedBy;

    // OVERDUE CLEARANCE
    private String overdueClearanceCertificateName;
    private String overdueClearanceCertificateUploadedBy;
    private LocalDateTime overdueClearanceCertificateDate;

    // Deviation Approval Sanction
    private String deviationSanctionLetterRemark;
    private String deviationSanctionLetterFileName;
    private String deviationSanctionLetterUploadedBy;
    private String deviationSanctionLetterNumber;
    private LocalDateTime deviationSanctionLetterDate;
    private Boolean deviationDeclarationCheck;
}
