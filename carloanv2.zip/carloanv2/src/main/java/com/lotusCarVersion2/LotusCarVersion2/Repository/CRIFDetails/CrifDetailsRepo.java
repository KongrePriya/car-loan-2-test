package com.lotusCarVersion2.LotusCarVersion2.Repository.CRIFDetails;


import com.lotusCarVersion2.LotusCarVersion2.Models.CRIFDetails.StdCrifDetailsModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CrifDetailsRepo extends JpaRepository<StdCrifDetailsModel,Long> {

        List<StdCrifDetailsModel> findAllByReferenceId(String referenceId);

}
