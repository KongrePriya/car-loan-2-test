package com.lotusCarVersion2.LotusCarVersion2.Config;

import java.math.BigDecimal;

public class MarginSlabs {
    public static final BigDecimal FIFTY_THOUSAND = BigDecimal.valueOf(50000);
    public static final BigDecimal ONE_LAKH = BigDecimal.valueOf(100000);
    public static final BigDecimal TWO_LAKH = BigDecimal.valueOf(200000);
    public static final BigDecimal FIVE_LAKH = BigDecimal.valueOf(500000);
    public static final BigDecimal SIX_LAKH = BigDecimal.valueOf(500000);
    public static final BigDecimal TWELVE_LAKH = BigDecimal.valueOf(1200000);
    public static final BigDecimal TWENTYFOUR_LAKH = BigDecimal.valueOf(2400000);
    public static final BigDecimal SIXTY_LAKH = BigDecimal.valueOf(2400000);

    public static final BigDecimal SIXTY_PERCENT = BigDecimal.valueOf(0.60);
    public static final BigDecimal SIXTYFIVE_PERCENT = BigDecimal.valueOf(0.65);
    public static final BigDecimal SEVENTY_PERCENT = BigDecimal.valueOf(0.70);
    public static final BigDecimal SEVENTYFIVE_PERCENT = BigDecimal.valueOf(0.75);
    public static final BigDecimal EIGHTY_PERCENT = BigDecimal.valueOf(0.80);




}
