package com.lotusCarVersion2.LotusCarVersion2.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IndividualBasicDetailsDto {

    private Long idDto;
    private Long id;

    private String referenceId;
    private String branchCode;
    private String userId;

    private String title;
    private String fatherName;
    private String pan;
    private String aadhar;
    private String voterIdCard;
    private String drivingLicence;
    private String passportNum;
    private String rationCardNumber;
    private String qualification;
    private String permanentAddress;
    private String residenceOwnership;
    private String cif;
    private String netWorth;
    private String presentAddress;
    private String alternateEmail;
    private String altMobile;
    private String tempAddressLine1;
    private String tempAddressLandmark;
    private String tempAddressSubDist;
    private String tempAddressDist;
    private String tempAddressState;

    private String tempAddressPincode;
    private String customerType;
    private int ageInMonths;
    private LocalDateTime timestamp=LocalDateTime.now();

    // Fetched fields
    private String fullName;
    private String gender;
    private String email;
    private String dateOfBirth;
    private String mobileNumber;
    private String careOf;
    private String house;
    private String street;
    private String district;
    private String subDistrict;
    private String landmark;
    private String locality;
    private String postOfficeName;
    private String state;
    private String pincode;
    private String country;
    private String vtcName;
    private String mobile;
    private String aadharAddress;

    private String consideringIncome;
    private String incomeSourceType;
    private String itrFilledForAnyYear;
    private String form16Available;
    private String ageInYears; //added on 20022025

    private String relationWithApplicant; //added on 26032025
    private String relationWithApplicantOther;//added on 26032025

    private String crifFetched; //NEW ADDITION

}
