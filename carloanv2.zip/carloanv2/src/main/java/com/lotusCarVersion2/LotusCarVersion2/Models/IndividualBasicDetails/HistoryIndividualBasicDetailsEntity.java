package com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "individual_basic_details_history")

public class HistoryIndividualBasicDetailsEntity {

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long idone;

        private Long id;

        private String referenceId;
        private String branchCode;
        private String userId;

        private String title;
        private String fatherName;
        private String pan;
        private String aadhar;
        private String voterIdCard;
        private String drivingLicence;
        private String passportNum;
        private String rationCardNumber;
        private String qualification;
        private String permanentAddress;
        private String residenceOwnership;
        private String cif;
        private String netWorth;
        private String presentAddress;
        private String alternateEmail;
        private String altMobile;
        private String tempAddressLine1;
        private String tempAddressLandmark;
        private String tempAddressSubDist;
        private String tempAddressDist;
        private String tempAddressState;

        private String tempAddressPincode;
        private String customerType;
        private int ageInMonths;
        private LocalDateTime timestamp=LocalDateTime.now();

        // Fetched fields
        private String fullName;
        private String gender;
        private String email;
        private String dateOfBirth;
        private String mobileNumber;
        private String careOf;
        private String house;
        private String street;
        private String district;
        private String subDistrict;
        private String landmark;
        private String locality;
        private String postOfficeName;
        private String state;
        private String pincode;
        private String country;
        private String vtcName;
        private String mobile;
        private String aadharAddress;

        private String consideringIncome;
        private String incomeSourceType;
        private String itrFilledForAnyYear;
        private String form16Available;


        private String crifFetched;  //NEW ADDITION

        //extra
        private LocalDateTime deletedAt;
        private String deletedBy;

        private String ageInYears; //added on 20022025

        private String relationWithApplicant; //added on 26032025
        private String relationWithApplicantOther;//added on 26032025


        public Long getIdone() {
                return idone;
        }

        public void setIdone(Long idone) {
                this.idone = idone;
        }

        public Long getId() {
                return id;
        }

        public void setId(Long id) {
                this.id = id;
        }

        public String getReferenceId() {
                return referenceId;
        }

        public void setReferenceId(String referenceId) {
                this.referenceId = referenceId;
        }

        public String getBranchCode() {
                return branchCode;
        }

        public void setBranchCode(String branchCode) {
                this.branchCode = branchCode;
        }

        public String getUserId() {
                return userId;
        }

        public void setUserId(String userId) {
                this.userId = userId;
        }

        public String getTitle() {
                return title;
        }

        public void setTitle(String title) {
                this.title = title;
        }

        public String getFatherName() {
                return fatherName;
        }

        public void setFatherName(String fatherName) {
                this.fatherName = fatherName;
        }

        public String getPan() {
                return pan;
        }

        public void setPan(String pan) {
                this.pan = pan;
        }

        public String getAadhar() {
                return aadhar;
        }

        public void setAadhar(String aadhar) {
                this.aadhar = aadhar;
        }

        public String getVoterIdCard() {
                return voterIdCard;
        }

        public void setVoterIdCard(String voterIdCard) {
                this.voterIdCard = voterIdCard;
        }

        public String getDrivingLicence() {
                return drivingLicence;
        }

        public void setDrivingLicence(String drivingLicence) {
                this.drivingLicence = drivingLicence;
        }

        public String getPassportNum() {
                return passportNum;
        }

        public void setPassportNum(String passportNum) {
                this.passportNum = passportNum;
        }

        public String getRationCardNumber() {
                return rationCardNumber;
        }

        public void setRationCardNumber(String rationCardNumber) {
                this.rationCardNumber = rationCardNumber;
        }

        public String getQualification() {
                return qualification;
        }

        public void setQualification(String qualification) {
                this.qualification = qualification;
        }

        public String getPermanentAddress() {
                return permanentAddress;
        }

        public void setPermanentAddress(String permanentAddress) {
                this.permanentAddress = permanentAddress;
        }

        public String getResidenceOwnership() {
                return residenceOwnership;
        }

        public void setResidenceOwnership(String residenceOwnership) {
                this.residenceOwnership = residenceOwnership;
        }

        public String getCif() {
                return cif;
        }

        public void setCif(String cif) {
                this.cif = cif;
        }

        public String getNetWorth() {
                return netWorth;
        }

        public void setNetWorth(String netWorth) {
                this.netWorth = netWorth;
        }

        public String getPresentAddress() {
                return presentAddress;
        }

        public void setPresentAddress(String presentAddress) {
                this.presentAddress = presentAddress;
        }

        public String getAlternateEmail() {
                return alternateEmail;
        }

        public void setAlternateEmail(String alternateEmail) {
                this.alternateEmail = alternateEmail;
        }

        public String getAltMobile() {
                return altMobile;
        }

        public void setAltMobile(String altMobile) {
                this.altMobile = altMobile;
        }

        public String getTempAddressLine1() {
                return tempAddressLine1;
        }

        public void setTempAddressLine1(String tempAddressLine1) {
                this.tempAddressLine1 = tempAddressLine1;
        }

        public String getTempAddressLandmark() {
                return tempAddressLandmark;
        }

        public void setTempAddressLandmark(String tempAddressLandmark) {
                this.tempAddressLandmark = tempAddressLandmark;
        }

        public String getTempAddressSubDist() {
                return tempAddressSubDist;
        }

        public void setTempAddressSubDist(String tempAddressSubDist) {
                this.tempAddressSubDist = tempAddressSubDist;
        }

        public String getTempAddressDist() {
                return tempAddressDist;
        }

        public void setTempAddressDist(String tempAddressDist) {
                this.tempAddressDist = tempAddressDist;
        }

        public String getTempAddressState() {
                return tempAddressState;
        }

        public void setTempAddressState(String tempAddressState) {
                this.tempAddressState = tempAddressState;
        }

        public String getTempAddressPincode() {
                return tempAddressPincode;
        }

        public void setTempAddressPincode(String tempAddressPincode) {
                this.tempAddressPincode = tempAddressPincode;
        }

        public String getCustomerType() {
                return customerType;
        }

        public void setCustomerType(String customerType) {
                this.customerType = customerType;
        }

        public int getAgeInMonths() {
                return ageInMonths;
        }

        public void setAgeInMonths(int ageInMonths) {
                this.ageInMonths = ageInMonths;
        }

        public LocalDateTime getTimestamp() {
                return timestamp;
        }

        public void setTimestamp(LocalDateTime timestamp) {
                this.timestamp = timestamp;
        }

        public String getFullName() {
                return fullName;
        }

        public void setFullName(String fullName) {
                this.fullName = fullName;
        }

        public String getGender() {
                return gender;
        }

        public void setGender(String gender) {
                this.gender = gender;
        }

        public String getEmail() {
                return email;
        }

        public void setEmail(String email) {
                this.email = email;
        }

        public String getDateOfBirth() {
                return dateOfBirth;
        }

        public void setDateOfBirth(String dateOfBirth) {
                this.dateOfBirth = dateOfBirth;
        }

        public String getMobileNumber() {
                return mobileNumber;
        }

        public void setMobileNumber(String mobileNumber) {
                this.mobileNumber = mobileNumber;
        }

        public String getCareOf() {
                return careOf;
        }

        public void setCareOf(String careOf) {
                this.careOf = careOf;
        }

        public String getHouse() {
                return house;
        }

        public void setHouse(String house) {
                this.house = house;
        }

        public String getStreet() {
                return street;
        }

        public void setStreet(String street) {
                this.street = street;
        }

        public String getDistrict() {
                return district;
        }

        public void setDistrict(String district) {
                this.district = district;
        }

        public String getSubDistrict() {
                return subDistrict;
        }

        public void setSubDistrict(String subDistrict) {
                this.subDistrict = subDistrict;
        }

        public String getLandmark() {
                return landmark;
        }

        public void setLandmark(String landmark) {
                this.landmark = landmark;
        }

        public String getLocality() {
                return locality;
        }

        public void setLocality(String locality) {
                this.locality = locality;
        }

        public String getPostOfficeName() {
                return postOfficeName;
        }

        public void setPostOfficeName(String postOfficeName) {
                this.postOfficeName = postOfficeName;
        }

        public String getState() {
                return state;
        }

        public void setState(String state) {
                this.state = state;
        }

        public String getPincode() {
                return pincode;
        }

        public void setPincode(String pincode) {
                this.pincode = pincode;
        }

        public String getCountry() {
                return country;
        }

        public void setCountry(String country) {
                this.country = country;
        }

        public String getVtcName() {
                return vtcName;
        }

        public void setVtcName(String vtcName) {
                this.vtcName = vtcName;
        }

        public String getMobile() {
                return mobile;
        }

        public void setMobile(String mobile) {
                this.mobile = mobile;
        }

        public String getAadharAddress() {
                return aadharAddress;
        }

        public void setAadharAddress(String aadharAddress) {
                this.aadharAddress = aadharAddress;
        }

        public String getConsideringIncome() {
                return consideringIncome;
        }

        public void setConsideringIncome(String consideringIncome) {
                this.consideringIncome = consideringIncome;
        }

        public String getIncomeSourceType() {
                return incomeSourceType;
        }

        public void setIncomeSourceType(String incomeSourceType) {
                this.incomeSourceType = incomeSourceType;
        }

        public String getItrFilledForAnyYear() {
                return itrFilledForAnyYear;
        }

        public void setItrFilledForAnyYear(String itrFilledForAnyYear) {
                this.itrFilledForAnyYear = itrFilledForAnyYear;
        }

        public String getForm16Available() {
                return form16Available;
        }

        public void setForm16Available(String form16Available) {
                this.form16Available = form16Available;
        }

        public String getCrifFetched() {
                return crifFetched;
        }

        public void setCrifFetched(String crifFetched) {
                this.crifFetched = crifFetched;
        }

        public LocalDateTime getDeletedAt() {
                return deletedAt;
        }

        public void setDeletedAt(LocalDateTime deletedAt) {
                this.deletedAt = deletedAt;
        }

        public String getDeletedBy() {
                return deletedBy;
        }

        public void setDeletedBy(String deletedBy) {
                this.deletedBy = deletedBy;
        }

        public String getAgeInYears() {
                return ageInYears;
        }

        public void setAgeInYears(String ageInYears) {
                this.ageInYears = ageInYears;
        }

        public String getRelationWithApplicant() {
                return relationWithApplicant;
        }

        public void setRelationWithApplicant(String relationWithApplicant) {
                this.relationWithApplicant = relationWithApplicant;
        }

        public String getRelationWithApplicantOther() {
                return relationWithApplicantOther;
        }

        public void setRelationWithApplicantOther(String relationWithApplicantOther) {
                this.relationWithApplicantOther = relationWithApplicantOther;
        }
}
