package com.lotusCarVersion2.LotusCarVersion2.Config;

import lombok.Getter;
import org.springframework.stereotype.Component;

@Component
@Getter
public class AllStaticFields {

    public static String FILE_UPLOAD_DIR = "F:/CAR-LOAN-V2-DOCS/";

    //------------------ //CUSTOMER TYPE --------------------//

    public static String applicant = "APPLICANT";
    public static String coApplicant = "COAPPLICANT";
    public static String coApplicant1 = "COAPPLICANT1";
    public static String coApplicant2 = "COAPPLICANT2";
    public static String guarantor = "GUARANTOR";
    public static String borrowerCorp = "BORROWER";

    //------------------ // INCOME SOURCE TYPE --------------------//

    public static String salaried = "Salaried";
    public static String business = "Business";
    public static String pensioner = "Pensioner";
    public static String other = "Other";

    //------------------ //LOAN TYPE --------------------//

    public static String newPassengerCar = "Purchase of New Passenger Car";
    public static String newElectricPassengerCar = "Purchase of New Electric Passenger Car";

    //----------------- //BORROWER TYPE -------------------//

    public static String residentIndian = "Resident Indian Citizen";
    public static String nriOrPoi = "Non Resident Indian or Person of Indian Origin";
    public static String corporateClient = "Corporate Clients";


    //--------------//USER TYPE & USER LOC ----------------//
    //location
    public static String userLocBr = "BR";
    public static String userLocRo = "RO";
    public static String userLocHo = "HO";
    //type
    public static String userTypeOfficer = "OF";
    public static String userTypeBm = "BM";
    public static String userTypeCpcOf = "CPC_officer";
    public static String userTypeCpcHead = "CPC_head";
    public static String userTypeRm = "RM";
    public static String userTypeHoCreditOf = "HO_Credit_Officer";
    public static String userTypeCm = "CM";

    //--------------//APPLICATION STATUS ----------------//
    public static String pendingStatus = "PEN";
    public static String recommendedStatus = "REC";
    public static String returnedStatus = "RET";
    public static String rejectedStatus = "REJ";
    public static String sanctionedStatus = "SAN";
    public static String deviationStatus = "DEV";
}