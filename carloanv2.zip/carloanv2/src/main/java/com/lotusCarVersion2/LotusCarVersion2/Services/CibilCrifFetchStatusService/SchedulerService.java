package com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService;

import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifStatus.CibilCrifFetchStatusEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifFetchStatus.CibilCrifFetchStatusRepo;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
@Transactional
public class SchedulerService {

    private final CibilCrifFetchStatusRepo cibilCrifFetchStatusRepo;


    public String ResetFlagsOfCibilAndCrif() {

        System.out.println("//----------------------------------- INSIDE CIBIL-CRIF FLAG RESET SERVICE METHOD. -------------------------------------//");
        LocalDate today = LocalDate.now();
        System.out.println("TODAY'S DATE IS: "+today);
        // Check if today is the 10th
        if (today.getDayOfMonth() == 10) {
            List<CibilCrifFetchStatusEntity> allEntities;
            // Fetch all records
            try {
                allEntities = cibilCrifFetchStatusRepo.getAllCibilCrifFlagResetEntities();
                System.out.println("COUNT OF ALL RETRIEVED STATUS ENTITY WHICH WILL BE RESET :"+allEntities.size());
            }catch (Exception e){
                e.printStackTrace();
                System.err.println("ERROR WHILE RETRIEVING LIST OF CibilCrifFetchStatusEntity TO RESET FLAGS :"+e.getMessage());
                throw new RuntimeException("ERROR WHILE RETRIEVING LIST OF CibilCrifFetchStatusEntity TO RESET FLAGS :"+e.getMessage());
            }
            for (CibilCrifFetchStatusEntity entity : allEntities) {
                //CIBIL FLAGS
                entity.setApplicantCibilFetched(false);
                entity.setCoappIncomeCibilFetched(false);
                entity.setCoappNonIncomeCibilFetched(false);
                entity.setGuarantorCibilFetched(false);

                //CRIF FLAGS
                entity.setApplicantCrifFetched(false);
                entity.setCoappIncomeCrifFetched(false);
                entity.setCoappNonIncomeCrifFetched(false);
                entity.setGuarantorCrifFetched(false);

                //otherFlags
                entity.setAllCibilFetched(false);
                entity.setAllCrifFetched(false);
                entity.setAllCibilCrifUptodate(false);


                // Update last reset date
                entity.setLastResetDate(LocalDateTime.now());
                cibilCrifFetchStatusRepo.save(entity);
                System.out.println("CIBIL CRIF FLAG RESET, REF-ID :"+entity.getReferenceId());
            }
            System.out.println("//------------------------------------✅  CIBIL CRIF FLAG RESET:Flags have been reset to default values. -----------------------------------------------//");
            return "✅  CIBIL CRIF FLAG RESET:Flags have been reset to default values.";
        }
        System.out.println("//------------------------------------ CIBIL CRIF FLAG RESET:Reset can only be performed on the 10th of the month. ------------------------------------//");
        return "CIBIL CRIF FLAG RESET:Reset can only be performed on the 10th of the month.";
    }
    }


