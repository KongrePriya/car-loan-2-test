package com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeMainList;



import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeMainList.IncomeMainListModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessMain.IncomeBusinessMainHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessMain.IncomeBusinessMainRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeMainList.IncomeMainListRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomePension.IncomePensionHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomePension.IncomePensionRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeSalary.IncomeSalaryHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeSalary.IncomeSalaryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeBusiness.IncomeBusinessService;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomePension.IncomePensionService;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeSalary.IncomeSalaryService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class IncomeMainListServiceImpl implements IncomeMainListService {


    @Autowired
    private IndividualBasicDetailsRepo applicantCoappGuarantorRepo;
    @Autowired
    private IncomeBusinessMainRepo incomeBusinessMainRepo;
    @Autowired
    private IncomeBusinessMainHistoryRepo incomeBusinessMainHistoryRepo;
    @Autowired
    private IncomeSalaryRepo incomeSalaryRepo;
    @Autowired
    private IncomeSalaryHistoryRepo incomeSalaryHistoryRepo;
    @Autowired
    private IncomePensionRepo incomePensionRepo;
    @Autowired
    private IncomePensionHistoryRepo incomePensionHistoryRepo;
    @Autowired
    private IncomeMainListRepo incomeMainListRepo;

    @Autowired
    private IncomeSalaryService incomeSalaryService;
    @Autowired
    private IncomePensionService incomePensionService;
    @Autowired
    private IncomeBusinessService incomeBusinessService;
//    @Autowired
//    private CalculationRawDataService calculationRawDataService;


    @Override
    @Transactional
    public List<IncomeMainListModel> getIncomeList(String referenceId) {

        try {
            List<IndividualBasicDetailsEntity> applicantCoappGuarantorBasicEntityList = applicantCoappGuarantorRepo.getAllApplicantCoappConsiderIncome(referenceId);
            List<IncomeMainListModel> foundRecords = incomeMainListRepo.findAllByReferenceId(referenceId);

            Set<String> applicantArrayToSet = applicantCoappGuarantorBasicEntityList.stream().map(IndividualBasicDetailsEntity::getPan).collect(Collectors.toSet());
            List<IncomeMainListModel> missingRecords =
                    foundRecords.stream()
                            .filter(myRecord -> !applicantArrayToSet.contains(myRecord.getPan()))
                            .toList();

//--------------------------------- Delete Missing Record -----------------------------------//

            if(!missingRecords.isEmpty()){
                System.out.println("missing Income Record" + missingRecords);
                deleteMissingOrChangedRecords(missingRecords);
            }


            List<IncomeMainListModel> changedIncomeTypeArray = new ArrayList<>();
            for (IncomeMainListModel incomeListFoundEntry : foundRecords) {
                if (applicantCoappGuarantorBasicEntityList.stream().anyMatch(
                        appCoAppNewEntry -> appCoAppNewEntry.getPan().equalsIgnoreCase(incomeListFoundEntry.getPan()) &&
                                !appCoAppNewEntry.getIncomeSourceType().equalsIgnoreCase(incomeListFoundEntry.getIncomeSourceType()))) {
                    changedIncomeTypeArray.add(incomeListFoundEntry);
                }
            }
//--------------------------------- Delete Changed Record -----------------------------------//
            if(!changedIncomeTypeArray.isEmpty()){
                System.out.println("changed Income Record" + changedIncomeTypeArray);
                deleteMissingOrChangedRecords(changedIncomeTypeArray);
            }



//-------------------------------- Delete Previous Income List ------------------------------//
            try {
                incomeMainListRepo.deleteAll(foundRecords);
            } catch (Exception e) {
                throw new RuntimeException("Error Deleting Income List" + e);
            }


            List<IncomeMainListModel> incomeMainListModelArray = new ArrayList<>();
            for (IndividualBasicDetailsEntity applicantCoappGuarantorBasicEntity : applicantCoappGuarantorBasicEntityList) {
                IncomeMainListModel incomeMainListModel = new IncomeMainListModel();

                incomeMainListModel.setReferenceId(applicantCoappGuarantorBasicEntity.getReferenceId());
                incomeMainListModel.setFullName(applicantCoappGuarantorBasicEntity.getFullName());
                incomeMainListModel.setPan(applicantCoappGuarantorBasicEntity.getPan());
                incomeMainListModel.setCustomerType(applicantCoappGuarantorBasicEntity.getCustomerType());
                incomeMainListModel.setIncomeSourceType(applicantCoappGuarantorBasicEntity.getIncomeSourceType());
                incomeMainListModel.setConsideringIncome(applicantCoappGuarantorBasicEntity.getConsideringIncome());
                incomeMainListModel.setCreatedDate(LocalDateTime.now());
                incomeMainListModelArray.add(incomeMainListModel);

            }

            incomeMainListRepo.saveAll(incomeMainListModelArray);
            return incomeMainListModelArray;
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred In Income List " + e);
        }
    }


    //    -------------------- Match Count To Enable/Disable Next Button On Frontend ------------------- //
    @Override
    public String matchCountIncomeDataForProceeding(String referenceId) {
        try {
            String countMatch = "";
            IndividualBasicDetailsEntity applicantCoAppList = new IndividualBasicDetailsEntity();
            List<IndividualBasicDetailsEntity> applicantCoappGuarantorBasicEntityList = applicantCoappGuarantorRepo.getAllApplicantCoappConsiderIncome(referenceId);

            Integer countApplicantCoApp = applicantCoappGuarantorBasicEntityList.size();
            Integer countSalary = incomeSalaryRepo.countIncomeSalary(referenceId);
            Integer countPension = incomePensionRepo.countIncomePension(referenceId);
            Integer countBusiness = incomeBusinessMainRepo.countIncomeBusiness(referenceId);

            System.out.println("Salary" +countSalary);
            System.out.println("Pension" +countPension);
            System.out.println("Business" +countBusiness);
            System.out.println("App CoApp count" +countApplicantCoApp);

            Integer totalIncomeCount = countSalary + countPension + countBusiness;
            if(countApplicantCoApp >= 1){
                if (countApplicantCoApp.equals(totalIncomeCount)) {
                    countMatch = "yes";
                } else {
                    countMatch = "no";
                }
            }else {
                countMatch = "no";
            }

            return countMatch;
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred While Getting Count Income" + e);
        }
    }

    @Override
    @Transactional
    public void deleteMissingOrChangedRecords(List<IncomeMainListModel> missingOrChangedIncomeMainListModel) {
        try {
            for (IncomeMainListModel missingOrChangedRecord : missingOrChangedIncomeMainListModel) {
                if (missingOrChangedRecord.getIncomeSourceType().equalsIgnoreCase("Salaried")) {
                    System.out.println("In Income List Delete Service - Salary");
                    if(incomeSalaryRepo.existsByReferenceIdAndPanNumber(missingOrChangedRecord.getReferenceId(), missingOrChangedRecord.getPan())){
                        incomeSalaryService.deleteIncomeSalaryAndSaveToHistory(missingOrChangedRecord.getReferenceId(), missingOrChangedRecord.getPan());
                    }
                }
                if (missingOrChangedRecord.getIncomeSourceType().equalsIgnoreCase("Business")) {
                    System.out.println("In Income List Delete Service - Business");
                    if(incomeBusinessMainRepo.existsByReferenceIdAndPanNumber(missingOrChangedRecord.getReferenceId(),missingOrChangedRecord.getPan())){
                        incomeBusinessService.deleteIncomeBusinessAndSaveToHistory(missingOrChangedRecord.getReferenceId(), missingOrChangedRecord.getPan());
                    }
                }
                if (missingOrChangedRecord.getIncomeSourceType().equalsIgnoreCase("Pensioner")) {
                    System.out.println("In Income List Delete Service - Pension");
                    if(incomePensionRepo.existsByReferenceIdAndPanNumber(missingOrChangedRecord.getReferenceId(),missingOrChangedRecord.getPan())){
                        incomePensionService.deleteIncomePensionAndSaveToHistory(missingOrChangedRecord.getReferenceId(), missingOrChangedRecord.getPan());
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred While Deleting Missing Or Changed Income Record " + e);
        }
    }

    @Override
    public String redirectToDeleteIncomeData(String referenceId, String pan, String incomeType) {

        System.out.println("INSIDE redirectToDeleteIncomeData , FOR PAN : "+pan +"\n referenceID : "+referenceId + "\n income-type : "+incomeType);
        switch (incomeType){
            case "Salaried":
                incomeSalaryService.deleteIncomeSalaryAndSaveToHistory(referenceId,pan);
                break;
            case "Business" :
                incomeBusinessService.deleteIncomeBusinessAndSaveToHistory(referenceId,pan);
                break;
            case "Pensioner" :
                incomePensionService.deleteIncomePensionAndSaveToHistory(referenceId,pan);
                break;
            default:
                System.out.println("INCOME TYPE NOT MATCHING.");
                break;
        }
//        calculationRawDataService.redirectToSaveIncomeData(referenceId);

        return "";
    }
}
