package com.lotusCarVersion2.LotusCarVersion2.Controller.CibilFetchStatus;

import com.lotusCarVersion2.LotusCarVersion2.DTO.CibilCrifFetchedStatusDto;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusServiceImpl;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.SchedulerService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@AllArgsConstructor
@RequestMapping("/api/v1/cibil-status")
public class CibilFetchStatusController {

    private final CibilCrifFetchStatusServiceImpl cibilCrifFetchStatusService;
    private final SchedulerService schedulerService;
//**********************************************************************************************************//
@GetMapping("/{referenceId}")
public ResponseEntity<CibilCrifFetchedStatusDto> getCibilCrifStatusFlagsDetails(@PathVariable("referenceId") String referenceId) {

    cibilCrifFetchStatusService.callAllStatusFunctions(referenceId);
    CibilCrifFetchedStatusDto cibilCrifFetchedStatusDto = cibilCrifFetchStatusService.getFetchStatusCibilCrif(referenceId);
    if (cibilCrifFetchedStatusDto != null) {
        return new ResponseEntity<>(cibilCrifFetchedStatusDto, HttpStatus.OK);
    } else {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
//**********************************************************************************************************//
@GetMapping("/test/{referenceId}")
public CibilCrifFetchedStatusDto testCibilCrifStatusFlagsDetails(@PathVariable("referenceId") String referenceId) {

   return cibilCrifFetchStatusService.callAllStatusFunctions(referenceId);

}
//**********************************************************************************************************//

// RESET ALL FLAGS MANUALLY
@GetMapping("/scheduler")
public ResponseEntity<?> RunSchedulerToResetFlags(){

    String result = schedulerService.ResetFlagsOfCibilAndCrif();
    return ResponseEntity.ok(result);
}
//**************************************************************************************************//
}
