package com.lotusCarVersion2.LotusCarVersion2.Models.ProductCode;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class ProductCodeModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private String productCode;
    private String productDescription;
    private BigDecimal rateOfInterest;
    private String insertedDate;
    private String borrowerType;
    private String loanType;

}
