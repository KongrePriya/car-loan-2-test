package com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsCommercial;

import com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsCommercial.CibilCommScreen1BasicDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommercialCibilbasicDetailsRepo extends JpaRepository<CibilCommScreen1BasicDetailsEntity, Long>{

    //************ BASIC DETAILS **********// for jasper appraisal note
    @Query(nativeQuery = true, value = "SELECT * FROM cibil_commercial.cibil_commercial_screen_basic_details " +
        " WHERE old_record IS NULL AND reference_id = :referenceId ORDER BY  corporate_type,date_of_fetching ASC ")
    List<CibilCommScreen1BasicDetailsEntity> cibilCommBasicDetailsScreen1(String referenceId);

    //************ CHANGE EXISTING ENTRIES STATUS TO OLD WHEN GUARANTOR DELETED **********//
    @Modifying
    @Query(nativeQuery = true, value = "UPDATE cibil_commercial.cibil_commercial_screen_basic_details SET old_record='OLD' " +
            "WHERE customer_pan= :panCard AND corporate_type='GUARANTOR' AND reference_id = :referenceId")
    int updateCibilStatusOldWhenDeleted(String panCard, String referenceId);


}


