package com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsPersonal;

import com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsIndividual.ScreenCibilHistoryDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CibilHistoryDetailsRepo extends JpaRepository<ScreenCibilHistoryDetails, Long>{


    //*********************** HISTORY DETAILS **********// for jasper appraisal note
    @Query(nativeQuery = true, value = "SELECT * FROM cibil_personal.screen_personal_cibil_history_details " +
            " WHERE old_record IS NULL AND customer_pan= :panCard AND reference_id= :referenceId ORDER BY date_of_fetching ASC ")
    List<ScreenCibilHistoryDetails> cibilPersonalHistoryDetailsScreen1(String referenceId,String panCard);

    //************************ CHANGE EXISTING ENTRIES STATUS TO OLD WHEN BORROWER/GUARANTOR DELETED **********//
    @Modifying
    @Query(nativeQuery = true, value = "UPDATE cibil_personal.screen_personal_cibil_history_details SET old_record='OLD' " +
            " WHERE customer_pan= :panCard AND reference_id = :referenceId")
    int updatePersonalCibilStatusOldWhenDeleted(String panCard, String referenceId);

    //*********************** HISTORY DETAILS **********// for jasper appraisal note
    @Query(nativeQuery = true, value = "SELECT * FROM cibil_personal.screen_personal_cibil_history_details " +
            " WHERE old_record IS NULL  AND reference_id= :referenceId ORDER BY date_of_fetching ASC ")
    List<ScreenCibilHistoryDetails> cibilPersonalHistoryDetailsAll(String referenceId);


}


