package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessMain;

import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainHistoryModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncomeBusinessMainHistoryRepo extends JpaRepository<IncomeBusinessMainHistoryModel,Long> {
}
