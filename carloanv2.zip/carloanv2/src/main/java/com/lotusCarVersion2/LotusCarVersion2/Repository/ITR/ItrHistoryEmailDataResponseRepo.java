package com.lotusCarVersion2.LotusCarVersion2.Repository.ITR;

import com.lotusCarVersion2.LotusCarVersion2.Models.ITR.ItrHistoryEmailVerifiedResponseEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface ItrHistoryEmailDataResponseRepo extends JpaRepository<ItrHistoryEmailVerifiedResponseEntity, Long> {

//************** //To copy entry of ITR Reference-ID Verified Response  to history table when Borrower/guarantor Deleted *************//
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO kyc_itr.screen_itr_email_ref_id_generated_response_history " +
            "(reference_id_itr, reference_id_lotus, fetched_by, branch_code, customer_type, fetch_date, user_email_id, consent_provided, refetched_at, refetched_by) " +
            "SELECT reference_id_itr, reference_id_lotus, fetched_by, branch_code, customer_type, fetch_date, user_email_id, consent_provided, NOW(), :refetchedBy " +
            "FROM kyc_itr.screen_itr_email_ref_id_generated_response " +
            "WHERE reference_id_lotus = :referenceIdLotus AND customer_type = :customerType", nativeQuery = true)
    int moveToITRRefIdResponseHistory(String referenceIdLotus, String customerType, String refetchedBy);
}
