package com.lotusCarVersion2.LotusCarVersion2.Repository.CRIFRemark;


import com.lotusCarVersion2.LotusCarVersion2.Models.CRIFRemark.CrifRemarkModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.CrifIndividualRequest.CrifFetchList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface CrifRemarkRepo extends JpaRepository<CrifRemarkModel,Long> {

    CrifRemarkModel findByReferenceId(String ReferenceId);

    boolean existsByReferenceId(String referenceId);


//    CrifRemarkModel findByReferenceIdAndRemarkStatusNull(String referenceId);


//***********************************************************************************************************************//
//01/01/2025 : To set OLD flag only for application which are in process.
    @Query(value = """
            SELECT * FROM los_gst.cibil_and_crif_remark c,los_gst.gst_application_status s WHERE c.reference_id=s.reference_id
            	AND s.appln_status_main NOT IN ('SAN','REJ')""", nativeQuery = true)
    List<CrifRemarkModel> getAllListToMarkAsOLD();



    //------------------------------- CRIF "FETCH BUTTON" VALIDATION IN FRONTEND -----------------------------//
    //@Query(value = "SELECT * FROM crif_individual_home.std_crif_summary_model WHERE individual_pan=:individual_pan AND reference_id=:reference_id", nativeQuery = true)
    @Query(value = "SELECT individual_pan, reference_id FROM crif_individual_home.std_crif_summary_model WHERE individual_pan=:individual_pan AND reference_id=:reference_id;", nativeQuery = true)
    CrifFetchList getCrifFetchedValidationData(String individual_pan, String reference_id);
}
