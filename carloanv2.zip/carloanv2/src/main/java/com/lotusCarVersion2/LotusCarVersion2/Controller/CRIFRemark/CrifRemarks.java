package com.lotusCarVersion2.LotusCarVersion2.Controller.CRIFRemark;


import com.lotusCarVersion2.LotusCarVersion2.Models.CRIFRemark.CrifRemarkModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CRIFRemark.CrifRemarkRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.CRIFRemark.CrifRemarkService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
//@RequiredArgsConstructor
@RequestMapping("/api/v1/crif-remark")
public class CrifRemarks {

    @Autowired
    private CrifRemarkService cibilAndCrifRemarkService;

    @Autowired
    private CrifRemarkRepo cibilAndCrifRemarkRepo;

    //**********************************************************************************************************************************************************************************
    // ***************** API TO INSERT OR UPDATE REMARKS ***************************************************************************************************************************
    @PostMapping("/update")
    public ResponseEntity<String> saveOrUpdateRemarks(@Validated @RequestBody CrifRemarkModel crifRemarkData) {

            String updateRemark = cibilAndCrifRemarkService.saveRemark(crifRemarkData);
            return new ResponseEntity<String>("CRIF REMARKS OF REFERENCE_ID: " + crifRemarkData.getReferenceId() +  " Saved SUCCESSFULLY.", HttpStatus.OK);


    }

//*******************************************************************************************************************************************************************

    // ********************** API TO GET CIBIL AND CRIF REMARKS OF REFERENCE ID **************************************************************************************
    @GetMapping("/get/{referenceId}")
    public ResponseEntity<CrifRemarkModel> getCibilAndCrifRemarks(@PathVariable String referenceId){

        System.out.println("IN GET API METHOD ");
        CrifRemarkModel cibilAndCrifRemark= cibilAndCrifRemarkService.getCrifRemarksByRefId(referenceId);

        return new ResponseEntity<>(cibilAndCrifRemark,HttpStatus.OK);

    }




}
