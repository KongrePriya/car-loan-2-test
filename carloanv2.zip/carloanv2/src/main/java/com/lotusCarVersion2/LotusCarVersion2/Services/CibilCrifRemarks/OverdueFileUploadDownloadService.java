package com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifRemarks;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifRemark.CibilCrifRemarkEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifRemark.CibilCrifRemarkRepo;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;

@Service
@AllArgsConstructor
public class OverdueFileUploadDownloadService {

    private final CibilCrifRemarkRepo cibilCrifRemarkRepo;
    private final CibilCrifRemarkService cibilCrifRemarkService;

//*********************************************************************************************************//
// STEP-1:  method to save PDF files to the directory with new names
    public String saveFileToDirectory(MultipartFile file, String referenceId) throws IOException {
        // Construct a new file name: brCode+ accountNumber + fileType + .pdf
        String newFileName = referenceId+"_overdue_certificate.pdf";
        try {
            Path filePath = Paths.get(AllStaticFields.FILE_UPLOAD_DIR + newFileName);

            // Save the file, replacing if it already exists
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            // Return the new file name
            return newFileName;

        }catch (IOException e) {
            e.printStackTrace();
            System.err.println("ERROR WHILE SAVING FILE : "+newFileName+ " Error Details: "+e.getMessage());
            throw new RuntimeException("ERROR WHILE SAVING FILE : "+newFileName+ " Error Details: "+e.getMessage());
        }
    }
//**********************************************************************************************************//
    //single file save in table
    @Transactional
    public CibilCrifRemarkEntity saveFileNamesInTable(String referenceId, String userId, String fileName) {

        CibilCrifRemarkEntity entity = cibilCrifRemarkService.checkOrCreateCibilCrifRemarkEntity(referenceId);

        entity.setOverdueClearanceCertificateName(fileName);
        entity.setOverdueClearanceCertificateDate(LocalDateTime.now());
        entity.setOverdueClearanceCertificateUploadedBy(userId);

        return cibilCrifRemarkRepo.save(entity);
    }

//**********************************************************************************************************//
    //Fetches a file  for preview (i.e., displayed in the browser).
    public ResponseEntity<Resource> previewFile(String referenceId) {

        CibilCrifRemarkEntity entity = cibilCrifRemarkRepo.findByReferenceIdAndRemarkStatusNull(referenceId);

        System.out.println("FILENAME TO PREVIEW: "+entity.getOverdueClearanceCertificateName());
        try {
            // Load the file as a Resource
            Resource resource = loadFileAsResource(entity.getOverdueClearanceCertificateName());

            String contentType = Files.probeContentType(Paths.get(AllStaticFields.FILE_UPLOAD_DIR + entity.getOverdueClearanceCertificateName()));

            // Return the file as response to be previewed (e.g., in the browser)
            return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType)).body(resource);

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("ERROR WHILE PREVIEW FILE : "+entity.getOverdueClearanceCertificateName()+ " Error Details: "+e.getMessage());
            throw new RuntimeException("ERROR WHILE PREVIEW FILE : "+entity.getOverdueClearanceCertificateName()+ " Error Details: "+e.getMessage());
        }
    }
//**********************************************************************************************************//
public ResponseEntity<Resource> downloadFile(String referenceId) {

    CibilCrifRemarkEntity entity = cibilCrifRemarkRepo.findByReferenceIdAndRemarkStatusNull(referenceId);

    // Dynamically create the file name based on account number, branch code, and file type
    String fileName = entity.getOverdueClearanceCertificateName();
    System.out.println("FILENAME TO DOWNLOAD: " + fileName);
    try {
        // Load the file as a Resource from the directory
        Resource resource = loadFileAsResource(fileName);

        // Detect the file type (e.g., PDF, Image, etc.)
        String contentType = Files.probeContentType(Paths.get(AllStaticFields.FILE_UPLOAD_DIR + fileName));

        // Set headers to force file download, including the dynamically created file name
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))  // Set the content type of the file
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"") // Set the download file name
                .body(resource);  // Send the file content

    } catch (IOException e) {
        e.printStackTrace();
        System.err.println("ERROR WHILE DOWNLOADING FILE: " + fileName + " Error Details: " + e.getMessage());
        throw new RuntimeException("ERROR WHILE DOWNLOADING FILE: " + fileName + " Error Details: " + e.getMessage());
    }
}

//**********************************************************************************************************//
// method to load a file from the filesystem as a resource.
    private Resource loadFileAsResource(String fileName) throws IOException {

        Path filePath = Paths.get(AllStaticFields.FILE_UPLOAD_DIR + fileName);
        System.out.println("FILE_UPLOAD_DIR = " + AllStaticFields.FILE_UPLOAD_DIR);
        System.out.println("Constructed file name: " + fileName);
        System.out.println("Resolved full file path: " + filePath.toString());

        // Check if file exists, otherwise throw exception
        if (!Files.exists(filePath)) {
            throw new IOException("File not found: " + fileName);
        }

        // Return the file as a resource
        return new FileSystemResource(filePath);
    }
//**********************************************************************************************************//
}
