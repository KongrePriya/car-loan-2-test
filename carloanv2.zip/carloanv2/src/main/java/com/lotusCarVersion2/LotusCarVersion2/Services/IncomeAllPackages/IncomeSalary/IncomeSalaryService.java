package com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeSalary;


import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryModel;

public interface IncomeSalaryService {


    String postIncomeSalary(IncomeSalaryModel incomeSalaryModel);
    IncomeSalaryModel getIncomeSalary(String referenceId, String panNumber);

    void deleteIncomeSalaryAndSaveToHistory(String referenceId, String panNumber);
}
