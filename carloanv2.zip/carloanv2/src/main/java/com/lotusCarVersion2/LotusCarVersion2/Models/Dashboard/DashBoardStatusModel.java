package com.lotusCarVersion2.LotusCarVersion2.Models.Dashboard;

import jakarta.persistence.Id;
import lombok.Data;

@Data
public class DashBoardStatusModel {
    @Id
    long id;
    private String statusRecommended;
    private String statusPending;
    private String statusSanctioned;
    private String statusReturn;
    private String statusReject;
    private String statusDeviation;
    private String branchCode;

}
