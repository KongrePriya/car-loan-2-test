package com.lotusCarVersion2.LotusCarVersion2.Controller.CommercialCibil;

import com.lotusCarVersion2.LotusCarVersion2.Config.CibilConfig;
import com.lotusCarVersion2.LotusCarVersion2.DTO.CorporateGuarantorDto;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@RestController
@AllArgsConstructor
@CrossOrigin
@RequestMapping("/api/v1/com-cibil/guarantor")
public class GuarantorsCommercialCIBILController {

    @Autowired
    private final RestTemplate restTemplate;
    private final CibilCrifFetchStatusService cibilCrifFetchStatusService;

//*************************************************** TO FETCH CIBIL OF SINGLE Corporate Guarantors **************************************************************//
// api to fetch for single guarantor is only used to fetch directly but not used while
// fetching cibil while saving data: as while saving I have called a service method:-FetchCommercialCibilService

    @PostMapping("/fetch-single")
    public ResponseEntity<String> fetchCommercialCibilSingleGuarantor(@Valid @RequestBody CorporateGuarantorDto corpGuarantorSingleDto) {

        cibilCrifFetchStatusService.corpGuarCibilFetchedCountStatus(corpGuarantorSingleDto.getReferenceId());

        String commercialCibilFetchUrl = CibilConfig.CommercialCibilIP +"/commercial-cibil/fetch/guarantor";
        System.out.println("COMMERCIAL CIBIL, inside fetchCommercialCibil- Single Guarantor LOS-GST, URL:"+commercialCibilFetchUrl);


        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));


        System.out.println(" COMMERCIAL CIBIL, header: "+headers);
        HttpEntity<CorporateGuarantorDto> requestEntity = new HttpEntity<>(corpGuarantorSingleDto, headers);

        System.out.println("COMMERCIAL CIBIL REQUEST ENTITY:"+ requestEntity.getBody());

        ResponseEntity<String> responseEntity = restTemplate.exchange(
                commercialCibilFetchUrl,
                HttpMethod.POST,
                requestEntity,
                String.class);
        System.out.println("COMMERCIAL CIBIL RESPONSE STATUS CODE: " + responseEntity.getStatusCode());
        System.out.println("COMMERCIAL CIBIL RESPONSE FROM CIBIL-COMMERCIAL PROJECT:"+responseEntity.getBody());
        return responseEntity;
    }

//******************************************* TO FETCH CIBIL OF List of Corporate Guarantors **********************************************************************//
    @PostMapping("/fetch-all")
//    public ResponseEntity<?> fetchGuarantorsCommercialCibil(@RequestBody List<CorporateGuarantorDto> corporateGuarantorDtoList) {
//        System.out.println("inside fetchGuarantorsCommercialCibil LOS-GST");
//
//        cibilCrifFetchStatusService.corpGuarCibilFetchedCountStatus(corporateGuarantorDtoList.get(0).getReferenceId());
//
//        String commercialCibilFetchUrl =CibilConfig.CommercialCibilIP +"/commercial-cibil/fetch/guarantors-list";
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
//
//        HttpEntity<List<CorporateGuarantorDto>> requestEntity = new HttpEntity<>(corporateGuarantorDtoList, headers);
//
//        ResponseEntity<Object> commCibilResponseEntity = null;
//        try {
//            commCibilResponseEntity = restTemplate.exchange(
//                    commercialCibilFetchUrl,
//                    HttpMethod.POST,
//                    requestEntity,
//                    Object.class
//            );
//            System.out.println("commCibilResponseEntity :"+ commCibilResponseEntity);
//            if (commCibilResponseEntity.getStatusCode() == HttpStatus.OK) {
//                cibilCrifFetchStatusService.corpGuarCibilFetchedCountStatus(corporateGuarantorDtoList.get(0).getReferenceId());
//                return ResponseEntity.ok(commCibilResponseEntity.getBody().toString());
//            }
//            else {
////                cibilCrifFetchStatusService.updateCorpGuarCibilStatus(corporateGuarantorDtoList.get(0).getReferenceId());
//                return ResponseEntity.status(commCibilResponseEntity.getStatusCode())
//                        .body("COMMERCIAL CIBIL: Failed to fetch for GUARANTOR.");
//            }
//        }catch (HttpClientErrorException.Forbidden e) {
//            // 403 Forbidden error
//            System.err.println("COMMERCIAL CIBIL: HTTP 403 Forbidden Error: " + e.getRawStatusCode() + " - " + e.getResponseBodyAsString());
//            return ResponseEntity.status(HttpStatus.FORBIDDEN)
//                    .body("Forbidden: " + e.getMessage());
//        } catch (HttpClientErrorException e) {
//            // Other HttpClientErrorException
//            System.err.println("COMMERCIAL CIBIL: HTTP Error: " + e.getRawStatusCode() + " - " + e.getResponseBodyAsString());
//            return ResponseEntity.status(e.getStatusCode())
//                    .body("COMMERCIAL CIBIL: Failed to communicate with external API: " + e.getMessage());
//        } catch (Exception e) {
//            e.printStackTrace();
//            System.err.println("COMMERCIAL CIBIL:Failed to communicate with external API: " + e.getMessage());
//            return ResponseEntity.status(commCibilResponseEntity.getStatusCode())
//                    .body("COMMERCIAL CIBIL:Failed to communicate with external API: " + e.getMessage());
//        }
//    }

    public ResponseEntity<String> fetchGuarantorsCommercialCibil(@RequestBody List<CorporateGuarantorDto> corporateGuarantorDtoList) {
        System.out.println("inside fetchGuarantorsCommercialCibil LOS-GST");

        // Update fetch count status
        cibilCrifFetchStatusService.corpGuarCibilFetchedCountStatus(corporateGuarantorDtoList.get(0).getReferenceId());

        String commercialCibilFetchUrl = CibilConfig.CommercialCibilIP + "/commercial-cibil/fetch/guarantors-list";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        HttpEntity<List<CorporateGuarantorDto>> requestEntity = new HttpEntity<>(corporateGuarantorDtoList, headers);

        ResponseEntity<String> commCibilResponseEntity = null;
        try {
            // Expect plain text response
            commCibilResponseEntity = restTemplate.exchange(
                    commercialCibilFetchUrl,
                    HttpMethod.POST,
                    requestEntity,
                    String.class
            );
            System.out.println("commCibilResponseEntity: " + commCibilResponseEntity);

            if (commCibilResponseEntity.getStatusCode() == HttpStatus.OK) {
                System.out.println("COMMERCIAL CIBIL:-CIBIL OF ALL GUARANTORS FETCHED SUCCESSFULLY IN LOS-GST.");
                cibilCrifFetchStatusService.corpGuarCibilFetchedCountStatus(corporateGuarantorDtoList.get(0).getReferenceId());
                return ResponseEntity.ok(commCibilResponseEntity.getBody());
            } else {
                //  non-200 responses
                return ResponseEntity.status(commCibilResponseEntity.getStatusCode())
                        .body("COMMERCIAL CIBIL: Failed to fetch for GUARANTOR.");
            }
        } catch (HttpClientErrorException.Forbidden e) {
            // 403 Forbidden error
            System.err.println("COMMERCIAL CIBIL: HTTP 403 Forbidden Error: " + e.getRawStatusCode() + " - " + e.getResponseBodyAsString());
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Forbidden: " + e.getMessage());
        } catch (HttpClientErrorException e) {
            // Other HttpClientErrorException
            System.err.println("COMMERCIAL CIBIL: HTTP Error: " + e.getRawStatusCode() + " - " + e.getResponseBodyAsString());
            return ResponseEntity.status(e.getStatusCode())
                    .body("COMMERCIAL CIBIL: Failed to communicate with external API: " + e.getMessage());
        } catch (Exception e) {
            // general exceptions
            e.printStackTrace();
            System.err.println("COMMERCIAL CIBIL: Failed to communicate with external API: " + e.getMessage());
            HttpStatus status = (commCibilResponseEntity != null) ? (HttpStatus) commCibilResponseEntity.getStatusCode() : HttpStatus.INTERNAL_SERVER_ERROR;
            return ResponseEntity.status(status)
                    .body("COMMERCIAL CIBIL: Failed to communicate with external API: " + e.getMessage());
        }
    }

//*****************************************************************************************************************//
    //SCREEN 1: BASIC CIBIL DETAILS OF GUARANTORS (ALL)
    @GetMapping("/basic/{referenceId}")
    public List<Object> ScreenBasicDetails(@PathVariable String referenceId){
        String basicDetailsUrl = CibilConfig.CommercialCibilIP +"/commercial-cibil/guarantor/basic-details/"+ referenceId;
        try {
            Object[] result = restTemplate.getForObject(basicDetailsUrl, Object[].class);
            System.out.println("IN LOS-GST: CORPORATE GUARANTOR'S CIBIL BASIC DETAILS- LENGTH : " + result.length);
            return Arrays.asList(result);
        }catch (RestClientException e) {
            System.err.println("IN LOS-GST: CORPORATE GUARANTOR'S CIBIL: ERROR FETCHING BASIC DETAILS: "+e.getMessage());
            e.printStackTrace();
            throw new RestClientException(e.getMessage());
        }
    }

//*****************************************************************************************************************//
    //SCREEN 2: CIBIL HISTORY DETAILS OF GUARANTORS (ALL)
    @GetMapping("/history/{referenceId}")
    public ResponseEntity<List<Object>> ScreenHistoryDetails(@PathVariable String referenceId){

        //  String historyDetailsUrl = commercialCibilBaseUrl +"history-details/"+ referenceId;
        String historyDetailsUrl = CibilConfig.CommercialCibilIP +"/commercial-cibil/guarantor/new-history-details/"+ referenceId;
       try {
           Object[] historyResult = restTemplate.getForObject(historyDetailsUrl, Object[].class);
//           return Arrays.asList(historyResult);
//           if(historyResult !=null){
//               return Arrays.asList(historyResult);
//           }else{
//               return (List<Object>) ResponseEntity.status(HttpStatus.NO_CONTENT);
//           }

           if (historyResult == null || historyResult.length == 0) {

               return ResponseEntity.status(HttpStatus.NO_CONTENT).body(Collections.emptyList());
           } else {
               System.out.println("IN LOS-GST: CORPORATE GUARANTOR'S CIBIL HISTORY DETAILS: LENGTH :" + historyResult.length);

               return ResponseEntity.ok(Arrays.asList(historyResult));
           }

       }catch (RestClientException e) {
           System.err.println("IN LOS-GST: CORPORATE GUARANTOR'S CIBIL: ERROR FETCHING HISTORY DETAILS: "+e.getMessage());
           e.printStackTrace();
           throw new RestClientException(e.getMessage());
       }
    }

//*****************************************************************************************************************//
    //SCREEN 1: CIBIL SUMMARY DETAILS OF GUARANTORS (ALL)
    @GetMapping("/summary/{referenceId}")
    public List<Object> ScreenSummaryDetails(@PathVariable String referenceId){

        String summaryDetailsUrl = CibilConfig.CommercialCibilIP +"/commercial-cibil/guarantor/summary-details/"+ referenceId;
       try{
        Object[] summaryResult =restTemplate.getForObject(summaryDetailsUrl, Object[].class);
        System.out.println("IN LOS-GST: CORPORATE GUARANTOR'S CIBIL SUMMARY DETAILS: LENGTH :" + summaryResult.length);
        return Arrays.asList(summaryResult);
    }catch (RestClientException e) {
           System.err.println("IN LOS-GST: CORPORATE GUARANTOR'S CIBIL: ERROR FETCHING SUMMARY DETAILS: "+e.getMessage());
           e.printStackTrace();
           throw new RestClientException(e.getMessage());
       }
    }
//*****************************************************************************************************************//



}
