package com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifRemarks;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.DTO.CibilAndCrifRemarkDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifRemark.CibilCrifRemarkEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DecisionStatus.DecisionStatusModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifRemark.CibilCrifRemarkRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DecisionStatus.DecisionStatusRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo.RefIdGenerationRepo;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@AllArgsConstructor
@Service
@Transactional
public class CibilCrifRemarkServiceImpl implements CibilCrifRemarkService {
    
    private final CibilCrifRemarkRepo cibilCrifRemarkRepo;
    private ModelMapper modelMapper;
    private final RefIdGenerationRepo refIdGenerationRepo;
    private final DecisionStatusRepo decisionStatusRepo;

//-------------------------------------------------------------------------------------------------------------------//
//CHECK AND CREATE NEW ENTITY   
@Override
public CibilCrifRemarkEntity checkOrCreateCibilCrifRemarkEntity(String referenceId) {
   
    // Check if data already present from referenceId
    CibilCrifRemarkEntity entityPresent = cibilCrifRemarkRepo.findByReferenceIdAndRemarkStatusNull(referenceId);
        if (entityPresent == null) {
            CibilCrifRemarkEntity newEntity = new CibilCrifRemarkEntity();
            newEntity.setReferenceId(referenceId);
            System.out.println("EXISTING Entity NOT PRESENT , NEW CibilCrifRemarkEntity CREATED ");
            return newEntity;
        } else {
        System.out.println("EXISTING ENTRY PRESENT CibilCrifRemarkEntity : "+entityPresent);
            return entityPresent;
        }
    }
//-------------------------------------------------------------------------------------------------------------------//
//SAVE REMARKS OF PERSONAL CIBIL
@Override
public String savePersonalCibilRemarks(CibilAndCrifRemarkDto remarkDto) {

    try {
        CibilCrifRemarkEntity remarkEntity = checkOrCreateCibilCrifRemarkEntity(remarkDto.getReferenceId());
        remarkEntity.setPersonalCibilRemark(remarkDto.getPersonalCibilRemark());
        remarkEntity.setPersonalCibilOverdueRemark(remarkDto.getPersonalCibilOverdueRemark());
        remarkEntity.setPersonalCibilRejectRemark(remarkDto.getPersonalCibilRejectRemark());
        remarkEntity.setPersonalCibilSuitFilledRemark(remarkDto.getPersonalCibilSuitFilledRemark());
        remarkEntity.setPersonalCibilWrittenOffRemark(remarkDto.getPersonalCibilWrittenOffRemark());
        remarkEntity.setPersonalCibilAccountSettledRemark(remarkDto.getPersonalCibilAccountSettledRemark());
        remarkEntity.setPersonalCibilSubmitDate(LocalDateTime.now());

        System.out.println("PERSONAL CIBIL REMARKS SAVED/UPDATED FOR REFERENCE-ID: " + remarkDto.getReferenceId());
        return "PERSONAL CIBIL REMARKS SAVED/UPDATED FOR REFERENCE-ID: " + remarkDto.getReferenceId();
    }catch (Exception e){
        System.err.println("ERROR WHILE SAVING PERSONAL CIBIL REMARKS :" +e.getMessage());
        throw new RuntimeException("ERROR WHILE SAVING PERSONAL CIBIL REMARKS :" +e.getMessage());
    }
}
//-------------------------------------------------------------------------------------------------------------------//
//SAVE REMARKS OF COMMERCIAL CIBIL
@Override
public String saveCommercialCibilRemarks(CibilAndCrifRemarkDto remarkDto) {

    try {
        CibilCrifRemarkEntity remarkEntity = checkOrCreateCibilCrifRemarkEntity(remarkDto.getReferenceId());
        remarkEntity.setCommercialCibilRemark(remarkDto.getCommercialCibilRemark());
        remarkEntity.setCommercialCibilOverdueRemark(remarkDto.getCommercialCibilOverdueRemark());
        remarkEntity.setCommercialCibilRejectRemark(remarkDto.getCommercialCibilRejectRemark());
        remarkEntity.setCommercialCibilSuitFilledRemark(remarkDto.getCommercialCibilSuitFilledRemark());
        remarkEntity.setCommercialCibilAccountSettledRemark(remarkDto.getCommercialCibilRemark());
        remarkEntity.setCommercialCibilWrittenOffRemark(remarkDto.getCommercialCibilWrittenOffRemark());
        remarkEntity.setCommercialCibilSubmitDate(LocalDateTime.now());

        System.out.println("COMMERCIAL CIBIL REMARKS SAVED/UPDATED FOR REFERENCE-ID: " + remarkDto.getReferenceId());
        return "COMMERCIAL CIBIL REMARKS SAVED/UPDATED FOR REFERENCE-ID: " + remarkDto.getReferenceId();
    }
    catch (Exception e){
        System.err.println("ERROR WHILE SAVING COMMERCIAL CIBIL REMARKS :" +e.getMessage());
        throw new RuntimeException("ERROR WHILE SAVING COMMERCIAL CIBIL REMARKS :" +e.getMessage());
    }
}
//-------------------------------------------------------------------------------------------------------------------//
//SAVE REMARKS OF PERSONAL CRIF
@Override
public String savePersonalCrifRemarks(CibilAndCrifRemarkDto remarkDto) {

    try{
        CibilCrifRemarkEntity remarkEntity=checkOrCreateCibilCrifRemarkEntity(remarkDto.getReferenceId());
        remarkEntity.setPersonalCrifRemark(remarkDto.getPersonalCrifRemark());
        remarkEntity.setPersonalCrifOverdueRemark(remarkDto.getPersonalCrifOverdueRemark());
        remarkEntity.setPersonalCrifRejectRemark(remarkDto.getPersonalCrifRejectRemark());
        remarkEntity.setPersonalCrifSuitFilledRemark(remarkDto.getPersonalCrifSuitFilledRemark());
        remarkEntity.setPersonalCrifWrittenOffRemark(remarkDto.getPersonalCrifWrittenOffRemark());
        remarkEntity.setPersonalCrifAccountSettledRemark(remarkDto.getPersonalCrifAccountSettledRemark());
        remarkEntity.setPersonalCrifSubmitDate(LocalDateTime.now());

        System.out.println("PERSONAL CRIF REMARKS SAVED/UPDATED FOR REFERENCE-ID: "+remarkDto.getReferenceId());
        return "PERSONAL CRIF REMARKS SAVED/UPDATED FOR REFERENCE-ID: "+remarkDto.getReferenceId();
    }
    catch (Exception e){
        System.err.println("ERROR WHILE SAVING PERSONAL CRIF REMARKS :" +e.getMessage());
        throw new RuntimeException("ERROR WHILE SAVING PERSONAL CRIF REMARKS :" +e.getMessage());
    }
}
//-------------------------------------------------------------------------------------------------------------------//
//CHECK AND CREATE NEW ENTITY
@Override
public String saveCommercialCrifRemarks(CibilAndCrifRemarkDto remarkDto) {

    try{
        CibilCrifRemarkEntity remarkEntity=checkOrCreateCibilCrifRemarkEntity(remarkDto.getReferenceId());
        remarkEntity.setCommercialCrifRemark(remarkDto.getCommercialCrifRemark());
        remarkEntity.setCommercialCrifOverdueRemark(remarkDto.getCommercialCrifOverdueRemark());
        remarkEntity.setCommercialCrifRejectRemark(remarkDto.getCommercialCrifRejectRemark());
        remarkEntity.setCommercialCrifSuitFilledRemark(remarkDto.getCommercialCrifSuitFilledRemark());
        remarkEntity.setCommercialCrifAccountSettledRemark(remarkDto.getCommercialCrifRemark());
        remarkEntity.setCommercialCrifWrittenOffRemark(remarkDto.getCommercialCrifWrittenOffRemark());
        remarkEntity.setCommercialCrifSubmitDate(LocalDateTime.now());

        System.out.println("COMMERCIAL CRIF REMARKS SAVED/UPDATED FOR REFERENCE-ID: "+remarkDto.getReferenceId());
        return "COMMERCIAL CRIF REMARKS SAVED/UPDATED FOR REFERENCE-ID: "+remarkDto.getReferenceId();
    }
    catch (Exception e){
        System.err.println("ERROR WHILE SAVING COMMERCIAL CRIF REMARKS :" +e.getMessage());
        throw new RuntimeException("ERROR WHILE SAVING COMMERCIAL CRIF REMARKS :" +e.getMessage());
    }
}
//-------------------------------------------------------------------------------------------------------------------//

@Override
public CibilAndCrifRemarkDto getAllCibiCrifRemarks(String referenceId) {
    try {
        CibilCrifRemarkEntity remarkEntity = checkOrCreateCibilCrifRemarkEntity(referenceId);

        CibilAndCrifRemarkDto remarkDtoConverted = modelMapper.map(remarkEntity, CibilAndCrifRemarkDto.class);
        System.out.println(" ALL CIBIL CRIF REMARKS FOUND :" + remarkDtoConverted);
        return remarkDtoConverted;
    }
    catch (Exception e){
        System.err.println("ERROR WHILE FETCHING CIBIL-CRIF REMARKS :" +e.getMessage());
        throw new RuntimeException("ERROR WHILE FETCHING CIBIL-CRIF REMARKS :" +e.getMessage());
    }
 }
//-------------------------------------------------------------------------------------------------------------------//

@Override
public String rejectDueToCibilCrif(CibilAndCrifRemarkDto rejectRemarkDto) {

    if(rejectRemarkDto.getPersonalCibilRejectRemark()!=null || rejectRemarkDto.getCommercialCibilRejectRemark()!=null ||
            rejectRemarkDto.getPersonalCrifRejectRemark() !=null || rejectRemarkDto.getCommercialCrifRejectRemark()!=null ){

        CibilCrifRemarkEntity cibilCrifRemarkEntity=checkOrCreateCibilCrifRemarkEntity(rejectRemarkDto.getReferenceId());
        modelMapper.map(rejectRemarkDto,cibilCrifRemarkEntity);
        cibilCrifRemarkEntity.setRemarkStatus(AllStaticFields.rejectedStatus);
        cibilCrifRemarkRepo.save(cibilCrifRemarkEntity);

        try {
            ReferenceIdGenerationEntity refIdEntity  = refIdGenerationRepo.findByReferenceId(rejectRemarkDto.getReferenceId());
            refIdEntity.setApplicationStatus(AllStaticFields.rejectedStatus);
            refIdGenerationRepo.save(refIdEntity);
        } catch (Exception e) {
            throw new RuntimeException(" APPLICATION STATUS SET TO REJECTED in Reference ID Entity " + rejectRemarkDto.getReferenceId() + e);
        }
        try {
            DecisionStatusModel decisionStatusModel=decisionStatusRepo.findByReferenceId(rejectRemarkDto.getReferenceId());
            decisionStatusModel.setApplicationStatus(AllStaticFields.rejectedStatus);
            decisionStatusModel.setFinalSubmitBy(rejectRemarkDto.getUserType());
            decisionStatusModel.setFinalSubmitDate(LocalDateTime.now());
            decisionStatusRepo.save(decisionStatusModel);
        } catch (Exception e) {
            throw new RuntimeException(" FINAL APPLICATION STATUS SET TO REJECTED in Decision Status Model " + rejectRemarkDto.getReferenceId() + e);
        }
    }
    System.out.println("APPLICATION STATUS SET TO REJECTED DUE TO CIBIL/CRIF FOR REF-ID :"+rejectRemarkDto.getReferenceId());
    return "APPLICATION STATUS SET TO REJECTED DUE TO CIBIL/CRIF.";
}
//-------------------------------------------------------------------------------------------------------------------//

}
