package com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsCommercial;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CibilCommScreen1BasicDetailsEntity {

    @Id
    private Long id;

    private String customerName;
    private String customerPan;
    private LocalDateTime dateOfFetching;
    private String referenceId;
    private String branchCode;
    private String userId;


    //to display BASIC DETAILS
    private String rankName;
    private String rankNumber;
    private String rankingReasons;
    private String totalCfAccounts; //creditProfileSummary -> total -> totalCF
    private String regularAccounts;// total-overdue-zero blc
    private String overdueAccounts;//delinquentCF
    private String zeroBalanceAccount; //total-open
    private String reportOrderNumber;


    //to display SUMMARY
    private String rankStatusSummary;
    private String accountWrittenOffSummary;
    private String accountSettledSummary;
    private String accountOverdueSummary;
    private String suitFilledSummary;

    //for summary fields
    private String numberOfSuitFiled;
    private String suitFiledAmt;
    private String numberOfWrittenOff;
    private String writtenOffAmt;
    private String numberOfSettledAcc;
    private String settledAmt;
    private String corporateType;

    //additional field to update old entries
    private String oldRecord;
    private LocalDateTime refetchedDate;



}
