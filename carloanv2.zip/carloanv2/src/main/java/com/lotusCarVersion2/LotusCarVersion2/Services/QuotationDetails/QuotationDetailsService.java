package com.lotusCarVersion2.LotusCarVersion2.Services.QuotationDetails;


import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsModel;

public interface QuotationDetailsService {

    String postQuotationDetails(QuotationDetailsModel quotationDetailsModel);

    QuotationDetailsModel getQuotationDetails(String referenceId);
}
