package com.lotusCarVersion2.LotusCarVersion2.exception;

//@Data
//public class ExceptionDetails {
//    private LocalDateTime exceptionTimestamp;
//    private String exceptionMessage;
//    private String exceptionResource;
//    private String errorCode;
//}


import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

public record ExceptionDetails(LocalDateTime errorTimestamp,
                           String message,
                           String details,
                           String errorCode,
                           Optional<Map<String, String>> validationErrors) {
}
