package com.lotusCarVersion2.LotusCarVersion2.Services.DashBoard;

import com.lotusCarVersion2.LotusCarVersion2.Models.ApplicationList.UserModelDashBoard;
import com.lotusCarVersion2.LotusCarVersion2.Models.Dashboard.DashBoardStatusModel;

public interface DashBoardStatusService {

    DashBoardStatusModel getDashBoardCount(UserModelDashBoard applicationActionModel);

    DashBoardStatusModel getDashBoardCountCurrent(UserModelDashBoard applicationActionModel);
    DashBoardStatusModel getDashBoardCountQuarter(UserModelDashBoard applicationActionModel);

}
