package com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsCommercial;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CibilCommScreen2HistoryListEntity {
@Id
private Long id;
    private String referenceId;

    private String customerName;
    private String customerPan;
    private String facilityType;
    private String ownership;
    private String bankerName;
    private String sanctionDate;
    private String sanctionAmount;
    private String amountOutstanding;
    private String overdueAmount;
    private String facilityStatus;
    private String assetClassification;
    private String corporateType;
    private String oldRecord;
}
