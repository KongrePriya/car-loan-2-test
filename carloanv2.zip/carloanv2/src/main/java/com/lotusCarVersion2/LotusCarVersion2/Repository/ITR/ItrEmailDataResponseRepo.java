package com.lotusCarVersion2.LotusCarVersion2.Repository.ITR;

import com.lotusCarVersion2.LotusCarVersion2.Models.ITR.ItrEmailVerifiedResponseEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface ItrEmailDataResponseRepo extends JpaRepository<ItrEmailVerifiedResponseEntity, Long> {
    //**************  //To delete entry of ITR Reference-ID Verified Response from table when Borrower/guarantor Deleted **********************//
    @Modifying
    @Transactional
    @Query(value = "DELETE FROM kyc_itr.screen_itr_email_ref_id_generated_response " +
            "WHERE reference_id_lotus = :referenceIdLotus AND customer_type = :customerType", nativeQuery = true)
    int deleteFromITRRefIDVerifiedResponseTable(String referenceIdLotus, String customerType);
}
