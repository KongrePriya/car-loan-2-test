package com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo;

import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.HistoryIndividualBasicDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HistoryIndividualBasicDetailsRepo extends JpaRepository<HistoryIndividualBasicDetailsEntity, Long> {

}
