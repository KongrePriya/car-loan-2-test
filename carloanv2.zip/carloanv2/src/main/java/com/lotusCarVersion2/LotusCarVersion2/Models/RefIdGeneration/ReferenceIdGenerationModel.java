//package com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration;
//
//
//import jakarta.persistence.*;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//
//import java.time.LocalDateTime;
//
//@Entity
//@Table(name = "referenceid")
//@AllArgsConstructor
//@NoArgsConstructor
//@Data
//
//public class ReferenceIdGenerationModel {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private String panNumber;
//    private String referenceId;
//    private String applicationStatus="0";
//    private LocalDateTime applicationCreatedDate;
//    private String userId;
//    private String u_type;
//    private String brcode;
//    private String roname;
//    private String u_status;
//    private String u_loc;
//    private String u_name;
//    private String scale;
//    private String sourceType;
//    private String dsaNumber;
//    private String brname;
//    private String borrowerType;
//    private String shortBorrowerType;
//    private String loanType;
//    private String shortLoanType;
//}
