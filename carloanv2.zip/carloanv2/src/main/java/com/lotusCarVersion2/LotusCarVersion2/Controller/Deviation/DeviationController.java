package com.lotusCarVersion2.LotusCarVersion2.Controller.Deviation;

import com.lotusCarVersion2.LotusCarVersion2.DTO.DeviationDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.RawDataForDeviationCheckingEntity;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationCheckingRequiredDataService;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationFlagsStatusService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@AllArgsConstructor
@RequestMapping("/api/v1/deviation")
public class DeviationController {


    private final DeviationCheckingRequiredDataService deviationCheckingRequiredDataService;
    private final DeviationFlagsStatusService deviationFlagsStatusService;

//*************************************************************************************************************************************//
//Api to get Deviation Raw data entity by reference-Id
@GetMapping("/raw-data/{referenceId}")
public ResponseEntity<RawDataForDeviationCheckingEntity> getDeviationRawData(@PathVariable("referenceId") String referenceId) {
    RawDataForDeviationCheckingEntity rawDataForDeviationCheckingEntity = deviationCheckingRequiredDataService.getDeviationRawData(referenceId);
    if (rawDataForDeviationCheckingEntity != null) {
        return new ResponseEntity<>(rawDataForDeviationCheckingEntity, HttpStatus.OK);
    } else {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
//*************************************************************************************************************************************//
//Api to get Deviation flags entity by reference-Id
@GetMapping("/{referenceId}")
public ResponseEntity<DeviationDetailsDto> getAllNormalDeviationData(@PathVariable("referenceId") String referenceId) {

    System.out.println("INSIDE getAllNormalDeviationData FOR REF-ID:"+referenceId);

    DeviationDetailsDto deviationDetailsDto = deviationFlagsStatusService.getAllDeviationFlags(referenceId);
    if (deviationDetailsDto != null) {
        return new ResponseEntity<>(deviationDetailsDto, HttpStatus.OK);
    } else {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}


//*************************************************************************************************************************************//

}
