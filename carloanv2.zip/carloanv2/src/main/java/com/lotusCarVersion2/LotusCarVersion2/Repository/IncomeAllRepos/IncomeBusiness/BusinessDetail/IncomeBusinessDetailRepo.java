package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessDetail;

import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessDetail.IncomeBusinessDetailModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncomeBusinessDetailRepo extends JpaRepository<IncomeBusinessDetailModel,Long> {
}
