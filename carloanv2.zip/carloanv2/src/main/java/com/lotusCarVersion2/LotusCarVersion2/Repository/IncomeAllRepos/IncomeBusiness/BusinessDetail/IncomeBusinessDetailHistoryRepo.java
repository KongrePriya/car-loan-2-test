package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessDetail;

import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessDetail.IncomeBusinessDetailHistoryModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncomeBusinessDetailHistoryRepo extends JpaRepository<IncomeBusinessDetailHistoryModel, Long> {
}
