package com.lotusCarVersion2.LotusCarVersion2.DTO;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class FirmDetailsDto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String firmSalutation;
    @NotNull(message = "Firm-Trade Name cannot be blank")
    private String firmTradeName;
    @NotNull(message = "Firm-Legal Name of Business cannot be blank")
    private String firmLegalNameOfBusiness;

    @NotNull(message = "Customer Type cannot be blank")
    @Size(max = 42, message = "Customer Type length must be less than or equal to 42 characters")
    private String firmCustomerType;
    private String firmMobile;
    private String firmBusinessSector;

    @Size(max = 55, message = "Email length must be less than or equal to 55 characters")
    @Email(message = "Email should be valid")
    private String firmEmail;
    private String firmNatureOfBusiness;
    private String firmTypeOfBorrower;
    @NotNull(message = "Branch Code cannot be blank")
    private String firmBranchCode;
    private String firmBranchName;
    @NotNull(message = "RO Name cannot be blank")
    private String firmRoName;
    private String firmRegisterAddress;
    private String firmRegisterVillage;
    private String firmRegisterBlock;

    @Size(max = 6, message = "Pincode length must be less than or equal to 6 characters")
    @NotNull(message = "Pincode cannot be blank")
    private String firmRegisterPin;
    private String firmRegisterDistrict;
    private String firmRegisterState;
    private String firmOtherAddress;
    private String firmOtherVillage;
    private String firmOtherBlock;

    @Size(max = 6, message = "Pincode length must be less than or equal to 6 characters")
    @NotNull(message = "Pincode cannot be blank")
    private String firmOtherPin;
    private String firmOtherDistrict;
    private String firmOtherState;
    @NotNull(message = "Reference ID cannot be blank")
    private String firmReferenceId;

    @Size(max = 21, message = "CIN length must be less than or equal to 21 characters")
    private String firmCin;
    @NotNull(message = "PAN cannot be blank")
    @Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]", message = "Invalid PAN number of Firm")
    private String firmPan;
    @NotNull(message = "Firm- GSTIN cannot be blank")
    private String firmGstn;
    private String firmUdyam;
    private String firmTan;
    private String firmLei;

    @PastOrPresent(message = "Date of Certificate cannot have a future date.")
    private LocalDate firmDateOfCertificate;
    private String firmUdin;
    private Long firmNetWorth;
    private String firmSourceOfNetWorth;
    private LocalDate firmNetWorthAsOnDate;
    private String firmNameOfCa;

    @NotNull(message = "Establishment/Incorporation Date cannot be blank")
    @PastOrPresent(message = "Establishment/Incorporation Date cannot have a future date.")
    private LocalDate firmEstablishmentDate;

    private LocalDateTime timestamp=LocalDateTime.now();
    private String firmGstinStatus;
    private String firmConstitutionOfBusiness;
    private String firmDateOfRegistration;
    @Size(max = 200, message = "Address length must be less than or equal to 200 characters")
    @NotNull(message = "Address cannot be blank")
    private String firmPrincipalPlaceOfBusinessAddress;
    private String firmStateJurisdictionCode;
    private String firmDateOfCancellation;
    private String firmCentreJurisdictionCode;
    private String firmLastUpdatedDate;
    private String firmCentreJurisdiction;
    private String firmTaxpayerType;
    @Size(max = 200, message = "Address length must be less than or equal to 200 characters")
    private String firmAdditionalPlaceOfBusinessAddress;
    private String firmStateJurisdiction;

    @NotNull(message = "User ID cannot be blank")
    private String userId;
    private String commCrifFetchedFor;
    private String crifCommFetched;
    private LocalDate bankingwithus;

}
