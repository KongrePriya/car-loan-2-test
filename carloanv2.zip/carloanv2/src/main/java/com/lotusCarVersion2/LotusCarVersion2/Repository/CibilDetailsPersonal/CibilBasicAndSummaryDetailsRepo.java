package com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsPersonal;


import com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsIndividual.ScreenCibilSummaryBasicDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CibilBasicAndSummaryDetailsRepo extends JpaRepository<ScreenCibilSummaryBasicDetails, Long> {

    //************ BASIC DETAILS **********// for jasper appraisal note
    @Query(nativeQuery = true, value = "SELECT * from cibil_personal.screen_personal_cibil_basic_summary_details " +
            " WHERE old_record IS NULL AND reference_id= :referenceId ORDER BY date_of_fetching ASC ")
    List<ScreenCibilSummaryBasicDetails> cibilPersonalBasicDetailsScreen1(String referenceId);


    //************ CHANGE EXISTING ENTRIES STATUS TO OLD WHEN INDIVIDUAL DELETED **********//
    @Modifying
    @Query(nativeQuery = true, value = "UPDATE cibil_personal.screen_personal_cibil_basic_summary_details SET old_record='OLD' " +
            " WHERE customer_pan= :panCard AND reference_id = :referenceId")
    int updatePersonalCibilStatusOldWhenDeleted(String panCard, String referenceId);


    //************ BASIC DETAILS **********// for Deviation
    @Query(nativeQuery = true, value = "SELECT * from cibil_personal.screen_personal_cibil_basic_summary_details " +
            " WHERE old_record IS NULL  AND reference_id= :referenceId  ")
    List<ScreenCibilSummaryBasicDetails> getAllCibilDetailsForDeviationByRefId(String referenceId);

    //************ TO GET COUNT OF ROWS PRESENT AGAINST THE REF-ID************//
    @Query(nativeQuery = true, value = "SELECT COUNT(*) FROM cibil_personal.screen_personal_cibil_basic_summary_details " +
            " WHERE old_record IS NULL AND reference_id= :referenceId  ")
    int getCountOfCibilForReferenceId( String referenceId);
}


