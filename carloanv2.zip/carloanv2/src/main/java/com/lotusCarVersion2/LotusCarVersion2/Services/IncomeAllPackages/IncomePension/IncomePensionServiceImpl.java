package com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomePension;



import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomePension.IncomePensionHistoryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomePension.IncomePensionModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomePension.IncomePensionHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomePension.IncomePensionRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class IncomePensionServiceImpl implements IncomePensionService{


    @Autowired
    private IncomePensionRepo incomePensionRepo;

    @Autowired
    private IncomePensionHistoryRepo incomePensionHistoryRepo;

//    @Autowired
//    private CalculationRawDataService calculationRawDataService;

    @Override
    @Transactional
    public String postIncomePension(IncomePensionModel incomePensionModel) {

        if (incomePensionModel.getId()!=null){
            incomePensionModel.setId(null);
        }

        if(incomePensionRepo.existsByReferenceIdAndPanNumber(incomePensionModel.getReferenceId(),incomePensionModel.getPanNumber())){
            deleteIncomePensionAndSaveToHistory(incomePensionModel.getReferenceId(),incomePensionModel.getPanNumber());
        }
        try{
            incomePensionModel.setCreatedDate(LocalDateTime.now());
            incomePensionRepo.save(incomePensionModel);
        }catch(Exception e){
            throw new RuntimeException("Error Occurred While Saving Income Pension " + e);
        }

        //====================================== INCOME DETAILS FOR CALCULATION =====================================//
          //05032025: directly called in calculation page
       try{
//            calculationRawDataService.redirectToSaveIncomeData(incomePensionModel.getReferenceId());
        }catch(Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE SETTING Income Details For Pensioner :"+incomePensionModel.getCustomerType()+"\n ERROR DETAILS : " + e.getMessage());
            throw new RuntimeException("ERROR WHILE SETTING Income Details For Pensioner :"+incomePensionModel.getCustomerType()+"\n ERROR DETAILS : " + e.getMessage());
        }
        //======================================//======================================//======================================
        return "Income Pension Saved Successfully";
    }

    @Override
    public IncomePensionModel getIncomePension(String referenceId, String panNumber) {

        try{
            return incomePensionRepo.findByReferenceIdAndPanNumber(referenceId,panNumber);
        }catch(Exception e){
            throw new RuntimeException("Error Occurred while Getting Income Pension Details" +e);
        }
    }


//    ------------------------ Delete Income Pension And Save To History -------------------------
    @Override
    @Transactional
    public void deleteIncomePensionAndSaveToHistory(String referenceId, String panNumber) {
        IncomePensionModel foundRecord = incomePensionRepo.findByReferenceIdAndPanNumber(referenceId, panNumber);
        if (foundRecord != null) {
        IncomePensionHistoryModel incomePensionHistoryModel = new IncomePensionHistoryModel();
        incomePensionHistoryModel.setUpdatedDate(LocalDateTime.now());
        try{
            BeanUtils.copyProperties(foundRecord,incomePensionHistoryModel, "updatedDate","id");
            incomePensionHistoryRepo.save(incomePensionHistoryModel);
        }catch(Exception e){
            throw new RuntimeException("Error Occurred While Saving Income Pension History" + e);
        }
        try{
            incomePensionRepo.delete(foundRecord);
        }catch(Exception e){
            throw new RuntimeException("Error Occurred While Deleting Income Pension" + e);
        }
    }
}}
