package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomePension;

import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomePension.IncomePensionModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface IncomePensionRepo extends JpaRepository<IncomePensionModel,Long> {

    boolean existsByReferenceIdAndPanNumber(String referenceId, String panNumber);
//    IncomePensionModel findByReferenceId(String referenceId);
    IncomePensionModel findByReferenceIdAndPanNumber(String referenceId, String panNumber);


    @Query(value = "SELECT COUNT(*) FROM los_car_v2.income_pension_model WHERE reference_id=:referenceId;",nativeQuery = true)
    Integer countIncomePension(String referenceId);

    List<IncomePensionModel> findAllByReferenceId(String referenceId);

}
