package com.lotusCarVersion2.LotusCarVersion2.Services.CRIFRemark;



import com.lotusCarVersion2.LotusCarVersion2.Models.CRIFRemark.CrifRemarkModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CRIFRemark.CrifRemarkRepo;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
@Transactional
public class CrifRemarkServiceImpl implements CrifRemarkService {

    @Autowired
    private CrifRemarkRepo crifRemarkRepo;
    //    private final GstStatusRepo gstStatusRepo;
//    private final RefNoVarificationRepo refNoVarificationRepo;
//    private final AppraisalNoteService appraisalNoteService;  -- Uncomment Later
    //    private final GstStatusService gstStatusService;
//    @Autowired
//    private final AppraisalRepository appraisalRepository; -- Uncomment Later


    //****************************************************************************************************//

    public String saveRemark(CrifRemarkModel crifRemarkModel) {

        System.out.println("INSIDE SAVE REMARKS METHOD " + crifRemarkModel.getCrifRemark());
//        System.out.println(crifRemarkModel);
        CrifRemarkModel crifRemarkPresentData = crifRemarkRepo.findByReferenceId(crifRemarkModel.getReferenceId());
        System.out.println(crifRemarkModel.getReferenceId());
        System.out.println(crifRemarkPresentData != null);


        if (crifRemarkPresentData != null) {
            crifRemarkPresentData.setCrifSubmitDate(LocalDateTime.now());
            crifRemarkPresentData.setUserId(crifRemarkModel.getUserId());
            crifRemarkPresentData.setUserType(crifRemarkModel.getUserType());
            crifRemarkPresentData.setReferenceId(crifRemarkModel.getReferenceId());
            crifRemarkPresentData.setCrifRemark(crifRemarkModel.getCrifRemark());
            crifRemarkPresentData.setCrifAccountSettledRemark(crifRemarkModel.getCrifAccountSettledRemark());
            crifRemarkPresentData.setCrifRejectRemark(crifRemarkModel.getCrifRejectRemark());
            crifRemarkPresentData.setCrifOverdueRemark(crifRemarkModel.getCrifOverdueRemark());
            crifRemarkPresentData.setCrifWrittenOffRemark(crifRemarkModel.getCrifWrittenOffRemark());
            try {

                crifRemarkRepo.save(crifRemarkPresentData);

//                appraisalNoteService.updateAppraisalCrifRemark(crifRemarkModel.getReferenceId());-- Uncomment Later
            } catch (Exception e) {
                throw new RuntimeException("CRIF Remark Not Saved....");
            }
            //gstStatusService.updateIndividualGuarantorCrifStatus(crifRemarkModel.getReferenceId());
        } else {
            CrifRemarkModel crifRemarkNewData = new CrifRemarkModel();
            crifRemarkNewData.setCrifSubmitDate(LocalDateTime.now());
            crifRemarkNewData.setUserId(crifRemarkModel.getUserId());
            crifRemarkNewData.setUserType(crifRemarkModel.getUserType());
            crifRemarkNewData.setReferenceId(crifRemarkModel.getReferenceId());
            crifRemarkNewData.setCrifRemark(crifRemarkModel.getCrifRemark());
            crifRemarkNewData.setCrifAccountSettledRemark(crifRemarkModel.getCrifAccountSettledRemark());
            crifRemarkNewData.setCrifRejectRemark(crifRemarkModel.getCrifRejectRemark());
            crifRemarkNewData.setCrifOverdueRemark(crifRemarkModel.getCrifOverdueRemark());
            crifRemarkNewData.setCrifWrittenOffRemark(crifRemarkModel.getCrifWrittenOffRemark());


            try {
                crifRemarkRepo.save(crifRemarkNewData);

//                appraisalNoteService.updateAppraisalCrifRemark(crifRemarkModel.getReferenceId()); -- Uncomment Later
            } catch (Exception e) {
                throw new RuntimeException("CRIF Remark Not Saved....");

            }
        }


//--------------------------- GST REJECT ---------------------------------------------

        // SAVE DATA IN APPRAISAL NOTE TABLE
        //   appraisalNoteService.updateAppraisalCrifRemark(entity.getReferenceId());
        System.out.println("APPRAISAL NOTE TABLE UPDATED SUCEESFULLY");

        return "CRIF Remark Saved Successfully";

    }


    public CrifRemarkModel getCrifRemarksByRefId(String referenceId) {
        CrifRemarkModel CrifRemark = crifRemarkRepo.findByReferenceId(referenceId);
        return CrifRemark;
    }


//*****************************************************************************************************************************
//********************************* UPDATE CIBIL REMARK TO OLD ****************************************************************

//    public String updateCrifRemarkStatus() {
//
//
//        List<CrifRemark> allList = crifRemarkRepo.getAllListToMarkAsOLD();
//        int i=0;
//        for (CrifRemark entity : allList) {
//
//            entity.setRemarkStatus("OLD");
//            entity.setStatusDate(LocalDateTime.now());
//            crifRemarkRepo.save(entity);
//            i++;
//        }
//        System.out.println("CrifRemark: REMARK STATUS FOR ALL/LIST UPDATED TO OLD SUCCESSFULLY. TOTAL ENTITIES AFFECTED:- "+i);
//        return "CrifRemark: REMARK STATUS FOR ALL/LIST UPDATED TO OLD SUCCESSFULLY. TOTAL ENTITIES AFFECTED:- "+i;
//    }

//*****************************************************************************************************************************


}
