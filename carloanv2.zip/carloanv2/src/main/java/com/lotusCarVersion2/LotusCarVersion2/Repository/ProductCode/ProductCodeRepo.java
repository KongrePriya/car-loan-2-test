package com.lotusCarVersion2.LotusCarVersion2.Repository.ProductCode;

import com.lotusCarVersion2.LotusCarVersion2.DTO.ProductCodeDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.ProductCode.ProductCodeModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.List;

public interface ProductCodeRepo extends JpaRepository<ProductCodeModel, Long> {

    @Query(value = "SELECT * FROM los_car_v2.product_code_model;", nativeQuery = true)
    List<ProductCodeModel> getAllProductCodes();

    @Query(value = "SELECT rate_of_interest FROM los_car_v2.product_code_model WHERE product_code= :productCode;", nativeQuery = true)
    BigDecimal getRateOfInterest(String productCode);

    @Query(value = "SELECT product_description FROM los_car_v2.product_code_model WHERE product_code= :productCode;", nativeQuery = true)
    String getProductDescription(String productCode);


//    @Query(value = "SELECT * FROM los_car_v2.product_code_model;", nativeQuery = true)
//    List<ProductCodeModel> getAllMasterProductCodes();
}
