package com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifRemark;

import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifRemark.CibilCrifRemarkEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CibilCrifRemarkRepo extends JpaRepository<CibilCrifRemarkEntity , Long> {

    CibilCrifRemarkEntity findByReferenceId(String referenceId);

    CibilCrifRemarkEntity findByReferenceIdAndRemarkStatusNull(String referenceId);

}
