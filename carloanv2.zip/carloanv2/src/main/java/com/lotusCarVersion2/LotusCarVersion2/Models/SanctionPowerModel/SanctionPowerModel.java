package com.lotusCarVersion2.LotusCarVersion2.Models.SanctionPowerModel;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@Setter
@Getter
@Component
@Table(name = "sanction_power")
public class SanctionPowerModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private int srno;
    private String loanType;
    private String userType;
    private String scale;
    private BigDecimal sanctionPowerAmt;
    private String userId;
    private LocalDateTime timeStamp;
    private String status;

}
