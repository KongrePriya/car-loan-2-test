package com.lotusCarVersion2.LotusCarVersion2.Models.CRIFDetails;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "std_crif_history_model", schema = "crif_individual")
public class StdCrifHistoryModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private String nameOfCustomer;
    private String facilityType;
    private String ownership;
    private String bank;
    private String sanctionDate;
    private String sanctionAmount;
    private String amountOutstanding;
    private String overdue;
    private String accountStatus;
    private String referenceId;
    private String branchCode;
    private String userId;
    private String individualPan;
    private LocalDateTime createdDate;
}
