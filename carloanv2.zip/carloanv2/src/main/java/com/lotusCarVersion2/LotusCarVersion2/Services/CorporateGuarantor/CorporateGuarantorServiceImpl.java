package com.lotusCarVersion2.LotusCarVersion2.Services.CorporateGuarantor;

import com.lotusCarVersion2.LotusCarVersion2.DTO.CorporateGuarantorDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.CorporateGuarantor.CorporateGuarantorEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsCommercial.CommercialCibilHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsCommercial.CommercialCibilbasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifFetchStatus.CibilCrifFetchStatusRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CorporateGuarantorRepo.CorporateGuarantorRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusServiceImpl;
import com.lotusCarVersion2.LotusCarVersion2.exception.ResourceNotFoundException;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class CorporateGuarantorServiceImpl implements CorporateGuarantorService{

    private ModelMapper modelMapper;
    private final CorporateGuarantorRepo corporateGuarantorRepo;
    private final CibilCrifFetchStatusRepo cibilCrifFetchStatusRepo ;
    private final CibilCrifFetchStatusServiceImpl cibilCrifFetchStatusService;
//   PRIYA private final GstStatusService gstStatusService;
    private final CommercialCibilHistoryRepo commercialCibilHistoryRepo;
    private final CommercialCibilbasicDetailsRepo commercialCibilbasicDetailsRepo;


    //*************************************************************************************************************//
    @Override
    @Transactional
    public CorporateGuarantorDto saveSingleCorpGuarantor(CorporateGuarantorDto saveCorpGuarantorDto) {
        CorporateGuarantorEntity entityToSave = modelMapper.map(saveCorpGuarantorDto, CorporateGuarantorEntity.class);
        entityToSave= corporateGuarantorRepo.save(entityToSave);

      /* PRIYA //to update the count in CibilCrifstatusTable
        cibilCrifFetchStatusService.corpGuarCountStatus(saveCorpGuarantorDto.getReferenceId());

        // UPDATE GST STATUS FOR CORPORATE GUARANTOR
        gstStatusService.updateCorporateGuarantorStatus(entityToSave.getReferenceId());*/

        return  modelMapper.map(entityToSave, CorporateGuarantorDto.class);
    }
//*************************************************************************************************************//

    @Override
    @Transactional
    public CorporateGuarantorDto updateSingleCorpGuarantor(CorporateGuarantorDto updateCorpGuarantorDto) {
        CorporateGuarantorEntity entityToUpdate = modelMapper.map(updateCorpGuarantorDto, CorporateGuarantorEntity.class);
        entityToUpdate=corporateGuarantorRepo.save(entityToUpdate);
        System.out.println("update entity: "+entityToUpdate);
      /* PRIYA //to update the count in CibilCrifstatusTable
        cibilCrifFetchStatusService.corpGuarCountStatus(updateCorpGuarantorDto.getReferenceId());

        // UPDATE GST STATUS FOR CORPORATE GUARANTOR
        gstStatusService.updateCorporateGuarantorStatus(updateCorpGuarantorDto.getReferenceId());*/

        return modelMapper.map(entityToUpdate, CorporateGuarantorDto.class);
    }
//*************************************************************************************************************//

    @Override
    public List<CorporateGuarantorDto> getAllCorpGuarantorsList(String referenceId) {

        List<CorporateGuarantorEntity> corpGuarantorList = corporateGuarantorRepo.findByReferenceIdAndCorpGuarStatusNull(referenceId);

        List<CorporateGuarantorDto> corpGuarantorDtoList=corpGuarantorList.stream()
                .map(singleEntity -> modelMapper.map(singleEntity, CorporateGuarantorDto.class))
                .collect(Collectors.toList());

        return corpGuarantorDtoList;
    }
    //*************************************************************************************************************//
    @Override
    @Transactional
    public String updateCorpGuarantorStatusDeletedByUniqueId(String referenceId, Long id) {
        CorporateGuarantorEntity corpGuarEntity = corporateGuarantorRepo.findByReferenceIdAndId(referenceId, id);
        if (corpGuarEntity == null) {
            throw new ResourceNotFoundException("Corporate Guarantor with id " + id + " and referenceId " + referenceId + " not found");
        } else {
            corpGuarEntity.setCorpGuarStatus("deleted");
            //TO UPDATE STATUS TO "OLD" IN CIBIL-COMMERCIAL TABLES
            int basicDetailsRowsAffected= commercialCibilbasicDetailsRepo.updateCibilStatusOldWhenDeleted(corpGuarEntity.getPan(),referenceId);
            int historyRowsAffected= commercialCibilHistoryRepo.updateCibilHistoryOldWhenDeleted(corpGuarEntity.getPan(),referenceId);
            System.out.println("Commercial-cibil existing entries for deleted Guarantor is set old(removed), " +
                    " basicDetailsRowsAffected :"+basicDetailsRowsAffected+ " historyRowsAffected : "+historyRowsAffected);

           /* PRIYA //to update the count in CibilCrifstatusTable
            cibilCrifFetchStatusService.corpGuarCountStatus(referenceId);*/


            System.out.println("status updated for corporate guarantor as: "+corpGuarEntity.getCorpGuarStatus());
            return "Corporate guarantor with ID :"+ id+" updated as deleted successfully";
        }
    }

//*************************************************************************************************************//
}
