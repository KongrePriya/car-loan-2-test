package com.lotusCarVersion2.LotusCarVersion2.Models.ApplicationList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationStatusSetModel {
    private String referenceId;
    private String branchCode;
    private String branchName;
    private String regionName;
    private BigDecimal appliedLoanAmt;
    private String userId;
    private String userType;
    private String userLoc;
    private String userName;
    private String userScale;

}
