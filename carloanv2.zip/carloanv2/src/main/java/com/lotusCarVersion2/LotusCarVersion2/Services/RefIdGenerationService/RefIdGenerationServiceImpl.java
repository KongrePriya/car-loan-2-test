package com.lotusCarVersion2.LotusCarVersion2.Services.RefIdGenerationService;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifRemark.CibilCrifRemarkEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksMandatoryEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifRemark.CibilCrifRemarkRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DocumentUpload.DocumentsAndRemarksMandatoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo.RefIdGenerationRepo;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class RefIdGenerationServiceImpl implements RefIdGenerationService {


    private final RefIdGenerationRepo referenceIdGenerationRepo;
    private final AllStaticFields allStaticFields;
    private final CibilCrifRemarkRepo cibilCrifRemarkRepo;
    private final DocumentsAndRemarksMandatoryRepo mandatoryDocumentListRepo;

@Override
public ReferenceIdGenerationEntity checkAndGenerateReferenceIdByPan(ReferenceIdGenerationEntity idGenerationEntity) {
        System.out.println("IN checkAndGenerateReferenceIdByPan FUNCTION ");

        String panNumber = idGenerationEntity.getPanNumber();

        boolean panExists = referenceIdGenerationRepo.existsByPanNumber(panNumber);

        if (panExists) {
            ReferenceIdGenerationEntity existingEntity = referenceIdGenerationRepo.findByPanNumber(panNumber);

            boolean isApplicationValid = !(existingEntity.getApplicationStatus().equalsIgnoreCase("REJ") ||
                    existingEntity.getApplicationStatus().equalsIgnoreCase("SAN"));

            if (isApplicationValid) {
                System.out.println("IN CHECKING VALID APPLICATION STATUS FUNCTION ");
                existingEntity.setRefIdFlag("alreadyExists");
                System.out.println("REF-ID GENERATION FUNCTION : REF-ID :" + existingEntity.getReferenceId() + " ALREADY PRESENT AGAINST PAN :" + existingEntity.getPanNumber());
                return existingEntity;
            } else {
                //IF REF-ID IS SANCTIONED OR REJECTED  THEN CREATE NEW REF-ID
                ReferenceIdGenerationEntity newRefIdEntity = saveNewReferenceId(idGenerationEntity);
                return newRefIdEntity;
            }
        } else {
            //IF REF-ID NOT EXISTS FROM PAN THEN CREATE NEW REF-ID
            ReferenceIdGenerationEntity newRefIdEntity = saveNewReferenceId(idGenerationEntity);
            return newRefIdEntity;
        }
    }

//*********************************************************************************************************************************
@Override
public String createReferenceIdByPan(String brcode, String panNumber) {

    System.out.println(" INSIDE createReferenceIdByPan for  brcode  "+brcode);

    if(!brcode.isEmpty() ) {
        try {
            // String newRef = "MGBCAR2" + brcode + "@" + LocalDateTime.now().toString().substring(0, 10).replace("-", "") + UUID.randomUUID().toString().substring(0, 3).replace("-", "");

            String newRef = "MGBCAR" + brcode + "@" +panNumber.substring(0, 5)+ LocalDateTime.now().toString().substring(0, 10).replace("-", "")+ UUID.randomUUID().toString().substring(0, 3).replace("-", "") ;

            return newRef;
        }catch (Exception e){
            System.err.println("ERROR WHILE GENERATING NEW REFERENCE ID, details: "+e.getMessage());
            throw new RuntimeException("ERROR WHILE GENERATING NEW REFERENCE ID, details: "+e.getMessage());
        }
    }
    else
    {
        System.err.println("ERROR WHILE GENERATING NEW REFERENCE ID, BRANCH CODE IS EMPTY");
        throw new RuntimeException("ERROR WHILE GENERATING NEW REFERENCE ID, BRANCH CODE IS EMPTY");
    }
}

//***************************************************************************************************************************************
@Override
public ReferenceIdGenerationEntity saveNewReferenceId(ReferenceIdGenerationEntity receivedEntity) {

    ReferenceIdGenerationEntity newEntity= new ReferenceIdGenerationEntity();

   //------------------------- STEP-1 : GENERATE NEW REFERENCE ID --------------------------------//
    String newReferenceId = createReferenceIdByPan(receivedEntity.getBrcode(), receivedEntity.getPanNumber());

    System.out.println("INSIDE saveNewReferenceId , RECEIVED ENTITY : "+receivedEntity );

    newEntity.setPanNumber(receivedEntity.getPanNumber());
    newEntity.setReferenceId(newReferenceId);
    newEntity.setBrcode(receivedEntity.getBrcode());
    newEntity.setLoanType(receivedEntity.getLoanType());
    newEntity.setRoname(receivedEntity.getRoname());
    newEntity.setBrname(receivedEntity.getBrname());
    newEntity.setUserId(receivedEntity.getUserId());
    newEntity.setU_name(receivedEntity.getU_name());
    newEntity.setU_loc(receivedEntity.getU_loc());
    newEntity.setU_status(receivedEntity.getU_status());
    newEntity.setU_type(receivedEntity.getU_type());
    newEntity.setScale(receivedEntity.getScale());
    newEntity.setDsaNumber(receivedEntity.getDsaNumber());
    newEntity.setSourceType(receivedEntity.getSourceType());
    newEntity.setBorrowerType(receivedEntity.getBorrowerType());
    newEntity.setCustType(receivedEntity.getCustType());
    newEntity.setApplicationStatus("0");
    newEntity.setApplicationCreatedDate(LocalDateTime.now());

    String shortLoanType="";
    String shortBorrowerType="";

    //STEP-2 : GENERATE SHORT LOAN TYPE
    if (receivedEntity.getLoanType().equalsIgnoreCase(allStaticFields.newPassengerCar)) {
        shortLoanType="newPassengerCar";
    }else if (receivedEntity.getLoanType().equalsIgnoreCase(allStaticFields.newElectricPassengerCar)){
        shortLoanType="newElectricPassengerCar";
    }

    newEntity.setShortLoanType(shortLoanType);

    //STEP-3 : GENERATE SHORT BORROWER TYPE
    if (receivedEntity.getBorrowerType().equalsIgnoreCase(allStaticFields.residentIndian)) {
        shortBorrowerType="residentIndian";
    }else if (receivedEntity.getBorrowerType().equalsIgnoreCase(allStaticFields.nriOrPoi)){
        shortBorrowerType="nriOrPoi";
    }else if (receivedEntity.getBorrowerType().equalsIgnoreCase(allStaticFields.corporateClient)){
        shortBorrowerType="corporateClient";
    }
    newEntity.setShortBorrowerType(shortBorrowerType);

    //--------------------------- STEP-2 : SAVE NEW REFERENCE ID ---------------------------//
    referenceIdGenerationRepo.save(newEntity);

    //--------------------------- STEP-3 : SAVE REFERENCE ID DATA IN OTHER TABLES ---------------------------//

    createEntriesInTablesFromReferenceIdData(newEntity);

    System.out.println("NEW REFERENCE ID DATA SAVED :"+newEntity);
    return newEntity;
 }
//***************************************************************************************************************************************

    @Override
    public ReferenceIdGenerationEntity getReferenceIdDetails(String referenceId) {
        ReferenceIdGenerationEntity refIdData = referenceIdGenerationRepo.findByReferenceId(referenceId);

        if (refIdData != null)
        {
            return refIdData;
        }else{
        return null;
       }
    }
//***************************************************************************************************************************************

    @Override
    public String createEntriesInTablesFromReferenceIdData(ReferenceIdGenerationEntity newEntity) {

        //--------------------------- STEP-1 : SAVE REFERENCE ID DATA IN CIBIL-CRIF REMARK TABLE ---------------------------//

        CibilCrifRemarkEntity cibilCrifRemarkEntity=new CibilCrifRemarkEntity();

        cibilCrifRemarkEntity.setReferenceId(newEntity.getReferenceId());
        cibilCrifRemarkEntity.setUserId(newEntity.getUserId());
        cibilCrifRemarkEntity.setLoanType(newEntity.getLoanType());
        cibilCrifRemarkEntity.setBorrowerType(newEntity.getBorrowerType());
        cibilCrifRemarkRepo.save(cibilCrifRemarkEntity);

        //--------------------------- STEP-2: SAVE REFERENCE ID DATA IN DOCUMENTS & REMARK Mandatory TABLE ---------------------------//
        DocumentsAndRemarksMandatoryEntity mandatoryEntity=new DocumentsAndRemarksMandatoryEntity();
        mandatoryEntity.setReferenceId(newEntity.getReferenceId());
        mandatoryEntity.setLoanType(newEntity.getLoanType());
        mandatoryEntity.setShortLoanType(newEntity.getShortLoanType());
        mandatoryEntity.setBorrowerType(newEntity.getBorrowerType());
        mandatoryEntity.setShortBorrowerType(newEntity.getShortBorrowerType());
        if(newEntity.getBorrowerType().equalsIgnoreCase(AllStaticFields.nriOrPoi)){
            mandatoryEntity.setApplicantPassport("YES");
        }
        mandatoryDocumentListRepo.save(mandatoryEntity);



        return "";
    }


}




