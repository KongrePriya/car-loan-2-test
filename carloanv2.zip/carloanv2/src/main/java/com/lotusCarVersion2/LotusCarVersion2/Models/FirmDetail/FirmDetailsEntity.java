package com.lotusCarVersion2.LotusCarVersion2.Models.FirmDetail;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@Data
@Table(name = "firm_details")
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class FirmDetailsEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String firmSalutation;
    private String firmTradeName;
    private String firmLegalNameOfBusiness;
    private String firmCustomerType;
    private String firmMobile;
    private String firmBusinessSector;
    private String firmEmail;
    private String firmNatureOfBusiness;
    private String firmTypeOfBorrower;
    private String firmBranchCode;
    private String firmBranchName;
    private String firmRoName;
    private String firmRegisterAddress;
    private String firmRegisterVillage;
    private String firmRegisterBlock;
    private String firmRegisterPin;
    private String firmRegisterDistrict;
    private String firmRegisterState;
    private String firmOtherAddress;
    private String firmOtherVillage;
    private String firmOtherBlock;
    private String firmOtherPin;
    private String firmOtherDistrict;
    private String firmOtherState;
    private String firmReferenceId;
    private String firmCin;
    private String firmPan;
    private String firmGstn;
    private String firmUdyam;
    private String firmTan;
    private String firmLei;
    private LocalDate firmDateOfCertificate;
    private String firmUdin;
    private Long firmNetWorth;
    private String firmSourceOfNetWorth;
    private LocalDate firmNetWorthAsOnDate;
    private String firmNameOfCa;
    private LocalDate firmEstablishmentDate;

    private LocalDateTime timestamp=LocalDateTime.now();
    private String firmGstinStatus;
    private String firmConstitutionOfBusiness;
    private String firmDateOfRegistration;
    private String firmPrincipalPlaceOfBusinessAddress;
    private String firmStateJurisdictionCode;
    private String firmDateOfCancellation;
    private String firmCentreJurisdictionCode;
    private String firmLastUpdatedDate;
    private String firmCentreJurisdiction;
    private String firmTaxpayerType;
    private String firmAdditionalPlaceOfBusinessAddress;
    private String firmStateJurisdiction;

    private String userId;
    private String commCrifFetchedFor;
    private String crifCommFetched;
    private LocalDate bankingwithus;

}
