package com.lotusCarVersion2.LotusCarVersion2.Services.IndividualBasicDetails;

import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.HistoryIndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;

public interface HistoryIndividualBasicDetailsService {

     String deleteDetailsAndSaveToHistory(String referenceId, String customerType,String pan, String deletedBy);

     String saveToHistoryTable(HistoryIndividualBasicDetailsEntity entity);
     String deleteFromBaseTable(IndividualBasicDetailsEntity existingEntity);

     String deleteITRDetails(String referenceId, String customerType, String deletedBy);
}
