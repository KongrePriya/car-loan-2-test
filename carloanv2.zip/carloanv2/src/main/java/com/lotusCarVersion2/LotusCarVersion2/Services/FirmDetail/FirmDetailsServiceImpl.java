package com.lotusCarVersion2.LotusCarVersion2.Services.FirmDetail;


import com.lotusCarVersion2.LotusCarVersion2.DTO.FirmDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.FirmDetailsDtoHistory;
import com.lotusCarVersion2.LotusCarVersion2.Models.FirmDetail.FirmDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.FirmDetail.FirmDetailsEntityHistory;
import com.lotusCarVersion2.LotusCarVersion2.Repository.FirmDetail.FirmDetailsHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.FirmDetail.FirmDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.exception.ResourceNotFoundException;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;

@Service
@AllArgsConstructor
public class FirmDetailsServiceImpl implements FirmDetailsService {

    private FirmDetailsRepo firmDetailsRepo;
    private FirmDetailsHistoryRepo firmDetailsHistoryRepo;
    private ModelMapper modelMapper;
 /*   private final AppraisalNoteService appraisalNoteService;
    @Autowired
    private GstStatusService gstStatusService;*/

    public String saveFirmDetails(FirmDetailsDto firmDetailsDto) throws IOException {

        // Mapping the list of DTOs to a list of entities and calculating lowest values for each entity
        FirmDetailsEntity firmDetailsentity = modelMapper.map(firmDetailsDto, FirmDetailsEntity.class);
        boolean isIdPresent = firmDetailsRepo.existsByFirmReferenceId(firmDetailsentity.getFirmReferenceId());
        System.out.println("Step 1" + isIdPresent);
        if (isIdPresent) {
            System.out.println("Step 2");
            FirmDetailsEntity existingFirm = firmDetailsRepo.findByFirmReferenceId(firmDetailsentity.getFirmReferenceId());
            System.out.println("Step 3 with data" + existingFirm);
            return createFirmDetailsHistory(existingFirm, firmDetailsentity);
        } else {
            try {
                System.out.println("Step 4 try with data");

                firmDetailsRepo.save(firmDetailsentity); //... Saving the entity to the database
/*

                // SAVE DATA IN APPRAISAL NOTE TABLE
                appraisalNoteService.updateAppraisalFirmData(firmDetailsentity.getFirmReferenceId());
                System.out.println("APPRAISAL NOTE TABLE UPDATED SUCEESFULLY");

                // UPDATE GST STATUS FOR FIRM DETAILS
                gstStatusService.updateFirmDetailStatus(firmDetailsentity.getFirmReferenceId());
*/

            } catch (Exception e) {
                System.out.println("Step 5 with catch ");
                throw new IOException("Error While Saving/Updating Firm details");
            }

//            appraisalNoteService.updateAppraisalFirmData(firmDetailsDto.getFirmReferenceId());

            return "Saved Success";
        }


    }


    @Override
    public FirmDetailsDto getFirmDetails(String ref_id) {
        System.out.println("REFERENCE NUMBER: " + ref_id);
        FirmDetailsEntity entity = firmDetailsRepo.findByFirmReferenceId(ref_id);
        System.out.println(" EXISTING FIRM DETAILS: " + entity);
        if (entity == null) {
            throw new ResourceNotFoundException("Data For Reference Id " + ref_id + " Not Found");
//            System.out.println("Firm Data for Reference Id "+ref_id+" Not exists, New Application Found.");
        } else {
            return modelMapper.map(entity, FirmDetailsDto.class);

        }
        //firmDetailsRepo.findByFirmReferenceNumber(ref_id);
    }

    @Override
    public String createFirmDetailsHistory(FirmDetailsEntity existingFirm, FirmDetailsEntity toSavedAsNew) {
        FirmDetailsEntityHistory historyData = new FirmDetailsEntityHistory();
        historyData.setFirmCin(existingFirm.getFirmCin());
        historyData.setFirmEmail(existingFirm.getFirmEmail());
        historyData.setFirmEstablishmentDate(existingFirm.getFirmEstablishmentDate());
        historyData.setFirmBranchName(existingFirm.getFirmBranchName());
        historyData.setFirmBranchCode(existingFirm.getFirmBranchCode());
        historyData.setFirmLei(existingFirm.getFirmLei());
        historyData.setFirmGstn(existingFirm.getFirmGstn());
        historyData.setFirmMobile(existingFirm.getFirmMobile());
        historyData.setFirmTradeName(existingFirm.getFirmTradeName());
        historyData.setFirmLegalNameOfBusiness(existingFirm.getFirmLegalNameOfBusiness());
        historyData.setUserId(existingFirm.getUserId());
        historyData.setFirmUdin(existingFirm.getFirmUdin());
        historyData.setFirmPan(existingFirm.getFirmPan());
        historyData.setFirmTan(existingFirm.getFirmTan());
        historyData.setFirmUdyam(existingFirm.getFirmUdyam());
        historyData.setFirmRoName(existingFirm.getFirmRoName());
        historyData.setFirmBusinessSector(existingFirm.getFirmBusinessSector());
        historyData.setFirmNameOfCa(existingFirm.getFirmNameOfCa());
        historyData.setFirmSalutation(existingFirm.getFirmSalutation());
        historyData.setFirmCustomerType(existingFirm.getFirmCustomerType());
        historyData.setFirmDateOfCertificate(existingFirm.getFirmDateOfCertificate());
        historyData.setFirmNatureOfBusiness(existingFirm.getFirmNatureOfBusiness());
        historyData.setFirmNetWorth(existingFirm.getFirmNetWorth());
        historyData.setFirmNetWorthAsOnDate(existingFirm.getFirmNetWorthAsOnDate());
        historyData.setFirmSourceOfNetWorth(existingFirm.getFirmSourceOfNetWorth());
        historyData.setTimestamp(existingFirm.getTimestamp());
        historyData.setModifiedDate(LocalDateTime.now());
        historyData.setFirmTypeOfBorrower(existingFirm.getFirmTypeOfBorrower());

        historyData.setFirmRegisterAddress(existingFirm.getFirmRegisterAddress());
        historyData.setFirmRegisterBlock(existingFirm.getFirmRegisterBlock());
        historyData.setFirmRegisterDistrict(existingFirm.getFirmRegisterDistrict());
        historyData.setFirmRegisterPin(existingFirm.getFirmRegisterPin());
        historyData.setFirmRegisterState(existingFirm.getFirmRegisterState());
        historyData.setFirmRegisterVillage(existingFirm.getFirmRegisterVillage());

        historyData.setFirmReferenceId(existingFirm.getFirmReferenceId());
        historyData.setFirmOtherAddress(existingFirm.getFirmOtherAddress());
        historyData.setFirmOtherBlock(existingFirm.getFirmOtherBlock());
        historyData.setFirmOtherPin(existingFirm.getFirmOtherPin());
        historyData.setFirmOtherState(existingFirm.getFirmOtherState());
        historyData.setFirmOtherVillage(existingFirm.getFirmOtherVillage());
        historyData.setFirmOtherDistrict(existingFirm.getFirmOtherDistrict());

        historyData.setFirmGstinStatus(existingFirm.getFirmGstinStatus());
        historyData.setFirmConstitutionOfBusiness(existingFirm.getFirmConstitutionOfBusiness());
        historyData.setFirmDateOfRegistration(existingFirm.getFirmDateOfRegistration());
        historyData.setFirmPrincipalPlaceOfBusinessAddress(existingFirm.getFirmPrincipalPlaceOfBusinessAddress());
        historyData.setFirmStateJurisdictionCode(existingFirm.getFirmStateJurisdictionCode());
        historyData.setFirmDateOfCancellation(existingFirm.getFirmDateOfCancellation());
        historyData.setFirmCentreJurisdictionCode(existingFirm.getFirmCentreJurisdictionCode());
        historyData.setFirmLastUpdatedDate(existingFirm.getFirmLastUpdatedDate());
        historyData.setFirmCentreJurisdiction(existingFirm.getFirmCentreJurisdiction());
        historyData.setFirmTaxpayerType(existingFirm.getFirmTaxpayerType());
        historyData.setFirmAdditionalPlaceOfBusinessAddress(existingFirm.getFirmAdditionalPlaceOfBusinessAddress());
        historyData.setFirmStateJurisdiction(existingFirm.getFirmStateJurisdiction());
        historyData.setCommCrifFetchedFor(existingFirm.getCommCrifFetchedFor());
        historyData.setCrifCommFetched(existingFirm.getCrifCommFetched());
        historyData.setBankingwithus(existingFirm.getBankingwithus());


        try {
            firmDetailsHistoryRepo.save(historyData);

            toSavedAsNew.setCrifCommFetched(existingFirm.getCrifCommFetched());
            firmDetailsRepo.delete(existingFirm);
            //Set Commercial Fetch Status to yes or no
            firmDetailsRepo.save(toSavedAsNew);

           /* // SAVE DATA IN APPRAISAL NOTE TABLE
            appraisalNoteService.updateAppraisalFirmData(toSavedAsNew.getFirmReferenceId());
            System.out.println("APPRAISAL NOTE TABLE UPDATED SUCEESFULLY");

            // UPDATE GST STATUS FOR FIRM DETAILS
            gstStatusService.updateFirmDetailStatus(toSavedAsNew.getFirmReferenceId());*/
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return "Update Successfully";
    }

    @Override
    public FirmDetailsDtoHistory getFirmDetailHistory(String ref_id) {
        FirmDetailsEntityHistory entity = firmDetailsHistoryRepo.findByFirmReferenceId(ref_id);
        System.out.println(" EXISTING FIRM DETAILS: " + entity);
        if (entity == null) {
            throw new ResourceNotFoundException("Data For Reference Id " + ref_id + " Not Found");
        } else {
            return modelMapper.map(entity, FirmDetailsDtoHistory.class);
        }
        //  return firmDetailsHistoryRepo.getReferenceById(ref_id);
    }


}