package com.lotusCarVersion2.LotusCarVersion2.Controller.Calculation;

import com.lotusCarVersion2.LotusCarVersion2.DTO.FinalLoanSummaryDTO;
import com.lotusCarVersion2.LotusCarVersion2.Services.Calculation.CalculationService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@AllArgsConstructor
@RequestMapping("/api/v1/calculation")
public class CalculationController {

private final CalculationService calculationService;

@GetMapping("/get/{referenceId}")
public ResponseEntity<FinalLoanSummaryDTO> getCalculationDisplaySummary(@PathVariable String referenceId){
    FinalLoanSummaryDTO finalLoanSummaryDTO=calculationService.getCalculationDisplaySummary(referenceId);
    if(finalLoanSummaryDTO != null){
        System.out.println(" CALCULATION SUMMARY FOUND FOR REF-ID: "+finalLoanSummaryDTO);
        return ResponseEntity.ok(finalLoanSummaryDTO);
    }else{
        System.out.println(" NO DATA FOUND FOR CALCULATION SUMMARY ");
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
}
