package com.lotusCarVersion2.LotusCarVersion2.Services.CibilDetailsCommercial;

import com.lotusCarVersion2.LotusCarVersion2.Config.CibilConfig;
import com.lotusCarVersion2.LotusCarVersion2.DTO.CorporateGuarantorDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.FirmDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

@Service
@AllArgsConstructor

public class FetchCommercialCibilService {

    @Autowired
    private final RestTemplate restTemplate;
    private final CibilCrifFetchStatusService cibilCrifFetchStatusService;

//********************************************************************************************************************//
//TO FETCH CIBIL OF SINGLE Corporate Guarantors
    public ResponseEntity<String> fetchCommercialCibilSingleGuarantor(@Valid @RequestBody CorporateGuarantorDto corpGuarantorSingleDto) {

        System.out.println("inside fetchCommercialCibil- Single Guarantor LOS-GST. ");

        String commercialCibilFetchUrl = CibilConfig.CommercialCibilIP + "/commercial-cibil/fetch/guarantor";
        System.out.println(" URL: " + commercialCibilFetchUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        HttpEntity<CorporateGuarantorDto> corpGuarDto = new HttpEntity<>(corpGuarantorSingleDto, headers);
        try {
            ResponseEntity<String>  responseEntity = restTemplate.postForEntity(
                    commercialCibilFetchUrl,
                    corpGuarDto,
                    String.class);
            System.out.println(responseEntity);
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
//                cibilCrifFetchStatusService.corpGuarCountStatus(corpGuarantorSingleDto.getReferenceId());
                return ResponseEntity.ok(responseEntity.getBody());
            } else {
                System.err.println("ERROR IN FETCHING COMMERCIAL  FETCH,, RESPONSE:" + responseEntity.getBody());
                return ResponseEntity.status(responseEntity.getStatusCode())
                        .body("FAILED to fetch commercial CIBIL for FIRM/BORROWER");
            }
        } catch (Exception e) {
            System.err.println("FAILED TO FETCH COMMERCIAL-CIBIL FOR PAN :" + corpGuarantorSingleDto.getPan());
            throw new RuntimeException("Guarantor commercial Cibil ErrorFAILED TO FETCH COMMERCIAL-CIBIL FOR PAN :" + corpGuarantorSingleDto.getPan());
        }
    }

//********************************************************************************************************************//
//TO FETCH CIBIL OF FIRM/BORROWER
    public ResponseEntity<String> fetchFirmCommercialCibil(@RequestBody FirmDetailsDto firmDetailsDto) {
        String commercialCibilFetchUrl = CibilConfig.CommercialCibilIP + "/commercial-cibil/fetch/firm";

        System.out.println("firm commercialCibilFetchUrl url:" +commercialCibilFetchUrl);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        HttpEntity<FirmDetailsDto> firmDtoHttp = new HttpEntity<>(firmDetailsDto, headers);

        try{
            //  POST request to local external API
            ResponseEntity<String> responseEntity = restTemplate.postForEntity
                    (commercialCibilFetchUrl,
                            firmDtoHttp,
                            String.class);
            System.out.println("FIRM CIBIL: responseEntity: " + responseEntity);
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                //firm cibil up to date set status
//                cibilCrifFetchStatusService.callAllFunctionsAtLast(firmDetailsDto.getFirmReferenceId());
                System.out.println("In fetchFirmCommercialCibil service: responseEntity :"+responseEntity.getBody());
                return ResponseEntity.ok(responseEntity.getBody());
            } else {
                System.err.println(" In fetchFirmCommercialCibil service: Failed to fetch commercial CIBIL for FIRM/BORROWER");
                return ResponseEntity.status(responseEntity.getStatusCode())
                        .body("Failed to fetch commercial CIBIL for FIRM/BORROWER");
            }
        } catch (Exception e) {

            System.err.println("CONNECTION ERROR-(IN SERVICE fetchFirmCommercialCibil) FAILED TO FETCH COMMERCIAL-CIBIL OF FIRM FOR PAN :" + firmDetailsDto.getFirmPan());
            throw new RuntimeException("FIRM/BORROWER COMMERCIAL-CIBIL : CONNECTION ERROR- FAILED TO FETCH COMMERCIAL-CIBIL,\n FOR PAN :" + firmDetailsDto.getFirmPan());
        }
    }
}
