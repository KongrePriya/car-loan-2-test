package com.lotusCarVersion2.LotusCarVersion2.Repository.CorporateGuarantorRepo;

import com.lotusCarVersion2.LotusCarVersion2.Models.CorporateGuarantor.CorporateGuarantorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CorporateGuarantorRepo extends JpaRepository<CorporateGuarantorEntity, Long> {


    //to retrieve list of Corporate-guarantors which are not deleted i.e. have  status null
    List<CorporateGuarantorEntity> findByReferenceIdAndCorpGuarStatusNull(String referenceId);

    //to delete unique entry or to set status as deleted
    CorporateGuarantorEntity findByReferenceIdAndId(String referenceId, Long id);


    //to get count of corporate guarantors
    @Query(nativeQuery = true, value = "SELECT COUNT(*) FROM los_car_v2.corp_guarantor_details WHERE corp_guar_status IS NULL AND reference_id = :referenceId")
    Integer countCorpGuarByReferenceId(@Param("referenceId") String referenceId);


    @Query(value = "SELECT SUM(CAST(corp_guar_networth AS numeric)) FROM los_car_v2.corp_guarantor_details WHERE corp_guar_status IS NULL AND reference_id = :referenceId", nativeQuery = true)
    Integer findByReferenceIdAndSumCorpGuarantorNetworth(@Param("referenceId") String referenceId);

}
