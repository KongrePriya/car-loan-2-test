package com.lotusCarVersion2.LotusCarVersion2.Controller.IncomeAll.IncomeDetailsList;


import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeMainList.IncomeMainListModel;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeMainList.IncomeMainListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1")
@CrossOrigin(origins = "*")
public class IncomeListMainController {

    @Autowired
    private IncomeMainListService incomeMainListService;

    @GetMapping("income-list/{referenceId}")
    public ResponseEntity<List<IncomeMainListModel>> getIncomeDetailsList(@PathVariable  String referenceId){
        List<IncomeMainListModel> incomeMainList = incomeMainListService.getIncomeList(referenceId);
        return new ResponseEntity<>(incomeMainList, HttpStatus.OK);
    }

    @GetMapping("income-count/{referenceId}")
    public ResponseEntity<String> matchIncomeDetailsCount(@PathVariable  String referenceId){
        String incomeDetailsCountMatch = incomeMainListService.matchCountIncomeDataForProceeding(referenceId);
        return new ResponseEntity<>(incomeDetailsCountMatch, HttpStatus.OK);
    }

}
