package com.lotusCarVersion2.LotusCarVersion2.Repository.FirmDetail;

import com.lotusCarVersion2.LotusCarVersion2.Models.FirmDetail.FirmDetailsEntityHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FirmDetailsHistoryRepo extends JpaRepository<FirmDetailsEntityHistory, String> {
    FirmDetailsEntityHistory findByFirmReferenceId(String ref_id);
}
