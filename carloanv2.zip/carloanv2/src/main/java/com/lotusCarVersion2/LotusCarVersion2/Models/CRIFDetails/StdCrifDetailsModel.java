package com.lotusCarVersion2.LotusCarVersion2.Models.CRIFDetails;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "std_crif_details_model", schema = "crif_individual")
public class StdCrifDetailsModel {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String customerScore;
    private Double totalAccounts;
    private Double activeAccounts;
    private String overdueAccounts;
    private Double overdueAmount;
    private String referenceId;
    private String branchCode;
    private String userId;
    private String individualPan;
    private LocalDateTime createdDate;
}
