package com.lotusCarVersion2.LotusCarVersion2.Services.RefIdGenerationService;

import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;

public interface RefIdGenerationService {

    ReferenceIdGenerationEntity checkAndGenerateReferenceIdByPan(ReferenceIdGenerationEntity idGenerationEntity);
    String createReferenceIdByPan(String brcode, String panNumber);
    ReferenceIdGenerationEntity saveNewReferenceId(ReferenceIdGenerationEntity receivedEntity);
    ReferenceIdGenerationEntity getReferenceIdDetails(String referenceId);

    String createEntriesInTablesFromReferenceIdData(ReferenceIdGenerationEntity newEntity);
}
