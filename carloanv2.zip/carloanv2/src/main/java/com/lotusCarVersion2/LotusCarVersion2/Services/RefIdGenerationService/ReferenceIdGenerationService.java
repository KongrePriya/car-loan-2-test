//package com.lotusCarVersion2.LotusCarVersion2.Services.RefIdGenerationService;
//
//
//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
//import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationModel;
//import com.lotusCarVersion2.LotusCarVersion2.Repository.DecisionStatus.DecisionStatusRepo;
//import com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo.ReferenceidGenerationRepo;
//import jakarta.transaction.Transactional;
//import lombok.RequiredArgsConstructor;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
//import java.util.Date;
//import java.util.Random;
//
//@Service
//@RequiredArgsConstructor
//@Transactional
//@JsonIgnoreProperties({"advisors"})
//public class ReferenceIdGenerationService {
//    @Autowired
//    private ReferenceidGenerationRepo referenceidGenerationRepo;
//    private DecisionStatusRepo decisionStatusRepo;
//    private final AllStaticFields allStaticFields;
//
////********************************* REFERENCE ID Generation ***********************************************************************
//
//    public String generateAndSave(ReferenceIdGenerationModel referenceIdGenerationModel) throws JsonProcessingException {
//
//        String message = "";
//        System.out.println("In Generating Reference Number");
//        String adharNumber = referenceIdGenerationModel.getPanNumber();
//
//// ************************************** FOR VALID CRR REFERENCE ID ***********************************************
//
//        if (adharNumber.length() == 12) {
//            boolean isAadharAvailable = referenceidGenerationRepo.existsByAadharNumber(adharNumber);
//
//            if (isAadharAvailable) {
//                //************ this status check from final application status model********
//                ReferenceIdGenerationModel refNoVar = referenceidGenerationRepo.findByAadharNumber(adharNumber);
//
//                boolean isApplicationValid = (refNoVar.getApplicationStatus().equalsIgnoreCase("REJ") ||
//                        refNoVar.getApplicationStatus().equalsIgnoreCase("SAN"));
//
//                if (isApplicationValid) {
//                    //generate New Reference Number As appliction is sanction or rejected For Same Aadhar Card
//                    message = saveNewReferenceId(referenceIdGenerationModel);
//                } else {
//                    message = "Aadhar Card Already exit with Reference Number :" + refNoVar.getReferenceId();
//                }
//            } else {
//                message = saveNewReferenceId(referenceIdGenerationModel);
//            }
//
//
//        } else {
//            System.out.println("IN AADHAR NUMBER  INVALID METHOD ");
//            message = "Error : ENTERED AADHAR NUMBER IS INVALID";
//        }
//        return message;
//
//    }
//
//
//    public String generateReferenceNumber(String brcode) {
//
//        String fixedPrefix = "MGBCARV";
//        String prefix = fixedPrefix + brcode; // e.g. ABCHUMV4000
//        String dateStr = new SimpleDateFormat("yyyyMMdd").format(new Date());
//
//        // Generate 3 random alphanumeric characters (A–Z, a–z, 0–9)
//        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
//        Random random = new Random();
//        StringBuilder randomStr = new StringBuilder(3);
//        for (int i = 0; i < 3; i++) {
//            randomStr.append(chars.charAt(random.nextInt(chars.length())));
//        }
//
//        return prefix + "@" + dateStr + randomStr.toString();
//
//    }
//
//    public String searchReferenceId(String refNumber) {
//
//        try {
//            return referenceidGenerationRepo.findByReferenceId(refNumber).getReferenceId();
//        } catch (Exception e) {
//            return "Reference Id Not Found / Error Occur ";
//        }
//    }
////***************************************************************************************************************************************
//
//    public String saveNewReferenceId(ReferenceIdGenerationModel refNoVarification) {
//
//
//        //********************* FOR NEW REFERENCE ID SET DATA IN REFNOVARIFICATION MODEL ***********************************
//
//        String referenceId;
//        System.out.println("Branch Code is"+refNoVarification.getBrcode());
//        referenceId = generateReferenceNumber(refNoVarification.getBrcode());
//        System.out.println("Reference Id Generated as -- " + referenceId);
//        refNoVarification.setPanNumber(refNoVarification.getPanNumber());
//        refNoVarification.setReferenceId(referenceId);
//        refNoVarification.setBrcode(refNoVarification.getBrcode());
//        refNoVarification.setLoanType(refNoVarification.getLoanType());
//        refNoVarification.setApplicationStatus("0");
//        refNoVarification.setApplicationCreatedDate(LocalDateTime.now());
//        refNoVarification.setRoname(refNoVarification.getRoname());
//        refNoVarification.setUserId(refNoVarification.getUserId());
//        refNoVarification.setU_name(refNoVarification.getU_name());
//        refNoVarification.setU_loc(refNoVarification.getU_loc());
//        refNoVarification.setU_status(refNoVarification.getU_status());
//        refNoVarification.setU_type(refNoVarification.getU_type());
//        refNoVarification.setScale(refNoVarification.getScale());
//        refNoVarification.setDsaNumber(refNoVarification.getDsaNumber());
//        refNoVarification.setSourceType(refNoVarification.getSourceType());
//
//        String shortLoanType="";
//        String shortBorrowerType="";
//
//        //STEP-2 : GENERATE SHORT LOAN TYPE
//        if (refNoVarification.getLoanType().equalsIgnoreCase(allStaticFields.newPassengerCar)) {
//            shortLoanType="newPassengerCar";
//        }else if (refNoVarification.getLoanType().equalsIgnoreCase(allStaticFields.newElectricPassengerCar)){
//            shortLoanType="newElectricPassengerCar";
//        }
//
//        refNoVarification.setShortLoanType(shortLoanType);
//
//        //STEP-3 : GENERATE SHORT BORROWER TYPE
//        if (refNoVarification.getBorrowerType().equalsIgnoreCase(allStaticFields.residentIndian)) {
//            shortBorrowerType="residentIndian";
//        }else if (refNoVarification.getBorrowerType().equalsIgnoreCase(allStaticFields.nriOrPoi)){
//            shortBorrowerType="nriOrPoi";
//        }else if (refNoVarification.getBorrowerType().equalsIgnoreCase(allStaticFields.corporateClient)){
//            shortBorrowerType="corporateClient";
//        }
//        refNoVarification.setShortBorrowerType(shortBorrowerType);
//
//        referenceidGenerationRepo.save(refNoVarification);
//
//        //createAndSaveStatus(refNoVarification);
//
//        System.out.println("REFERENCE ID GENERATION & DATA IS SAVED");
////        Appraisal Note Table load with data when new reference id generated
////        appraisalNoteService.updateAppraisalRefIdVarification(referenceId);
//        //  System.out.println("appraisal note  DATA SAVED");
//        return referenceId;
////********************** FOR NEW REFERENCE ID SET DATA IN LOS-GST-STATUS MODEL ***********************************
//    }
//
///*
//    public void createAndSaveStatus(ReferenceIdGenerationModel refNoVarification) {
//
//
////      Creating Reference No. enrty in Decision Status(home_application_status) and Document Upload Tables
//        DecisionStatusModel decisionStatusModel = new DecisionStatusModel();
//        DocumentUploadModel documentUploadModel = new DocumentUploadModel();
////        FinalCheckModel finalCheckModel=new FinalCheckModel();
//
////        finalCheckModel.setReferenceId(refNoVarification.getReferenceId());
////        finalCheckModel.setBranchCode(refNoVarification.getBrcode());
////        finalCheckModel.setUserId(refNoVarification.getUserId());
//
//        documentUploadModel.setReferenceId(refNoVarification.getReferenceId());
//
//        documentUploadModel.setBranchCode(refNoVarification.getBrcode());
//        decisionStatusModel.setApplnStatusBranchManager("PEN");
//        decisionStatusModel.setApplnStatusBranchOfficer("PEN");
//        decisionStatusModel.setApplnStatusMain("PEN");
//
//        decisionStatusModel.setReferenceId(refNoVarification.getReferenceId());
//        decisionStatusModel.setApplicationCreationDate(refNoVarification.getApplicationCreatedDate());
//        decisionStatusModel.setBranchCode(refNoVarification.getBrcode());
//        decisionStatusModel.setRoname(refNoVarification.getRoname());
//        decisionStatusModel.setUserType(refNoVarification.getU_type());
//        decisionStatusModel.setUserLoc(refNoVarification.getU_loc());
//        decisionStatusModel.setDeviationStatus("NO DEVIATION");
//        decisionStatusModel.setLoanType(refNoVarification.getLoanType());
//        decisionStatusModel.setApplnPendingAtWhichLevel("Application Not Submitted By Branch");
//
//
//        try {
//            decisionStatusRepo.save(decisionStatusModel);
//            documentUploadRepo.save(documentUploadModel);
////                finalFlagRepository.save(finalCheckModel);
//        } catch (Exception e) {
//            System.err.println("Error Occurred While Setting Values In DecisionStatusModel or Document Upload Model) Error----- " + e);
//            throw new RuntimeException("Error Occurred While Setting Values In DecisionStatusModel or Document Upload Model) Error----- " + e);
//        }
//    }
//*/
//}
//
//
//
//
