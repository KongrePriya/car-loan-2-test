package com.lotusCarVersion2.LotusCarVersion2.Services.IndividualBasicDetails;

import com.lotusCarVersion2.LotusCarVersion2.Models.ITR.ITRDetailsAsPerScreenEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.HistoryIndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsPersonal.CibilBasicAndSummaryDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilDetailsPersonal.CibilHistoryDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.ITR.ITRDetailsScreenHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.ITR.ITRDetailsScreenRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.ITR.ItrEmailDataResponseRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.ITR.ItrHistoryEmailDataResponseRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.HistoryIndividualBasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusService;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationCheckingRequiredDataService;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeMainList.IncomeMainListService;
import jakarta.persistence.OptimisticLockException;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@Transactional
@AllArgsConstructor
public class HistoryIndividualBasicDetailsServiceImpl implements HistoryIndividualBasicDetailsService{

    private ModelMapper modelMapper;
    private final IndividualBasicDetailsRepo individualBasicDetailsRepo;
    private final HistoryIndividualBasicDetailsRepo historyIndividualBasicDetailsRepo;
    private final CibilBasicAndSummaryDetailsRepo cibilBasicAndSummaryDetailsRepo;
    private final CibilHistoryDetailsRepo cibilHistoryDetailsRepo;
    private final CibilCrifFetchStatusService cibilFetchStatusService;
    private final IncomeMainListService incomeMainListService;
    private final ItrEmailDataResponseRepo itrEmailDataResponseRepo;
    private final ItrHistoryEmailDataResponseRepo itrHistoryEmailDataResponseRepo;
    private final ITRDetailsScreenHistoryRepo itrDetailsScreenHistoryRepo;
    private final ITRDetailsScreenRepo itrDetailsScreenRepo;
    private final DeviationCheckingRequiredDataService deviationCheckingRequiredDataService;

    //***********************************************************************************************************************//
    @Override
    @Transactional
    public String deleteDetailsAndSaveToHistory(String referenceId, String customerType, String pan, String deletedBy) {
        IndividualBasicDetailsEntity existingEntity = individualBasicDetailsRepo.findByReferenceIdAndPan(referenceId, pan);

        if (existingEntity != null) {
            System.out.println("//----------------------------------- INSIDE DELETE INDIVIDUAL METHOD -----------------------------------------//");
            HistoryIndividualBasicDetailsEntity historyEntity = new HistoryIndividualBasicDetailsEntity();
            historyEntity.setDeletedBy(deletedBy);
            historyEntity.setDeletedAt(LocalDateTime.now());

            // step-1 : Copy properties from entity to historyEntity
            System.out.println("step-1 : Copy properties from entity to historyEntity");
            try {
                modelMapper.map(existingEntity, historyEntity);
                System.out.println("historyEntity : "+historyEntity);
                System.out.println("DETAILS OF " + customerType + " EXISTING ENTITY MAPPED TO HISTORY-ENTITY.");
            } catch (Exception e) {
                System.err.println("ERROR WHILE MAPPING " + customerType + "  DETAILS TO HISTORY TABLE: " + e.getMessage());
                throw new RuntimeException("ERROR WHILE MAPPING  " + customerType + "  DETAILS TO HISTORY TABLE: " + e.getMessage());
            }

            // step-2 :  Save record to history table
            System.out.println("step-2 :  Save record to history table");
            try {
                String result = saveToHistoryTable(historyEntity);
                System.out.println(result);
            } catch (Exception e) {
                System.err.println(e);
                throw new RuntimeException(e.getMessage());
            }


            // step-3 : deleting CIBIL entries for that PAN against ref-id
            System.out.println("step-3 : deleting CIBIL entries for that PAN against ref-id");
            try {
                // Update CIBIL status :- MUST CALL THIS AFTER DEVIATION SERVICES CALLED AS AFTER THIS THE CIBIL DETAILS WILL BE REMOVED
                int basicDetailsRowsAffected = cibilBasicAndSummaryDetailsRepo.updatePersonalCibilStatusOldWhenDeleted(existingEntity.getPan(), referenceId);
                int historyRowsAffected = cibilHistoryDetailsRepo.updatePersonalCibilStatusOldWhenDeleted(existingEntity.getPan(), referenceId);
                System.out.println("CIBIL: Existing entries for deleted "+existingEntity.getCustomerType()+" set to old. FOR PAN:  "+existingEntity.getPan()+ "And ReferenceID : "+referenceId +
                        " basicDetailsRowsAffected: " + basicDetailsRowsAffected + ", historyRowsAffected: " + historyRowsAffected);
            } catch (Exception e) {
                System.err.println("ERROR WHILE UPDATING CIBIL STATUS: FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
                        " Error details: "+e.getMessage());
                throw new RuntimeException("ERROR WHILE UPDATING CIBIL STATUS: FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
                        " Error details: "+e.getMessage());
            }


            // step-4 : update CIBIL deviation when Individual Deleted
            System.out.println("step-4 : update CIBIL deviation when Individual Deleted");
            try{
                //DEVIATIONS FOR CIBIL
//                deviationFlagsStatusService.updateCibilDeviationCommon(existingEntity.getReferenceId());

                //CIBIL-FETCHED STATUS FLAGS : after deleting entries from cibil schema
//                cibilFetchStatusService.updateCibilFetchedBorrowerGuarantorFlag(exitingMappedDto);
            }catch (Exception e){
                System.err.println("ERROR WHILE UPDATING DEVIATION FOR CIBIL : FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
                        " Error details: "+e.getMessage());
                throw new RuntimeException("ERROR WHILE UPDATING DEVIATION FOR CIBIL : FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
                        " Error details: "+e.getMessage());
            }


            // step-5 : delete Income details based on Customer Type from income tables
            System.out.println("step-5 : delete Income details based on Customer Type from income tables");
            try{
                incomeMainListService.redirectToDeleteIncomeData(referenceId,existingEntity.getPan(), existingEntity.getIncomeSourceType());
            }catch(Exception e){
                System.err.println("ERROR WHILE DELETING INCOME DATA FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
                        " Error details: "+e.getMessage());
                throw new RuntimeException("ERROR WHILE DELETING INCOME DATA FOR PAN:  "+existingEntity.getPan()+ " And ReferenceID : "+referenceId +
                        " Error details: "+e.getMessage());
            }
            // step- 6: DELETE ITR DETAILS from ITR Schema
            System.out.println("step- 6: DELETE ITR DETAILS from ITR Schema");
            try {
                deleteITRDetails(referenceId,customerType, deletedBy);
            } catch (Exception e) {
                System.err.println("ERROR WHILE REMOVING ITR DETAILS REMOVED FROM REF-ID RESPONSE TABLE & ITR-DETAILS TABLE FOR reference-Id: "
                        +referenceId +" AND Customer-type :"+customerType+ " Error details: "+e.getMessage());
                throw new RuntimeException("ERROR WHILE REMOVING ITR DETAILS REMOVED FROM REF-ID RESPONSE TABLE & ITR-DETAILS TABLE FOR reference-Id: "
                        +referenceId +" AND Customer-type :"+customerType+ " Error details: "+e.getMessage());
            }

            // Delete the existingEntity
            // step-last : delete entity from base Table
            System.out.println("step-last : delete entity from base Table");
            try {
                String result1 = deleteFromBaseTable(existingEntity);
                System.out.println(result1);
            } catch (Exception e) {
                System.err.println(e);
                throw new RuntimeException(e.getMessage());
            }
            System.out.println("//--------- DETAILS OF " + customerType + " FOR REFERENCE-ID: " + referenceId + " DELETED SUCCESSFULLY...!!! ---------//");
            return "DETAILS OF " + customerType + " FOR REFERENCE-ID: " + referenceId + " DELETED SUCCESSFULLY...!!!";
        } else {
            System.err.println("DETAILS OF " + customerType + " FOR REFERENCE-ID: " + referenceId + " NOT FOUND OR ALREADY DELETED...!!!");
            throw new RuntimeException("DETAILS OF " + customerType + " FOR REFERENCE-ID: " + referenceId + " NOT FOUND OR ALREADY DELETED...!!!");
        }
    }
//***********************************************************************************************************************//
    @Override
    @Transactional
    public String saveToHistoryTable(HistoryIndividualBasicDetailsEntity historyEntity) {
        // Save record to history table
        try {
            historyIndividualBasicDetailsRepo.save(historyEntity);
            System.out.println("DETAILS OF " + historyEntity.getCustomerType() + " SAVED TO HISTORY-ENTITY.");
        }catch (OptimisticLockException e) {
            System.err.println("CONCURRENT UPDATE DETECTED FOR REFERENCE-ID: " +  historyEntity.getReferenceId() +" ERROR DETAILS: "+e.getMessage());
            throw new RuntimeException("CONCURRENT UPDATE DETECTED, PLEASE TRY AGAIN."+e.getMessage());
        } catch (Exception e) {
//                e.printStackTrace();
            System.err.println("ERROR WHILE SAVING  " +  historyEntity.getCustomerType() + " DATA IN HISTORY ENTITY: " + e.getMessage());
            throw new RuntimeException("ERROR WHILE SAVING " +  historyEntity.getCustomerType() + " DATA IN HISTORY ENTITY: " + e.getMessage());
        }

        return "PRIYA";
    }
//***********************************************************************************************************************//

    @Override
    @Transactional
    public String deleteFromBaseTable(IndividualBasicDetailsEntity existingEntity) {
        // Save record to history table
        try {
            individualBasicDetailsRepo.delete(existingEntity);
            System.out.println("EXISTING DETAILS OF " + existingEntity.getCustomerType() + " DELETED FROM BASE ENTITY.");

            // DELETE BASIC DATA FROM APPRAISAL TABLE
            //  STATUS RESET METHOD CALLED

        }
        catch (OptimisticLockException e) {
            System.err.println("CONCURRENT UPDATE DETECTED FOR REFERENCE-ID: " + existingEntity.getCustomerType() );
            throw new RuntimeException("CONCURRENT UPDATE DETECTED, PLEASE TRY AGAIN."+e.getMessage());
        } catch (Exception e) {
            System.err.println("ERROR WHILE DELETING " + existingEntity.getCustomerType()  + " DETAILS FROM BASE TABLE: " + e.getMessage());
            throw new RuntimeException("ERROR WHILE DELETING  " + existingEntity.getCustomerType()  + "  DETAILS FROM BASE TABLE: " + e.getMessage());
        }

        return "PRIYA";
    }

//****************************** REMOVE ITR DETAILS *************************************//
@Transactional
public String deleteITRDetails(String referenceId, String customerType, String deletedBy) {
        System.out.println("//--------------------------------------------- INSIDE DELETE ITR Details from KYC_ITR Schema.---------------------------------------------//");

        ITRDetailsAsPerScreenEntity itrDetails= itrDetailsScreenRepo.getITRDataByReferenceAndType(referenceId, customerType);
        if(itrDetails != null) {
            System.out.println("ITR DETAILS PRESENT : " + itrDetails);

            try {

                // DELETE ITR-DETAILS
                // step 1: move to ITR-Ref-ID response history table
                itrHistoryEmailDataResponseRepo.moveToITRRefIdResponseHistory(referenceId, customerType, deletedBy);
                System.out.println(" STEP-1 : ITR REF-ID RESPONSE MOVED TO HISTORY TABLE ");
                // step 2: delete from ITR-Ref-ID response table
                itrEmailDataResponseRepo.deleteFromITRRefIDVerifiedResponseTable(referenceId, customerType);
                System.out.println(" STEP-2 : ITR REF-ID RESPONSE DELETED FROM BASE TABLE ");


                // step 3: move to ITR-DETAILS  history table
                itrDetailsScreenHistoryRepo.moveToITRDetailsHistory(referenceId, customerType, deletedBy);
                System.out.println(" STEP-3 : ITR COMPLETE DETAILS MOVED TO HISTORY TABLE ");

                // step 4: delete from ITR-DETAILS table
                itrDetailsScreenRepo.deleteFromITRDetails(referenceId, customerType);
                System.out.println(" STEP-4 : ITR COMPLETE DETAILS DELETED FROM BASE TABLE ");


                // step 5: to set/update ITR fields in Deviation raw data entity for ITR list flags
                deviationCheckingRequiredDataService.updateItrFetchedStatus(referenceId);


                System.out.println("ITR DETAILS REMOVED FROM REF-ID RESPONSE TABLE & ITR-DETAILS TABLE FOR reference-Id: "
                        + referenceId + " AND Customer-type :" + customerType);
                System.out.println("//------------------------------------------------------------------------------------------------------------------------------------//");
                return "ITR DETAILS REMOVED FROM REF-ID RESPONSE TABLE & ITR-DETAILS TABLE FOR reference-Id: "
                        + referenceId + " AND Customer-type :" + customerType;
            } catch (Exception e) {
                System.err.println("ERROR WHILE REMOVING ITR DETAILS REMOVED FROM REF-ID RESPONSE TABLE & ITR-DETAILS TABLE FOR reference-Id: "
                        + referenceId + " AND Customer-type :" + customerType + " Error details: " + e.getMessage());
                throw new RuntimeException("ERROR WHILE REMOVING ITR DETAILS REMOVED FROM REF-ID RESPONSE TABLE & ITR-DETAILS TABLE FOR reference-Id: "
                        + referenceId + " AND Customer-type :" + customerType + " Error details: " + e.getMessage());
            }
        }else{
            System.out.println("ITR DETAILS NOT PRESENT FOR REF-ID : "+referenceId+" AND CUSTOMER-TYPE : "+customerType);
            System.out.println("//------------------------------------------------------------------------------------------------------------------------------------//");

            return "ITR DETAILS NOT PRESENT FOR REF-ID : "+referenceId+" AND CUSTOMER-TYPE : "+customerType;
        }
    }
}
