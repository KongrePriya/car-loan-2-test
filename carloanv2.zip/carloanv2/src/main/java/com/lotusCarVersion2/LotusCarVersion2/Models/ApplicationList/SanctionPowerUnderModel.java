package com.lotusCarVersion2.LotusCarVersion2.Models.ApplicationList;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "sanction_power_under")
@Entity
public class SanctionPowerUnderModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String referenceId;
    private String finalActionAuthorityScale;
    private String finalActionAuthorityUserType;
    private BigDecimal loanAmount;
    private String canuserSanction;

}
