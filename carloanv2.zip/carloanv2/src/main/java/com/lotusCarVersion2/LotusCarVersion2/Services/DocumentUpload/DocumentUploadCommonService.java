package com.lotusCarVersion2.LotusCarVersion2.Services.DocumentUpload;

import com.lotusCarVersion2.LotusCarVersion2.DTO.DocumentAndRemarkSingleDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.DocumentsAndRemarksDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksMandatoryEntity;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface DocumentUploadCommonService {

    DocumentsAndRemarksEntity checkOrCreateDocumentsAndRemarkEntity(String referenceId);

    String saveFileDetailsInTable(MultipartFile file, DocumentAndRemarkSingleDto singleDto) throws IOException;

    ResponseEntity<Resource> previewFile(String referenceId, String fileType);

    ResponseEntity<Resource> downloadFile(String referenceId, String fileType);

    DocumentsAndRemarksDto getAllDocumentsAndRemarks(String referenceId);

    DocumentsAndRemarksMandatoryEntity getMandatoryDocumentsForReferenceId(String referenceId);

    DocumentsAndRemarksMandatoryEntity setMandatoryDocumentsForReferenceId(String referenceId);

}
