package com.lotusCarVersion2.LotusCarVersion2.Services.CrifList;


import com.lotusCarVersion2.LotusCarVersion2.Models.CrifIndividualRequest.StandardCrifIndvRequest;

import java.util.List;

public interface CrifListService {


    List<StandardCrifIndvRequest> getAllApplicantCoAppGuarantor(String referenceId);

    String updateCrifFetchedFlag(String referenceId, String panNumber, String crifFlagStatus);


    String resetAllCrifFlagEveryMonth(String referenceId);



}
