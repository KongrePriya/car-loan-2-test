package com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifRemark;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Blob;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CibilCrifRemarkEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String referenceId;
    private String userId;
    private String loanType;
    private String borrowerType;

    //--------------- PERSONAL CIBIL REMARKS COMBINED --------------//
    @Column(columnDefinition = "TEXT")
    private String personalCibilRemark;
    @Column(columnDefinition = "TEXT")
    private String personalCibilOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String personalCibilRejectRemark;
    //additional
    @Column(columnDefinition = "TEXT")
    private String personalCibilWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String personalCibilAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private String personalCibilSuitFilledRemark;

    private LocalDateTime personalCibilSubmitDate;

    //--------------- COMMERCIAL CIBIL REMARKS COMBINED --------------//
    @Column(columnDefinition = "TEXT")
    private String commercialCibilRemark;
    @Column(columnDefinition = "TEXT")
    private String commercialCibilOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String commercialCibilRejectRemark;
    //additional
    @Column(columnDefinition = "TEXT")
    private String commercialCibilWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String commercialCibilAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private String commercialCibilSuitFilledRemark;

    private LocalDateTime commercialCibilSubmitDate;

    //--------------- PERSONAL CRIF REMARKS COMBINED --------------//
    @Column(columnDefinition = "TEXT")
    private String personalCrifRemark;
    @Column(columnDefinition = "TEXT")
    private String personalCrifOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String personalCrifRejectRemark;
    //additional
    @Column(columnDefinition = "TEXT")
    private String personalCrifWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String personalCrifAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private String personalCrifSuitFilledRemark;

    private LocalDateTime personalCrifSubmitDate;

    //--------------- COMMERCIAL CRIF REMARKS COMBINED --------------//
    @Column(columnDefinition = "TEXT")
    private String commercialCrifRemark;
    @Column(columnDefinition = "TEXT")
    private String commercialCrifOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String commercialCrifRejectRemark;
    //additional
    @Column(columnDefinition = "TEXT")
    private String commercialCrifWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String commercialCrifAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private String commercialCrifSuitFilledRemark;

    private LocalDateTime commercialCrifSubmitDate;

    //--------------- STATUS --------------//
    private String remarkStatus;
    private String rejectedStatus;
    private LocalDateTime statusDate;

    //--------------OVERDUE CLEARANCE ---------//
    private String overdueClearanceCertificateName;
    private String overdueClearanceCertificateUploadedBy;
    private LocalDateTime overdueClearanceCertificateDate;
}

