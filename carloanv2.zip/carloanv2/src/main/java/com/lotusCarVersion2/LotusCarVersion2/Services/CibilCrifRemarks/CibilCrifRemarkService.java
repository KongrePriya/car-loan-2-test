package com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifRemarks;

import com.lotusCarVersion2.LotusCarVersion2.DTO.CibilAndCrifRemarkDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifRemark.CibilCrifRemarkEntity;

public interface CibilCrifRemarkService {

    //return entity because we need to then manipulate it
    CibilCrifRemarkEntity checkOrCreateCibilCrifRemarkEntity(String referenceId);

    String savePersonalCibilRemarks(CibilAndCrifRemarkDto remarkDto);
    String saveCommercialCibilRemarks(CibilAndCrifRemarkDto remarkDto);
    String savePersonalCrifRemarks(CibilAndCrifRemarkDto remarkDto);
    String saveCommercialCrifRemarks(CibilAndCrifRemarkDto remarkDto);

    CibilAndCrifRemarkDto getAllCibiCrifRemarks(String referenceId);

    String rejectDueToCibilCrif(CibilAndCrifRemarkDto rejectRemarkDto);
}
