package com.lotusCarVersion2.LotusCarVersion2.Services.DocumentUpload;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.DTO.DocumentAndRemarkSingleDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.DocumentsAndRemarksDto;
import com.lotusCarVersion2.LotusCarVersion2.DTO.IndividualBasicDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.CorporateGuarantor.CorporateGuarantorEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksMandatoryEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeMainList.IncomeMainListModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CorporateGuarantorRepo.CorporateGuarantorRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DocumentUpload.DocumentUploadAndRemarksRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DocumentUpload.DocumentsAndRemarksMandatoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.FirmDetail.FirmDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeMainList.IncomeMainListService;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class DocumentUploadCommonServiceImpl implements  DocumentUploadCommonService {

private final DocumentUploadAndRemarksRepo documentUploadAndRemarksRepo;
private final ModelMapper modelMapper;
private final DocumentsAndRemarksMandatoryRepo documentsAndRemarksMandatoryRepo;
private final IndividualBasicDetailsRepo individualBasicDetailsRepo;
private final CorporateGuarantorRepo corporateGuarantorRepo;
private final IncomeMainListService incomeMainListService;

//*********************************************************************************************************//
@Override
public DocumentsAndRemarksEntity checkOrCreateDocumentsAndRemarkEntity(String referenceId) {
    // Check if data already present from referenceId
    DocumentsAndRemarksEntity entityPresent = documentUploadAndRemarksRepo.findByReferenceId(referenceId);
    if (entityPresent == null) {
        DocumentsAndRemarksEntity newEntity = new DocumentsAndRemarksEntity();
        newEntity.setReferenceId(referenceId);
        System.out.println("EXISTING Entity NOT PRESENT , NEW DocumentsAndRemarksEntity CREATED ");
        return newEntity;
    } else {
        System.out.println("EXISTING ENTRY PRESENT DocumentsAndRemarksEntity : " + entityPresent);
        return entityPresent;
    }
}

//*********************************************************************************************************//
//STEP-1 : SAVE SINGLE REMARK DETAILS AND THEN CALL METHOD TO SAVE FILE.
@Override
@Transactional
public String saveFileDetailsInTable(MultipartFile file, DocumentAndRemarkSingleDto singleDto) throws IOException {

    System.err.println("RECEIVE DATA TO UPLOAD DOCUMENT :" + singleDto);
    DocumentsAndRemarksEntity entity = checkOrCreateDocumentsAndRemarkEntity(singleDto.getReferenceId());

    String fileName = singleDto.getReferenceId() + "_" + singleDto.getFileType();
    System.out.println("GENERATED FILE NAME : " + fileName);

    try {
        switch (singleDto.getFileType()) {

            case "applicantDueDiligence":
                System.out.println("Uploading applicantDueDiligence.... ");
                entity.setApplicantDueDiligenceFileName(fileName);
                entity.setApplicantDueDiligenceUploadedBy(singleDto.getUserId());
                entity.setApplicantDueDiligenceRemark(singleDto.getRemark());
                entity.setApplicantDueDiligenceFileDate(LocalDateTime.now());
                break;
            case "applicantKyc":
                System.out.println("Uploading applicantKyc.... ");
                entity.setApplicantKYCFileName(fileName);
                entity.setApplicantKYCUploadedBy(singleDto.getUserId());
                entity.setApplicantKYCRemark(singleDto.getRemark());
                entity.setApplicantKYCFileDate(LocalDateTime.now());
                break;
            case "applicantItrForm16":
                System.out.println("Uploading applicantItrForm16.... ");
                entity.setApplicantITRForm16FileName(fileName);
                entity.setApplicantITRForm16UploadedBy(singleDto.getUserId());
                entity.setApplicantITRForm16Remark(singleDto.getRemark());
                entity.setApplicantITRForm16FileDate(LocalDateTime.now());
                break;
            case "applicantSalaryPension":
                System.out.println("Uploading applicantSalaryPension.... ");
                entity.setApplicantSalaryPensionFileName(fileName);
                entity.setApplicantSalaryPensionUploadedBy(singleDto.getUserId());
                entity.setApplicantSalaryPensionRemark(singleDto.getRemark());
                entity.setApplicantSalaryPensionFileDate(LocalDateTime.now());
                break;
            case "applicantPassport":
                System.out.println("Uploading applicantPassport.... ");
                entity.setApplicantPassportFileName(fileName);
                entity.setApplicantPassportUploadedBy(singleDto.getUserId());
                entity.setApplicantPassportRemark(singleDto.getRemark());
                entity.setApplicantPassportFileDate(LocalDateTime.now());
                break;
            case "applicantBankStatement":
                System.out.println("Uploading applicantBankStatement.... ");
                entity.setApplicantBankStatementFileName(fileName);
                entity.setApplicantBankStatementUploadedBy(singleDto.getUserId());
                entity.setApplicantBankStatementRemark(singleDto.getRemark());
                entity.setApplicantBankStatementFileDate(LocalDateTime.now());
                break;


            case "coappDueDiligence":
                System.out.println("Uploading coappDueDiligence.... ");
                entity.setCoAppDueDiligenceFileName(fileName);
                entity.setCoAppDueDiligenceUploadedBy(singleDto.getUserId());
                entity.setCoAppDueDiligenceRemark(singleDto.getRemark());
                entity.setCoAppDueDiligenceFileDate(LocalDateTime.now());
                break;
            case "coappKyc":
                System.out.println("Uploading coappKyc.... ");
                entity.setCoAppKYCFileName(fileName);
                entity.setCoAppKYCUploadedBy(singleDto.getUserId());
                entity.setCoAppKYCRemark(singleDto.getRemark());
                entity.setCoAppKYCFileDate(LocalDateTime.now());
                break;
            case "coappItrForm16":
                System.out.println("Uploading coappItrForm16.... ");
                entity.setCoAppITRForm16FileName(fileName);
                entity.setCoAppITRForm16UploadedBy(singleDto.getUserId());
                entity.setCoAppITRForm16Remark(singleDto.getRemark());
                entity.setCoAppITRForm16FileDate(LocalDateTime.now());
                break;
            case "coappSalaryPension":
                System.out.println("Uploading coappSalaryPension.... ");
                entity.setCoAppSalaryPensionFileName(fileName);
                entity.setCoAppSalaryPensionUploadedBy(singleDto.getUserId());
                entity.setCoAppSalaryPensionRemark(singleDto.getRemark());
                entity.setCoAppSalaryPensionFileDate(LocalDateTime.now());
                break;



            case "guarantorDueDiligence":
                System.out.println("Uploading guarantorDueDiligence.... ");
                entity.setGuarantorDueDiligenceFileName(fileName);
                entity.setGuarantorDueDiligenceUploadedBy(singleDto.getUserId());
                entity.setGuarantorDueDiligenceRemark(singleDto.getRemark());
                entity.setGuarantorDueDiligenceFileDate(LocalDateTime.now());
                break;
            case "guarantorKyc":
                System.out.println("Uploading guarantorKyc.... ");
                entity.setGuarantorKYCFileName(fileName);
                entity.setGuarantorKYCUploadedBy(singleDto.getUserId());
                entity.setGuarantorKYCRemark(singleDto.getRemark());
                entity.setGuarantorKYCFileDate(LocalDateTime.now());
                break;
            case "guarantorItrForm16":
                System.out.println("Uploading guarantorItrForm16.... ");
                entity.setGuarantorITRForm16FileName(fileName);
                entity.setGuarantorITRForm16UploadedBy(singleDto.getUserId());
                entity.setGuarantorITRForm16Remark(singleDto.getRemark());
                entity.setGuarantorITRForm16FileDate(LocalDateTime.now());
                break;
            case "guarantorSalaryPension":
                System.out.println("Uploading guarantorSalaryPension.... ");
                entity.setGuarantorSalaryPensionFileName(fileName);
                entity.setGuarantorSalaryPensionUploadedBy(singleDto.getUserId());
                entity.setGuarantorSalaryPensionRemark(singleDto.getRemark());
                entity.setGuarantorSalaryPensionFileDate(LocalDateTime.now());
                break;


            case "quotation":
                System.out.println("Uploading quotation.... ");
                entity.setQuotationFileName(fileName);
                entity.setQuotationFileUploadedBy(singleDto.getUserId());
                entity.setQuotationFileRemark(singleDto.getRemark());
                entity.setQuotationFileDate(LocalDateTime.now());
                break;

            case "visitReport":
                System.out.println("Uploading visitReport.... ");
                entity.setVisitReportFileName(fileName);
                entity.setVisitReportUploadedBy(singleDto.getUserId());
                entity.setVisitReportRemark(singleDto.getRemark());
                entity.setVisitReportFileDate(LocalDateTime.now());
                break;

            case "employmentOrBusinessProof":
                System.out.println("Uploading employmentOrBusinessProof.... ");
                entity.setEmploymentOrBusinessProofFileName(fileName);
                entity.setEmploymentOrBusinessProofUploadedBy(singleDto.getUserId());
                entity.setEmploymentOrBusinessProofRemark(singleDto.getRemark());
                entity.setEmploymentOrBusinessProofFileDate(LocalDateTime.now());
                break;

            case "other":
                System.out.println("Uploading other.... ");
                entity.setOtherFileName(fileName);
                entity.setOtherFileUploadedBy(singleDto.getUserId());
                entity.setOtherRemark(singleDto.getRemark());
                entity.setOtherFileDate(LocalDateTime.now());
                break;

            case "cibilOverdue":
                System.out.println("Uploading cibilOverdue.... ");
                entity.setOverdueClearanceCertificateName(fileName);
                entity.setOverdueClearanceCertificateUploadedBy(singleDto.getUserId());
                entity.setOverdueClearanceCertificateDate(LocalDateTime.now());
                break;

            case "deviationSanctionLetter":
                System.out.println("Uploading deviationSanctionLetter.... ");
//                System.err.println("singleDto.getDeviationNumber() :"+singleDto.getDeviationSanctionLetterNumber());
                entity.setDeviationSanctionLetterFileName(fileName);
                entity.setDeviationSanctionLetterUploadedBy(singleDto.getUserId());
                entity.setDeviationSanctionLetterNumber(singleDto.getDeviationSanctionLetterNumber());
                entity.setDeviationSanctionLetterRemark(singleDto.getRemark());
                entity.setDeviationDeclarationCheck(singleDto.getDeclarationCheck());
                entity.setDeviationSanctionLetterDate(LocalDateTime.now());
                break;
        }

        // Save File to Directory
        String fileSaveResponse = saveFileToDirectory(file, singleDto.getReferenceId(), singleDto.getFileType());
        System.out.println(fileSaveResponse + " FILE SAVED SUCCESSFULLY.");
        documentUploadAndRemarksRepo.save(entity);

        return fileSaveResponse + " FILE SAVED SUCCESSFULLY.";

    } catch (Exception e) {
        System.err.println("ERROR WHILE SAVING FILE :" + singleDto.getFileType() + " , ERROR DETAILS:: " + e.getMessage());
        throw new RuntimeException("ERROR WHILE SAVING FILE :" + singleDto.getFileType() + " , ERROR DETAILS:: " + e.getMessage());
    }
}

//**********************************************************************************************************//
// STEP-2:  method to save PDF files to the directory with new names
public String saveFileToDirectory(MultipartFile file, String referenceId, String fileType) throws IOException {

    String newFileName = referenceId + "_" + fileType + ".pdf";
    try {
        Path filePath = Paths.get(AllStaticFields.FILE_UPLOAD_DIR + newFileName);

        // Save the file, replacing if it already exists
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        // Return the new file name
        return newFileName;

    } catch (IOException e) {
        e.printStackTrace();
        System.err.println("ERROR WHILE SAVING FILE : " + newFileName + " Error Details: " + e.getMessage());
        throw new RuntimeException("ERROR WHILE SAVING FILE : " + newFileName + " Error Details: " + e.getMessage());
    }
}

//**********************************************************************************************************//
//Fetches a file for preview (i.e., displayed in the browser).
@Override
public ResponseEntity<Resource> previewFile(String referenceId, String fileType) {

    String fileToPreview = referenceId + "_" + fileType + ".pdf";

    System.out.println("FILENAME TO PREVIEW: " + fileToPreview);
    try {
        // Load the file as a Resource
        Resource resource = loadFileAsResource(fileToPreview);

        String contentType = Files.probeContentType(Paths.get(AllStaticFields.FILE_UPLOAD_DIR + fileToPreview));

        // Return the file as response to be previewed (e.g., in the browser)
        return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType)).body(resource);

    } catch (IOException e) {
        e.printStackTrace();
        System.err.println("ERROR WHILE PREVIEW FILE : " + fileToPreview + " Error Details: " + e.getMessage());
        throw new RuntimeException("ERROR WHILE PREVIEW FILE : " + fileToPreview + " Error Details: " + e.getMessage());
    }
}

//**********************************************************************************************************//
@Override
public ResponseEntity<Resource> downloadFile(String referenceId, String fileType) {

    String fileToDownload = referenceId + "_" + fileType + ".pdf";

    //   use switch to get filename or pass filename from UI
    String fileName = fileToDownload;
    System.out.println("FILENAME TO DOWNLOAD: " + fileToDownload);
    try {
        // Load the file as a Resource from the directory
        Resource resource = loadFileAsResource(fileName);

        // Detect the file type (e.g., PDF, Image, etc.)
        String contentType = Files.probeContentType(Paths.get(AllStaticFields.FILE_UPLOAD_DIR + fileName));

        // Set headers to force file download, including the dynamically created file name
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))  // Set the content type of the file
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(resource);  // Send the file content

    } catch (IOException e) {
        e.printStackTrace();
        System.err.println("ERROR WHILE DOWNLOADING FILE: " + fileName + " Error Details: " + e.getMessage());
        throw new RuntimeException("ERROR WHILE DOWNLOADING FILE: " + fileName + " Error Details: " + e.getMessage());
    }
}


//**********************************************************************************************************//
// method to load a file from the filesystem as a resource while preview or download
private Resource loadFileAsResource(String fileName) throws IOException {

    try {
        Path filePath = Paths.get(AllStaticFields.FILE_UPLOAD_DIR + fileName);
        System.out.println("FILE_UPLOAD_DIR = " + AllStaticFields.FILE_UPLOAD_DIR);
        System.out.println("Constructed file name: " + fileName);
        System.out.println("Resolved full file path: " + filePath.toString());

        // Check if file exists, otherwise throw exception
        if (!Files.exists(filePath)) {
            throw new IOException("File not found: " + fileName);
        }
        // Return the file as a resource
        return new FileSystemResource(filePath);
    } catch (Exception e) {
        System.err.println("ERROR WHILE LOADING FILE :" + fileName + " AS RESOURCE : " + e.getMessage());
        throw new RuntimeException("ERROR WHILE LOADING FILE :" + fileName + " AS RESOURCE : " + e.getMessage());
    }
}

//**********************************************************************************************************//
//Method to get all documents and remarks
@Override
public DocumentsAndRemarksDto getAllDocumentsAndRemarks(String referenceId) {
    DocumentsAndRemarksEntity documentsAndRemarksEntity = checkOrCreateDocumentsAndRemarkEntity(referenceId);
    return modelMapper.map(documentsAndRemarksEntity, DocumentsAndRemarksDto.class);
}

//**********************************************************************************************************//
//Method to get all mandatory documents flags
@Override
public DocumentsAndRemarksMandatoryEntity getMandatoryDocumentsForReferenceId(String referenceId) {

    //set all the flags
    try {
        setMandatoryDocumentsForReferenceId(referenceId);
    }catch (Exception e){
        e.printStackTrace();
        System.err.println("ERROR WHILE SETTING MANDATORY DOCUMENTS FLAG :"+e.getMessage());
    }
  DocumentsAndRemarksMandatoryEntity mandatoryEntity = documentsAndRemarksMandatoryRepo.findByReferenceId(referenceId);
  return mandatoryEntity;
}

//**********************************************************************************************************//
@Override
public DocumentsAndRemarksMandatoryEntity setMandatoryDocumentsForReferenceId(String referenceId) {

DocumentsAndRemarksMandatoryEntity mandatoryEntity = documentsAndRemarksMandatoryRepo.findByReferenceId(referenceId);
System.out.println("//--------------------------------------- INSIDE SETTING MANDATORY DOCUMENTS ----------------------------------------------//");
//-------------------------------------------------------------------------------------------------------------------------------//
    //WHEN BORROWER IS CORPORATE
    if (mandatoryEntity.getBorrowerType().equalsIgnoreCase(AllStaticFields.corporateClient)) {

       mandatoryEntity.setApplicantSalaryPensionSlip("NO"); //As Applicant is Corporate-Client
        List<CorporateGuarantorEntity> corpGuarantorList = corporateGuarantorRepo.findByReferenceIdAndCorpGuarStatusNull(referenceId);
        if (!corpGuarantorList.isEmpty() || corpGuarantorList != null) {
            mandatoryEntity.setGuarantorKyc("YES");
            mandatoryEntity.setGuarantorITRForm16("YES");
            mandatoryEntity.setGuarantorDueDiligence("YES");
        }else{
            mandatoryEntity.setGuarantorKyc("NO");
            mandatoryEntity.setGuarantorITRForm16("NO");
            mandatoryEntity.setGuarantorDueDiligence("NO");
        }
        System.out.println("step-1: set for Corporate-Client");
    }
//-------------------------------------------------------------------------------------------------------------------------------//
    else {
        //WHEN BORROWER IS INDIVIDUAL

        IndividualBasicDetailsEntity applicantDetails=individualBasicDetailsRepo.findByReferenceIdAndCustomerType(referenceId,AllStaticFields.applicant);
        List<IndividualBasicDetailsEntity> allIndividualCoappList = individualBasicDetailsRepo.findAllCoappByReferenceId(referenceId);
        List<IndividualBasicDetailsEntity> guarantorsIndividualList = individualBasicDetailsRepo.findAllGuarantorByReferenceId(referenceId);

        //--------------------------Applicant------------------------------//
        if (applicantDetails.getIncomeSourceType().equalsIgnoreCase(AllStaticFields.salaried) ||
                applicantDetails.getIncomeSourceType().equalsIgnoreCase(AllStaticFields.pensioner)) {
            mandatoryEntity.setApplicantSalaryPensionSlip("YES");
        }else{
            mandatoryEntity.setApplicantSalaryPensionSlip("NO");
        }
        System.out.println("step-1: set for INDIVIDUAL APPLICANT");

        //-------------------------Co-applicants-----------------------------//
        if (allIndividualCoappList.size() > 0 ) {
            System.out.println("Individual Co-applicants list is not null,size : "+allIndividualCoappList.size());

            mandatoryEntity.setCoAppKyc("YES");
            mandatoryEntity.setCoAppDueDiligence("YES");
            mandatoryEntity.setCoAppITRForm16("YES");

            //CO-APPLICANT SALARY/PENSION SLIP
            List<String> coAppIncomeSourceList=allIndividualCoappList.stream().map( i -> i.getIncomeSourceType()).collect(Collectors.toList());
            if(coAppIncomeSourceList.contains(AllStaticFields.salaried)|| coAppIncomeSourceList.contains(AllStaticFields.pensioner)){
                mandatoryEntity.setCoAppSalaryPensionSlip("YES");
            }else{
                mandatoryEntity.setCoAppSalaryPensionSlip("NO");
            }
        }else{
            System.out.println("Individual Co-applicants list is null");

            mandatoryEntity.setCoAppKyc("NO");
            mandatoryEntity.setCoAppDueDiligence("NO");
            mandatoryEntity.setCoAppITRForm16("NO");
            mandatoryEntity.setCoAppSalaryPensionSlip("NO");
        }
        System.out.println("step-2: set for INDIVIDUAL CO-APPLICANTS");

        //-------------------------Individual Guarantors-----------------------------//
        if (guarantorsIndividualList.size() >0 ) {
            System.out.println("Individual Guarantors list is not null,size : "+guarantorsIndividualList.size());
            mandatoryEntity.setGuarantorKyc("YES");
            mandatoryEntity.setGuarantorITRForm16("YES");
            mandatoryEntity.setGuarantorDueDiligence("YES");

            //Guarantors SALARY/PENSION SLIP
            List<String> guarantorsIncomeSourceList=guarantorsIndividualList.stream().map( i -> i.getIncomeSourceType()).collect(Collectors.toList());
            if(guarantorsIncomeSourceList.contains(AllStaticFields.salaried)|| guarantorsIncomeSourceList.contains(AllStaticFields.pensioner)){
                mandatoryEntity.setGuarantorSalaryPensionSlip("YES");
            }else{
                mandatoryEntity.setGuarantorSalaryPensionSlip("NO");
            }
        }else{
            System.out.println("Individual Guarantors list is null");

            mandatoryEntity.setGuarantorKyc("NO");
            mandatoryEntity.setGuarantorITRForm16("NO");
            mandatoryEntity.setGuarantorDueDiligence("NO");
            mandatoryEntity.setGuarantorSalaryPensionSlip("NO");
        }
        System.out.println("step-3: set for INDIVIDUAL GUARANTORS");

    }
//-------------------------------------------------------------------------------------------------------------------------------//

    documentsAndRemarksMandatoryRepo.save(mandatoryEntity);
    System.out.println("MANDATORY DOCUMENTS SET FOR REF-ID :"+mandatoryEntity);
    return mandatoryEntity;
}

//********************************************************************************************************************//

}
