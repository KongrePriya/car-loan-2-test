package com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name="documents_and_remarks_details")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DocumentsAndRemarksEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String referenceId;

    //applicant due diligence
    @Column(columnDefinition = "TEXT")
    private String applicantDueDiligenceRemark;
    private LocalDateTime applicantDueDiligenceFileDate;
    private String applicantDueDiligenceFileName;
    private String applicantDueDiligenceUploadedBy;

    //applicant KYC
    @Column(columnDefinition = "TEXT")
    private String applicantKYCRemark;
    private LocalDateTime applicantKYCFileDate;
    private String applicantKYCFileName;
    private String applicantKYCUploadedBy;

    //applicant ITR form 16
    @Column(columnDefinition = "TEXT")
    private String applicantITRForm16Remark;
    private LocalDateTime applicantITRForm16FileDate;
    private String applicantITRForm16FileName;
    private String applicantITRForm16UploadedBy;

    //applicant Bank Statement
    @Column(columnDefinition = "TEXT")
    private String applicantBankStatementRemark;
    private LocalDateTime applicantBankStatementFileDate;
    private String applicantBankStatementFileName;
    private String applicantBankStatementUploadedBy;

    //applicant salary
    @Column(columnDefinition = "TEXT")
    private String applicantSalaryPensionRemark;
    private LocalDateTime applicantSalaryPensionFileDate;
    private String applicantSalaryPensionFileName;
    private String applicantSalaryPensionUploadedBy;

    //applicant passport
    @Column(columnDefinition = "TEXT")
    private String applicantPassportRemark;
    private LocalDateTime applicantPassportFileDate;
    private String applicantPassportFileName;
    private String applicantPassportUploadedBy;

    //co-app due diligence : optional
    @Column(columnDefinition = "TEXT")
    private String coAppDueDiligenceRemark;
    private LocalDateTime coAppDueDiligenceFileDate;
    private String coAppDueDiligenceFileName;
    private String coAppDueDiligenceUploadedBy;

    //co-applicant ITR form 16
    @Column(columnDefinition = "TEXT")
    private String coAppITRForm16Remark;
    private LocalDateTime coAppITRForm16FileDate;
    private String coAppITRForm16FileName;
    private String coAppITRForm16UploadedBy;

    //co-applicant KYC
    @Column(columnDefinition = "TEXT")
    private String coAppKYCRemark;
    private LocalDateTime coAppKYCFileDate;
    private String coAppKYCFileName;
    private String coAppKYCUploadedBy;

    //co-applicant salary
    @Column(columnDefinition = "TEXT")
    private String coAppSalaryPensionRemark;
    private LocalDateTime coAppSalaryPensionFileDate;
    private String coAppSalaryPensionFileName;
    private String coAppSalaryPensionUploadedBy;

    //guarantor due diligence
    @Column(columnDefinition = "TEXT")
    private String guarantorDueDiligenceRemark;
    private LocalDateTime guarantorDueDiligenceFileDate;
    private String guarantorDueDiligenceFileName;
    private String guarantorDueDiligenceUploadedBy;

    //guarantor ITR form 16
    @Column(columnDefinition = "TEXT")
    private String guarantorITRForm16Remark;
    private LocalDateTime guarantorITRForm16FileDate;
    private String guarantorITRForm16FileName;
    private String guarantorITRForm16UploadedBy;

    //guarantor KYC
    @Column(columnDefinition = "TEXT")
    private String guarantorKYCRemark;
    private LocalDateTime guarantorKYCFileDate;
    private String guarantorKYCFileName;
    private String guarantorKYCUploadedBy;

    //guarantor salary
    @Column(columnDefinition = "TEXT")
    private String guarantorSalaryPensionRemark;
    private LocalDateTime guarantorSalaryPensionFileDate;
    private String guarantorSalaryPensionFileName;
    private String guarantorSalaryPensionUploadedBy;

    //quotation
    @Column(columnDefinition = "TEXT")
    private String quotationFileRemark;
    private LocalDateTime quotationFileDate;
    private String quotationFileName;
    private String quotationFileUploadedBy;

    //Visit report
    @Column(columnDefinition = "TEXT")
    private String visitReportRemark;
    private LocalDateTime visitReportFileDate;
    private String visitReportFileName;
    private String visitReportUploadedBy;


    //applicant business/employment proof
    @Column(columnDefinition = "TEXT")
    private String employmentOrBusinessProofRemark;
    private LocalDateTime employmentOrBusinessProofFileDate;
    private String employmentOrBusinessProofFileName;
    private String employmentOrBusinessProofUploadedBy;

    //other Remark
    @Column(columnDefinition = "TEXT")
    private String otherRemark;
    private LocalDateTime otherFileDate;
    private String otherFileName;
    private String otherFileUploadedBy;




    // OVERDUE CLEARANCE
    private String overdueClearanceCertificateName;
    private String overdueClearanceCertificateUploadedBy;
    private LocalDateTime overdueClearanceCertificateDate;

    // Deviation Approval Sanction
    @Column(columnDefinition = "TEXT")
    private String deviationSanctionLetterRemark;
    private String deviationSanctionLetterFileName;
    private String deviationSanctionLetterUploadedBy;
    private String deviationSanctionLetterNumber;
    private LocalDateTime deviationSanctionLetterDate;
    private Boolean deviationDeclarationCheck;

}
