package com.lotusCarVersion2.LotusCarVersion2.Services.DashBoard;

import java.util.HashMap;
import java.util.Map;

public class StatusMapper {
    private static final Map<String, String> statusMap = new HashMap<>();

    static {
        statusMap.put("REJ", "statusReject");
        statusMap.put("PEN", "statusPending");
        statusMap.put("SAN", "statusSanctioned");
        statusMap.put("RET", "statusReturn");
        statusMap.put("REC", "statusRecommended");
        statusMap.put("DEV", "statusDeviation");
    }

    public static String mapStatus(String status) {
        if (status == null) {
            return "PEN";
        }
        return statusMap.getOrDefault(status, status);
    }
}
