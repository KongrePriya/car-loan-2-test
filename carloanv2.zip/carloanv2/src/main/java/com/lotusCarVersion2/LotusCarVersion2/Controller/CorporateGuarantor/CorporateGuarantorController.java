package com.lotusCarVersion2.LotusCarVersion2.Controller.CorporateGuarantor;

import com.lotusCarVersion2.LotusCarVersion2.DTO.CorporateGuarantorDto;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilDetailsCommercial.FetchCommercialCibilService;
import com.lotusCarVersion2.LotusCarVersion2.Services.CorporateGuarantor.CorporateGuarantorService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@CrossOrigin
@Validated
@RequestMapping("/api/v1/corporate")
public class CorporateGuarantorController {

private final CorporateGuarantorService corporateGuarantorService;
private final FetchCommercialCibilService fetchCommercialCibilService;

//*****************************************************************************************************************//
@PostMapping("/save-or-update")
public ResponseEntity<String> saveOrUpdateCorpGuarantor(@Valid @RequestBody CorporateGuarantorDto saveOrUpdateDto) {
    if (saveOrUpdateDto.getId() != null && saveOrUpdateDto.getId() != 0) {
        // Update existing corp guarantor
        CorporateGuarantorDto updatedCorpGuarantor = corporateGuarantorService.updateSingleCorpGuarantor(saveOrUpdateDto);
        if (updatedCorpGuarantor != null) {
//            System.out.println("TEMPORARILY ADDED IN UPDATE FOR TESTING....... CORP GUARANTOR DATA SENT TO FETCH CIBIL... WAITING FOR RESULT ");
//            //TEMP COMMENT TO SAVE DATA
//            String  commCibilFetch= String.valueOf(fetchCommercialCibilService.fetchCommercialCibilSingleGuarantor(updatedCorpGuarantor));
//            System.out.println("TEMPORARILY ADDED IN UPDATE FOR TESTING.......AFTER FETCHING CORP GUARANTOR CIBIL..  "+commCibilFetch);
            return ResponseEntity.ok("Corporate Guarantor updated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update Corporate Guarantor.");
        }
    } else {

        if (saveOrUpdateDto != null) {
            System.out.println("CORP GUARANTOR DATA SENT TO FETCH CIBIL... WAITING FOR RESULT ");

          /* PRIYA //FETCH COMMERCIAL CIBIL
            String  commCibilFetch= String.valueOf(fetchCommercialCibilService.fetchCommercialCibilSingleGuarantor(saveOrUpdateDto));
            System.out.println("AFTER FETCHING CORPORATE GUARANTOR CIBIL....:::   "+commCibilFetch);*/


            // Insert new corp guarantor & when cibil fetched successfully
            CorporateGuarantorDto savedCorpGuarantorDto = corporateGuarantorService.saveSingleCorpGuarantor(saveOrUpdateDto);
            return ResponseEntity.status(HttpStatus.CREATED).body("New Corporate Guarantor added And Commercial CIBIL Fetched Successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add new Corporate Guarantor.");
        }
    }
}

 //********************************************************************************************************//
    //Api to get List of corp guarantor from reference Id which are not deleted
@GetMapping("/retrieve/{referenceId}")
    public ResponseEntity<?> getAllCorpGuarantorList(@PathVariable String referenceId){
        List<CorporateGuarantorDto> corporateGuarantorDtoList = corporateGuarantorService.getAllCorpGuarantorsList(referenceId);
        if(corporateGuarantorDtoList != null && corporateGuarantorDtoList.size() > 0){

            return new ResponseEntity<>(corporateGuarantorDtoList, HttpStatus.OK );
        }else {
            System.out.println("inside else of get all");
            String message = "Corp guarantors not present for this Reference Id";
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(message);
        }
}
//**************************************************************************************************//
//Api to mark guarantor as Deleted i.e. corpGuarStatus= deleted
@PutMapping("/remove/{referenceId}/{id}")
public ResponseEntity<String> updateStatusByRefIdAndId(@PathVariable String referenceId, @PathVariable Long id){
    //extracting returned message from method into messageResponse
    String messageResponse = corporateGuarantorService.updateCorpGuarantorStatusDeletedByUniqueId(referenceId,id);
    return new ResponseEntity<>(messageResponse, HttpStatus.OK);
}
//**************************************************************************************************//


}



