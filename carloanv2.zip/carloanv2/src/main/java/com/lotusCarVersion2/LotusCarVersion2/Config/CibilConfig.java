package com.lotusCarVersion2.LotusCarVersion2.Config;

public class CibilConfig {

//    public static String PersonalCibilIP ="http://10.15.51.23:8282";
//    public static String PersonalCibilIP ="http://desktop-ha58tif:8282";
    public static String PersonalCibilIP ="http://10.16.237.74:8282";

    //    public static String CommercialCibilIP ="http://10.15.51.23:8282";
//    public static String CommercialCibilIP ="http://desktop-ha58tif:8282";
    public static String CommercialCibilIP ="http://10.16.237.74:8282";
}
