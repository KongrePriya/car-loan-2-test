package com.lotusCarVersion2.LotusCarVersion2.Repository.DocumentUpload;

import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksMandatoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentsAndRemarksMandatoryRepo extends JpaRepository<DocumentsAndRemarksMandatoryEntity, Long> {


    DocumentsAndRemarksMandatoryEntity findByReferenceId(String referenceId);

}
