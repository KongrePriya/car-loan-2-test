package com.lotusCarVersion2.LotusCarVersion2.Models.SanctionPowerModel;

import lombok.*;

@Getter
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Setter
public class SanctionPowerParameter {
    private String loanType;
    private String userType;
    private String scale;
}
