package com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomePension;


import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomePension.IncomePensionModel;

public interface IncomePensionService {


    String postIncomePension(IncomePensionModel incomePensionModel);
    IncomePensionModel getIncomePension(String referenceId, String panNumber);

    void deleteIncomePensionAndSaveToHistory(String referenceId, String panNumber);
}
