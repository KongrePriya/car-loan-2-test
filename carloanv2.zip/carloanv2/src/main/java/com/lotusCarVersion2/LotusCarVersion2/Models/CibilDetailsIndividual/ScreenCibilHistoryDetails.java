package com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsIndividual;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cibil_history_details_jasper")
// THE ACTUAL DATA IS PRESENT IN THE CIBIL_PERSONAL SCHEMA , this is just a entity to get the data for jasper reports
public class ScreenCibilHistoryDetails {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String customerPan;
    private LocalDateTime dateOfFetching;
    private String referenceId;
    private String branchCode;
    private String userId;


    //history fields
    private String facilityType;
    private String ownership;
    private String bankerName;
    private String sanctionDate;
    private int sanctionAmount;
    private int amountOutstanding;
    private int emiAmount;
    private int overdueAmount;
    private String facilityStatus;


    //additional field to update old entries
    private String oldRecord;
    private LocalDateTime refetchedDate;

}
