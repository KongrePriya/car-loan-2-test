package com.lotusCarVersion2.LotusCarVersion2.Repository.CRIFDetails;

import com.lotusCarVersion2.LotusCarVersion2.Models.CRIFDetails.StdCrifSummaryModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CrifSummaryRepo extends JpaRepository<StdCrifSummaryModel,Long> {
    List<StdCrifSummaryModel> findAllByReferenceId(String referenceId);
}
