package com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeBusiness;


import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainModel;

public interface IncomeBusinessService {



    String postIncomeBusiness(IncomeBusinessMainModel incomeBusinessMainModel);
    IncomeBusinessMainModel getIncomeBusiness(String referenceId, String panNumber);
    void deleteIncomeBusinessAndSaveToHistory(String referenceId, String panNumber);
}
