package com.lotusCarVersion2.LotusCarVersion2.Repository.ITR;

import com.lotusCarVersion2.LotusCarVersion2.Models.ITR.ITRDetailsAsPerScreenEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ITRDetailsScreenRepo extends JpaRepository<ITRDetailsAsPerScreenEntity, Long> {

    //**************  //To delete entry of ITR DETAILS from table when Borrower/guarantor Deleted **********************//
    @Modifying
    @Transactional
    @Query(value = "DELETE FROM kyc_itr.screen_itr_final_details " +
            "WHERE reference_id_lotus = :referenceIdLotus AND customer_type = :customerType", nativeQuery = true)
    int deleteFromITRDetails(String referenceIdLotus, String customerType);


    //************ ITR DETAILS **********// for jasper appraisal note
    @Query(nativeQuery = true, value = "SELECT * FROM kyc_itr.screen_itr_final_details WHERE " +
            " reference_id_lotus= :referenceIdLotus AND  customer_type= :customerType ")
    ITRDetailsAsPerScreenEntity getITRDataByReferenceAndType(String referenceIdLotus, String customerType);


    @Query(value = """
            SELECT it.* FROM kyc_itr.screen_itr_final_details it where reference_id_lotus=:referenceIdLotus""", nativeQuery = true)
    List<ITRDetailsAsPerScreenEntity> findByReferenceIdLotus(String referenceIdLotus);
}
