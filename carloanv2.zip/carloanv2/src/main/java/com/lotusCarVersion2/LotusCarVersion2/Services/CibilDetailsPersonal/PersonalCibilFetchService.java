package com.lotusCarVersion2.LotusCarVersion2.Services.CibilDetailsPersonal;

import com.lotusCarVersion2.LotusCarVersion2.Config.CibilConfig;
import com.lotusCarVersion2.LotusCarVersion2.DTO.IndividualBasicDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsIndividual.StandardRequestPersonalDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor

public class PersonalCibilFetchService {

    @Autowired
    private final RestTemplate restTemplate;
    private ModelMapper modelMapper;
    private final IndividualBasicDetailsRepo applicantCoappGuarantorRepo;


//********************************************************************************************************************//
//API INTEGRATION TO FETCH CIBIL OF SINGLE INDIVIDUAL
    public ResponseEntity<String> fetchPersonalCibilSingleIndividual(@RequestBody IndividualBasicDetailsDto detailsDto) throws IOException {
        System.out.println("Inside Fetch Personal Cibil- Single Individual LOS-HOME-LOAN.");

        String PersonalCibilFetchUrl = CibilConfig.PersonalCibilIP + "/personal-cibil/fetch/std-individual";
        System.out.println(" URL: " + PersonalCibilFetchUrl);

        //****CONVERTING TO STANDARD REQUEST
        StandardRequestPersonalDto stdDtoToFetchCibil = ConverterIndividualDetailsToStdCibilRequest.ConverterIndiviualDetailsToStdCibilRequest(detailsDto);

        System.out.println("HOME-LOAN: REQUEST CONVERTED TO STANDARD CIBIL REQUEST : " +stdDtoToFetchCibil);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        HttpEntity<StandardRequestPersonalDto> stdCibilRequestDto = new HttpEntity<>(stdDtoToFetchCibil, headers);
        try {
            ResponseEntity<String> responseEntity = restTemplate.postForEntity(
                    PersonalCibilFetchUrl,
                    stdCibilRequestDto,
                    String.class);

            if (responseEntity.getStatusCode() == HttpStatus.OK) {

             /* HOME:  //DEVIATIONS FOR CIBIL
                deviationFlagsStatusService.updateCibilDeviationCommon(detailsDto.getPan(), detailsDto.getReferenceId());

                //CIBIL-FETCHED STATUS FLAGS
                cibilFetchStatusService.updateCibilFetchedBorrowerGuarantorFlag(detailsDto);*/

                return ResponseEntity.ok(responseEntity.getBody());
            } else {
                System.err.println("ERROR IN FETCHING PERSONAL CIBIL, RESPONSE:" + responseEntity.getBody());
                return ResponseEntity.status(responseEntity.getStatusCode())
                        .body("PERSONAL CIBIL: Failed to fetch CIBIL::"+ responseEntity.getBody());
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("PERSONAL CIBIL CONNECTION FAILED : FAILED TO FETCH CIBIL FOR PAN :" + detailsDto.getPan());
            throw new RuntimeException(" CIBIL CONNECTION FAILED :: FAILED TO FETCH CIBIL FOR PAN :" + detailsDto.getPan() +" ERROR DETAILS : "+e.getMessage());
        }
    }

//********************************************************************************************************************//
//API INTEGRATION TO FETCH CIBIL OF LIST OF INDIVIDUAL
    public ResponseEntity<String> refetchPersonalCibilOfAll(String referenceId) throws IOException {
        System.out.println("Inside Fetch Personal CIBIL- ALL Individual LOS-HOME-LOAN.");

        String PersonalCibilFetchUrl = CibilConfig.PersonalCibilIP + "/personal-cibil/fetch/std-individual-list";
        System.out.println("HOME-LOAN CIBIL RE-FETCH URL: " + PersonalCibilFetchUrl);

        //****CONVERTING ALL TO STANDARD REQUEST
        List<StandardRequestPersonalDto> stdDtoListToFetchCibil = new ArrayList<>();
        List<IndividualBasicDetailsEntity> listOfAllIndividuals=applicantCoappGuarantorRepo.findAllByReferenceId(referenceId);
        List<IndividualBasicDetailsDto> dtoListOfAllIndividuals=listOfAllIndividuals.stream()
                .map(entity -> modelMapper.map(entity, IndividualBasicDetailsDto.class)).collect(Collectors.toList());

         if(!dtoListOfAllIndividuals.isEmpty()) {
             for (IndividualBasicDetailsDto singleIndividualDto : dtoListOfAllIndividuals) {
                 StandardRequestPersonalDto convertedDto = ConverterIndividualDetailsToStdCibilRequest.ConverterIndiviualDetailsToStdCibilRequest(singleIndividualDto);

                 // Add converted standard-DTO to list
                 stdDtoListToFetchCibil.add(convertedDto);
             }

             System.out.println("HOME-LOAN CIBIL RE-FETCH: LIST OF REQUEST CONVERTED TO STANDARD CIBIL REQUEST stdDtoListToFetchCibil : " + stdDtoListToFetchCibil);
             HttpHeaders headers = new HttpHeaders();
             headers.setContentType(MediaType.APPLICATION_JSON);
             headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

             HttpEntity<List<StandardRequestPersonalDto>> stdCibilRequestDto = new HttpEntity<>(stdDtoListToFetchCibil, headers);
             try {
                 ResponseEntity<String> responseEntity = restTemplate.postForEntity(
                         PersonalCibilFetchUrl,
                         stdCibilRequestDto,
                         String.class);

                 if (responseEntity.getStatusCode() == HttpStatus.OK) {

             /* HOME:  //DEVIATIONS FOR CIBIL
                deviationFlagsStatusService.updateCibilDeviationCommon(detailsDto.getPan(), detailsDto.getReferenceId());

                //CIBIL-FETCHED STATUS FLAGS
                cibilFetchStatusService.updateCibilFetchedBorrowerGuarantorFlag(detailsDto);*/

                     return ResponseEntity.ok(responseEntity.getBody());
                 } else {
                     System.err.println("ERROR IN RE-FETCHING PERSONAL CIBIL, RESPONSE:" + responseEntity.getBody());
                     return ResponseEntity.status(responseEntity.getStatusCode())
                             .body("PERSONAL CIBIL: Failed to RE-FETCH CIBIL::" + responseEntity.getBody());
                 }
             } catch (Exception e) {
                 e.printStackTrace();
                 System.err.println("PERSONAL CIBIL CONNECTION FAILED : FAILED TO RE-FETCH CIBIL FOR" );
                 throw new RuntimeException(" CIBIL CONNECTION FAILED :: FAILED TO RE-FETCH CIBIL, ERROR DETAILS : " + e.getMessage());
             }
         }else{

             throw new RuntimeException("ERROR WHILE RE-FETCHING CIBIL : DTO LIST OF INDIVIDUALS IS EMPTY...!!! ");
         }
    }

//*************************************************************************************************************************//
}