package com.lotusCarVersion2.LotusCarVersion2.Repository.StandardParameters;

import com.lotusCarVersion2.LotusCarVersion2.Models.StandardParameters.StandardParametersEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;

public interface StandardParametersRepo extends JpaRepository<StandardParametersEntity, Long> {

    @Query(value = "SELECT documentation_charge FROM los_car_v2.standard_parameters_table", nativeQuery = true)
    BigDecimal getDocumetationCharges();

    @Query(value = "SELECT processing_charge FROM los_car_v2.standard_parameters_table", nativeQuery = true)
    BigDecimal getProcessingCharges();

    @Query(value = "SELECT margin_percentage FROM los_car_v2.standard_parameters_table", nativeQuery = true)
    BigDecimal getMarginPercentage();
}
