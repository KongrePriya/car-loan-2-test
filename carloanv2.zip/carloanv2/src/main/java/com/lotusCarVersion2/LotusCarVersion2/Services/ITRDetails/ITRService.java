package com.lotusCarVersion2.LotusCarVersion2.Services.ITRDetails;

import com.lotusCarVersion2.LotusCarVersion2.DTO.ITRDetailsDto;

public interface ITRService {

    String SaveItrDetailsBusinessmen(ITRDetailsDto itrDetailsDto);
}
