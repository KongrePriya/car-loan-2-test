package com.lotusCarVersion2.LotusCarVersion2.Services.CibilDetailsPersonal;

import com.lotusCarVersion2.LotusCarVersion2.DTO.IndividualBasicDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsIndividual.StandardRequestPersonalDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
@AllArgsConstructor
public class ConverterIndividualDetailsToStdCibilRequest {

public static StandardRequestPersonalDto ConverterIndiviualDetailsToStdCibilRequest(IndividualBasicDetailsDto detailsDto) throws IOException {

     System.out.println("//***************************** PERSONAL CIBIL : MAPPING STANDARD REQUEST DTO TO IND-GUAR DTO.****************************//");
        try {
        StandardRequestPersonalDto stdDto = new StandardRequestPersonalDto();

//        //fetched from KYC verify API
        stdDto.setFullName(detailsDto.getFullName());
        stdDto.setGender(detailsDto.getGender());
        stdDto.setDateOfBirth(detailsDto.getDateOfBirth());
        stdDto.setPan(detailsDto.getPan());
        stdDto.setAadhar(detailsDto.getAadhar());
        stdDto.setPassportNum(detailsDto.getPassportNum());

        stdDto.setTempAddressLine1(detailsDto.getTempAddressLine1());
        stdDto.setTempAddressSubDist(detailsDto.getTempAddressSubDist());
        stdDto.setTempAddressDist(detailsDto.getTempAddressDist());
        stdDto.setTempAddressLandmark(detailsDto.getTempAddressLandmark());
        stdDto.setTempAddressState(detailsDto.getTempAddressState());
        stdDto.setTempAddressPincode(detailsDto.getTempAddressPincode());

//        //LOCAL DATA
        stdDto.setReferenceId(detailsDto.getReferenceId());
        stdDto.setUserId(detailsDto.getUserId());
        stdDto.setBranchCode(detailsDto.getBranchCode());
        stdDto.setIndividualType(detailsDto.getCustomerType());

        System.out.println("CAR-LOAN-V2 :PERSONAL CIBIL STD: CONVERTED STANDARD FORMAT DETAILS TO INDIVIDUAL DTO: " +stdDto);
        return stdDto;
    } catch (Exception e) {
        System.err.println("Error converting Firm DTO TO CORP DTO : " + e.getMessage());
        throw new IOException("Error converting Firm DTO TO CORP DTO : " + e.getMessage());
    }
}
}
