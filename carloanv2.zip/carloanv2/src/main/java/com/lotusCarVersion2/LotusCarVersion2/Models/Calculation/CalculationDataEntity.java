package com.lotusCarVersion2.LotusCarVersion2.Models.Calculation;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class CalculationDataEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String referenceId;
    private String loanType;
    private String borrowerType;

    private BigDecimal applicantIncome;
    private BigDecimal applicantDeduction;
    private BigDecimal coapplicantIncomeCombined;
    private BigDecimal coapplicantDeductionCombined;
    private BigDecimal combinedIncomeAll;
    private BigDecimal combinedDeductionAll;
    private BigDecimal loanEligibleAsPerMargin;
    private BigDecimal loanEligibleAsPerDeductionSalaried;
    private BigDecimal loanEligibleAsPerDeductionBusiness;
    private BigDecimal loanEligibleAsPerDeductionFinal;

    private BigDecimal principleAmountAfterAllowedDeduction;


    //FinalLoanSummaryDTO
    private String applicantName;

    private BigDecimal finalEligibleLoanWithKLI;
    private BigDecimal finalEligibleLoanWithoutKLI;
    private BigDecimal emiAsPerEligibleLoan;

    private BigDecimal appliedLoanWithKLI;
    private BigDecimal appliedLoanWithoutKLI;
    private BigDecimal emiAsPerAppliedLoan;

    private BigDecimal rateOfInterest;
    private Integer loanTenure;
    private BigDecimal kliFundedAmount;

    private BigDecimal deductionPercentage;
}
