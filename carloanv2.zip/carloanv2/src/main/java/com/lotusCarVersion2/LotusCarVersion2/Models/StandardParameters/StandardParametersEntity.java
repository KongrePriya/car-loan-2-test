package com.lotusCarVersion2.LotusCarVersion2.Models.StandardParameters;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "standard_parameters_table")
public class StandardParametersEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private BigDecimal processingCharge;
    private BigDecimal documentationCharge;
    private BigDecimal marginPercentage; //15%
}
