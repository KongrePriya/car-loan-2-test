package com.lotusCarVersion2.LotusCarVersion2.Controller.QuotationDetails;

import com.lotusCarVersion2.LotusCarVersion2.DTO.ProductCodeDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.ProductCode.ProductCodeModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.ProductCode.ProductCodeRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.StandardParameters.StandardParametersRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.QuotationDetails.QuotationDetailsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("api/v1/quotation-details/")
@CrossOrigin(origins = "*")
public class QuotationDetailsController {

    @Autowired
    private QuotationDetailsService quotationDetailsService;

    @Autowired
    private StandardParametersRepo standardParametersRepo;

    @Autowired
    private ProductCodeRepo productCodeRepo;

    @Autowired
    private ModelMapper modelMapper;

    @PostMapping("save-quotation-details")
    public ResponseEntity<String> postOtherRequiredDetails(@RequestBody QuotationDetailsModel quotationDetailsModel){
        String postOtherRequiredDetailsResponse = quotationDetailsService.postQuotationDetails(quotationDetailsModel);
        return new ResponseEntity<>(postOtherRequiredDetailsResponse, HttpStatus.OK);
    }


    @GetMapping("fetch-quotation-details/{referenceId}")
    public ResponseEntity<QuotationDetailsModel> getOtherRequiredDetails(@PathVariable("referenceId") String referenceId){
        QuotationDetailsModel otherRequiredDetailsModel = quotationDetailsService.getQuotationDetails(referenceId);
        if(otherRequiredDetailsModel !=null){
            return new ResponseEntity<>(otherRequiredDetailsModel, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }


    //    -------------------------------------- Get Documentation Charges ----------------------------------
    @GetMapping("documentation-charges")
    public ResponseEntity<BigDecimal> fetchDocumentationCharges(){
        BigDecimal documentationCharges = standardParametersRepo.getDocumetationCharges();
        if(documentationCharges==null){
            throw new RuntimeException("No Documentation Charges Data In Standard Finance Parameter Table");
        }else {
            return ResponseEntity.ok().body(documentationCharges);
        }
    }


    //    -------------------------------------- Get Processing Charges ----------------------------------
    @GetMapping("processing-charges")
    public ResponseEntity<BigDecimal> fetchProcessingCharges(){
        BigDecimal processingCharges = standardParametersRepo.getProcessingCharges();
        if(processingCharges==null){
            throw new RuntimeException("No Processing Charges Data In Standard Finance Parameter Table");
        }else {
            return ResponseEntity.ok().body(processingCharges);
        }
    }

    //    -------------------------------------- Get All Product Codes ----------------------------------
    @GetMapping("product-codes")
    public ResponseEntity<List<ProductCodeDto>> fetchAllProductCodes(){
        List<ProductCodeModel> allProductCodes = productCodeRepo.getAllProductCodes();
        if(allProductCodes.isEmpty()){
            throw new RuntimeException("No Product-Codes Data In Product-Codes Table");
        }else {
            List<ProductCodeDto> productCodeDtoList=allProductCodes.stream()
                    .map(singleEntity -> modelMapper.map(singleEntity,ProductCodeDto.class)).collect(Collectors.toList());
            System.out.println(" ALL PRODUCT CODES DTO LIST : "+productCodeDtoList);

            return ResponseEntity.ok().body(productCodeDtoList);
        }
    }

    //    -------------------------------------- Get Rate Of Interest ----------------------------------
    @GetMapping("rate-of-interest/{productCode}")
    public ResponseEntity<BigDecimal> fetchRateOfInterest(@PathVariable String productCode){
        BigDecimal rateOfInterest = productCodeRepo.getRateOfInterest(productCode);
        if(rateOfInterest==null){
            throw new RuntimeException("No Rate Of Interest Data In Product-Codes Table");
        }else {
            return ResponseEntity.ok().body(rateOfInterest);
        }
    }

    //    -------------------------------------- Get Rate Of Interest ----------------------------------
    @GetMapping("product-desc/{productCode}")
    public ResponseEntity<String> fetchProductDescription(@PathVariable String productCode){
        String productDesc = productCodeRepo.getProductDescription(productCode);
        if(productDesc==null){
            throw new RuntimeException("No Product Code Data In Product-Codes Table");
        }else {
            return ResponseEntity.ok().body(productDesc);
        }
    }
}
