package com.lotusCarVersion2.LotusCarVersion2.Services.Calculation;

import com.lotusCarVersion2.LotusCarVersion2.DTO.FinalLoanSummaryDTO;
import com.lotusCarVersion2.LotusCarVersion2.Models.Calculation.CalculationDataEntity;

import java.math.BigDecimal;

public interface CalculationService {


     CalculationDataEntity checkOrCreateCalculationRawEntity(String referenceId);
     CalculationDataEntity callAllFunctionToCollectData(String referenceId);
     FinalLoanSummaryDTO getCalculationDisplaySummary(String referenceId);

     //     ----------------------- Income Calculation --------------------
     BigDecimal calculateIncomeForApplicant(String referenceId);
     BigDecimal calculateIncomeForCoApplicants(String referenceId);

//     ----------------------- Deduction Calculation --------------------
     BigDecimal calculateDeductionsForApplicant(String referenceId);
     BigDecimal calculateDeductionsForCoApplicants(String referenceId);

//     ----------------------- Total Incomes For Calculation --------------------
     BigDecimal getAllIncomesForAppAndCoApp(String referenceId);

//     ----------------------- Total Deductions For Calculation --------------------
     BigDecimal getAllDeductionsForAppAndCoApp(String referenceId);

//     ----------------------- Calculate Eligible Loan Amount By Margin  --------------------
     BigDecimal calculateEligibleLoanByMargin(String referenceId);

//     ----------------------- Calculate Eligible Loan Amount By Deduction - Salaried/Pensioner  --------------------
     BigDecimal calculateEligibleLoanByDeductionForSalaried(String referenceId);

//     ----------------------- Calculate Eligible Loan Amount By Deduction - Business  --------------------
     BigDecimal calculateEligibleLoanByDeductionForBusiness(String referenceId);

//     ----------------------- Calculate Principal Amount After Allowed Deduction --------------------
     BigDecimal calculatePrincipleAmountAfterAllowedDeduction(BigDecimal deductionAllowed, String referenceId);

//     ----------------------- EMI Calculator : common --------------------
     BigDecimal  calculateEMI(BigDecimal loanAmount, BigDecimal rateOfInterest, Integer loanTenure);


//     ----------------------- Get Final Eligible Loan Amount  --------------------
     String calculateFinalLoanSummary(String referenceId);

//     ----------------------- Get Final Eligible Loan Amount  --------------------
     BigDecimal calculateDeductionPercentage(BigDecimal emiAsPerEligibilityWithoutKLI, String referenceId);
}
