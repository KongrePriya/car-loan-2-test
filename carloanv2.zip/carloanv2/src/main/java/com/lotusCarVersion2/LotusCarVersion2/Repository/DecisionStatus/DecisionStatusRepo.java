package com.lotusCarVersion2.LotusCarVersion2.Repository.DecisionStatus;

import com.lotusCarVersion2.LotusCarVersion2.Models.DecisionStatus.DecisionStatusModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DecisionStatusRepo extends JpaRepository<DecisionStatusModel,Long> {

    DecisionStatusModel findByReferenceId(String referenceId);

    boolean existsByReferenceId(String referenceId);
    boolean existsByFinalSubmitByBranchAndReferenceId(String branchData,String refId);
    //BR
    List<DecisionStatusModel> findByBranchCodeAndApplnStatusBranchManagerOrderByApplicationCreationDateDesc(@Param("status") String brCode, String action);

    List<DecisionStatusModel> findByBranchCodeAndApplnStatusBranchOfficerOrderByApplicationCreationDateDesc(@Param("status") String brCode,String action);

    //RO
    List<DecisionStatusModel> findByRonameAndApplnStatusCpcOfficerOrderByApplicationCreationDateDesc(@Param("status") String regionCode,String action);

    List<DecisionStatusModel> findByRonameAndApplnStatusCpcHeadOrderByApplicationCreationDateDesc(@Param("status") String regionCode,String action);

    List<DecisionStatusModel> findByRonameAndApplnStatusRegionalManagerOrderByApplicationCreationDateDesc(@Param("status") String regionCode,String action);

//HO


    List<DecisionStatusModel> findByApplnStatusHoOfficerOrderByApplicationCreationDateDesc(String action);


    List<DecisionStatusModel> findByApplnStatusChiefManagerOrderByApplicationCreationDateDesc(String action);

    //Get All Application List For BR
    List<DecisionStatusModel> findByBranchCodeOrderByApplicationCreationDateDesc(String brCode);

    //Get All Application List For RO

    List<DecisionStatusModel> findByRonameOrderByApplicationCreationDateDesc(String Roname);
}
