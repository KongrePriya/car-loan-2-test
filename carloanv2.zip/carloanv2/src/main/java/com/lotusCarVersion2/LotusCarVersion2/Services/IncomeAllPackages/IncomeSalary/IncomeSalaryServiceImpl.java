package com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeSalary;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksMandatoryEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryHistoryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DocumentUpload.DocumentsAndRemarksMandatoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeSalary.IncomeSalaryHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeSalary.IncomeSalaryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationFlagsStatusService;
import jakarta.transaction.Transactional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class IncomeSalaryServiceImpl implements IncomeSalaryService{

    @Autowired
    private IncomeSalaryRepo incomeSalaryRepo;

    @Autowired
    private IncomeSalaryHistoryRepo incomeSalaryHistoryRepo;
    @Autowired
    private DeviationFlagsStatusService deviationFlagsStatusService;
//    @Autowired
//    private CalculationRawDataService calculationRawDataService;


    @Override
    @Transactional
    public String postIncomeSalary(IncomeSalaryModel incomeSalaryModel) {
        if (incomeSalaryModel.getId()!=null){
            incomeSalaryModel.setId(null);
        }

        if(incomeSalaryRepo.existsByReferenceIdAndPanNumber(incomeSalaryModel.getReferenceId(), incomeSalaryModel.getPanNumber())){
            deleteIncomeSalaryAndSaveToHistory(incomeSalaryModel.getReferenceId(), incomeSalaryModel.getPanNumber());
        }
            try{
                Integer totalExpInMonths= ((incomeSalaryModel.getTotalWorkExperienceYears())*12);
                Integer currentExpInMonths= ((incomeSalaryModel.getCurrentOrgExperienceYears())*12);
                Integer retirementAgeInMonths= ((incomeSalaryModel.getRetirementAge())*12);
                incomeSalaryModel.setTotalWorkExperienceMonths(totalExpInMonths);
                incomeSalaryModel.setCurrentOrgExperienceMonths(currentExpInMonths);
                incomeSalaryModel.setRetirementAgeInMonths(retirementAgeInMonths);
                incomeSalaryModel.setCreatedDate(LocalDateTime.now());
                incomeSalaryRepo.save(incomeSalaryModel);

            }catch(Exception e){
                throw new RuntimeException("Error Occurred While Saving Income Salary " + e);
            }

        //====================================== DEVIATION METHODS =====================================//
        //WORK EXPERIENCE
        try{
            deviationFlagsStatusService.updateSalariedServiceIncomeDeviation(incomeSalaryModel);
        }catch(Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE SETTING DEVIATION FOR SALARIED WORK EXPERIENCE : " + e.getMessage());
            throw new RuntimeException("ERROR WHILE SETTING DEVIATION FOR SALARIED WORK EXPERIENCE : " + e.getMessage());
        }

        //====================================== INCOME DETAILS FOR CALCULATION =====================================//
          //05032025: directly called in calculation page
       try{
//            calculationRawDataService.redirectToSaveIncomeData(incomeSalaryModel.getReferenceId());
        }catch(Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE SETTING Income Details For Salaried :"+incomeSalaryModel.getCustomerType()+"\n ERROR DETAILS : " + e.getMessage());
            throw new RuntimeException("ERROR WHILE SETTING Income Details For Salaried :"+incomeSalaryModel.getCustomerType()+"\n ERROR DETAILS : " + e.getMessage());
        }
        //========================================================================================================//

        return "Income Salary Saved Successfully";
    }

    @Override
    public IncomeSalaryModel getIncomeSalary(String referenceId, String panNumber) {
        try{
            return incomeSalaryRepo.findByReferenceIdAndPanNumber(referenceId,panNumber);
        }catch(Exception e){
            throw new RuntimeException("Error Occurred while Getting Income Salary Details" +e);
        }
    }


//    ---------------------------- Delete Salary Record and Save To History--------------------
    @Override
    @Transactional
    public void deleteIncomeSalaryAndSaveToHistory(String referenceId, String panNumber) {
        IncomeSalaryModel foundRecord = incomeSalaryRepo.findByReferenceIdAndPanNumber(referenceId, panNumber);

        if (foundRecord != null) {
            IncomeSalaryHistoryModel incomeSalaryHistoryModel = new IncomeSalaryHistoryModel();
            incomeSalaryHistoryModel.setUpdatedDate(LocalDateTime.now());
            try {
                BeanUtils.copyProperties(foundRecord, incomeSalaryHistoryModel, "updatedDate", "id");
                incomeSalaryHistoryRepo.save(incomeSalaryHistoryModel);
            } catch (Exception e) {
                throw new RuntimeException("Error Occurred While Saving Income Salary History" + e);
            }
            try {
                incomeSalaryRepo.delete(foundRecord);
            } catch (Exception e) {
                throw new RuntimeException("Error Occurred While Deleting Income Salary" + e);
            }
        }
    }


}
