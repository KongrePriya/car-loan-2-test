package com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeMainList;


import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeMainList.IncomeMainListModel;

import java.util.List;

public interface IncomeMainListService {

    List<IncomeMainListModel> getIncomeList(String referenceId);

    String matchCountIncomeDataForProceeding(String referenceId);

    void deleteMissingOrChangedRecords(List<IncomeMainListModel> missingIncomeMainListModel);

    String redirectToDeleteIncomeData(String referenceId,String pan, String incomeType);
}
