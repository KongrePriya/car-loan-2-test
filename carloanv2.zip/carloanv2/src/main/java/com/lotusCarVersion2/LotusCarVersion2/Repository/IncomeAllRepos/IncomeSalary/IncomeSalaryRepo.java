package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeSalary;

import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface IncomeSalaryRepo extends JpaRepository<IncomeSalaryModel,Long> {

    boolean existsByReferenceIdAndPanNumber(String referenceId, String panNumber);
//    IncomeSalaryModel findByReferenceId(String referenceId);
    IncomeSalaryModel findByReferenceIdAndPanNumber(String referenceId, String panNumber);

    @Query(value = "SELECT COUNT(*) FROM los_car_v2.income_salary_model WHERE reference_id=:referenceId;",nativeQuery = true)
    Integer countIncomeSalary (String referenceId);


    List<IncomeSalaryModel> findAllByReferenceId(String referenceId);


}
