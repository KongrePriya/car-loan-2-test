package com.lotusCarVersion2.LotusCarVersion2.Services.Calculation;

import com.lotusCarVersion2.LotusCarVersion2.DTO.FinalLoanSummaryDTO;
import com.lotusCarVersion2.LotusCarVersion2.Models.Calculation.CalculationDataEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomePension.IncomePensionModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CalculationRepo.CalculationDataRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeBusiness.BusinessMain.IncomeBusinessMainRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomePension.IncomePensionRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeSalary.IncomeSalaryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.QuotationDetails.QuotationDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo.RefIdGenerationRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.StandardParameters.StandardParametersRepo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import static com.lotusCarVersion2.LotusCarVersion2.Config.MarginSlabs.*;

@Service
public class CalculationServiceImpl implements CalculationService {

    @Autowired
    private IncomeSalaryRepo incomeSalaryRepo;
    @Autowired
    private IncomeBusinessMainRepo incomeBusinessMainRepo;
    @Autowired
    private IncomePensionRepo incomePensionRepo;
    @Autowired
    private IndividualBasicDetailsRepo applicantCoappGuarantorRepo;
    @Autowired
    QuotationDetailsRepo quotationDetailsRepo;
    @Autowired
    StandardParametersRepo standardParametersRepo;
    @Autowired
    CalculationDataRepo calculationRawDataRepo;
    @Autowired
    RefIdGenerationRepo refIdGenerationRepo;
    @Autowired
    ModelMapper modelMapper;

//********************************************************************************//********************************************************************************//

    @Override
    public CalculationDataEntity checkOrCreateCalculationRawEntity(String referenceId) {
        // Check if data already present from referenceId
        CalculationDataEntity entityPresent = calculationRawDataRepo.findByReferenceId(referenceId);

        if (entityPresent == null) {
            CalculationDataEntity newDevEntity = new CalculationDataEntity();
            newDevEntity.setReferenceId(referenceId);

            ReferenceIdGenerationEntity refNoData = refIdGenerationRepo.findByReferenceId(referenceId);
            newDevEntity.setLoanType(refNoData.getLoanType());
            newDevEntity.setBorrowerType(refNoData.getBorrowerType());

            newDevEntity =calculationRawDataRepo.save(newDevEntity);

            System.out.println("EXISTING Calculation Raw Entity NOT PRESENT , NEW  CREATED ");
            return newDevEntity;
        } else {
            System.out.println("EXISTING ENTRY PRESENT CalculationDataEntity ");
            return entityPresent;
        }
    }
//********************************************************************************//********************************************************************************//

    @Override
    public CalculationDataEntity callAllFunctionToCollectData(String referenceId) {

        System.out.println("//------------------------------------------------------------- CALCULATION STARTED FOR REF-ID :"+referenceId+" -----------------------------------------------------------------//");
        CalculationDataEntity rawDataEntity=checkOrCreateCalculationRawEntity(referenceId);

        //STEP-1 : calculate Income For Applicant
        BigDecimal applicantIncome =calculateIncomeForApplicant(referenceId);
        rawDataEntity.setApplicantIncome(applicantIncome);

        //STEP-2 : calculate Income For co-Applicants
        BigDecimal coappIncomeCombined =calculateIncomeForCoApplicants(referenceId);
        rawDataEntity.setCoapplicantIncomeCombined(coappIncomeCombined);

        //STEP-3 : calculate Deduction For Applicant
        BigDecimal applicantDeduction =calculateDeductionsForApplicant(referenceId);
        rawDataEntity.setApplicantDeduction(applicantDeduction);

        //STEP-4 : calculate Deduction For co-Applicants
        BigDecimal coappDeductionCombined =calculateDeductionsForCoApplicants(referenceId);
        rawDataEntity.setCoapplicantDeductionCombined(coappDeductionCombined);

        //STEP-5 : calculate combined total income of all members
        BigDecimal combinedIncomeAll =getAllIncomesForAppAndCoApp(referenceId);
        rawDataEntity.setCombinedIncomeAll(combinedIncomeAll);

        //STEP-6 : calculate combined total deduction of all members
        BigDecimal combinedDeductionAll =getAllDeductionsForAppAndCoApp(referenceId);
        rawDataEntity.setCombinedDeductionAll(combinedDeductionAll);

        //STEP-7 : save above fields
        calculationRawDataRepo.save(rawDataEntity);


        //STEP-8 : CALCULATE EVERYTHING AND SAVE THOSE FIELDS
        calculateFinalLoanSummary(referenceId);
        System.out.println("//------------------------------------------------------------- CALCULATION ENDED FOR REF-ID :"+referenceId+" -----------------------------------------------------------------//");

        return rawDataEntity;
    }
//********************************************************************************//********************************************************************************//
    @Override
    public FinalLoanSummaryDTO getCalculationDisplaySummary(String referenceId) {
       CalculationDataEntity calculationData=checkOrCreateCalculationRawEntity(referenceId);
       FinalLoanSummaryDTO finalLoanSummaryDTO;
       if(calculationData !=null){
           finalLoanSummaryDTO =modelMapper.map(calculationData, FinalLoanSummaryDTO.class);
           System.out.println("COMPLETE CALCULATION ENTITY FOUND : "+calculationData);
           System.out.println(" FINAL CALCULATED SUMMARY : "+finalLoanSummaryDTO);
           return finalLoanSummaryDTO;
       }else{
           System.out.println("CALCULATION DATA NOT FOUND YET FOR REF-ID :"+referenceId);
           return null;
       }
    }

//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateIncomeForApplicant(String referenceId) {
        BigDecimal applicantTotalIncome = BigDecimal.ZERO;
        try {
            IndividualBasicDetailsEntity applicantBasicEntity = applicantCoappGuarantorRepo.findByReferenceIdAndCustomerType(referenceId, "APPLICANT");

            if (applicantBasicEntity.getConsideringIncome().equalsIgnoreCase("Yes")) {
                if (applicantBasicEntity.getIncomeSourceType().equalsIgnoreCase("Salaried")) {
                    System.out.println("In calculateIncomeForApplicant - Applicant is Salaried ");
                    IncomeSalaryModel incomeSalaryModel = incomeSalaryRepo.findByReferenceIdAndPanNumber(referenceId, applicantBasicEntity.getPan());
                    applicantTotalIncome = incomeSalaryModel.getMonthThreeSalary();
                } else if (applicantBasicEntity.getIncomeSourceType().equalsIgnoreCase("Business")) {
                    System.out.println("In calculateIncomeForApplicant - Applicant is Business Professional ");
                    IncomeBusinessMainModel incomeBusinessMainModel = incomeBusinessMainRepo.findByReferenceIdAndPanNumber(referenceId, applicantBasicEntity.getPan());
                    if (incomeBusinessMainModel.getIncomeAvailableFor().equalsIgnoreCase("One Year")) {
                        System.out.println("Applicant Business Income Considered for One Year");
                        applicantTotalIncome = incomeBusinessMainModel.getNetIncomeSecondYear().divide(BigDecimal.valueOf(12), 5, RoundingMode.FLOOR);
                    } else {
                        System.out.println("Applicant Business Income Considered for Two Years");
                        BigDecimal twoYearAverage = (incomeBusinessMainModel.getNetIncomeFirstYear().add(incomeBusinessMainModel.getNetIncomeSecondYear())).divide(BigDecimal.valueOf(2), 5, RoundingMode.FLOOR);
                //----------------- Convert Yearly Income to Monthly, Divide By 12 ----------------
                        applicantTotalIncome = twoYearAverage.divide(BigDecimal.valueOf(12), 5, RoundingMode.FLOOR);
                    }
                } else if (applicantBasicEntity.getIncomeSourceType().equalsIgnoreCase("Pensioner")) {
                    System.out.println("In calculateIncomeForApplicant - Applicant is Pensioner ");
                    IncomePensionModel incomePensionModel = incomePensionRepo.findByReferenceIdAndPanNumber(referenceId, applicantBasicEntity.getPan());
                    applicantTotalIncome = incomePensionModel.getMonthThreeSalary();
                }
            }
        }catch (Exception e) {
            throw new RuntimeException("Error Occurred in calculateIncomeForApplicant " + e);
        }
        System.out.println(" final applicantTotalIncome :: "+applicantTotalIncome);
        return applicantTotalIncome;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateIncomeForCoApplicants(String referenceId) {
        BigDecimal coAppTotalIncome = BigDecimal.ZERO;
        try {

            List<IndividualBasicDetailsEntity> coApplicantList = new ArrayList<>();
            List<IndividualBasicDetailsEntity> coappIncomeConsiderYesList = applicantCoappGuarantorRepo.getAllApplicantCoappConsiderIncome(referenceId);
       //---------------- Get All Coapplicants whose income is considered -------------
         /*   applicantCoappIncomeConsiderYes.forEach(item -> {
                if (item.getCustomerType().equalsIgnoreCase("COAPPLICANT")) {
                    coApplicantList.add(item);
                }
            });*/

            if(!coappIncomeConsiderYesList.isEmpty() || coappIncomeConsiderYesList !=null){
            for (IndividualBasicDetailsEntity coAppItem : coappIncomeConsiderYesList) {
                if (coAppItem.getIncomeSourceType().equalsIgnoreCase("Salaried")) {
                    IncomeSalaryModel incomeSalaryModel = incomeSalaryRepo.findByReferenceIdAndPanNumber(referenceId, coAppItem.getPan());
                    coAppTotalIncome = incomeSalaryModel.getMonthThreeSalary();
                } else if (coAppItem.getIncomeSourceType().equalsIgnoreCase("Business")) {
                    System.out.println("In calculateIncomeForCoApplicants - CoApplicant Business, PAN :"+coAppItem.getPan());

                    IncomeBusinessMainModel businessMainModel = incomeBusinessMainRepo.findByReferenceIdAndPanNumber(referenceId, coAppItem.getPan());
                    if (businessMainModel.getIncomeAvailableFor().equalsIgnoreCase("One Year")) {
                        System.out.println("CoApplicant Business Income is considered for One Year");
                  // ----------------- Divide by 12 to convert yearly business net income to monthly ----------------
                        coAppTotalIncome = businessMainModel.getNetIncomeSecondYear().divide(BigDecimal.valueOf(12), 5, RoundingMode.FLOOR);
                    } else {
                        System.out.println("CoApplicant Business Income is considered for Two Years");
                        BigDecimal twoYearAverageIncome = BigDecimal.ZERO;
                        twoYearAverageIncome = (businessMainModel.getNetIncomeFirstYear().add(businessMainModel.getNetIncomeSecondYear())).divide(BigDecimal.valueOf(2), 5, RoundingMode.FLOOR);
                  // ----------------- Divide by 12 to convert yearly business net income to monthly ----------------
                        coAppTotalIncome = twoYearAverageIncome.divide(BigDecimal.valueOf(12), 5, RoundingMode.FLOOR);
                    }
                } else if (coAppItem.getIncomeSourceType().equalsIgnoreCase("Pensioner")) {
                    System.out.println("In calculateIncomeForCoApplicants - CoApplicant Pensioner, PAN:"+coAppItem.getPan());
                    IncomePensionModel incomePensionModel = incomePensionRepo.findByReferenceIdAndPanNumber(referenceId, coAppItem.getPan());
                    coAppTotalIncome = incomePensionModel.getMonthThreeSalary();
                }
            }
        }
        }
            catch (Exception e) {
            throw new RuntimeException("Error Occurred in calculateIncomeForCoApplicants " + e);
        }
        System.out.println(" final coAppTotalIncome :: "+coAppTotalIncome);

        return coAppTotalIncome;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateDeductionsForApplicant(String referenceId) {
        BigDecimal applicantTotalDeduction = BigDecimal.ZERO;
        try {

            IndividualBasicDetailsEntity applicantBasicEntity = applicantCoappGuarantorRepo.findByReferenceIdAndCustomerType(referenceId, "APPLICANT");
            if (applicantBasicEntity.getConsideringIncome().equalsIgnoreCase("Yes")) {
                if (applicantBasicEntity.getIncomeSourceType().equalsIgnoreCase("Salaried")) {
                    System.out.println("In calculateDeductionsForApplicant - Applicant is Salaried ");
                    IncomeSalaryModel incomeSalaryModel = incomeSalaryRepo.findByReferenceIdAndPanNumber(referenceId, applicantBasicEntity.getPan());
                    applicantTotalDeduction = incomeSalaryModel.getTotalCurrentDeduction();
                } else if (applicantBasicEntity.getIncomeSourceType().equalsIgnoreCase("Business")) {
                    System.out.println("In calculateDeductionsForApplicant - Applicant is Business Professional ");
                    IncomeBusinessMainModel incomeBusinessMainModel = incomeBusinessMainRepo.findByReferenceIdAndPanNumber(referenceId, applicantBasicEntity.getPan());
//            ----------------------- Business Deductions are Yearly so divide by 12 to convert in monthly --------------------
                    applicantTotalDeduction = incomeBusinessMainModel.getTotalCurrentDeduction().divide(BigDecimal.valueOf(12), 5, RoundingMode.FLOOR);
                } else if (applicantBasicEntity.getIncomeSourceType().equalsIgnoreCase("Pensioner")) {
                    System.out.println("In calculateDeductionsForApplicant - Applicant is Pensioner ");
                    IncomePensionModel incomePensionModel = incomePensionRepo.findByReferenceIdAndPanNumber(referenceId, applicantBasicEntity.getPan());
                    applicantTotalDeduction = incomePensionModel.getTotalCurrentDeduction();
                }
            }
        }catch (Exception e) {
            throw new RuntimeException("Error Occurred in calculateDeductionsForApplicant " + e);
        }
        System.out.println(" final applicantTotalDeduction :: "+applicantTotalDeduction);

        return applicantTotalDeduction;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateDeductionsForCoApplicants(String referenceId) {
        BigDecimal coAppTotalDeductions = BigDecimal.ZERO;
        try {
            List<IndividualBasicDetailsEntity> coApplicantList = new ArrayList<>();
            List<IndividualBasicDetailsEntity> coappIncomeConsiderYesList = applicantCoappGuarantorRepo.getAllApplicantCoappConsiderIncome(referenceId);
        //---------------- Get All Coapplicants whose income is considered -------------
       /*     applicantCoappIncomeConsiderYes.forEach(item -> {
                if (item.getCustomerType().equalsIgnoreCase("COAPPLICANT")) {
                    coApplicantList.add(item);
                }
            });*/
            if (!coappIncomeConsiderYesList.isEmpty() || coappIncomeConsiderYesList != null) {
                for (IndividualBasicDetailsEntity coAppItem : coApplicantList) {
                    if (coAppItem.getIncomeSourceType().equalsIgnoreCase("Salaried")) {
                        System.out.println("In calculateDeductionsForCoApplicants - CoApplicant is Salaried");
                        IncomeSalaryModel incomeSalaryModel = incomeSalaryRepo.findByReferenceIdAndPanNumber(referenceId, coAppItem.getPan());
                        coAppTotalDeductions = incomeSalaryModel.getTotalCurrentDeduction();
                    } else if (coAppItem.getIncomeSourceType().equalsIgnoreCase("Business")) {
                        IncomeBusinessMainModel businessMainModel = incomeBusinessMainRepo.findByReferenceIdAndPanNumber(referenceId, coAppItem.getPan());
                        System.out.println("In calculateDeductionsForCoApplicants - CoApplicant is  Business Professional");
                  // ----------------- Divide by 12 to convert yearly total deductions to monthly ----------------
                        coAppTotalDeductions = businessMainModel.getTotalCurrentDeduction().divide(BigDecimal.valueOf(12), 5, RoundingMode.FLOOR);
                    } else if (coAppItem.getIncomeSourceType().equalsIgnoreCase("Pensioner")) {
                        System.out.println("In calculateDeductionsForCoApplicants - CoApplicant Pensioner");
                        IncomePensionModel incomePensionModel = incomePensionRepo.findByReferenceIdAndPanNumber(referenceId, coAppItem.getPan());
                        coAppTotalDeductions = incomePensionModel.getTotalCurrentDeduction();
                    }
                }
            }
        }catch (Exception e) {
            throw new RuntimeException("Error Occurred in calculateDeductionsForCoApplicants " + e);
        }
        System.out.println(" final coAppTotalDeductions :: "+coAppTotalDeductions);

        return coAppTotalDeductions;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal getAllIncomesForAppAndCoApp(String referenceId) {
        try {
            BigDecimal applicantIncome = calculateIncomeForApplicant(referenceId);
            BigDecimal allCoAppsIncome = calculateIncomeForCoApplicants(referenceId);

            BigDecimal combinedIncomeAll =applicantIncome.add(allCoAppsIncome);
            System.out.println(" final applicant coapp combinedIncomeAll :: "+allCoAppsIncome);

            return combinedIncomeAll;

        } catch (Exception e) {
            throw new RuntimeException("Error Occurred in getAllIncomesForAppAndCoApp " + e);
        }
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal getAllDeductionsForAppAndCoApp(String referenceId) {
        try {
            BigDecimal applicantDeductions = calculateDeductionsForApplicant(referenceId);
            BigDecimal allCoAppsDeductions = calculateDeductionsForCoApplicants(referenceId);
            BigDecimal combinedDeductionAll=applicantDeductions.add(allCoAppsDeductions);
            System.out.println(" final applicant coapp combinedDeductionAll :: "+combinedDeductionAll);
            return combinedDeductionAll;
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred in getAllDeductionsForAppAndCoApp " + e);
        }
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateEligibleLoanByMargin(String referenceId) {
        QuotationDetailsModel quotationDetailsModel = quotationDetailsRepo.findByReferenceId(referenceId);
        BigDecimal marginPercentage = quotationDetailsModel.getMargin().multiply(BigDecimal.valueOf(100));
        BigDecimal totalCostToConsider = quotationDetailsModel.getTotalCostToConsider();
        BigDecimal eligibleAsPerMargin = (marginPercentage.divide(BigDecimal.valueOf(100),2,RoundingMode.FLOOR)).multiply(totalCostToConsider);
        System.out.println("final eligibleAsPerMargin :"+eligibleAsPerMargin);
        return eligibleAsPerMargin;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateEligibleLoanByDeductionForSalaried(String referenceId) {
        BigDecimal consolidatedIncome = getAllIncomesForAppAndCoApp(referenceId);
        BigDecimal deductionAllowed;
        BigDecimal eligibilityAsPerDeductionSalaried;
        if(consolidatedIncome.compareTo(FIFTY_THOUSAND)<0){
            deductionAllowed = consolidatedIncome.multiply(SIXTY_PERCENT);
        }else if(consolidatedIncome.compareTo(FIFTY_THOUSAND)>=0 && consolidatedIncome.compareTo(ONE_LAKH) < 0){
            deductionAllowed = consolidatedIncome.multiply(SIXTYFIVE_PERCENT);
        } else if (consolidatedIncome.compareTo(ONE_LAKH)>=0 && consolidatedIncome.compareTo(TWO_LAKH) <0) {
            deductionAllowed = consolidatedIncome.multiply(SEVENTY_PERCENT);
        } else if (consolidatedIncome.compareTo(TWO_LAKH)>=0 && consolidatedIncome.compareTo(FIVE_LAKH) <0) {
            deductionAllowed = consolidatedIncome.multiply(SEVENTYFIVE_PERCENT);
        }else {
            deductionAllowed = consolidatedIncome.multiply(EIGHTY_PERCENT);
        }
        eligibilityAsPerDeductionSalaried = calculatePrincipleAmountAfterAllowedDeduction(deductionAllowed,referenceId);
        System.out.println(" eligibilityAsPerDeductionSalaried :"+eligibilityAsPerDeductionSalaried);

        return eligibilityAsPerDeductionSalaried;
    }

//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateEligibleLoanByDeductionForBusiness(String referenceId) {
        BigDecimal consolidatedIncome = getAllIncomesForAppAndCoApp(referenceId);
        BigDecimal deductionAllowed;
        BigDecimal eligibilityAsPerDeductionBusiness;
        if(consolidatedIncome.compareTo(SIX_LAKH)<0){
            deductionAllowed = consolidatedIncome.multiply(SIXTY_PERCENT);
        }else if(consolidatedIncome.compareTo(SIX_LAKH)>=0 && consolidatedIncome.compareTo(TWELVE_LAKH) < 0){
            deductionAllowed = consolidatedIncome.multiply(SIXTYFIVE_PERCENT);
        } else if (consolidatedIncome.compareTo(TWELVE_LAKH)>=0 && consolidatedIncome.compareTo(TWENTYFOUR_LAKH) <0) {
            deductionAllowed = consolidatedIncome.multiply(SEVENTY_PERCENT);
        } else if (consolidatedIncome.compareTo(TWENTYFOUR_LAKH)>=0 && consolidatedIncome.compareTo(SIXTY_LAKH) <0) {
            deductionAllowed = consolidatedIncome.multiply(SEVENTYFIVE_PERCENT);
        }else {
            deductionAllowed = consolidatedIncome.multiply(EIGHTY_PERCENT);
        }
        eligibilityAsPerDeductionBusiness = calculatePrincipleAmountAfterAllowedDeduction(deductionAllowed,referenceId);
        System.out.println(" eligibilityAsPerDeductionBusiness :"+eligibilityAsPerDeductionBusiness);

        return eligibilityAsPerDeductionBusiness;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculatePrincipleAmountAfterAllowedDeduction(BigDecimal deductionAllowed, String referenceId) {

        QuotationDetailsModel quotationDetailsModel =quotationDetailsRepo.findByReferenceId(referenceId);
        System.out.println("//-----------------calculation of Principle Amount After Allowed Deduction------------------//");
        System.out.println(" quotationDetailsModel.getRateOfInterest() : "+quotationDetailsModel.getRateOfInterest());

        BigDecimal monthlyRateOfInterest = quotationDetailsModel.getRateOfInterest().divide(BigDecimal.valueOf(12*100),5,RoundingMode.CEILING);
        System.out.println("monthlyRateOfInterest : "+monthlyRateOfInterest);

        BigDecimal onePlusRPowerN = monthlyRateOfInterest.add(BigDecimal.ONE).pow((quotationDetailsModel.getLoanTenure()).intValue());
        onePlusRPowerN =onePlusRPowerN.setScale(5,RoundingMode.CEILING);

        System.out.println("onePlusRPowerN : "+onePlusRPowerN);

        //numerator ( (ONE PLUS R POWER N) - ONE)
        BigDecimal numerator = deductionAllowed.multiply(onePlusRPowerN.subtract(BigDecimal.ONE)).setScale(5,RoundingMode.CEILING);
        System.out.println("numerator ( ONE PLUS R POWER N MINUS ONE) : "+numerator);

        //denominator ( (ONE PLUS R POWER N ) * monthlyRateOfInterest )
        BigDecimal denominator = monthlyRateOfInterest.multiply(onePlusRPowerN).setScale(5,RoundingMode.CEILING);
        System.out.println("denominator ( (ONE PLUS R POWER N ) * monthlyRateOfInterest ) : "+denominator);

        BigDecimal principleAmountAfterAllowedDeduction= numerator.divide(denominator, 5, RoundingMode.CEILING);
        System.out.println("principleAmountAfterAllowedDeduction (numerator/denominator) :: "+principleAmountAfterAllowedDeduction);

        return principleAmountAfterAllowedDeduction;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateEMI(BigDecimal loanAmount, BigDecimal rateOfInterest, Integer loanTenure) {
        BigDecimal monthlyRateOfInterest = rateOfInterest.divide(BigDecimal.valueOf(12 * 100), 10, RoundingMode.HALF_UP);
        BigDecimal onePlusRPowerN = BigDecimal.ONE.add(monthlyRateOfInterest).pow(loanTenure.intValue());

        BigDecimal numerator = loanAmount.multiply(monthlyRateOfInterest).multiply(onePlusRPowerN);
        BigDecimal denominator = onePlusRPowerN.subtract(BigDecimal.ONE);

        BigDecimal emi=numerator.divide(denominator, 2, RoundingMode.HALF_UP);
        return emi;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public String calculateFinalLoanSummary(String referenceId) {

        System.out.println("//------------------------------------ INSIDE FINAL LOAN SUMMARY CALCULATION ------------------------------//");

        IndividualBasicDetailsEntity applicantCoappGuarantorBasicEntity = applicantCoappGuarantorRepo.findByReferenceIdAndCustomerType(referenceId,"APPLICANT");
        QuotationDetailsModel quotationDetailsModel = quotationDetailsRepo.findByReferenceId(referenceId);

        //----------------------------STEP 1:  retrieve existing calculationEntity -------------------------------------------//
        CalculationDataEntity calculationEntity = checkOrCreateCalculationRawEntity(referenceId);

        //--------------------------- STEP 2: ELIGIBLE LOAN AS PER MARGIN CRITERIA -------------------------------//
        BigDecimal getEligibleLoanByMargin = calculateEligibleLoanByMargin(referenceId);
        calculationEntity.setLoanEligibleAsPerMargin(getEligibleLoanByMargin);

        BigDecimal getEligibleLoanByDeduction;
        BigDecimal finalEligibleLoanAmountWithoutKLI;
        BigDecimal finalEligibleLoanAmountWithKLI;
        BigDecimal finalEligibleLoanForEMI;
        BigDecimal rateOfInterest = quotationDetailsModel.getRateOfInterest();
        Integer loanTenure = quotationDetailsModel.getLoanTenure();
        BigDecimal kliFundedAmount = BigDecimal.ZERO;
        BigDecimal deductionPercentage;

        if(quotationDetailsModel.getKotakKliOptions().equalsIgnoreCase("Funded")){
            kliFundedAmount = quotationDetailsModel.getKotakKliFundedAmount();
        }

      // -------------------------STEP 3: Setting Fields For Applied Loan Amount ------------------------//
        BigDecimal appliedLoanAmount=quotationDetailsModel.getLoanAppliedAmount();
        BigDecimal appliedLoanAmountToConsider =appliedLoanAmount;
        if(quotationDetailsModel.getKotakKliOptions().equalsIgnoreCase("Funded")){
            appliedLoanAmountToConsider = appliedLoanAmount.add(kliFundedAmount);
        }
        calculationEntity.setAppliedLoanWithoutKLI(appliedLoanAmount);
        calculationEntity.setAppliedLoanWithKLI(appliedLoanAmountToConsider);

        //------------------ STEP 4a : CALCULATE ELIGIBLE LOAN AS PER DEDUCTION CRITERIA ------------------------------//
        if(applicantCoappGuarantorBasicEntity.getIncomeSourceType().equalsIgnoreCase("Business")){
            System.out.println("In calculateFinalLoanSummary - APPLICANT INCOME IS BUSINESS");
            getEligibleLoanByDeduction = calculateEligibleLoanByDeductionForBusiness(referenceId);
            calculationEntity.setLoanEligibleAsPerDeductionBusiness(getEligibleLoanByDeduction);

        }else {
            System.out.println("In calculateFinalLoanSummary - APPLICANT INCOME IS SALARIED/PENSIONER");
            getEligibleLoanByDeduction = calculateEligibleLoanByDeductionForSalaried(referenceId);
            calculationEntity.setLoanEligibleAsPerDeductionSalaried(getEligibleLoanByDeduction);
        }
        System.out.println("final EligibleLoanByDeduction :"+getEligibleLoanByDeduction);
        calculationEntity.setLoanEligibleAsPerDeductionFinal(getEligibleLoanByDeduction);

        //------------------ STEP 4b : CALCULATION OF FINAL LOAN ELIGIBLE WITHOUT KLI ----------------------------//
        //FINAL ELIGIBLE LOAN IS MINIMUM OF ALL 3 i.e. APPLIED, ELIGIBLE AS PER MARGIN , ELIGIBLE AS PER DEDUCTION

        finalEligibleLoanAmountWithoutKLI= getEligibleLoanByMargin.min(getEligibleLoanByDeduction).min(appliedLoanAmount);

        System.out.println("//---------------------- Eligible Loan for REF-ID :"+referenceId+"--------------------------//\n" +
                "  AppliedLoanAmount : "+appliedLoanAmount
                +" \n EligibleLoanByMargin : "+getEligibleLoanByMargin
                +"\n EligibleLoanByDeduction : "+getEligibleLoanByDeduction
                +"\n finalEligibleLoanAmount (MINIMUM OF ALL THREE): "+ finalEligibleLoanAmountWithoutKLI
        +"-----------------------------------------------------//");


        if(quotationDetailsModel.getKotakKliOptions().equalsIgnoreCase("Funded")){
            finalEligibleLoanAmountWithKLI = finalEligibleLoanAmountWithoutKLI.add(kliFundedAmount);
            calculationEntity.setFinalEligibleLoanWithKLI(finalEligibleLoanAmountWithKLI);
            finalEligibleLoanForEMI=finalEligibleLoanAmountWithKLI;
        }else{
            //KLI NOT FUNDED HENCE FINAL ELIGIBLE LOAN WITH AND WITHOUT KLI WILL BE SAME
            finalEligibleLoanForEMI=finalEligibleLoanAmountWithoutKLI;
            calculationEntity.setFinalEligibleLoanWithKLI(finalEligibleLoanAmountWithoutKLI);
        }
        calculationEntity.setFinalEligibleLoanWithoutKLI(finalEligibleLoanAmountWithoutKLI);

       // -------------------------------------STEP 5: Calculation of EMI Fields ------------------------------
        //USING finalEligibleLoanAmountWithKLI AS IT HOLDS FINAL ELIGIBLE VALUE  IRRESPECTIVE OF KLI (as per STEP 4b)
        BigDecimal emiAsPerEligibleLoan= calculateEMI(finalEligibleLoanForEMI,rateOfInterest,loanTenure);
        System.out.println("final EMI AS Per Eligible Loan :: "+emiAsPerEligibleLoan);
        calculationEntity.setEmiAsPerEligibleLoan(emiAsPerEligibleLoan);

        BigDecimal emiAsPerAppliedLoan=calculateEMI(appliedLoanAmountToConsider,rateOfInterest,loanTenure);
        System.out.println("final EMI As Per Applied Loan :: "+emiAsPerAppliedLoan);
        calculationEntity.setEmiAsPerAppliedLoan(emiAsPerAppliedLoan);


       // -------------- STEP 5: EMI for Final Eligible Loan Amount for Deduction Percentage Calculation ------------
        //to calculate deduction percetage we consider eligible loan amount without adding KLI
        BigDecimal emiForEligibleLoanWithoutKLI = calculateEMI(finalEligibleLoanAmountWithoutKLI, rateOfInterest, loanTenure);
        System.out.println(" EMI on Eligible Loan Without KLI (To calculate allowed monthly deduction) :: "+emiForEligibleLoanWithoutKLI);

       // ------------------------- STEP 6: Get and Set Deduction Percentage ------------------------
        deductionPercentage = calculateDeductionPercentage(emiForEligibleLoanWithoutKLI, referenceId);
        calculationEntity.setDeductionPercentage(deductionPercentage);

        // -------------------------STEP 7:  Setting Other Fields for Calculation Summary ------------------------
        calculationEntity.setApplicantName(applicantCoappGuarantorBasicEntity.getFullName());
        calculationEntity.setRateOfInterest(rateOfInterest);
        calculationEntity.setLoanTenure(loanTenure);
        calculationEntity.setReferenceId(referenceId);
        calculationEntity.setKliFundedAmount(kliFundedAmount);

        calculationRawDataRepo.save(calculationEntity);
        System.out.println("//============ CALCULATION COMPLETED, FINAL CALCULATED DATA :: "+calculationEntity);
        return "//============ CALCULATION COMPLETED, FINAL CALCULATED DATA :: "+calculationEntity;
    }
//********************************************************************************//********************************************************************************//

    @Override
    public BigDecimal calculateDeductionPercentage(BigDecimal emiAsPerEligibilityWithoutKLI, String referenceId) {
        BigDecimal getTotalIncome = getAllIncomesForAppAndCoApp(referenceId);
        BigDecimal getTotalDeductions = getAllDeductionsForAppAndCoApp(referenceId);
        BigDecimal finalDeductionPercentage=((getTotalDeductions.add(emiAsPerEligibilityWithoutKLI)).divide(getTotalIncome,2,RoundingMode.CEILING)).multiply(BigDecimal.valueOf(100));
        System.out.println("final DeductionPercentage :: "+finalDeductionPercentage);
        return finalDeductionPercentage;
    }

//********************************************************************************//********************************************************************************//

}
