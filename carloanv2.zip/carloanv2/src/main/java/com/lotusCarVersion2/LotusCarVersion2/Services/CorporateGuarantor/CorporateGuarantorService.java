package com.lotusCarVersion2.LotusCarVersion2.Services.CorporateGuarantor;

import com.lotusCarVersion2.LotusCarVersion2.DTO.CorporateGuarantorDto;

import java.util.List;

public interface CorporateGuarantorService {

    CorporateGuarantorDto saveSingleCorpGuarantor(CorporateGuarantorDto corporateGuarantorDto);

    CorporateGuarantorDto updateSingleCorpGuarantor(CorporateGuarantorDto corporateGuarantorDto);

    List<CorporateGuarantorDto> getAllCorpGuarantorsList(String referenceId);

    String updateCorpGuarantorStatusDeletedByUniqueId(String referenceId, Long id);


}
