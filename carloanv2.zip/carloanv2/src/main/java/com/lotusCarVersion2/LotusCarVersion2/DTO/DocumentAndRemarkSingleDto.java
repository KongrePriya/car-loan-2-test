package com.lotusCarVersion2.LotusCarVersion2.DTO;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class DocumentAndRemarkSingleDto {

    private String referenceId;
    private String fileType;
    private String userId;
    @Column(columnDefinition = "TEXT")
    private String remark;
    private Boolean declarationCheck;
    private String deviationSanctionLetterNumber;

}
