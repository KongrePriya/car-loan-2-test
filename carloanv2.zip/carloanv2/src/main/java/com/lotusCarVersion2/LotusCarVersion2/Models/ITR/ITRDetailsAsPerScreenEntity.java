package com.lotusCarVersion2.LotusCarVersion2.Models.ITR;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "itr_screen_final_details" )
//// THE ACTUAL DATA IS PRESENT IN THE kyc_itr SCHEMA , this is just a entity to get the data for jasper reports and to set in appraisal note
public class ITRDetailsAsPerScreenEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String referenceIdItr;
    private String referenceIdLotus;
    private String customerName;
    private String customerPan;
    private String fetchedByUser;
    private String branchCode;

    private LocalDateTime fetchedDate;
    private String detailsStatus;
    private String customerType; //to store borrower or guarantor or nominee

    private String year1;
    private String year2;

    // ITR Filing Details : year 1
    private String itrTypeYear1;
    private String originalOrRevisedYear1;
    private String acknowledgementNumberYear1;
    private String originalReturnFilingDateYear1;
    private String revisedReturnFilingDateYear1;
    // ITR Filing Details: year 2
    private String itrTypeYear2;
    private String originalOrRevisedYear2;
    private String acknowledgementNumberYear2;
    private String originalReturnFilingDateYear2;
    private String revisedReturnFilingDateYear2;


    //Income Details From All Sources : year 1
    private int grossIncomeFromSalaryYear1;
    private int incomeFromHousePropertyYear1;
    private int shortTermCapitalGainTotalYear1;
    private int longTermCapitalGainTotalYear1;
    private int capitalGainTotalYear1;//sum of short+long
    private int incomeFromOtherSourcesYear1;
    private int totalIncomeByAddingAllYear1;
    private int profitGainsFromBusinessOrProfYear1;

    //Income Details From All Sources : year 2
    private int grossIncomeFromSalaryYear2;
    private int incomeFromHousePropertyYear2;
    private int shortTermCapitalGainTotalYear2;
    private int longTermCapitalGainTotalYear2;
    private int capitalGainTotalYear2; //sum of short+long
    private int incomeFromOtherSourcesYear2;
    private int totalIncomeByAddingAllYear2;
    private int profitGainsFromBusinessOrProfYear2;



    //Income As Per ITR : year 1
    private int grossTotalIncomeYear1;
    private int totalTaxableIncomeYear1;
    //Income As Per ITR : year 2
    private int grossTotalIncomeYear2;
    private int totalTaxableIncomeYear2;


    //Deduction & Liability Details As Per ITR : year 1
    private int deductionUnder6aYear1;
    private int deductionUnder10aaYear1;
    private int incomeExcludingTotalIncomeYear1;
    private int otherDeductionsTotalYear1; // incomeExcludingTotalIncomeYear1 + otherDeductionsTotalYear1
    private int netTaxLiabilityYear1;

    //Deduction & Liability Details As Per ITR : year 2
    private int deductionUnder6aYear2;
    private int deductionUnder10aaYear2;
    private int incomeExcludingTotalIncomeYear2;
    private int otherDeductionsTotalYear2;// incomeExcludingTotalIncomeYear2 + otherDeductionsTotalYear2
    private int netTaxLiabilityYear2;

}
