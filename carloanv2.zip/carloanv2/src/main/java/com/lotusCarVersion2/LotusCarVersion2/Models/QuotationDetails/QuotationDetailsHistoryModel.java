package com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Entity
public class QuotationDetailsHistoryModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String referenceId;
    private String branchCode;
    private String region;
    private String userId;
    private String companyName;
    private String modelName;
    private String dealerPan;
    private String gstnNumber;
    private String dealerName;
    private LocalDate dateOfQuotation;
    private String productCode;
    private String productDescription;
    private BigDecimal rateOfInterest;
    private BigDecimal margin;
    private BigDecimal loanTenure;
    private BigDecimal processingCharges;
    private BigDecimal documentCharges;
    private BigDecimal showroomPrice;
    private BigDecimal rtoCharges;
    private BigDecimal carInsuranceCharges;
    private BigDecimal totalCostToConsider;
    private BigDecimal loanAppliedAmount;
    private String kotakKliOptions;
    private BigDecimal kotakKliPremiumAmount;
    private BigDecimal kotakKliFundedAmount;
    private BigDecimal carScore;
    private LocalDateTime submitDate;
    private LocalDateTime updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getDealerPan() {
        return dealerPan;
    }

    public void setDealerPan(String dealerPan) {
        this.dealerPan = dealerPan;
    }

    public String getGstnNumber() {
        return gstnNumber;
    }

    public void setGstnNumber(String gstnNumber) {
        this.gstnNumber = gstnNumber;
    }

    public String getDealerName() {
        return dealerName;
    }

    public void setDealerName(String dealerName) {
        this.dealerName = dealerName;
    }

    public LocalDate getDateOfQuotation() {
        return dateOfQuotation;
    }

    public void setDateOfQuotation(LocalDate dateOfQuotation) {
        this.dateOfQuotation = dateOfQuotation;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public BigDecimal getRateOfInterest() {
        return rateOfInterest;
    }

    public void setRateOfInterest(BigDecimal rateOfInterest) {
        this.rateOfInterest = rateOfInterest;
    }

    public BigDecimal getMargin() {
        return margin;
    }

    public void setMargin(BigDecimal margin) {
        this.margin = margin;
    }

    public BigDecimal getLoanTenure() {
        return loanTenure;
    }

    public void setLoanTenure(BigDecimal loanTenure) {
        this.loanTenure = loanTenure;
    }

    public BigDecimal getProcessingCharges() {
        return processingCharges;
    }

    public void setProcessingCharges(BigDecimal processingCharges) {
        this.processingCharges = processingCharges;
    }

    public BigDecimal getDocumentCharges() {
        return documentCharges;
    }

    public void setDocumentCharges(BigDecimal documentCharges) {
        this.documentCharges = documentCharges;
    }

    public BigDecimal getShowroomPrice() {
        return showroomPrice;
    }

    public void setShowroomPrice(BigDecimal showroomPrice) {
        this.showroomPrice = showroomPrice;
    }

    public BigDecimal getRtoCharges() {
        return rtoCharges;
    }

    public void setRtoCharges(BigDecimal rtoCharges) {
        this.rtoCharges = rtoCharges;
    }

    public BigDecimal getCarInsuranceCharges() {
        return carInsuranceCharges;
    }

    public void setCarInsuranceCharges(BigDecimal carInsuranceCharges) {
        this.carInsuranceCharges = carInsuranceCharges;
    }

    public BigDecimal getTotalCostToConsider() {
        return totalCostToConsider;
    }

    public void setTotalCostToConsider(BigDecimal totalCostToConsider) {
        this.totalCostToConsider = totalCostToConsider;
    }

    public BigDecimal getLoanAppliedAmount() {
        return loanAppliedAmount;
    }

    public void setLoanAppliedAmount(BigDecimal loanAppliedAmount) {
        this.loanAppliedAmount = loanAppliedAmount;
    }

    public String getKotakKliOptions() {
        return kotakKliOptions;
    }

    public void setKotakKliOptions(String kotakKliOptions) {
        this.kotakKliOptions = kotakKliOptions;
    }

    public BigDecimal getKotakKliPremiumAmount() {
        return kotakKliPremiumAmount;
    }

    public void setKotakKliPremiumAmount(BigDecimal kotakKliPremiumAmount) {
        this.kotakKliPremiumAmount = kotakKliPremiumAmount;
    }

    public BigDecimal getKotakKliFundedAmount() {
        return kotakKliFundedAmount;
    }

    public void setKotakKliFundedAmount(BigDecimal kotakKliFundedAmount) {
        this.kotakKliFundedAmount = kotakKliFundedAmount;
    }

    public BigDecimal getCarScore() {
        return carScore;
    }

    public void setCarScore(BigDecimal carScore) {
        this.carScore = carScore;
    }

    public LocalDateTime getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(LocalDateTime submitDate) {
        this.submitDate = submitDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }
}
