package com.lotusCarVersion2.LotusCarVersion2.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CoappGuaPresentStatusDto {

    public Boolean coapplicantPresent= false;
    public Boolean guarantorPresent= false;


}
