package com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessDetail;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainHistoryModel;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class IncomeBusinessDetailHistoryModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;
    @Column(columnDefinition = "TEXT")
    private String nameOfConstitution;
    @Column(columnDefinition = "TEXT")
    private String nameOfBusiness;
    @Column(columnDefinition = "TEXT")
    private String natureOfBusiness;
    @Column(columnDefinition = "TEXT")
    private  String businessSector;
    @Column(columnDefinition = "TEXT")
    private String businessActivityDetail;
    @Column(columnDefinition = "TEXT")
    private String businessAddress;
    private String businessPan;
    private String businessGstin;
    private LocalDate incorporationDate;
    private LocalDateTime updatedDate;
    private String customerName; //New Addition 20022025
    @JsonIgnore
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "parent_history_id", referencedColumnName="parent_history_id", nullable = false)
    private IncomeBusinessMainHistoryModel incomeBusinessMainHistoryModel;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNameOfConstitution() {
        return nameOfConstitution;
    }

    public void setNameOfConstitution(String nameOfConstitution) {
        this.nameOfConstitution = nameOfConstitution;
    }

    public String getNameOfBusiness() {
        return nameOfBusiness;
    }

    public void setNameOfBusiness(String nameOfBusiness) {
        this.nameOfBusiness = nameOfBusiness;
    }

    public String getNatureOfBusiness() {
        return natureOfBusiness;
    }

    public void setNatureOfBusiness(String natureOfBusiness) {
        this.natureOfBusiness = natureOfBusiness;
    }

    public String getBusinessSector() {
        return businessSector;
    }

    public void setBusinessSector(String businessSector) {
        this.businessSector = businessSector;
    }

    public String getBusinessActivityDetail() {
        return businessActivityDetail;
    }

    public void setBusinessActivityDetail(String businessActivityDetail) {
        this.businessActivityDetail = businessActivityDetail;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getBusinessPan() {
        return businessPan;
    }

    public void setBusinessPan(String businessPan) {
        this.businessPan = businessPan;
    }

    public String getBusinessGstin() {
        return businessGstin;
    }

    public void setBusinessGstin(String businessGstin) {
        this.businessGstin = businessGstin;
    }

    public LocalDate getIncorporationDate() {
        return incorporationDate;
    }

    public void setIncorporationDate(LocalDate incorporationDate) {
        this.incorporationDate = incorporationDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public IncomeBusinessMainHistoryModel getIncomeBusinessMainHistoryModel() {
        return incomeBusinessMainHistoryModel;
    }

    public void setIncomeBusinessMainHistoryModel(IncomeBusinessMainHistoryModel incomeBusinessMainHistoryModel) {
        this.incomeBusinessMainHistoryModel = incomeBusinessMainHistoryModel;
    }
}
