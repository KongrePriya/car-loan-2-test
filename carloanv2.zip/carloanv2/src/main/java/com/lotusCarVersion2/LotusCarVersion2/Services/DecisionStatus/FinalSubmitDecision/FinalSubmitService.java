package com.lotusCarVersion2.LotusCarVersion2.Services.DecisionStatus.FinalSubmitDecision;

import com.lotusCarVersion2.LotusCarVersion2.DTO.DecisionStatusUserInfoDTO;

public interface FinalSubmitService {

    String getFinalSubmitStatusByBranch(String referenceId,String userLocation, String brcode);

    String postFinalSubmitByBranch(String referenceId, String userId);

    String canLoggedInUserSanction(DecisionStatusUserInfoDTO canLoggedUserSanctionDTO);


    String checkIsActionTakenByPreviousAuthority(DecisionStatusUserInfoDTO canLoggedUserSanctionDTO);

    String sanctionUnderGmOrChairman(DecisionStatusUserInfoDTO canLoggedUserSanctionDTO);

    String checkRejectSanctionStatus(String referenceId);

    String getFinalSubmitStatusForAppraisalEditButton(String referenceId);
}
