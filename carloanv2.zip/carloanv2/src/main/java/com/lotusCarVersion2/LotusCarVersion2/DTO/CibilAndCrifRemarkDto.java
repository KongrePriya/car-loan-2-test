package com.lotusCarVersion2.LotusCarVersion2.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cglib.core.Block;

import java.sql.Blob;
import java.time.LocalDateTime;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CibilAndCrifRemarkDto {

    private Long id;
    private String referenceId;
    private String userId;
    private String userType;

    //--------------- PERSONAL CIBIL REMARKS COMBINED --------------//
  
    private String personalCibilRemark;
    private String personalCibilOverdueRemark;
    private String personalCibilRejectRemark;
    //additional
    private String personalCibilWrittenOffRemark;
    private String personalCibilAccountSettledRemark;
    private String personalCibilSuitFilledRemark;
    private LocalDateTime personalCibilSubmitDate;

    //--------------- COMMERCIAL CIBIL REMARKS COMBINED --------------//
  
    private String commercialCibilRemark;
    private String commercialCibilOverdueRemark;
    private String commercialCibilRejectRemark;
    //additional
    private String commercialCibilWrittenOffRemark;
    private String commercialCibilAccountSettledRemark;
    private String commercialCibilSuitFilledRemark;
    private LocalDateTime commercialCibilSubmitDate;

    //--------------- PERSONAL CRIF REMARKS COMBINED --------------//
  
    private String personalCrifRemark;
    private String personalCrifOverdueRemark;
    private String personalCrifRejectRemark;
    //additional
  
    private String personalCrifWrittenOffRemark;
    private String personalCrifAccountSettledRemark;
    private String personalCrifSuitFilledRemark;
    private LocalDateTime personalCrifSubmitDate;

    //--------------- COMMERCIAL CRIF REMARKS COMBINED --------------//
  
    private String commercialCrifRemark;
    private String commercialCrifOverdueRemark;
    private String commercialCrifRejectRemark;
    //additional
    private String commercialCrifWrittenOffRemark;
    private String commercialCrifAccountSettledRemark;
    private String commercialCrifSuitFilledRemark;
    private LocalDateTime commercialCrifSubmitDate;

    //--------------- STATUS --------------//
    private String remarkStatus;
    private String rejectedStatus;
    private LocalDateTime statusDate;

    //--------------OVERDUE CLEARANCE ---------//
    private Blob overdueClearanceCertificate;
    private String overdueClearanceCertificateName;
}
