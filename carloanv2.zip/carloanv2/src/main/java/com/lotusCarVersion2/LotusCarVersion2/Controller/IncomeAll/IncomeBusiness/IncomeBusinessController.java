package com.lotusCarVersion2.LotusCarVersion2.Controller.IncomeAll.IncomeBusiness;



import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeBusiness.BusinessMain.IncomeBusinessMainModel;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeBusiness.IncomeBusinessService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/income-business")
@CrossOrigin(origins = "*")
public class IncomeBusinessController {


    @Autowired
    private IncomeBusinessService incomeBusinessService;


    @PostMapping("add")
    public ResponseEntity<String> postIncomeBusinessDetails( @RequestBody @Valid IncomeBusinessMainModel incomeBusinessMainModel){
         String incomeBusinessResponse = incomeBusinessService.postIncomeBusiness(incomeBusinessMainModel);
         return new ResponseEntity<>(incomeBusinessResponse, HttpStatus.OK);
    }

    @GetMapping("fetch")
    public ResponseEntity<IncomeBusinessMainModel> getIncomePensionDetails(@RequestParam String referenceId, @RequestParam String panNumber){
        IncomeBusinessMainModel getIncomeBusinessResponse = incomeBusinessService.getIncomeBusiness(referenceId,panNumber);
        if(getIncomeBusinessResponse != null){
            return new ResponseEntity<>(getIncomeBusinessResponse,HttpStatus.OK);
        }else {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }

}
