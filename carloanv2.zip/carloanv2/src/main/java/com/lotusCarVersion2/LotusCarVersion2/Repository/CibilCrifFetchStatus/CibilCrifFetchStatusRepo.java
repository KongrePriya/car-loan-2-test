package com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifFetchStatus;

import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifStatus.CibilCrifFetchStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CibilCrifFetchStatusRepo extends JpaRepository<CibilCrifFetchStatusEntity, Long> {

    CibilCrifFetchStatusEntity findByReferenceId(String referenceId);

//***************************************** APPLICANT **************************************************************//

// Query to check if applicant CIBIL is fetched
@Query(value = """
SELECT COUNT(*) FROM cibil_personal.screen_personal_cibil_basic_summary_details 
WHERE old_record IS NULL and individual_type='APPLICANT' 
and reference_id = :referenceId""", nativeQuery = true)
Integer isApplicantCibilDetailsPresent(@Param("referenceId") String referenceId);


//******************************************************************************************************************//


//************************************** CO-APPLICANTS : contributing in loan *****************************************************//
/* Query to retrieve COUNT of Co-applicants contributing income in loan
// ( customer_type in ('COAPPLICANT1','COAPPLICANT2','COAPPLICANT3')) */
@Query(value = """
        SELECT COUNT(*) FROM los_car_v2.individual_basic_details WHERE  
        customer_type in ('COAPPLICANT1','COAPPLICANT2','COAPPLICANT3') and reference_id = :referenceId""" , nativeQuery = true)
Integer calculateEarningCoappCount(@Param("referenceId") String referenceId);


// Query to retrieve COUNT of Co-applicants contributing income in loan whose CIBIL is fetched
@Query(value = """
    SELECT COUNT(*) FROM cibil_personal.screen_personal_cibil_basic_summary_details 
    WHERE old_record IS NULL and individual_type in ('COAPPLICANT1','COAPPLICANT2','COAPPLICANT3') 
    and reference_id = :referenceId""", nativeQuery = true)
Integer calculateEarningCoappCibilCount(@Param("referenceId") String referenceId);


//************************************** CO-APPLICANTS : not contributing in loan *****************************************************//
// Query to retrieve COUNT of Co-applicants NOT contributing income in loan
@Query(value = """
    SELECT COUNT(*) FROM los_car_v2.individual_basic_details WHERE  
    customer_type='COAPPLICANT' and reference_id = :referenceId""" , nativeQuery = true)
Integer calculateNonEarningCoappCount(@Param("referenceId") String referenceId);


// Query to retrieve COUNT of Co-applicants NOT contributing income in loan whose CIBIL is fetched
@Query(value = """
SELECT COUNT(*) FROM cibil_personal.screen_personal_cibil_basic_summary_details 
WHERE old_record IS NULL and individual_type='COAPPLICANT' 
and reference_id = :referenceId""", nativeQuery = true)
Integer calculateNonEarningCoappCibilCount(@Param("referenceId") String referenceId);

//***************************************** GUARANTORS **************************************************************//
// Query to retrieve COUNT of Guarantors
@Query(value = """
    SELECT COUNT(*) FROM los_car_v2.individual_basic_details WHERE  
    customer_type='GUARANTOR' and reference_id = :referenceId""" , nativeQuery = true)
Integer calculateGuarantorsCount(@Param("referenceId") String referenceId);


// Query to retrieve COUNT of Guarantors whose CIBIL fetched
@Query(value = """
SELECT COUNT(*) FROM cibil_personal.screen_personal_cibil_basic_summary_details 
WHERE old_record IS NULL and individual_type='GUARANTOR' 
and reference_id = :referenceId""", nativeQuery = true)
Integer calculateGuarantorsCibilCount(@Param("referenceId") String referenceId);


//******************************************************************************************************************//





//***********************************************************************************************************************//
//To retrieve list reset flags of application which are in process.
@Query( value = """
        SELECT cc.* FROM los_housing.cibil_crif_fetch_status as cc,los_housing.home_application_status as ss WHERE cc.reference_id=ss.reference_id
        AND ss.appln_status_main NOT IN ('SAN','REJ')
        	""",nativeQuery = true)
List<CibilCrifFetchStatusEntity> getAllCibilCrifFlagResetEntities();


//---------------------------------------- :::: SET CRIF STATUS FLAGS :::: -------------------------------------------


//------------------------------------------ Applicant CRIF Fetched Status -------------------------------------------
    @Query(value = "SELECT count(*) FROM crif_individual.std_crif_summary_model WHERE customer_type='APPLICANT' AND reference_id=:referenceId",nativeQuery = true)
    Integer getApplicantCrifFetchedStatus(@Param("referenceId") String referenceId);

//------------------------------------------ Earning Co-Applicant CRIF Fetched Status --------------------------------
    @Query(value = "SELECT count(*) FROM crif_individual.std_crif_summary_model WHERE customer_type in ('COAPPLICANT1','COAPPLICANT2','COAPPLICANT3')  AND reference_id=:referenceId",nativeQuery = true)
    Integer getEarningCoAppCrifFetchedStatus(@Param("referenceId") String referenceId);

//------------------------------------------ Non Earning Co-Applicant CRIF Fetched Status --------------------------------
    @Query(value = "SELECT count(*) FROM crif_individual.std_crif_summary_model WHERE customer_type='COAPPLICANT' AND reference_id=:referenceId",nativeQuery = true)
    Integer getNonEarningCoAppCrifFetchedStatus(@Param("referenceId") String referenceId);

//------------------------------------------ Guarantors CRIF Fetched Status --------------------------------
    @Query(value = "SELECT count(*) FROM crif_individual.std_crif_summary_model WHERE customer_type='GUARANTOR' AND reference_id=:referenceId",nativeQuery = true)
    Integer getGuarantorsCrifFetchedStatus(@Param("referenceId") String referenceId);



//############################################ FROM GST PROJECT #######################################################//

    //********************************** corporate guarantor CIBIL fetched count********************************************//
    @Query(nativeQuery = true,
            value = "SELECT COUNT(*) FROM cibil_commercial.cibil_commercial_screen_basic_details " +
                    " WHERE old_record IS NULL and corporate_type='GUARANTOR' and reference_id = :referenceId")
    Integer calculateCorpGuarCibilCount(@Param("referenceId") String referenceId);


    //********************************** corporate guarantor CIBIL fetched count********************************************//
    @Query(nativeQuery = true,
            value = "SELECT COUNT(*) FROM cibil_personal.screen_personal_cibil_basic_summary_details " +
                    " WHERE old_record IS NULL and reference_id = :referenceId")
    Integer calculateIndividualGuarCibilCount(@Param("referenceId") String referenceId);

    //*********************************** Individual guarantor CRIF fetched count *******************************************//
    @Query(nativeQuery = true,
            value = "SELECT COUNT(*) FROM los_gst.individual_guarantor_details WHERE ind_guarantor_status IS NULL AND" +
                    " crif_fetched='yes' AND  reference_id_gst = :referenceId")
    Integer calculateIndvGuarCrifCount(@Param("referenceId") String referenceId);

    //*********************************** Corporate guarantor CRIF fetched count *******************************************//
//@Query(nativeQuery = true,
//        value = "SELECT COUNT(*) FROM los_gst.commercial_crif_details WHERE " +
//                " comm_crif_fetched_for='GUARANTOR' AND reference_id = :referenceId")
    @Query(nativeQuery = true,
            value = "SELECT COUNT(*) FROM los_gst.corp_guarantor_details WHERE corp_guar_status IS NULL AND " +
                    " crif_comm_fetched='yes' AND reference_id = :referenceId")
    Integer calculateCorpGuarCrifCount(@Param("referenceId") String referenceId);


    //***************************************** FIRM CRIF FETCHED OR NOT******************************************************************************//
    @Query(nativeQuery = true,
            value = "SELECT COUNT(*) from los_gst.firm_details as f WHERE crif_comm_fetched='yes' AND " +
                    " firm_reference_id = :referenceId")
    Integer firmCrifFetchedOrNot(@Param("referenceId") String referenceId);

    //***************************************** FIRM CRIF FETCHED OR NOT******************************************************************************//
    @Query(nativeQuery = true,
            value = "SELECT COUNT(*) FROM cibil_commercial.cibil_commercial_screen_basic_details " +
                    " WHERE old_record IS NULL and corporate_type='BORROWER' and reference_id = :referenceId")
    Integer firmCibilFetchedOrNot(@Param("referenceId") String referenceId);


}
