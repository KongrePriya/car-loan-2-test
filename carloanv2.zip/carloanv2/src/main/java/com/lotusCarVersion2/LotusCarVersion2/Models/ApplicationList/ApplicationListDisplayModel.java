package com.lotusCarVersion2.LotusCarVersion2.Models.ApplicationList;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Data
public class ApplicationListDisplayModel {
    private String referenceId;
    private String branchCode;
    private String branchName;
    private String regionName;
    private String applicantName;
    private LocalDateTime applicationCreationDate;
    private BigDecimal appliedLoanAmt;
    private LocalDateTime  statusDate;
    private String  statusBy;
    private String loanType;
    private BigDecimal topUpAppliedLoanAmt;
}
