package com.lotusCarVersion2.LotusCarVersion2.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeviationDetailsDto {

    private String referenceId;
    private String branchCode;
    private String loanType;
    private String applicantName;
    private String applicantPan;

    //AGE DEVIATION
    private String applicantAgeDeviation;
    private String coapplicantOneAgeDeviation;
    private String coapplicantTwoAgeDeviation;

    //CIBIL-ALL
    private String cibilScoreDeviation;
    private String cibilOverdueDeviation;
    private String cibilWrittenOffDeviation;
    private String cibilSettledDeviation;
    private String CibilDeviation; //after comparing above 4 fields

    //LOAN METRICS
    private String roiDeviation;
    private String processingChargeDeviation;
    private String documentationChargeDeviation;
    private String maxLoanTenureAllowedDeviation;
    private String repaymentAgeDeviation;

    //WORK EXPERIENCE
    private String applicantWorkExperienceDeviation;
    private String coapplicantOneWorkExperienceDeviation;
    private String coapplicantTwoWorkExperienceDeviation;

    //ITR-FORM16 DEVIATION
    private String applicantItrForm16Deviation;
    private String coapplicantOneItrForm16Deviation;
    private String coapplicantTwoItrForm16Deviation;


    //INCOME DEVIATION
    private String incomeDeviationCombined;

    //LOAN ELIGIBILITY DEVIATION
    private String loanEligibleDeductionDeviation;
    private String loanEligibleMarginDeviation;

    private String ageServiceItrDeviationCombined;//COMBINED AGE & SERVICE DEVIATION FOR SEPARATE TABLE SHOW-HIDE

    private String relationWithApplicantDeviation;

    private String anyDeviationPresent;  //NORMAL DEVIATION ONLY


}
