package com.lotusCarVersion2.LotusCarVersion2.Controller.CommercialCibil;

import com.lotusCarVersion2.LotusCarVersion2.Config.CibilConfig;
import com.lotusCarVersion2.LotusCarVersion2.DTO.FirmDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@RestController
@AllArgsConstructor
@CrossOrigin
@RequestMapping("/api/v1/com-cibil/firm")
public class FirmCommercialCIBILController {

    @Autowired
    private RestTemplate restTemplate;
    private final CibilCrifFetchStatusService cibilCrifFetchStatusService;


//************************************************************************************************************************//
//*********************************** TO FETCH CIBIL OF SINGLE Corporate Guarantors ************************************//
// api to fetch for CIBIL FOR FIRM is only used to fetch directly but not used while
// fetching cibil while saving data: as while saving I have called a service method:-FetchCommercialCibilService
    @PostMapping("/fetch")
    public ResponseEntity<String> fetchCommercialCibilFirm(@Valid @RequestBody FirmDetailsDto firmDto) {

        cibilCrifFetchStatusService.corpGuarCibilFetchedCountStatus(firmDto.getFirmReferenceId());

        String commercialCibilFetchUrl = CibilConfig.CommercialCibilIP +"/commercial-cibil/fetch/firm";
        System.out.println("COMMERCIAL CIBIL FOR FIRM, inside fetchCommercialCibilFirm LOS-GST, URL:"+commercialCibilFetchUrl);


        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));


        System.out.println(" COMMERCIAL CIBIL FIRM, header: "+headers);
        HttpEntity<FirmDetailsDto> requestEntity = new HttpEntity<>(firmDto, headers);

        System.out.println("COMMERCIAL CIBIL FIRM -REQUEST ENTITY:"+ requestEntity.getBody());

        ResponseEntity<String> responseEntity = restTemplate.exchange(
                commercialCibilFetchUrl,
                HttpMethod.POST,
                requestEntity,
                String.class);
        System.out.println("COMMERCIAL CIBIL FIRM- RESPONSE STATUS CODE: " + responseEntity.getStatusCode());
        System.out.println("COMMERCIAL CIBIL FIRM- RESPONSE FROM CIBIL-COMMERCIAL PROJECT:"+responseEntity.getBody());
        return responseEntity;
    }

//*****************************************************************************************************************//
    //SCREEN 1: BASIC CIBIL DETAILS OF FIRM
    @GetMapping("/basic/{firmReferenceId}")
    public ResponseEntity<Object> FirmScreenBasicDetails(@PathVariable String firmReferenceId) {
        String basicDetailsUrl = CibilConfig.CommercialCibilIP + "/commercial-cibil/firm/basic-details/" + firmReferenceId;

        try {
            // If the response is a JSON object, use Object.class
            Object result = restTemplate.getForObject(basicDetailsUrl, Object.class);
            System.out.println("IN LOS-GST: FIRM CIBIL BASIC DETAILS: " + result);
            return ResponseEntity.ok(result);

        } catch (RestClientException e) {
            System.err.println("IN LOS-GST:FIRM CIBIL: ERROR FETCHING BASIC DETAILS: "+e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

//*****************************************************************************************************************//
    //SCREEN 2: HISTORY DETAILS OF FIRM
    @GetMapping("/history/{firmReferenceId}")
    public ResponseEntity<List<Object>> FirmScreenHistoryDetails(@PathVariable String firmReferenceId){

        String historyDetailsUrl = CibilConfig.CommercialCibilIP +"/commercial-cibil/firm/history-details/"+ firmReferenceId;
     try{
        Object[] historyResult =restTemplate.getForObject(historyDetailsUrl, Object[].class);

//        if(historyResult !=null){
//         return Arrays.asList(historyResult);
//        }else{
//            return (List<Object>) ResponseEntity.status(HttpStatus.NO_CONTENT);
//        }

         if (historyResult == null || historyResult.length == 0) {

             return ResponseEntity.status(HttpStatus.NO_CONTENT).body(Collections.emptyList());
         } else {
             System.out.println("IN LOS-GST: FIRM CIBIL HISTORY DETAILS, LENGTH : " + historyResult.length);

             return ResponseEntity.ok(Arrays.asList(historyResult));
         }
     } catch (RestClientException e) {
         System.err.println("IN LOS-GST:FIRM CIBIL ERROR FETCHING HISTORY DETAILS: "+e.getMessage());
         e.printStackTrace();
         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonList(e.getMessage()));
     }
    }
//*****************************************************************************************************************//
    //SCREEN 2: SUMMARY DETAILS OF FIRM
    @GetMapping("/summary/{firmReferenceId}")
    public Object FirmScreenSummaryDetails(@PathVariable String firmReferenceId){

        String summaryDetailsUrl = CibilConfig.CommercialCibilIP +"/commercial-cibil/firm/summary-details/"+ firmReferenceId;
        try {
        Object summaryResult =restTemplate.getForObject(summaryDetailsUrl, Object.class);
        System.out.println("LOS-GST: FIRM CIBIL SUMMARY DETAILS: "+summaryResult);
        return summaryResult;
        } catch (RestClientException e) {
            e.printStackTrace();
            System.err.println("IN LOS-GST:FIRM CIBIL: ERROR FETCHING SUMMARY DETAILS: "+e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }

    }
//*****************************************************************************************************************//



}
