package com.lotusCarVersion2.LotusCarVersion2.Services.DecisionStatus.ActionButtons;

import com.lotusCarVersion2.LotusCarVersion2.DTO.DecisionStatusUserInfoDTO;
import com.lotusCarVersion2.LotusCarVersion2.Models.DecisionStatus.DecisionStatusModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DecisionStatus.DecisionStatusRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo.RefIdGenerationRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;


@Service
public class ActionButtonsServiceImpl implements ActionButtonsService {

    @Autowired
    private DecisionStatusRepo decisionStatusRepo;

    @Autowired
    private RefIdGenerationRepo refIdGenerationRepo;


    @Override
    @Transactional
    public String buttonActionReturn(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO) {

        System.out.println("Button Action Return Called");
//            --------------------------- Set Return Status in Reference Number Verification -----------------------
        ReferenceIdGenerationEntity refIdEntity = new ReferenceIdGenerationEntity();
        try {
            refIdEntity = refIdGenerationRepo.findByReferenceId(decisionStatusUserInfoDTO.getReferenceId());

            refIdEntity.setApplicationStatus("RET");
            refIdGenerationRepo.save(refIdEntity);
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred While Setting RETURN Status in Reference Id Verification" + decisionStatusUserInfoDTO.getReferenceId() + e);
        }

//       --------------------------- Set Return Status in Decision Status Table -----------------------

        try {

            DecisionStatusModel decisionStatusModel = new DecisionStatusModel();
            decisionStatusModel = decisionStatusRepo.findByReferenceId(decisionStatusUserInfoDTO.getReferenceId());

            decisionStatusModel.setApplnMainActionDate(LocalDateTime.now());
            decisionStatusModel.setApplnMainActionBy(decisionStatusUserInfoDTO.getUserType());
            decisionStatusModel.setFinalSubmitByBranch(null);
            decisionStatusModel.setIsActionTakenByBM(null);


            if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("BR")) {
                System.out.println("In BR");
                if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("BM")) {
                    System.out.println("In Bm TAG");
                    decisionStatusModel.setReturnBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setReturnDate(LocalDateTime.now());
                    decisionStatusModel.setReturnUserId(decisionStatusUserInfoDTO.getUserId());

                    decisionStatusModel.setIsActionTakenByBM(null);


                    //Set Flag To Return (RET) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("RET");
                    decisionStatusModel.setApplnStatusBranchOfficer("RET");
                    decisionStatusModel.setApplnStatusBranchManager("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Branch Officer Action Pending");

                }
            } else if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("RO")) {
                //Check Which User returning this application
                System.out.println("In RO TAG");
                if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CPC_Officer")) {
                    System.out.println("In CPC Off TAG");

                    decisionStatusModel.setReturnBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setReturnDate(LocalDateTime.now());


                    decisionStatusModel.setIsActionTakenByCPCOF("yes");

                    decisionStatusModel.setIsActionTakenByBM(null);


                    decisionStatusModel.setReturnUserId(decisionStatusUserInfoDTO.getUserId());
                    //Set Flag To Return (RET) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("RET");
                    decisionStatusModel.setApplnStatusBranchOfficer("RET");
                    decisionStatusModel.setApplnStatusBranchManager("RET");

                    //Set Flag To return For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Application Returned, Pending At Branch.");


                } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CPC_HEAD")) {
                    System.out.println("In CPC HEad TAG");

                    decisionStatusModel.setReturnBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setReturnDate(LocalDateTime.now());


                    decisionStatusModel.setIsActionTakenByBM(null);
                    decisionStatusModel.setIsActionTakenByCPCOF("yes");
                    decisionStatusModel.setIsActionTakenByCPCHEAD("yes");


                    decisionStatusModel.setReturnUserId(decisionStatusUserInfoDTO.getUserId());
                    //Set Flag To Return (RET) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("RET");
                    decisionStatusModel.setApplnStatusBranchOfficer("RET");
                    decisionStatusModel.setApplnStatusBranchManager("RET");

                    //Set Flag To return For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("RET");

                    //Set Flag To return For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Application Returned, Pending At Branch");


                } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("RM")) {
                    System.out.println("In RM TAG");

                    decisionStatusModel.setReturnBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setReturnDate(LocalDateTime.now());


                    decisionStatusModel.setIsActionTakenByBM(null);
                    decisionStatusModel.setIsActionTakenByCPCOF("yes");
                    decisionStatusModel.setIsActionTakenByCPCHEAD("yes");
                    decisionStatusModel.setIsActionTakenByRM("yes");


                    decisionStatusModel.setReturnUserId(decisionStatusUserInfoDTO.getUserId());
                    //Set Flag To Return (RET) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("RET");
                    decisionStatusModel.setApplnStatusBranchOfficer("RET");
                    decisionStatusModel.setApplnStatusBranchManager("RET");

                    //Set Flag To return For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("RET");

                    //Set Flag To return For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("RET");

                    //Set Flag To return For RM
                    decisionStatusModel.setApplnStatusRegionalManager("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Application Returned, Pending At Branch");


                }


            } else if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("HO")) {
                System.out.println("In HO TAG");

                if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("HO_Credit_Officer")) {
                    System.out.println("In Ho OFFICER TAG");

                    decisionStatusModel.setReturnBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setReturnDate(LocalDateTime.now());


                    decisionStatusModel.setIsActionTakenByBM(null);
                    decisionStatusModel.setIsActionTakenByCPCOF("yes");
                    decisionStatusModel.setIsActionTakenByCPCHEAD("yes");
                    decisionStatusModel.setIsActionTakenByRM("yes");
                    decisionStatusModel.setIsActionTakenByHOOF("yes");


                    decisionStatusModel.setReturnUserId(decisionStatusUserInfoDTO.getUserId());
                    //Set Flag To Return (RET) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("RET");
                    decisionStatusModel.setApplnStatusBranchOfficer("RET");
                    decisionStatusModel.setApplnStatusBranchManager("RET");

                    //Set Flag To return For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("RET");

                    //Set Flag To return For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("RET");

                    //Set Flag To return For RM
                    decisionStatusModel.setApplnStatusRegionalManager("RET");
                    //Set Flag To return For HO OFFICER
                    decisionStatusModel.setApplnStatusHoOfficer("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Application Returned, Pending At Branch");


                }
                else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CM") && decisionStatusUserInfoDTO.getUserRegion().equalsIgnoreCase("CREDIT")) {

                    decisionStatusModel.setIsActionTakenByBM(null);
                    decisionStatusModel.setIsActionTakenByCPCOF("yes");
                    decisionStatusModel.setIsActionTakenByCPCHEAD("yes");
                    decisionStatusModel.setIsActionTakenByRM("yes");
                    decisionStatusModel.setIsActionTakenByHOOF("yes");
                    decisionStatusModel.setIsActionTakenByCM("yes");

                    decisionStatusModel.setReturnBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setReturnUserId(decisionStatusUserInfoDTO.getUserId());

                    System.out.println("In CM Credit TAG");

                    decisionStatusModel.setReturnDate(LocalDateTime.now());


                    //Set Flag To Return (RET) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("RET");
                    decisionStatusModel.setApplnStatusBranchOfficer("RET");
                    decisionStatusModel.setApplnStatusBranchManager("RET");

                    //Set Flag To return For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("RET");

                    //Set Flag To return For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("RET");

                    //Set Flag To return For RM
                    decisionStatusModel.setApplnStatusRegionalManager("RET");

                    //Set Flag To return For HO OFFICER
                    decisionStatusModel.setApplnStatusHoOfficer("RET");

                    //Set Flag To return For CM/GM/Chairman
                    decisionStatusModel.setApplnStatusChiefManager("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Application Returned, Pending At Branch");
                }
                //For GM
                else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("General Manager")) {
                    decisionStatusModel.setIsActionTakenByBM(null);
                    decisionStatusModel.setIsActionTakenByCPCOF("yes");
                    decisionStatusModel.setIsActionTakenByCPCHEAD("yes");
                    decisionStatusModel.setIsActionTakenByRM("yes");
                    decisionStatusModel.setIsActionTakenByHOOF("yes");
                    decisionStatusModel.setIsActionTakenByCM("yes");
                    decisionStatusModel.setReturnBy("General Manager");
                    decisionStatusModel.setReturnUserId("");
                    decisionStatusModel.setApplnStatusGeneralManager("RET");

                    //Set Flag To Return (RET) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("RET");
                    decisionStatusModel.setApplnStatusBranchOfficer("RET");
                    decisionStatusModel.setApplnStatusBranchManager("RET");

                    //Set Flag To return For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("RET");

                    //Set Flag To return For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("RET");

                    //Set Flag To return For RM
                    decisionStatusModel.setApplnStatusRegionalManager("RET");

                    //Set Flag To return For HO OFFICER
                    decisionStatusModel.setApplnStatusHoOfficer("RET");

                    //Set Flag To return For CM/GM/Chairman
                    decisionStatusModel.setApplnStatusChiefManager("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Application Returned, Pending At Branch");
                }
                //For Chairman
                else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("Chairman")) {
                    decisionStatusModel.setIsActionTakenByBM(null);
                    decisionStatusModel.setIsActionTakenByCPCOF("yes");
                    decisionStatusModel.setIsActionTakenByCPCHEAD("yes");
                    decisionStatusModel.setIsActionTakenByRM("yes");
                    decisionStatusModel.setIsActionTakenByHOOF("yes");
                    decisionStatusModel.setIsActionTakenByCM("yes");
                    decisionStatusModel.setReturnBy("Chairman");
                    decisionStatusModel.setReturnUserId("");
                    decisionStatusModel.setApplnStatusChairman("RET");
                    decisionStatusModel.setApplnStatusGeneralManager("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Application Returned, Pending At Branch");

                    //Set Flag To Return (RET) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("RET");
                    decisionStatusModel.setApplnStatusBranchOfficer("RET");
                    decisionStatusModel.setApplnStatusBranchManager("RET");

                    //Set Flag To return For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("RET");

                    //Set Flag To return For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("RET");

                    //Set Flag To return For RM
                    decisionStatusModel.setApplnStatusRegionalManager("RET");

                    //Set Flag To return For HO OFFICER
                    decisionStatusModel.setApplnStatusHoOfficer("RET");

                    //Set Flag To return For CM/GM/Chairman
                    decisionStatusModel.setApplnStatusChiefManager("RET");
                    decisionStatusModel.setApplnPendingAtWhichLevel("Application Returned, Pending At Branch");

                }else{
                    System.out.println("Invalid User Type For HO " + decisionStatusUserInfoDTO.getUserType());
                }
            } else {
                throw new RuntimeException("Invalid User Location");
            }


            try {
                decisionStatusRepo.save(decisionStatusModel);
            } catch (Exception e) {
                throw new RuntimeException("Error Occurred While Saving Decision Status RETURN " + e);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred While Setting Return Status " + e);
        }
        return "Application Return Successfully";

    }

    @Override
    @Transactional
    public String buttonActionReject(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO) {


//        ------------------- Setting Reject Flag in Refrence Id verification --------------------
        ReferenceIdGenerationEntity refIdEntity = new ReferenceIdGenerationEntity();
        try {
            refIdEntity = refIdGenerationRepo.findByReferenceId(decisionStatusUserInfoDTO.getReferenceId());

            refIdEntity.setApplicationStatus("REJ");
            refIdGenerationRepo.save(refIdEntity);

        } catch (Exception e) {
            throw new RuntimeException("Reference Id Not Found While Setting Reject Flag in ReferenceId Verification " + decisionStatusUserInfoDTO.getReferenceId() + e);
        }

        DecisionStatusModel decisionStatusModel;


        decisionStatusModel = decisionStatusRepo.findByReferenceId(decisionStatusUserInfoDTO.getReferenceId());
        decisionStatusModel.setApplnMainActionDate(LocalDateTime.now());
        decisionStatusModel.setApplnMainActionBy(decisionStatusUserInfoDTO.getUserType());
        decisionStatusModel.setApplnPendingAtWhichLevel("Application Rejected.");


        if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("BR")) {
            if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("OF")) {
                decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                decisionStatusModel.setRejectDate(LocalDateTime.now());

                decisionStatusModel.setRejectUserId(decisionStatusUserInfoDTO.getUserId());
                //-------------Set Flag To Return (RET) For OF------------------//
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
//                decisionStatusModel.setApplnStatusBranchManager("REJ");
                if(decisionStatusModel.getIsActionTakenByCM()!=null){
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                    decisionStatusModel.setApplnStatusCpcHead("REJ");
                    decisionStatusModel.setApplnStatusRegionalManager("REJ");
                    decisionStatusModel.setApplnStatusHoOfficer("REJ");
                    decisionStatusModel.setApplnStatusChiefManager("REJ");
                    decisionStatusModel.setApplnStatusGeneralManager("REJ");
                    decisionStatusModel.setApplnStatusChairman("REJ");
                } else if (decisionStatusModel.getIsActionTakenByHOOF()!=null) {
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                    decisionStatusModel.setApplnStatusCpcHead("REJ");
                    decisionStatusModel.setApplnStatusRegionalManager("REJ");
                    decisionStatusModel.setApplnStatusHoOfficer("REJ");
                }else if(decisionStatusModel.getIsActionTakenByRM()!=null){
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                    decisionStatusModel.setApplnStatusCpcHead("REJ");
                    decisionStatusModel.setApplnStatusRegionalManager("REJ");
                }else if (decisionStatusModel.getIsActionTakenByCPCHEAD()!=null) {
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                    decisionStatusModel.setApplnStatusCpcHead("REJ");
                } else if (decisionStatusModel.getIsActionTakenByCPCOF()!=null) {
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                } else {
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                }

            }
            if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("BM")) {
                decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                decisionStatusModel.setRejectDate(LocalDateTime.now());

                decisionStatusModel.setRejectUserId(decisionStatusUserInfoDTO.getUserId());
                //Set Flag To Return (RET) For OF and BM or Branch Only
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
                decisionStatusModel.setApplnStatusBranchManager("REJ");
                if(decisionStatusModel.getIsActionTakenByCM()!=null){
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                    decisionStatusModel.setApplnStatusCpcHead("REJ");
                    decisionStatusModel.setApplnStatusRegionalManager("REJ");
                    decisionStatusModel.setApplnStatusHoOfficer("REJ");
                    decisionStatusModel.setApplnStatusChiefManager("REJ");
                    decisionStatusModel.setApplnStatusGeneralManager("REJ");
                    decisionStatusModel.setApplnStatusChairman("REJ");
                } else if (decisionStatusModel.getIsActionTakenByHOOF()!=null) {
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                    decisionStatusModel.setApplnStatusCpcHead("REJ");
                    decisionStatusModel.setApplnStatusRegionalManager("REJ");
                    decisionStatusModel.setApplnStatusHoOfficer("REJ");
                }else if(decisionStatusModel.getIsActionTakenByRM()!=null){
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                    decisionStatusModel.setApplnStatusCpcHead("REJ");
                    decisionStatusModel.setApplnStatusRegionalManager("REJ");
                }else if (decisionStatusModel.getIsActionTakenByCPCHEAD()!=null) {
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                    decisionStatusModel.setApplnStatusCpcHead("REJ");
                } else if (decisionStatusModel.getIsActionTakenByCPCOF()!=null) {
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                    decisionStatusModel.setApplnStatusCpcOfficer("REJ");
                } else {
                    decisionStatusModel.setApplnStatusBranchManager("REJ");
                }
            }

        }
        else if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("RO")) {
            //Check Which User returning this application
            if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CPC_Officer")) {

                decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                decisionStatusModel.setRejectDate(LocalDateTime.now());
                decisionStatusModel.setRejectUserId(decisionStatusUserInfoDTO.getUserId());

                //Set Flag To Return (REJ) For OF and BM or Branch Only
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
                decisionStatusModel.setApplnStatusBranchManager("REJ");

                //Set Flag To reject For CPC Officer
                decisionStatusModel.setApplnStatusCpcOfficer("REJ");


            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CPC_HEAD")) {

                decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                decisionStatusModel.setRejectDate(LocalDateTime.now());
                decisionStatusModel.setRejectUserId(decisionStatusUserInfoDTO.getUserId());

                //Set Flag To Return (REJ) For OF and BM or Branch Only
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
                decisionStatusModel.setApplnStatusBranchManager("REJ");

                //Set Flag To reject For CPC Officer
                decisionStatusModel.setApplnStatusCpcOfficer("REJ");

                //Set Flag To reject For CPC HEAD
                decisionStatusModel.setApplnStatusCpcHead("REJ");

            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("RM")) {

                decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                decisionStatusModel.setRejectDate(LocalDateTime.now());
                decisionStatusModel.setRejectUserId(decisionStatusUserInfoDTO.getUserId());

                //Set Flag To Return (REJ) For OF and BM or Branch Only
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
                decisionStatusModel.setApplnStatusBranchManager("REJ");

                //Set Flag To reject For CPC Officer
                decisionStatusModel.setApplnStatusCpcOfficer("REJ");

                //Set Flag To reject For CPC HEAD
                decisionStatusModel.setApplnStatusCpcHead("REJ");

                //Set Flag To reject For RM
                decisionStatusModel.setApplnStatusRegionalManager("REJ");
            }


        }
        else if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("HO")) {
            if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("HO_Credit_Officer")) {

                decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                decisionStatusModel.setRejectDate(LocalDateTime.now());
                decisionStatusModel.setRejectUserId(decisionStatusUserInfoDTO.getUserId());

                //Set Flag To Return (REJ) For OF and BM or Branch Only
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
                decisionStatusModel.setApplnStatusBranchManager("REJ");

                //Set Flag To reject For CPC Officer
                decisionStatusModel.setApplnStatusCpcOfficer("REJ");

                //Set Flag To reject For CPC HEAD
                decisionStatusModel.setApplnStatusCpcHead("REJ");

                //Set Flag To reject For RM
                decisionStatusModel.setApplnStatusRegionalManager("REJ");
                //Set Flag To reject For HO OFFICER
                decisionStatusModel.setApplnStatusHoOfficer("REJ");


            }
            else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CM") && decisionStatusUserInfoDTO.getUserRegion().equalsIgnoreCase("CREDIT")) {

                    decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setRejectUserId(decisionStatusUserInfoDTO.getUserId());


                decisionStatusModel.setRejectDate(LocalDateTime.now());

                //Set Flag To Return (REJ) For OF and BM or Branch Only
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
                decisionStatusModel.setApplnStatusBranchManager("REJ");

                //Set Flag To reject For CPC Officer
                decisionStatusModel.setApplnStatusCpcOfficer("REJ");

                //Set Flag To reject For CPC HEAD
                decisionStatusModel.setApplnStatusCpcHead("REJ");

                //Set Flag To reject For RM
                decisionStatusModel.setApplnStatusRegionalManager("REJ");

                //Set Flag To reject For HO OFFICER
                decisionStatusModel.setApplnStatusHoOfficer("REJ");

                //Set Flag To reject For CM/GM/Chairman
                decisionStatusModel.setApplnStatusChiefManager("REJ");


            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("General Manager")) {
                decisionStatusModel.setRejectBy("General Manager");
                decisionStatusModel.setRejectUserId("");
                decisionStatusModel.setApplnStatusGeneralManager("REJ");
                //Set Flag To Return (REJ) For OF and BM or Branch Only
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
                decisionStatusModel.setApplnStatusBranchManager("REJ");

                //Set Flag To reject For CPC Officer
                decisionStatusModel.setApplnStatusCpcOfficer("REJ");

                //Set Flag To reject For CPC HEAD
                decisionStatusModel.setApplnStatusCpcHead("REJ");

                //Set Flag To reject For RM
                decisionStatusModel.setApplnStatusRegionalManager("REJ");

                //Set Flag To reject For HO OFFICER
                decisionStatusModel.setApplnStatusHoOfficer("REJ");

                //Set Flag To reject For CM/GM/Chairman
                decisionStatusModel.setApplnStatusChiefManager("REJ");
            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("Chairman")) {
                decisionStatusModel.setRejectBy("Chairman");
                decisionStatusModel.setRejectUserId("");
                decisionStatusModel.setApplnStatusChairman("REJ");
                decisionStatusModel.setApplnStatusGeneralManager("REJ");
                //Set Flag To Return (REJ) For OF and BM or Branch Only
                decisionStatusModel.setApplnStatusMain("REJ");
                decisionStatusModel.setApplnStatusBranchOfficer("REJ");
                decisionStatusModel.setApplnStatusBranchManager("REJ");

                //Set Flag To reject For CPC Officer
                decisionStatusModel.setApplnStatusCpcOfficer("REJ");

                //Set Flag To reject For CPC HEAD
                decisionStatusModel.setApplnStatusCpcHead("REJ");

                //Set Flag To reject For RM
                decisionStatusModel.setApplnStatusRegionalManager("REJ");

                //Set Flag To reject For HO OFFICER
                decisionStatusModel.setApplnStatusHoOfficer("REJ");

                //Set Flag To reject For CM/GM/Chairman
                decisionStatusModel.setApplnStatusChiefManager("REJ");
            }else {
                System.out.println("User Type Does Not Match " + decisionStatusUserInfoDTO.getUserType());
            }
        } else {
            throw new RuntimeException("Invalid User Location");
        }
        decisionStatusModel.setFinalSubmitByBranch("REJ");
        decisionStatusModel.setFinalSubmitByBranch("REJ");
        decisionStatusModel.setIsActionTakenByBM("yes");
        decisionStatusModel.setIsActionTakenByCPCOF("yes");
        decisionStatusModel.setIsActionTakenByCPCHEAD("yes");
        decisionStatusModel.setIsActionTakenByRM("yes");
        decisionStatusModel.setIsActionTakenByHOOF("yes");
        decisionStatusModel.setIsActionTakenByCM("yes");
        try {
            decisionStatusRepo.save(decisionStatusModel);
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred While Reject in Decision Status " + e);
        }
        return "Application Rejected Successfully";
    }

    @Override
    @Transactional
    public String buttonActionRecommend(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO) {

        try {

            DecisionStatusModel decisionStatusModel;
            decisionStatusModel = decisionStatusRepo.findByReferenceId(decisionStatusUserInfoDTO.getReferenceId());

            decisionStatusModel.setApplnMainActionDate(LocalDateTime.now());
            decisionStatusModel.setApplnMainActionBy(decisionStatusUserInfoDTO.getUserType());

            if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("BR")) {
                if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("BM")) {

                    decisionStatusModel.setRecommendBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setRecommendDate(LocalDateTime.now());
                    decisionStatusModel.setRecommendUserId(decisionStatusUserInfoDTO.getUserId());
                    decisionStatusModel.setIsActionTakenByBM("yes");

                    //Set Flag To Recommended (REC) For OF and BM or Branch Only
                    decisionStatusModel.setApplnStatusMain("REC");
                    decisionStatusModel.setApplnStatusBranchOfficer("PEN");
                    decisionStatusModel.setApplnStatusBranchManager("REC");

                    //Set Flag To Pending For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("PEN");


                    decisionStatusModel.setIsActionTakenByCPCOF(null);
                    decisionStatusModel.setApplnPendingAtWhichLevel("CPC-Officer Action Pending");

                }


            } else if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("RO")) {
                //Check Which User returning this application
                if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CPC_Officer")) {

                    decisionStatusModel.setRecommendBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setRecommendDate(LocalDateTime.now());
                    decisionStatusModel.setRecommendUserId(decisionStatusUserInfoDTO.getUserId());

//                decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
//                decisionStatusModel.setRejectDate(LocalDateTime.now());
                    decisionStatusModel.setRecommendUserId(decisionStatusUserInfoDTO.getUserId());
                    decisionStatusModel.setIsActionTakenByCPCOF("yes");

                    //Set Flag To Recommended (REC) For OF and BM or Branch Only

                    decisionStatusModel.setApplnStatusMain("REC");
                    decisionStatusModel.setApplnStatusBranchOfficer("PEN");
                    decisionStatusModel.setApplnStatusBranchManager("REC");

                    //Set Flag To Recommended For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("REC");

                    //Set Flag To Pending For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("PEN");

                    decisionStatusModel.setIsActionTakenByCPCHEAD(null);
                    decisionStatusModel.setApplnPendingAtWhichLevel("CPC-Head Action Pending");


                } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CPC_HEAD")) {

                    // decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                    // decisionStatusModel.setRejectDate(LocalDateTime.now());
                    decisionStatusModel.setRecommendBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setRecommendDate(LocalDateTime.now());

                    decisionStatusModel.setRecommendUserId(decisionStatusUserInfoDTO.getUserId());
                    decisionStatusModel.setIsActionTakenByCPCHEAD("yes");

                    //Set Flag To Recommended (REC) For OF and BM or Branch Only

                    decisionStatusModel.setApplnStatusMain("REC");
                    decisionStatusModel.setApplnStatusBranchOfficer("PEN");
                    decisionStatusModel.setApplnStatusBranchManager("REC");

                    //Set Flag To Recommended For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("REC");

                    //Set Flag To Recommended For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("REC");

                    //Set Flag To Pending For RM
                    decisionStatusModel.setApplnStatusRegionalManager("PEN");


                    decisionStatusModel.setIsActionTakenByRM(null);
                    decisionStatusModel.setApplnPendingAtWhichLevel("RM Action Pending");


                } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("RM")) {

                    //  decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                    // decisionStatusModel.setRejectDate(LocalDateTime.now());
                    decisionStatusModel.setRecommendBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setRecommendDate(LocalDateTime.now());

                    decisionStatusModel.setRecommendUserId(decisionStatusUserInfoDTO.getUserId());
                    decisionStatusModel.setIsActionTakenByRM("yes");


                    //Set Flag To Recommended (REC) For OF and BM or Branch Only

                    decisionStatusModel.setApplnStatusMain("REC");
                    decisionStatusModel.setApplnStatusBranchOfficer("PEN");
                    decisionStatusModel.setApplnStatusBranchManager("REC");

                    //Set Flag To Recommended For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("REC");

                    //Set Flag To Recommended For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("REC");

                    //Set Flag To Recommended For RM
                    decisionStatusModel.setApplnStatusRegionalManager("REC");

                    //Set Flag To Pending For HO OFFICER
                    decisionStatusModel.setApplnStatusHoOfficer("PEN");


                    decisionStatusModel.setIsActionTakenByHOOF(null);
                    decisionStatusModel.setApplnPendingAtWhichLevel("HO Credit Officer Action Pending");


                }


            } else if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("HO")) {
                if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("HO_Credit_Officer")) {

                    // decisionStatusModel.setRejectBy(decisionStatusUserInfoDTO.getUserType());
                    // decisionStatusModel.setRejectDate(LocalDateTime.now());
                    decisionStatusModel.setRecommendBy(decisionStatusUserInfoDTO.getUserType());
                    decisionStatusModel.setRecommendDate(LocalDateTime.now());
                    decisionStatusModel.setRecommendUserId(decisionStatusUserInfoDTO.getUserId());
                    decisionStatusModel.setIsActionTakenByHOOF("yes");


                    //Set Flag To Recommended (REC) For OF and BM or Branch Only

                    decisionStatusModel.setApplnStatusMain("REC");
                    decisionStatusModel.setApplnStatusBranchOfficer("PEN");
                    decisionStatusModel.setApplnStatusBranchManager("REC");

                    //Set Flag To Recommended For CPC Officer
                    decisionStatusModel.setApplnStatusCpcOfficer("REC");

                    //Set Flag To Recommended For CPC HEAD
                    decisionStatusModel.setApplnStatusCpcHead("REC");

                    //Set Flag To Recommended For RM
                    decisionStatusModel.setApplnStatusRegionalManager("REC");

                    //Set Flag To Recommended For HO OFFICER
                    decisionStatusModel.setApplnStatusHoOfficer("REC");

                    //Set Flag To Pending For CM/GM/Chairman
                    decisionStatusModel.setApplnStatusChiefManager("PEN");
                    decisionStatusModel.setIsActionTakenByCM(null);
                    decisionStatusModel.setApplnPendingAtWhichLevel("HOD-Credit Action Pending");
                }
            } else {
                throw new RuntimeException("Invalid User Location");
            }
            try {
                decisionStatusRepo.save(decisionStatusModel);
            } catch (Exception e) {
                throw new RuntimeException("Error Occurred while Saving Decision Status For Recommend " + e);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred in Button Action Recommend" + e);
        }
        return "Recommend Decision Status Updated";
    }

    @Override
    @Transactional
    public String buttonActionSanction(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO) {

        ReferenceIdGenerationEntity refIdEntity = new ReferenceIdGenerationEntity();
        try {
            refIdEntity = refIdGenerationRepo.findByReferenceId(decisionStatusUserInfoDTO.getReferenceId());

            refIdEntity.setApplicationStatus("SAN");
            refIdGenerationRepo.save(refIdEntity);
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred While Setting SAN Status in referenceId Verification" + e);
        }
        DecisionStatusModel applicationRecordForSanction = new DecisionStatusModel();
        applicationRecordForSanction.setIsActionTakenByBM("yes");
        applicationRecordForSanction.setIsActionTakenByCPCOF("yes");
        applicationRecordForSanction.setIsActionTakenByCPCHEAD("yes");
        applicationRecordForSanction.setIsActionTakenByRM("yes");
        applicationRecordForSanction.setIsActionTakenByHOOF("yes");
        applicationRecordForSanction.setIsActionTakenByCM("yes");

        applicationRecordForSanction = decisionStatusRepo.findByReferenceId(decisionStatusUserInfoDTO.getReferenceId());

        applicationRecordForSanction.setApplnMainActionDate(LocalDateTime.now());
        applicationRecordForSanction.setApplnMainActionBy(decisionStatusUserInfoDTO.getUserType());

        if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("BR")) {
            if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("BM")) {
                applicationRecordForSanction.setSanctionBy(decisionStatusUserInfoDTO.getUserType());
                applicationRecordForSanction.setSanctionDate(LocalDateTime.now());

                applicationRecordForSanction.setSanctionUserId(decisionStatusUserInfoDTO.getUserId());
                //Set Flag To Sanction (SAN) For OF and BM or Branch Only
                applicationRecordForSanction.setApplnStatusMain("SAN");
                applicationRecordForSanction.setApplnStatusBranchOfficer("SAN");
                applicationRecordForSanction.setApplnStatusBranchManager("SAN");

            }
        } else if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("RO")) {
            //Check Which User returning this application
            if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CPC_Officer")) {

                applicationRecordForSanction.setSanctionBy(decisionStatusUserInfoDTO.getUserType());
                applicationRecordForSanction.setSanctionDate(LocalDateTime.now());
                applicationRecordForSanction.setSanctionUserId(decisionStatusUserInfoDTO.getUserId());

                //Set Flag To Sanction (SAN) For OF and BM or Branch Only
                applicationRecordForSanction.setApplnStatusMain("SAN");
                applicationRecordForSanction.setApplnStatusBranchOfficer("SAN");
                applicationRecordForSanction.setApplnStatusBranchManager("SAN");

                //Set Flag To Sanction For CPC Officer
                applicationRecordForSanction.setApplnStatusCpcOfficer("SAN");


            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CPC_HEAD")) {

                applicationRecordForSanction.setSanctionBy(decisionStatusUserInfoDTO.getUserType());
                applicationRecordForSanction.setSanctionDate(LocalDateTime.now());
                applicationRecordForSanction.setSanctionUserId(decisionStatusUserInfoDTO.getUserId());

                //Set Flag To Sanction (REJ) For OF and BM or Branch Only
                applicationRecordForSanction.setApplnStatusMain("SAN");
                applicationRecordForSanction.setApplnStatusBranchOfficer("SAN");
                applicationRecordForSanction.setApplnStatusBranchManager("SAN");

                //Set Flag To Sanction For CPC Officer
                applicationRecordForSanction.setApplnStatusCpcOfficer("SAN");

                //Set Flag To Sanction For CPC HEAD
                applicationRecordForSanction.setApplnStatusCpcHead("SAN");


            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("RM")) {

                applicationRecordForSanction.setSanctionBy(decisionStatusUserInfoDTO.getUserType());
                applicationRecordForSanction.setSanctionDate(LocalDateTime.now());
                applicationRecordForSanction.setSanctionUserId(decisionStatusUserInfoDTO.getUserId());

                //Set Flag To Sanction (REJ) For OF and BM or Branch Only
                applicationRecordForSanction.setApplnStatusMain("SAN");
                applicationRecordForSanction.setApplnStatusBranchOfficer("SAN");
                applicationRecordForSanction.setApplnStatusBranchManager("SAN");

                //Set Flag To Sanction For CPC Officer
                applicationRecordForSanction.setApplnStatusCpcOfficer("SAN");

                //Set Flag To Sanction For CPC HEAD
                applicationRecordForSanction.setApplnStatusCpcHead("SAN");

                //Set Flag To Sanction For RM
                applicationRecordForSanction.setApplnStatusRegionalManager("SAN");
                decisionStatusRepo.save(applicationRecordForSanction);
            }


        } else if (decisionStatusUserInfoDTO.getUserLocation().equalsIgnoreCase("HO")) {
            if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("HO_Credit_Officer")) {

                applicationRecordForSanction.setSanctionBy(decisionStatusUserInfoDTO.getUserType());
                applicationRecordForSanction.setSanctionDate(LocalDateTime.now());
                applicationRecordForSanction.setSanctionUserId(decisionStatusUserInfoDTO.getUserId());

                //Set Flag To Sanction (SAN) For OF and BM or Branch Only
                applicationRecordForSanction.setApplnStatusMain("SAN");
                applicationRecordForSanction.setApplnStatusBranchOfficer("SAN");
                applicationRecordForSanction.setApplnStatusBranchManager("SAN");

                //Set Flag To Sanction For CPC Officer
                applicationRecordForSanction.setApplnStatusCpcOfficer("SAN");

                //Set Flag To Sanction For CPC HEAD
                applicationRecordForSanction.setApplnStatusCpcHead("SAN");

                //Set Flag To Sanction For RM
                applicationRecordForSanction.setApplnStatusRegionalManager("SAN");
                //Set Flag To Sanction For HO OFFICER
                applicationRecordForSanction.setApplnStatusHoOfficer("SAN");

                decisionStatusRepo.save(applicationRecordForSanction);

            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("CM") && decisionStatusUserInfoDTO.getUserRegion().equalsIgnoreCase("CREDIT")) {


                    applicationRecordForSanction.setSanctionBy(decisionStatusUserInfoDTO.getUserType());
                    applicationRecordForSanction.setSanctionUserId(decisionStatusUserInfoDTO.getUserId());


                applicationRecordForSanction.setSanctionDate(LocalDateTime.now());

                //Set Flag To Sanction (REJ) For OF and BM or Branch Only
                applicationRecordForSanction.setApplnStatusMain("SAN");
                applicationRecordForSanction.setApplnStatusBranchOfficer("SAN");
                applicationRecordForSanction.setApplnStatusBranchManager("SAN");

                //Set Flag To Sanction For CPC Officer
                applicationRecordForSanction.setApplnStatusCpcOfficer("SAN");

                //Set Flag To Sanction For CPC HEAD
                applicationRecordForSanction.setApplnStatusCpcHead("SAN");

                //Set Flag To Sanction For RM
                applicationRecordForSanction.setApplnStatusRegionalManager("SAN");

                //Set Flag To Sanction For HO OFFICER
                applicationRecordForSanction.setApplnStatusHoOfficer("SAN");

                //Set Flag To Sanction For CM/GM/Chairman
                applicationRecordForSanction.setApplnStatusChiefManager("SAN");


            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("General Manager")) {
                applicationRecordForSanction.setSanctionBy("General Manager");
                applicationRecordForSanction.setSanctionUserId("");
                applicationRecordForSanction.setApplnStatusGeneralManager("SAN");
                applicationRecordForSanction.setSanctionDate(LocalDateTime.now());
                //Set Flag To Sanction (REJ) For OF and BM or Branch Only
                applicationRecordForSanction.setApplnStatusMain("SAN");
                applicationRecordForSanction.setApplnStatusBranchOfficer("SAN");
                applicationRecordForSanction.setApplnStatusBranchManager("SAN");

                //Set Flag To Sanction For CPC Officer
                applicationRecordForSanction.setApplnStatusCpcOfficer("SAN");

                //Set Flag To Sanction For CPC HEAD
                applicationRecordForSanction.setApplnStatusCpcHead("SAN");

                //Set Flag To Sanction For RM
                applicationRecordForSanction.setApplnStatusRegionalManager("SAN");

                //Set Flag To Sanction For HO OFFICER
                applicationRecordForSanction.setApplnStatusHoOfficer("SAN");

                //Set Flag To Sanction For CM/GM/Chairman
                applicationRecordForSanction.setApplnStatusChiefManager("SAN");
            } else if (decisionStatusUserInfoDTO.getUserType().equalsIgnoreCase("Chairman")) {
                applicationRecordForSanction.setSanctionBy("Chairman");
                applicationRecordForSanction.setSanctionUserId("");
                applicationRecordForSanction.setApplnStatusChairman("SAN");
                applicationRecordForSanction.setApplnStatusGeneralManager("SAN");
                applicationRecordForSanction.setSanctionDate(LocalDateTime.now());
                //Set Flag To Sanction (REJ) For OF and BM or Branch Only
                applicationRecordForSanction.setApplnStatusMain("SAN");
                applicationRecordForSanction.setApplnStatusBranchOfficer("SAN");
                applicationRecordForSanction.setApplnStatusBranchManager("SAN");

                //Set Flag To Sanction For CPC Officer
                applicationRecordForSanction.setApplnStatusCpcOfficer("SAN");

                //Set Flag To Sanction For CPC HEAD
                applicationRecordForSanction.setApplnStatusCpcHead("SAN");

                //Set Flag To Sanction For RM
                applicationRecordForSanction.setApplnStatusRegionalManager("SAN");

                //Set Flag To Sanction For HO OFFICER
                applicationRecordForSanction.setApplnStatusHoOfficer("SAN");

                //Set Flag To Sanction For CM/GM/Chairman
                applicationRecordForSanction.setApplnStatusChiefManager("SAN");
            }else {
                System.err.println("User Type Does Not Match For Sanction Button " + decisionStatusUserInfoDTO.getUserType());
            }
        } else {
            throw new RuntimeException("Invalid User Location");
        }

        try {
            decisionStatusRepo.save(applicationRecordForSanction);
        } catch (Exception e) {
            throw new RuntimeException("Error Occurred while Saving Decision Status For Recommend " + e);
        }
        return "Return Decision Status Updated";
    }




}
