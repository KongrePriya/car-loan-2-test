package com.lotusCarVersion2.LotusCarVersion2.DTO;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CorporateGuarantorDto {
    private Long id;
    private String gstinStatus;
    private String constitutionOfBusiness;
    private String dateOfRegistration;
    private String principalPlaceOfBusinessAddress;
    private String natureOfBusiness;
    private String stateJurisdictionCode;

    @NotNull(message = "GSTIN cannot be blank")
    private String gstin;
    private String dateOfCancellation;
    private String centreJurisdictionCode;
    @NotNull(message = "Trade Name cannot be blank")
    private String tradeName;
    private String lastUpdatedDate;
    private String centreJurisdiction;
    private String taxpayerType;

    @NotNull(message = "Legal Name of Business cannot be blank")
    @Size(max = 125, message = "Legal Name of Business length must be less than or equal to 125 characters")
    private String legalNameOfBusiness;

    @NotNull(message = "PAN cannot be blank")
    @Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]", message = "Invalid PAN number")
    private String pan;

    private String additionalPlaceOfBusinessAddress;
    private String stateJurisdiction;

    // common fields
    @NotNull(message = "Reference ID cannot be blank")
    private String referenceId;
    @NotNull(message = "User ID cannot be blank")
    private String userId;
    @NotNull(message = "Branch Code cannot be blank")
    private String branchCode;
    private String branchName;
    @NotNull(message = "RO Name cannot be blank")
    private String roName;

    // corporate Guarantor Fields
    private String corpGuarSalutation;
    @NotNull(message = "Guarantor Name cannot be blank")
    private String corpGuarName;
    @NotNull(message = "Customer Type cannot be blank")
    @Size(max = 42, message = "Customer Type length must be less than or equal to 42 characters")
    private String corpGuarCustomerType;

    @NotNull(message = "Mobile Number cannot be blank")
    @Size(max = 10, message = "Mobile Number length must be less than or equal to 10 characters")
    private String corpGuarMobile;
    private String corpGuarBusinessSector;

    @Size(max = 55, message = "Email length must be less than or equal to 55 characters")
    @Email(message = "Email should be valid")
    private String corpGuarEmail;
    private String corpGuarNatureOfBusiness;

    @Size(max = 200, message = "Address length must be less than or equal to 200 characters")
    @NotNull(message = "Address cannot be blank")
    private String corpGuarRegisterAddress;
    private String corpGuarRegisterVillage;
    private String corpGuarRegisterBlock;

    @Size(max = 6, message = "Pincode length must be less than or equal to 6 characters")
    @NotNull(message = "Pincode cannot be blank")
    private String corpGuarRegisterPin;

    @Size(max = 100, message = "District length must be less than or equal to 100 characters")
    @NotNull(message = "District cannot be blank")
    private String corpGuarRegisterDistrict;

    @Size(max = 100, message = "State length must be less than or equal to 100 characters")
    @NotNull(message = "State cannot be blank")
    private String corpGuarRegisterState;

    @Size(max = 21, message = "CIN length must be less than or equal to 21 characters")
    private String corpGuarCin;
    private String corpGuarUdyam;
    private String corpGuarTan;
    private String corpGuarLei;

    private LocalDate corpGuarDateOfCertificate;
    private String corpGuarUdin;

    private String corpGuarNetworth;
    private String corpGuarSourceOfNetWorth;
    private LocalDate corpGuarNetworthAsondate;
    private String corpGuarNameOfCa;
    private String corpGuarStatus;

    @NotNull(message = "Establishment/Incorporation Date cannot be blank")
    @PastOrPresent(message = "Establishment/Incorporation Date cannot have a future date.")
    private LocalDate corpGuarEstablishmentDate;
    private String crifCommFetched;
    private String commCrifFetchedFor;
    private String corporateType="GUARANTOR";

}
