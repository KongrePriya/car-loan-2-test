package com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "reference_id_details")
@AllArgsConstructor
@NoArgsConstructor
@Data

public class ReferenceIdGenerationEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String panNumber;
    private String borrowerType;
    private String shortBorrowerType;
    private String referenceId;
    private String loanType;
    private String shortLoanType;
    private String applicationStatus="0";
    private String refIdFlag="N";
    private LocalDateTime applicationCreatedDate;
    private String userId;
    private String u_type;
    private String brcode;
    private String roname;
    private String u_status;
    private String u_loc;
    private String u_name;
    private String scale;
    private String sourceType;
    private String dsaNumber;
    private String brname;
    private String custType;

}
