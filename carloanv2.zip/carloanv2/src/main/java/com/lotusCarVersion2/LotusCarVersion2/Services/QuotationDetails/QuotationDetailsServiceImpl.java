package com.lotusCarVersion2.LotusCarVersion2.Services.QuotationDetails;

import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsHistoryModel;
import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsModel;
import com.lotusCarVersion2.LotusCarVersion2.Repository.QuotationDetails.QuotationDetailsHistoryRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.QuotationDetails.QuotationDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.Calculation.CalculationService;
import com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags.DeviationFlagsStatusService;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
public class QuotationDetailsServiceImpl implements QuotationDetailsService{
    
    private final QuotationDetailsRepo quotationDetailsRepo;
    private final QuotationDetailsHistoryRepo quotationDetailsHistoryRepo;
    private final CalculationService calculationService;
    private final DeviationFlagsStatusService deviationFlagsStatusService;

    @Override
    public String postQuotationDetails(QuotationDetailsModel quotationDetailsModel) {

        if(quotationDetailsModel.getId()!=null){
            quotationDetailsModel.setId(null);
        }

        boolean existingRecord = quotationDetailsRepo.existsByReferenceId(quotationDetailsModel.getReferenceId());
        if(existingRecord){
            QuotationDetailsModel foundRecord = quotationDetailsRepo.findByReferenceId(quotationDetailsModel.getReferenceId());
            QuotationDetailsHistoryModel quotationDetailsHistoryModel = new QuotationDetailsHistoryModel();
            quotationDetailsHistoryModel.setUpdatedDate(LocalDateTime.now());
            BeanUtils.copyProperties(foundRecord, quotationDetailsHistoryModel, "updatedDate","id"); // Exclude 'id' and any other fields
            try{
                quotationDetailsHistoryRepo.save(quotationDetailsHistoryModel);
            }catch (Exception e){
                throw new RuntimeException("Error Saving History Quotation Details " + e);
            }
            try{
                quotationDetailsRepo.delete(foundRecord);
            }catch (Exception e){
                throw new RuntimeException("Error Deleting Quotation Details" + e);
            }
        }

            try{
                quotationDetailsModel.setSubmitDate(LocalDateTime.now());
                quotationDetailsRepo.save(quotationDetailsModel);
    //    **************************Appraisal note updated with other required details************************
    //    appraisalNoteService.updateAppraisalOtherRequiredDetails(quotationDetailsModel.getReferenceId());
            }catch(Exception e){
                e.printStackTrace();
                System.err.println("Error Occurred While Saving Quotation Details for Appraisal Note :" + e.getMessage());
                throw new RuntimeException("Error Occurred While Saving Quotation Details for Appraisal Note .");
            }

            try{
                System.out.println("QUOTATION DETAILS SAVED/UPDATED....... MOVING TO PERFORM CALCULATIONS  ");
                calculationService.callAllFunctionToCollectData(quotationDetailsModel.getReferenceId());
            }catch(Exception e){
                e.printStackTrace();
                System.err.println("Error Occurred While Performing Calculation for REF-ID : "+ quotationDetailsModel.getReferenceId()
                        +"....ERROR DETAILS : "+ e.getMessage());
                throw new RuntimeException("Error Occurred While Performing Calculation.....ERROR DETAILS : "+ e.getMessage());
            }

//********************************************************************************// //********************************************************************************//
        try{
            deviationFlagsStatusService.updateRoiProcessingDocumentationTenureDeviation(quotationDetailsModel);
            deviationFlagsStatusService.updateRepaymentAgeDeviation(quotationDetailsModel);
        }catch (Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE CALLING DEVIATION FUNCTION ON OTHER DETAILS SERVICE. Error Details: "+e.getMessage());
            throw new RuntimeException("ERROR WHILE CALLING DEVIATION FUNCTION ON OTHER DETAILS SERVICE. Error Details: "+e.getMessage());
        }

        return "Quotation Details Saved Successfully";
    }
//********************************************************************************// //********************************************************************************//

    @Override
    public QuotationDetailsModel getQuotationDetails(String referenceId) {
        try{
            QuotationDetailsModel detailsModel=quotationDetailsRepo.findByReferenceId(referenceId);
            System.out.println("QUOTATION DETAILS FOR REF-ID :"+referenceId +" IS: "+detailsModel);

            if(detailsModel != null){
                return detailsModel;
            }else{
                return null;
            }
        }catch(Exception e){
            throw new RuntimeException("Error while Getting Other Quotation Details");
        }
    }
//********************************************************************************// //********************************************************************************//

}
