package com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo;

import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RefIdGenerationRepo extends JpaRepository<ReferenceIdGenerationEntity, Long> {

    boolean existsByPanNumber(String panNumber);
    ReferenceIdGenerationEntity findByPanNumber(String panNumber);
    ReferenceIdGenerationEntity findByReferenceId( String referenceId);
}