package com.lotusCarVersion2.LotusCarVersion2.Repository.QuotationDetails;

import com.lotusCarVersion2.LotusCarVersion2.Models.QuotationDetails.QuotationDetailsModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuotationDetailsRepo extends JpaRepository<QuotationDetailsModel, Long> {

    boolean existsByReferenceId(String referenceId);
    QuotationDetailsModel findByReferenceId(String referenceId);


}
