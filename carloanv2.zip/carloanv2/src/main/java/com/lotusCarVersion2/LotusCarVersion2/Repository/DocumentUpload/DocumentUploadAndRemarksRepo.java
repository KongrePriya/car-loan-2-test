package com.lotusCarVersion2.LotusCarVersion2.Repository.DocumentUpload;

import com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload.DocumentsAndRemarksEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentUploadAndRemarksRepo extends JpaRepository<DocumentsAndRemarksEntity, Long> {

    DocumentsAndRemarksEntity findByReferenceId(String referenceId);
}
