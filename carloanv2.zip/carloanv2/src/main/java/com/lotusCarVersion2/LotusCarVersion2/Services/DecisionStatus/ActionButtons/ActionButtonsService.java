package com.lotusCarVersion2.LotusCarVersion2.Services.DecisionStatus.ActionButtons;

import com.lotusCarVersion2.LotusCarVersion2.DTO.DecisionStatusUserInfoDTO;

public interface ActionButtonsService {

    String buttonActionReturn(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO);
    String buttonActionReject(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO);
    String buttonActionRecommend(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO);
    String buttonActionSanction(DecisionStatusUserInfoDTO decisionStatusUserInfoDTO);


}
