package com.lotusCarVersion2.LotusCarVersion2.Models.DocumentUpload;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name="documents_and_remarks_mandatory_model")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DocumentsAndRemarksMandatoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String referenceId;
    private String LoanType;
    private String BorrowerType;
    private String shortLoanType;
    private String shortBorrowerType;

    // due diligence
    private String applicantDueDiligence="YES"; //ALWAYS YES
    private String coAppDueDiligence="NO";
    private String guarantorDueDiligence="NO";

    //quotation
    private String quotationFile="YES"; //ALWAYS YES

    //Visit report
    private String visitReport="YES"; //ALWAYS YES

    // ITR form 16 : taken in both cases (individual or corporate)
    private String applicantITRForm16="YES"; //ALWAYS YES
    private String coAppITRForm16="NO";
    private String guarantorITRForm16="NO";

    private String applicantSalaryPensionSlip="NO";
    private String coAppSalaryPensionSlip="NO";
    private String guarantorSalaryPensionSlip="NO";

    private String applicantKyc="YES"; //ALWAYS YES
    private String coAppKyc="NO";
    private String guarantorKyc="NO";

    private String applicantBankStatement="YES"; //ALWAYS YES

    private String employmentOrBusinessProof="YES"; //COMBINED FIELD  //ALWAYS YES

    private String applicantPassport="NO"; //In case of NRI/PIO

    //other Remark
    private String otherDocuments="NO";


}
