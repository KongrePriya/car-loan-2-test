package com.lotusCarVersion2.LotusCarVersion2.DTO;


import lombok.Data;
import java.math.BigDecimal;

@Data
public class ProductCodeDto {

    private Long Id;
    private String productCode;
    private String productDescription;
    private BigDecimal rateOfInterest;
    private String insertedDate;
    private String borrowerType;
    private String loanType;

}
