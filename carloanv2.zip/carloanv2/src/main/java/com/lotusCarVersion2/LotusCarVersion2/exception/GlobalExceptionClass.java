package com.lotusCarVersion2.LotusCarVersion2.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Collectors;

@ControllerAdvice
public class GlobalExceptionClass {

//****************************************************************************************************//
    // Handler for ResourceNotFoundException
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ExceptionDetails> handleResourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
        ExceptionDetails details = new ExceptionDetails(
                LocalDateTime.now(),
                ex.getMessage(),
                request.getDescription(false),
                "RESOURCE_NOT_FOUND",
                Optional.empty()
        );
        return new ResponseEntity<>(details, HttpStatus.NOT_FOUND);
    }
//****************************************************************************************************//
    // Handler for MethodArgumentNotValidException
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ExceptionDetails> handleValidationExceptions(MethodArgumentNotValidException ex, WebRequest request) {
        String errorMessage = ex.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField().toUpperCase() + ": " + error.getDefaultMessage())
                .collect(Collectors.joining("\n"));

         errorMessage = "DATA VALIDATION FAILED...!!!\n Kindly refer below details and fill appropriate information : \n"+errorMessage;

        ExceptionDetails details = new ExceptionDetails(
                LocalDateTime.now(),
                errorMessage,
                request.getDescription(false),
                "VALIDATION_FAILED",
                Optional.empty()
        );
        return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);
    }

//****************************************************************************************************//
    // Handler for MethodArgumentTypeMismatchException
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ExceptionDetails> handleTypeMismatchException(MethodArgumentTypeMismatchException ex, WebRequest request) {
        String errorMessage = "Invalid value for parameter '" + ex.getName() + "': " + ex.getValue();
        ExceptionDetails details = new ExceptionDetails(
                LocalDateTime.now(),
                errorMessage,
                request.getDescription(false),
                "TYPE_MISMATCH",
                Optional.empty()
        );
        return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);
    }
//****************************************************************************************************//
//    // Handler for ConstraintViolationException :-gives complete detailed  error message
//    @ExceptionHandler(ConstraintViolationException.class)
//    public ResponseEntity<ExceptionDetails> handleConstraintViolationException(ConstraintViolationException ex, WebRequest request) {
//        String errorMessage = ex.getConstraintViolations().stream()
//                .map(ConstraintViolation::getMessage)
//                .collect(Collectors.joining(", "));
//
//        ExceptionDetails details = new ExceptionDetails(
//                LocalDateTime.now(),
//                errorMessage,
//                request.getDescription(false),
//                "VALIDATION_FAILED",
//                Optional.empty()
//        );
//        return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);
//    }

//****************************************************************************************************//
    // Handler for Generic Exception
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ExceptionDetails> handleGenericException(Exception ex, WebRequest request) {
        String errorMessage = "SERVER ERROR...!!! Kindly Contact Concerned Department : \n" + ex.getMessage();
        ExceptionDetails details = new ExceptionDetails(
                LocalDateTime.now(),
                ex.getMessage(),
                request.getDescription(false),
                "INTERNAL_SERVER_ERROR",
                Optional.empty()
        );
        return new ResponseEntity<>(details, HttpStatus.INTERNAL_SERVER_ERROR);
    }
//****************************************************************************************************//
}
