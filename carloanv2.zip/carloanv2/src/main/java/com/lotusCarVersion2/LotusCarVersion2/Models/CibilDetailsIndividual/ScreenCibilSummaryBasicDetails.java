package com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsIndividual;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cibil_basic_summary_details_jasper")
// THE ACTUAL DATA IS PRESENT IN THE CIBIL_PERSONAL SCHEMA , this is just a entity to get the data for jasper reports
public class ScreenCibilSummaryBasicDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String customerPan;
    private LocalDateTime dateOfFetching;
    private String referenceId;
    private String branchCode;
    private String userId;


    //to display BASIC DETAILS
    private String cibilScore;
    private String personalScore;

    private int totalAccounts;
    private int regularAccounts;
    private int overdueAccounts;
    private int zeroBalanceAccount;
    private int suitFiledAccounts;
    private int writtenOffAccounts;
    private int settledAccounts;

    private String cibilScoreDate;

    //to display SUMMARY
    private String scoreStatusSummary;
    private String accountWrittenOffSummary;
    private String accountSettledSummary;
    private String accountOverdueSummary;

    //for summary fields
    private String numberOfWrittenOff;
    private String writtenOffAmt;
    private String numberOfSettledAcc;
    private String settledAmt;

    //additional field to update old entries
    private String oldRecord;
    private LocalDateTime refetchedDate;
    private Double overdueSum;
}
