package com.lotusCarVersion2.LotusCarVersion2.Repository.FirmDetail;

import com.lotusCarVersion2.LotusCarVersion2.Models.FirmDetail.FirmDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FirmDetailsRepo extends JpaRepository<FirmDetailsEntity, String> {
    FirmDetailsEntity findByFirmReferenceId(String ref_id);
    boolean existsByFirmReferenceId(String ref_id);


}
