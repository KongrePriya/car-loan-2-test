package com.lotusCarVersion2.LotusCarVersion2.Models.CRIFDetails;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "std_crif_summary_model", schema = "crif_individual")
public class StdCrifSummaryModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String writtenOffAccounts;
    private String settledAccounts;
    private String overdueAccounts;
    private String referenceId;
    private String branchCode;
    private String userId;
    private String individualPan;
    private String customerType; //NEW ADDITION FOR CRIF COUNT IN FRONT END : 05-02-2025
    private LocalDateTime createdDate;
}
