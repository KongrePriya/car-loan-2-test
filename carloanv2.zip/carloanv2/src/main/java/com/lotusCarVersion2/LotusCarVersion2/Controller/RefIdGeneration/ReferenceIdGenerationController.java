//package com.lotusCarVersion2.LotusCarVersion2.Controller.RefIdGeneration;
//
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationModel;
//import com.lotusCarVersion2.LotusCarVersion2.Services.RefIdGenerationService.ReferenceIdGenerationService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//
//
//@CrossOrigin("*")
//@RequiredArgsConstructor
//@RestController
//@RequestMapping("/api/v1/ref-id")
//public class ReferenceIdGenerationController {
//
//    @Autowired
//    ReferenceIdGenerationService refNoVarificationService;
//
//   //************************* REFERENCE ID Generation ********************************************************************************************
//    @PostMapping("/generation")
//    public String generateAndSave(@RequestBody ReferenceIdGenerationModel refNumber)  throws JsonProcessingException {
//
//        System.out.println("In Generation Reference ID ");
//
//        return refNoVarificationService.generateAndSave(refNumber);
//    }
//
//    @GetMapping("/get/{referenceId}")
//
//    public String getRefIdVarifiedEntityRefNo(@PathVariable String referenceId)  {
//        System.out.println(" IN REFERENCE ID SEARCH OR GET API");
//
//        return refNoVarificationService.searchReferenceId(referenceId);
//
//    }
//
//
////*************************************for loan type loanding*************************
//
//
//}
