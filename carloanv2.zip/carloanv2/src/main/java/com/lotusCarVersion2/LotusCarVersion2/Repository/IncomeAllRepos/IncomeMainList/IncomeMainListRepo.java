package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeMainList;

import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeMainList.IncomeMainListModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IncomeMainListRepo extends JpaRepository<IncomeMainListModel, Long> {


    List<IncomeMainListModel> findAllByReferenceId(String referenceId);
}
