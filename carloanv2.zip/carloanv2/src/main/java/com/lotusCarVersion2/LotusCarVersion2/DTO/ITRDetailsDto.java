package com.lotusCarVersion2.LotusCarVersion2.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ITRDetailsDto {

    private Long id;
    private String referenceIdLotus;
    private String customerName;
    private String customerPan;
    private String customerType;
    private String branchCode;
    private String year1;
    private String year2;

    // ITR Filing Details: Year 1
    private String itrTypeYear1;
    private String originalOrRevisedYear1;
    private String acknowledgementNumberYear1;
    private LocalDate originalReturnFilingDateYear1;
    private LocalDate revisedReturnFilingDateYear1;

    // ITR Filing Details: Year 2
    private String itrTypeYear2;
    private String originalOrRevisedYear2;
    private String acknowledgementNumberYear2;
    private LocalDate originalReturnFilingDateYear2;
    private LocalDate revisedReturnFilingDateYear2;

    // Income Details From All Sources: Year 1
    private double grossIncomeFromSalaryYear1;
    private double incomeFromHousePropertyYear1;
    private double capitalGainTotalYear1;
    private double incomeFromOtherSourcesYear1;
    private double totalIncomeByAddingAllYear1;
    private double profitGainsFromBusinessOrProfYear1;

    // Income Details From All Sources: Year 2
    private double grossIncomeFromSalaryYear2;
    private double incomeFromHousePropertyYear2;
    private double capitalGainTotalYear2;
    private double incomeFromOtherSourcesYear2;
    private double totalIncomeByAddingAllYear2;
    private double profitGainsFromBusinessOrProfYear2;

    // Income As Per ITR: Year 1
    private double grossTotalIncomeYear1;
    private double totalTaxableIncomeYear1;

    // Income As Per ITR: Year 2
    private double grossTotalIncomeYear2;
    private double totalTaxableIncomeYear2;

    // Deduction & Liability Details As Per ITR: Year 1
    private double deductionUnder6aYear1;
    private double otherDeductionsTotalYear1;
    private double netTaxLiabilityYear1;

    // Deduction & Liability Details As Per ITR: Year 2
    private double deductionUnder6aYear2;
    private double otherDeductionsTotalYear2;
    private double netTaxLiabilityYear2;

}