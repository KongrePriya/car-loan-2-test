package com.lotusCarVersion2.LotusCarVersion2.Controller.IncomeAll.IncomeSalary;


import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryModel;
import com.lotusCarVersion2.LotusCarVersion2.Services.IncomeAllPackages.IncomeSalary.IncomeSalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/income-salary")
@CrossOrigin(origins = "*")
public class IncomeSalaryController {

    @Autowired
    private IncomeSalaryService incomeSalaryService;


    @PostMapping("add")
    public ResponseEntity<String> postIncomeSalaryDetails(@RequestBody IncomeSalaryModel incomeSalaryModel){
        String incomeSalaryResponse = incomeSalaryService.postIncomeSalary(incomeSalaryModel);
        return new ResponseEntity<>(incomeSalaryResponse, HttpStatus.OK);
    }


    @GetMapping("fetch")
    public ResponseEntity<IncomeSalaryModel> getIncomeSalaryDetails(@RequestParam String referenceId, @RequestParam String panNumber){
        IncomeSalaryModel getIncomeSalary = incomeSalaryService.getIncomeSalary(referenceId,panNumber);
        if(getIncomeSalary != null){
            return new ResponseEntity<>(getIncomeSalary,HttpStatus.OK);
        }else {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }

}
