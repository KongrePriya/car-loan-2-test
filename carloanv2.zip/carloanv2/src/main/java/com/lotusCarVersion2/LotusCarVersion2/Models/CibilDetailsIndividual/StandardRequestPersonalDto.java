package com.lotusCarVersion2.LotusCarVersion2.Models.CibilDetailsIndividual;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StandardRequestPersonalDto {

    private Long id;
    private String fullName;
    private String gender;
    private String dateOfBirth;
    private String pan;
    private String aadhar;
    private String passportNum;
    private String tempAddressLine1;
    private String tempAddressLandmark;
    private String tempAddressSubDist;
    private String tempAddressDist;
    private String tempAddressState;
    private String tempAddressPincode;

    //Additional
    private String referenceId;
    private String branchCode;
    private String userId;
//    private LocalDateTime fetchDate;
    private String individualType;


}
