package com.lotusCarVersion2.LotusCarVersion2.Services.DeviationFlags;

import com.lotusCarVersion2.LotusCarVersion2.Config.AllStaticFields;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifStatus.CibilCrifFetchStatusEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.DeviationFlagsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.DeviationFlags.RawDataForDeviationCheckingEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.ITR.ITRDetailsAsPerScreenEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Models.RefIdGeneration.ReferenceIdGenerationEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CibilCrifFetchStatus.CibilCrifFetchStatusRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DeviationRepo.DeviationFlagsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.DeviationRepo.RawDataForDeviationCheckingRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.ITR.ITRDetailsScreenRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.RefIdGenerationRepo.RefIdGenerationRepo;
import com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService.CibilCrifFetchStatusService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class DeviationCheckingRequiredDataServiceImpl implements DeviationCheckingRequiredDataService {

    private final RawDataForDeviationCheckingRepo rawDataForDeviationCheckingRepo;
    private final IndividualBasicDetailsRepo individualBasicDetailsRepo;
    private final DeviationFlagsRepo deviationFlagsRepo;
    private final DeviationFlagsStatusService deviationFlagsStatusService;
    private final ITRDetailsScreenRepo itrDetailsScreenRepo;
    private final CibilCrifFetchStatusRepo cibilCrifFetchStatusRepo;
    private final CibilCrifFetchStatusService cibilCrifFetchStatusService;
    private final RefIdGenerationRepo refNoVarificationRepo;


//*************************************************************************************************************//
// to check if entry is already present in Deviation Required data table against the reference id
    @Override
    public RawDataForDeviationCheckingEntity checkOrCreateDeviationRequiredData(String referenceId) {
        // Check if data already present from referenceId
        RawDataForDeviationCheckingEntity entityPresent = rawDataForDeviationCheckingRepo.findByReferenceId(referenceId);

        if (entityPresent == null) {
            RawDataForDeviationCheckingEntity newEntity = new RawDataForDeviationCheckingEntity();
            newEntity.setReferenceId(referenceId);

            ReferenceIdGenerationEntity refNoData = refNoVarificationRepo.findByReferenceId(referenceId);
            newEntity.setLoanType(refNoData.getLoanType());
            newEntity.setRegionName(refNoData.getRoname());
            newEntity=rawDataForDeviationCheckingRepo.save(newEntity);

            System.out.println("EXISTING Entity NOT PRESENT , NEW RawDataForDeviationCheckingEntity CREATED ");
            return newEntity;
        } else {
            ReferenceIdGenerationEntity refNoData = refNoVarificationRepo.findByReferenceId(referenceId);
            entityPresent.setLoanType(refNoData.getLoanType());
            entityPresent.setRegionName(refNoData.getRoname());
            rawDataForDeviationCheckingRepo.save(entityPresent);
            System.out.println("EXISTING ENTRY PRESENT RawDataForDeviationCheckingEntity ");
            return entityPresent;
        }
    }
//********************************** GET DEVIATION RAW DATA ********************************************//

    @Override
    public RawDataForDeviationCheckingEntity getDeviationRawData(String referenceId) {

        RetrieveAndSaveBasicDetailsOfAll(referenceId);
        RawDataForDeviationCheckingEntity rawData = rawDataForDeviationCheckingRepo.findByReferenceId(referenceId);
        if (rawData != null) {
            return rawData;
        } else {
            System.out.println("RAW-DATA DEVIATION ENTITY NOT PRESENT FOR REF-ID :" + referenceId);
            return null;
        }
    }

//*************************************************************************************************************//
    @Override
    public RawDataForDeviationCheckingEntity RetrieveAndSaveBasicDetailsOfAll(String referenceId) {
        List<IndividualBasicDetailsEntity> basicDetailsList = individualBasicDetailsRepo.findAllByReferenceId(referenceId);
        RawDataForDeviationCheckingEntity devRawDataEntity = checkOrCreateDeviationRequiredData(referenceId);

        // to check if customer type is present or not
        boolean applicantPresent = false;
        boolean coapplicant1Present = false;
        boolean coapplicant2Present = false;
        int highestAgeInMonths = 0;

        if (!basicDetailsList.isEmpty()) {
            devRawDataEntity.setBranchCode(basicDetailsList.get(0).getBranchCode());
        // devRawDataEntity.setRegionName(basicDetailsList.get(0).get());
            try {
                for (IndividualBasicDetailsEntity entity : basicDetailsList) {
                    System.out.println("INSIDE RetrieveAndSaveBasicDetailsOfAll, "+entity.getCustomerType()+
                            "\n DATA : "+entity);

                    boolean consideringIncome = entity.getConsideringIncome().equalsIgnoreCase("yes");

                    switch (entity.getCustomerType()) {
                        case "APPLICANT":
                            devRawDataEntity.setApplicantName(entity.getFullName());
                            devRawDataEntity.setApplicantAgeInMonths(entity.getAgeInMonths());
                            devRawDataEntity.setApplicantIncomeSource(entity.getIncomeSourceType());
                            devRawDataEntity.setApplicantIncomeConsider(entity.getConsideringIncome());
                            devRawDataEntity.setApplicantITRPresent(entity.getItrFilledForAnyYear());
                            devRawDataEntity.setApplicantForm16Present(entity.getForm16Available());
                            devRawDataEntity.setApplicantPan(entity.getPan());
//                        devRawDataEntity.setApplicantItrVerified(updateItrFetchedStatus(referenceId,entity.getCustomerType()));


                            //setting applicantPresent true so that its value gets saved
                            applicantPresent = true;
                            //if considering income then only check for age
                            if (consideringIncome) {
                                highestAgeInMonths = Math.max(highestAgeInMonths, entity.getAgeInMonths());
                            }
                            break;
                        case "COAPPLICANT1":
                            devRawDataEntity.setCoapplicantOneName(entity.getFullName());
                            devRawDataEntity.setCoapplicantOneAgeInMonths(entity.getAgeInMonths());
                            devRawDataEntity.setCoapplicantOneIncomeSource(entity.getIncomeSourceType());
                            devRawDataEntity.setCoapplicantOneIncomeConsider(entity.getConsideringIncome());
                            devRawDataEntity.setCoapplicantOneITRPresent(entity.getItrFilledForAnyYear());
                            devRawDataEntity.setCoapplicantOneForm16Present(entity.getForm16Available());
                            devRawDataEntity.setCoapplicantOnePan(entity.getPan());
//                        devRawDataEntity.setCoappOneItrVerified(updateItrFetchedStatus(referenceId,entity.getCustomerType()));

                            coapplicant1Present = true;
                            if (consideringIncome) {
                                highestAgeInMonths = Math.max(highestAgeInMonths, entity.getAgeInMonths());
                            }
                            break;
                        case "COAPPLICANT2":
                            devRawDataEntity.setCoapplicantTwoName(entity.getFullName());
                            devRawDataEntity.setCoapplicantTwoAgeInMonths(entity.getAgeInMonths());
                            devRawDataEntity.setCoapplicantTwoIncomeSource(entity.getIncomeSourceType());
                            devRawDataEntity.setCoapplicantTwoIncomeConsider(entity.getConsideringIncome());
                            devRawDataEntity.setCoapplicantTwoITRPresent(entity.getItrFilledForAnyYear());
                            devRawDataEntity.setCoapplicantTwoForm16Present(entity.getForm16Available());
                            devRawDataEntity.setCoapplicantTwoPan(entity.getPan());
                            coapplicant2Present = true;
                            if (consideringIncome) {
                                highestAgeInMonths = Math.max(highestAgeInMonths, entity.getAgeInMonths());
                            }
                            break;
                        default:
                            System.out.println("DEVIATION RAW DATA SERVICE :CUSTOMER TYPE OTHER THAN APPLICANT/CO-APPLICANT 1, 2, 3");
                            break;
                    }
                }
            } catch (Exception er) {
                System.err.println("RAW DATA DEVIATION: ERROR IN LOOP WHILE SETTING BASIC DETAILS:" + er.getMessage());
                throw new RuntimeException("RAW DATA DEVIATION: ERROR IN LOOP WHILE SETTING BASIC DETAILS:" + er.getMessage());
            }
        }
        // Reset the values (useful when data is deleted or co-applicants not added)
        if (!applicantPresent) {
            devRawDataEntity.setApplicantAgeInMonths(0);
            devRawDataEntity.setApplicantName(null);
            devRawDataEntity.setApplicantIncomeSource(null);
            devRawDataEntity.setApplicantIncomeConsider(null);
            devRawDataEntity.setApplicantITRPresent(null);
            devRawDataEntity.setApplicantForm16Present(null);
        }
        if (!coapplicant1Present) {
            devRawDataEntity.setCoapplicantOneAgeInMonths(0);
            devRawDataEntity.setCoapplicantOneName(null);
            devRawDataEntity.setCoapplicantOneIncomeSource(null);
            devRawDataEntity.setCoapplicantOneIncomeConsider(null);
            devRawDataEntity.setCoapplicantOneITRPresent(null);
            devRawDataEntity.setCoapplicantTwoForm16Present(null);

        }
        if (!coapplicant2Present) {
            devRawDataEntity.setCoapplicantTwoAgeInMonths(0);
            devRawDataEntity.setCoapplicantTwoName(null);
            devRawDataEntity.setCoapplicantTwoIncomeSource(null);
            devRawDataEntity.setCoapplicantTwoIncomeConsider(null);
            devRawDataEntity.setCoapplicantTwoITRPresent(null);
            devRawDataEntity.setCoapplicantTwoForm16Present(null);

        }

        // Saving updated devRawDataEntity
        devRawDataEntity.setHighestAgeOfEarningMemberInMonths(highestAgeInMonths);

        // Saving Count of people who have ITR
        Integer allItrCount= individualBasicDetailsRepo.countOfItrAvailablePerson(referenceId);
        devRawDataEntity.setNumberOfPersonHaveItr(allItrCount);


        rawDataForDeviationCheckingRepo.save(devRawDataEntity);
        System.out.println("RawDataForDeviationCheckingEntity :BASIC DETAILS DATA SAVED/UPDATED. ");

        //step-1 : SETTING ITR/FORM16 DEVIATION FIELD
        try{
            updateItrForm16Deviation(referenceId);
        }catch (Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE SETTING ITR/FORM16 DEVIATION FLAGS. :"+e.getMessage());
            throw new RuntimeException("ERROR WHILE SETTING ITR/FORM16 DEVIATION FLAGS. :"+e.getMessage());
        }

        //step-2: SETTING ITR VERIFIED STATUS FIELD
        try{
            devRawDataEntity= updateItrFetchedStatus(referenceId);
        }catch (Exception e){
            e.printStackTrace();
            System.err.println("ERROR WHILE SETTING ITR VERIFIED FLAGS. :"+e.getMessage());
            throw new RuntimeException("ERROR WHILE SETTING ITR VERIFIED FLAGS. :"+e.getMessage());
        }

        return devRawDataEntity;
    }
//--------------------------------------------------------------------------------------------------------------------------//
@Override
public String updateItrForm16Deviation(String referenceId) {

    RawDataForDeviationCheckingEntity devRawDataEntity = checkOrCreateDeviationRequiredData(referenceId);
    System.out.println("//--------------------------------------- INSIDE ITR-Form16 Deviation FLAG SETTING METHOD ---------------------------------------------//");

    System.out.println(" devRawDataEntity: "+devRawDataEntity);
    DeviationFlagsEntity deviationFlagsEntity = deviationFlagsStatusService.checkOrCreateDeviationEntity(referenceId);

    String applicantDeviation = "No";
    String coapplicantOneDeviation = "No";
    String coapplicantTwoDeviation = "No";


    //------------ STEP -1 : APPLICANT ITR/FORM16 Deviation ----------------//
    try {
         applicantDeviation = calculateItrForm16Deviation(
                devRawDataEntity.getApplicantIncomeConsider(),
                devRawDataEntity.getApplicantIncomeSource(),
                devRawDataEntity.getApplicantITRPresent(),
                devRawDataEntity.getApplicantForm16Present()
        );
        devRawDataEntity.setAppItrOrForm16Deviation(applicantDeviation);
        System.out.println("Step-1 : APPLICANT ITR/FORM16 Deviation Set");
    }catch (Exception e){
        System.err.println("ERROR WHILE SETTING  APPLICANT ITR/FORM16 Deviation :"+e.getMessage());
    }
    //------------ STEP -2: COAPPLICANT1 ITR/FORM16 Deviation  ---------------//
    try {
         coapplicantOneDeviation = calculateItrForm16Deviation(
                devRawDataEntity.getCoapplicantOneIncomeConsider(),
                devRawDataEntity.getCoapplicantOneIncomeSource(),
                devRawDataEntity.getCoapplicantOneITRPresent(),
                devRawDataEntity.getCoapplicantOneForm16Present()
        );
        devRawDataEntity.setCoappOneItrOrForm16Deviation(coapplicantOneDeviation);
        System.out.println("Step-2 : COAPPLICANT1 ITR/FORM16 Deviation Set");
     }catch (Exception e){
        System.err.println("ERROR WHILE SETTING  COAPPLICANT1 ITR/FORM16 Deviation :"+e.getMessage());
    }

    //------------ STEP -3: COAPPLICANT2 ITR/FORM16 Deviation ----------------------//
    try{
     coapplicantTwoDeviation = calculateItrForm16Deviation(
            devRawDataEntity.getCoapplicantTwoIncomeConsider(),
            devRawDataEntity.getCoapplicantTwoIncomeSource(),
            devRawDataEntity.getCoapplicantTwoITRPresent(),
            devRawDataEntity.getCoapplicantTwoForm16Present()
    );
    devRawDataEntity.setCoappTwoItrOrForm16Deviation(coapplicantTwoDeviation);
    System.out.println("Step-3 : COAPPLICANT2 ITR/FORM16 Deviation Set");
    }catch (Exception e){
        System.err.println("ERROR WHILE SETTING  COAPPLICANT2 ITR/FORM16 Deviation :"+e.getMessage());
    }

    rawDataForDeviationCheckingRepo.save(devRawDataEntity);
    System.out.println("DEVIATION RAW DATA: ITR/FORM16 FLAGS DATA SAVED");

    //Setting Deviation Flags in Deviation Table also.
    deviationFlagsEntity.setApplicantItrForm16Deviation(applicantDeviation.toUpperCase());
    deviationFlagsEntity.setCoapplicantOneItrForm16Deviation(coapplicantOneDeviation.toUpperCase());
    deviationFlagsEntity.setCoapplicantTwoItrForm16Deviation(coapplicantTwoDeviation.toUpperCase());

    deviationFlagsRepo.save(deviationFlagsEntity);
    System.out.println("//------------------------------------------- DEVIATION FLAGS: ITR/FORM16 FLAGS DATA SAVED ----------------------------------------------//");

    return "DEVIATION RAW DATA: ITR/FORM16 FLAGS DATA SAVED";
}

//***************************************************************************************************************************//
//Method to calculate ITR/Form16 deviation based on data.
private String calculateItrForm16Deviation(String incomeConsider, String incomeSource, String itrPresent, String form16Present) {

    System.out.println("incomeConsider:  "+incomeConsider
                        +" \n incomeSource : "+incomeSource
                        +" \n itrPresent : "+itrPresent
                        +" \n form16Present : "+form16Present);

        if (incomeConsider != null && incomeConsider.equalsIgnoreCase("Yes")) {
            if ((incomeSource.equalsIgnoreCase(AllStaticFields.salaried) || incomeSource.equalsIgnoreCase(AllStaticFields.pensioner)) &&
                    (itrPresent.equalsIgnoreCase("Yes") || form16Present.equalsIgnoreCase("Yes"))) {
                return "No";
            } else if (incomeSource.equalsIgnoreCase(AllStaticFields.business) && itrPresent.equalsIgnoreCase("Yes")) {
                return "No";
            } else {
                return "Yes";
            }
        } else {
            return "No";
        }
    }

//***************************************************************************************************************************//
//retrieving ITR data in ITR table and then setting flags
@Override
public RawDataForDeviationCheckingEntity updateItrFetchedStatus(String referenceId) {

    RawDataForDeviationCheckingEntity devRawDataEntity = checkOrCreateDeviationRequiredData(referenceId);
    System.out.println("//---------------- STEP-5 : Inside updateItrFetchedStatus for reference-id: " + referenceId +" -------------------------------------//");

    // fetching all ITR records related to the given referenceId
    List<ITRDetailsAsPerScreenEntity> itrDetailsList = itrDetailsScreenRepo.findByReferenceIdLotus(referenceId);

    System.out.println("ITR LIST SIZE :"+itrDetailsList.size());

    String applicantItrPresent="No";
    String coappOneItrPresent="No";
    String coappTwoItrPresent="No";
    Integer countOfCorrectItr = 0;

    if (itrDetailsList != null && !itrDetailsList.isEmpty()) {

        for (ITRDetailsAsPerScreenEntity itrEntity : itrDetailsList) {
            // Checking the customerType in the ITR List and set the flag to "Yes"
            switch (itrEntity.getCustomerType()) {
                case "APPLICANT":
                    applicantItrPresent ="Yes";
                    if(itrEntity.getCustomerPan().equals(devRawDataEntity.getApplicantPan())){
                        countOfCorrectItr++;
                    }
                    break;
                case "COAPPLICANT1":
                    coappOneItrPresent="Yes";
                    if(itrEntity.getCustomerPan().equals(devRawDataEntity.getCoapplicantOnePan())){
                        countOfCorrectItr++;
                    }
                    break;
                case "COAPPLICANT2":
                    coappTwoItrPresent="Yes";
                    if(itrEntity.getCustomerPan().equals(devRawDataEntity.getCoapplicantTwoPan())){
                        countOfCorrectItr++;
                    }
                    break;
                default:
                    System.out.println("DEVIATION RAW DATA SERVICE- ITR VERIFIED STATUS: CUSTOMER TYPE OTHER THAN APPLICANT/CO-APPLICANT 1, 2, 3");
                    break;
            }
        }
        System.out.println(" itrDetailsList size: "+itrDetailsList.size() +" AND countOfCorrectItr :"+countOfCorrectItr);

      }

    //Count of verified ITR for reference-Id: SETTING THIS OUTSIDE IF , SO THAT IF ITR DELETED AND LIST EMPTY THEN 0 CAN GET SET.
    devRawDataEntity.setNumberOfItrFetched(itrDetailsList.size());
    devRawDataEntity.setCountOfCorrectItrFetched(countOfCorrectItr);


        System.out.println("VALUES OF ITR-FETCHED STATUS FLAGS, applicantItrPresent :"+applicantItrPresent
                +" \n coappOneItrPresent :"+coappOneItrPresent +"\n coappTwoItrPresent :"+coappTwoItrPresent );

        devRawDataEntity.setApplicantItrVerified(applicantItrPresent);
        devRawDataEntity.setCoappOneItrVerified(coappOneItrPresent);
        devRawDataEntity.setCoappTwoItrVerified(coappTwoItrPresent);

    rawDataForDeviationCheckingRepo.save(devRawDataEntity);

    System.out.println("ITR VERIFIED FLAGS SET IN DEVIATION RAW-DATA ENTITY.");

    try{
        RawDataForDeviationCheckingEntity devRawDataEntityNew=  setAllRequiredItrVerified(referenceId);
        return devRawDataEntityNew;
    }catch (Exception e){
        e.printStackTrace();
        System.err.println("ERROR WHILE SETTING FINAL ITR VERIFIED FLAG :"+e.getMessage());
        throw  new RuntimeException("ERROR WHILE SETTING FINAL ITR VERIFIED FLAG :"+e.getMessage());
    }
}

//***********************************************************************************************************//
//To set All-ITR-FETCHED flag after setting counts
private RawDataForDeviationCheckingEntity setAllRequiredItrVerified(String referenceId){

    RawDataForDeviationCheckingEntity devRawDataEntity = checkOrCreateDeviationRequiredData(referenceId);

    if(devRawDataEntity != null)
    {
        System.out.println("NumberOfItrFetched : "+devRawDataEntity.getNumberOfItrFetched()
                            +"\n NumberOfPersonHaveItr : "+devRawDataEntity.getNumberOfPersonHaveItr()
                            +"\n CountOfCorrectItrFetched : "+devRawDataEntity.getCountOfCorrectItrFetched());

        if(devRawDataEntity.getNumberOfItrFetched().equals(devRawDataEntity.getNumberOfPersonHaveItr()) &&
                devRawDataEntity.getNumberOfItrFetched().equals(devRawDataEntity.getCountOfCorrectItrFetched()))
        {
            System.out.println("//-------------------------- ALL ITR ARE FETCHED CORRECTLY...!!! --------------------------//");
            devRawDataEntity.setAllItrFetched(true);

        }else{
            devRawDataEntity.setAllItrFetched(false);
        }

        //WHEN ITR FETCHED COUNT IS SAME AS NO. OF PEOPLE HAVING ITR BUT THE ITR FETCHED IS NOT FOR THE SAME PAN AS ADDED
        if(devRawDataEntity.getNumberOfItrFetched().equals(devRawDataEntity.getCountOfCorrectItrFetched())){
        devRawDataEntity.setAllFetchedItrAreCorrect(true);
        }else{
            devRawDataEntity.setAllFetchedItrAreCorrect(false); // i.e ITR is not fetched for the same PAN which are added in application
        }

        rawDataForDeviationCheckingRepo.save(devRawDataEntity);
    }

    //TO SET ITR FLAG IN CIBIL-CRIF STATUS ENTITY SO THAT IT CAN BE USED IN STATUS TABLE FROM ONE PLACE
    try{
        CibilCrifFetchStatusEntity statusEntity=cibilCrifFetchStatusService.checkOrCreateCibilCrifEntity(referenceId);
        statusEntity.setAllItrFetched(devRawDataEntity.isAllItrFetched());
        cibilCrifFetchStatusRepo.save(statusEntity);
    }catch (Exception e){
        System.err.println("ERROR WHILE SETTING ITR FLAG IN CIBIL-CRIF-STATUS ENTITY. :"+e.getMessage());
        throw new RuntimeException("ERROR WHILE SETTING ITR FLAG IN CIBIL-CRIF-STATUS ENTITY. :"+e.getMessage());
    }

    return devRawDataEntity;
 }

//*********************************************************************************************************************//
}

