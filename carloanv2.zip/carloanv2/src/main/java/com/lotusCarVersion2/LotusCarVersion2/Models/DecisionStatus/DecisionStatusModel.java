package com.lotusCarVersion2.LotusCarVersion2.Models.DecisionStatus;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
//@Table(name = "decision_status")
@Table(name = "car_loan_application_status")
public class DecisionStatusModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //Basic Details
    private String applicantName;
    private String applicantType;
    private String loanType;
    private BigDecimal appliedLoanAmt;
    private LocalDateTime applicationCreationDate;
    private String referenceId;
    private String roname; //change
    private String userLoc;
    private String userType;
    private String branchCode;
    private String applicantPan;
    private String finalActionAuthorityScale;
    private String finalActionAuthorityUserType;
    private BigDecimal topUpAppliedLoanAmt;


    //Application FINAL SUBMIT BY BRANCH OFFICER
    private String finalSubmitBy;
    private String finalSubmitByBranch;//"yes","no" this will detemined if application is submiited by Branch Only
    //    private String actionBy;
    private LocalDateTime finalSubmitDate;
    private String applnStatusMain;
    private String applnStatusBranchOfficer;
    private String applnStatusBranchManager;


    //Application FINAL SUBMIT BY BRANCH MANAGER

    //return Flag Set by and date
    private String returnBy;
    private String returnUserId;
    private LocalDateTime returnDate;



    //Reject Flag Set by and date
    private String rejectBy;
    private String rejectUserId;
    private LocalDateTime rejectDate;



    //Recommended Flag Set by and date
    private String recommendBy;
    private String recommendUserId;
    private LocalDateTime recommendDate;



    //Sanction Flag Set by and date
    private String sanctionBy;
    private String sanctionUserId;
    private LocalDateTime sanctionDate;

    //Flag For CPC-OFFICER
    private String applnStatusCpcOfficer;
    //Flag For CPC-HEAD
    private String applnStatusCpcHead;
    //Flag For RM
    private String applnStatusRegionalManager;
    //Flag For Ho Officer
    private String applnStatusHoOfficer;
    //Flag For CM
    private String applnStatusChiefManager;
    //Flag For GM

    private String applnStatusGeneralManager;

    //Flag For CHAIRMAN

    private String applnStatusChairman;

    //Flag For ActionTaken By User

    private String isActionTakenByBM;
    private String isActionTakenByCPCOF;
    private String isActionTakenByCPCHEAD;
    private String isActionTakenByRM;
    private String isActionTakenByHOOF;
    private String isActionTakenByCM;

    private LocalDateTime applnMainActionDate;
    private String applnMainActionBy;
    private String applnPendingAtWhichLevel;
    private String deviationStatus="NO DEVIATION";


    //PRIYA
    private String applicationStatus;
    private String lastActionBy;
    private String lastActionDate;

}
