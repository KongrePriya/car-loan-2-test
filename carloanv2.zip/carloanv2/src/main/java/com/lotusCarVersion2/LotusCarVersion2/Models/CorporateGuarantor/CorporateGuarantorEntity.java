package com.lotusCarVersion2.LotusCarVersion2.Models.CorporateGuarantor;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;


@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="corp_guarantor_details")
public class CorporateGuarantorEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // fetched from PAN & GSTN verification without OTP
    private String gstinStatus;
    private String constitutionOfBusiness;
    private String dateOfRegistration;
    private String principalPlaceOfBusinessAddress;
    private String natureOfBusiness;
    private String stateJurisdictionCode;
    private String gstin;
    private String dateOfCancellation;
    private String centreJurisdictionCode;
    private String tradeName;
    private String lastUpdatedDate;
    private String centreJurisdiction;
    private String taxpayerType;
    private String legalNameOfBusiness;
    private String pan;
    private String additionalPlaceOfBusinessAddress;
    private String stateJurisdiction;

    // common fields
    private String referenceId;
    private String userId;

    // corporate Guarantor Fields
    private String branchCode;
    private String branchName;
    private String roName;
    private String corpGuarSalutation;
    private String corpGuarName;
    private String corpGuarCustomerType;
    private String corpGuarMobile;
    private String corpGuarBusinessSector;
    private String corpGuarEmail;
    private String corpGuarNatureOfBusiness;
//    private String corpGuarTypeOfBorrower;
    private String corpGuarRegisterAddress;
    private String corpGuarRegisterVillage;
    private String corpGuarRegisterBlock;
    private String corpGuarRegisterPin;
    private String corpGuarRegisterDistrict;
    private String corpGuarRegisterState;
//    private String corpGuarOtherAddress;
//    private String corpGuarOtherVillage;
//    private String corpGuarOtherBlock;
//    private String corpGuarOtherPin;
//    private String corpGuarOtherDistrict;
//    private String corpGuarOtherState;
    private String corpGuarCin;
    private String corpGuarUdyam;
    private String corpGuarTan;
    private String corpGuarLei;
    private LocalDate corpGuarDateOfCertificate;
    private String corpGuarUdin;
    private String corpGuarNetworth;
    private String corpGuarSourceOfNetWorth;
    private LocalDate corpGuarNetworthAsondate;
    private String corpGuarNameOfCa;
    private String corpGuarStatus;
    private LocalDate corpGuarEstablishmentDate;
    private String crifCommFetched="no";
    private String commCrifFetchedFor="guarantor";

    private String corporateType;

    private String corpGuarPrintable; //for jasper


}
