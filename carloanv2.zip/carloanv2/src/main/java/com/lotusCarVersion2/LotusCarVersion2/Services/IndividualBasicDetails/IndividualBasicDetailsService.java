package com.lotusCarVersion2.LotusCarVersion2.Services.IndividualBasicDetails;


import com.lotusCarVersion2.LotusCarVersion2.DTO.IndividualBasicDetailsDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import org.apache.coyote.BadRequestException;

import java.util.List;

public interface IndividualBasicDetailsService {

    IndividualBasicDetailsDto saveIndividualsDetails(IndividualBasicDetailsDto detailsDto) throws BadRequestException;

    IndividualBasicDetailsDto updateIndividualsDetails(IndividualBasicDetailsDto detailsDto);

    IndividualBasicDetailsDto retreiveDetailsOfIndividuals(String referenceId, String customerType);
    IndividualBasicDetailsDto retreiveDetailsOfGuarantors(String referenceId, String customerType, String panNumber);

    int CalculateAgeInMonthsFromDOB(String dateOfBirth);

    //FOR INDIVIDUAL CO-APPLICANTS AND GUARANTORS

    List<IndividualBasicDetailsDto> getAllCoapplicantList(String referenceId);

    List<IndividualBasicDetailsDto> getAllGuarantorList(String referenceId);

    String getNewCustomerTypeAllowed(String referenceId,String consideringIncome) throws BadRequestException;

    Integer getIncomeConsideredCount(String referenceId);

    List<String> getCoapplicantIncomeConsiderOrNotList(String referenceId);

    String deleteDetailsAndSaveToHistory(String referenceId, String customerType, String aadhar,String deletedBy);

    IndividualBasicDetailsDto getCoapplicantBasicData(String referenceId, String aadhar, String pan);


}
