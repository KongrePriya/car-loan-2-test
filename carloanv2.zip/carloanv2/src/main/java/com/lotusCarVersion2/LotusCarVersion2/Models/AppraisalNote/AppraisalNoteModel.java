package com.lotusCarVersion2.LotusCarVersion2.Models.AppraisalNote;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "appraisal_note")
public class AppraisalNoteModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long srno;
    private String applicationMakerUserId;
    private String applicationCreatedUserName;
    private LocalDateTime applicationCreationDate;
    private String appraisalNoteStatus;
    private LocalDateTime applicationSubmitDate;

    //-------------------------- REFERENCE ID DATA -------------------------- //
    private String panNumber;
    private String borrowerType;
    private String shortBorrowerType;
    private String referenceId;
    private String loanType;
    private String shortLoanType;
    private String applicationStatus;
    private String refIdFlag;
    private LocalDateTime applicationCreatedDate;
    private String userId;
    private String u_type;
    private String brcode;
    private String roname;
    private String u_status;
    private String u_loc;
    private String u_name;
    private String scale;
    private String sourceType;
    private String dsaNumber;
    private String brname;
    private String custType;

    //-------------------------- APPLICANT/BORROWER DATA -------------------------- //
    //---------- INDIVIDUAL BORROWER -------------//
    private String title;
    private String fatherName;
    private String pan;
    private String aadhar;
    private String voterIdCard;
    private String drivingLicence;
    private String passportNum;
    private String rationCardNumber;
    private String qualification;
    private String permanentAddress;
    private String residenceOwnership;
    private String cif;
    private String netWorth;
    private String presentAddress;
    private String alternateEmail;
    private String altMobile;
    private String tempAddressLine1;
    private String tempAddressLandmark;
    private String tempAddressSubDist;
    private String tempAddressDist;
    private String tempAddressState;
    private String tempAddressPincode;
    private int ageInMonths;
    private LocalDateTime timestamp=LocalDateTime.now();
    // Fetched fields
    private String fullName;
    private String gender;
    private String email;
    private String dateOfBirth;
    private String mobileNumber;
    private String careOf;
    private String house;
    private String street;
    private String district;
    private String subDistrict;
    private String landmark;
    private String locality;
    private String postOfficeName;
    private String state;
    private String pincode;
    private String country;
    private String vtcName;
    private String mobile;
    private String aadharAddress;
    private String consideringIncome;
    private String incomeSourceType;
    private String itrFilledForAnyYear;
    private String form16Available;

    //---------- COMMERCIAL/CORPORATE BORROWER -------------//

    private String firmTradeName;
    private String firmLegalNameOfBusiness;
    private String firmCustomerType;
    private String firmMobile;
    private String firmBusinessSector;
    private String firmEmail;
    private String firmNatureOfBusiness;
    private String firmTypeOfBorrower;
    private String firmRegisterAddress;
    private String firmRegisterVillage;
    private String firmRegisterBlock;
    private String firmRegisterPin;
    private String firmRegisterDistrict;
    private String firmRegisterState;
    private String firmOtherAddress;
    private String firmOtherVillage;
    private String firmOtherBlock;
    private String firmOtherPin;
    private String firmOtherDistrict;
    private String firmOtherState;
    private String firmCin;
    private String firmPan;
    private String firmGstn;
    private String firmUdyam;
    private String firmTan;
    private String firmLei;
    private LocalDate firmDateOfCertificate;
    private String firmUdin;
    private Long firmNetWorth;
    private String firmSourceOfNetWorth;
    private LocalDate firmNetWorthAsOnDate;
    private String firmNameOfCa;
    private LocalDate firmEstablishmentDate;
    private String firmGstinStatus;
    private String firmConstitutionOfBusiness;
    private String firmDateOfRegistration;
    private String firmPrincipalPlaceOfBusinessAddress;
    private String firmStateJurisdictionCode;
    private String firmDateOfCancellation;
    private String firmCentreJurisdictionCode;
    private String firmLastUpdatedDate;
    private String firmCentreJurisdiction;
    private String firmTaxpayerType;
    private String firmAdditionalPlaceOfBusinessAddress;
    private String firmStateJurisdiction;
    private String commCrifFetchedFor;
    private String crifCommFetched;

//******************************** FIRM CRIF REMARK **********************************************************************

    @Column(columnDefinition = "TEXT")
    private String firmCommercialCrifRemark;
    @Column(columnDefinition = "TEXT")
    private String firmCommercialCrifOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String firmCommercialCrifRejectRemark;
    @Column(columnDefinition = "TEXT")
    private String firmCommercialCrifWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String firmCommercialCrifAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private String firmCommercialCrifSuitFilledRemark;
    private LocalDateTime firmCommercialCrifSubmitDate;

// ***************************** INDIVIDUAL GUARANTOR/PATNER CIBIL REMARK **********************************************

    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCibilRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCibilOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCibilRejectRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCibilWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCibilAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCibilSuitFilledRemark;
    private LocalDateTime patnerOrGuaCibilSubmitDate;

// ***************************** COMMERCIAL GUARANTOR/PATNER CIBIL REMARK **********************************************

    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCibilRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCibilOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCibilRejectRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCibilWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCibilAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCibilSuitFilledRemark;
    private LocalDateTime patnerOrGuaCommercialCibilSubmitDate;

//  **************************** INDIVIDUAL GUARANTOR/PATNER CRIF REMARK ***********************************************

    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCrifRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCrifOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCrifRejectRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCrifWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCrifAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private LocalDateTime patnerOrGuaCrifSubmitDate;

// ***************************** COMMERCIAL GUARANTOR/PATNER CIBIL REMARK **********************************************

    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCrifRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCrifOverdueRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCrifRejectRemark;
    private String patnerOrGuaCommercialCrifWrittenOffRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCrifAccountSettledRemark;
    @Column(columnDefinition = "TEXT")
    private String patnerOrGuaCommercialCrifSuitFilledRemark;
    private LocalDateTime patnerOrGuaCommercialCrifSubmitDate;



    //************************************* DOCUMETS UPLOAD REMARKS ****************************************************

    @Column(columnDefinition = "TEXT")
    private String agreementSaleRemark;

    @Column(columnDefinition = "TEXT")
    private String applicationRemark;

    @Column(columnDefinition = "TEXT")
    private String cersaiReportRemark;

    @Column(columnDefinition = "TEXT")
    private String constructionPermissionRemark;

    @Column(columnDefinition = "TEXT")
    private String crReportRemark;

    @Column(columnDefinition = "TEXT")
    private String dueDiligenceRemark;

    @Column(columnDefinition = "TEXT")
    private String estimateConstructionRemark;

    @Column(columnDefinition = "TEXT")
    private String estimateVettingRemark;

    @Column(columnDefinition = "TEXT")
    private String itrApplicantRemark;

    @Column(columnDefinition = "TEXT")
    private String itrCoApplicantRemark;

    @Column(columnDefinition = "TEXT")
    private String itrGuarantorRemark;

    @Column(columnDefinition = "TEXT")
    private String kycApplicantRemark;

    @Column(columnDefinition = "TEXT")
    private String kycCoApplicantRemark;

    @Column(columnDefinition = "TEXT")
    private String kycGuarantorRemark;

    @Column(columnDefinition = "TEXT")
    private String lodRemark;

    @Column(columnDefinition = "TEXT")
    private String otherRemark;

    @Column(columnDefinition = "TEXT")
    private String propertyDocumentRemark;

    @Column(columnDefinition = "TEXT")
    private String salarySlipApplicantRemark;

    @Column(columnDefinition = "TEXT")
    private String salarySlipCoApplicantRemark;

    @Column(columnDefinition = "TEXT")
    private String salarySlipGuarantorRemark;

    @Column(columnDefinition = "TEXT")
    private String sanctionLetterPrevBankRemark;

//    @Column(columnDefinition = "TEXT")
//    private String titleSearchReportRemark;

    @Column(columnDefinition = "TEXT")
    private String valuationReportOneRemark;

    @Column(columnDefinition = "TEXT")
    private String valuationReportTwoRemark;

    @Column(columnDefinition = "TEXT")
    private String visitRemark;

    @Column(columnDefinition = "TEXT")
    private String deviationRemark;

    @Column(columnDefinition = "TEXT")
    private String estimateRepairRemark;

    @Column(columnDefinition = "TEXT")
    private String estimateVettingRepairRemark;

    @Column(columnDefinition = "TEXT")
    private String sixMonthStatementRemark;


    //*********************************** ADDITIONAL CONDITIONS **************************************************************************
    @Column(columnDefinition = "TEXT")
    private String makerAdditionalCondition;
    @Column(columnDefinition = "TEXT")
    private String branchManagerAdditionalCondition;
    @Column(columnDefinition = "TEXT")
    private String cpcOfficerAdditionalCondition;
    @Column(columnDefinition = "TEXT")
    private String cpcHeadAdditionalCondition;
    @Column(columnDefinition = "TEXT")
    private String rmAdditionalCondition;
    @Column(columnDefinition = "TEXT")
    private String hoOfficerAdditionalCondition;
    @Column(columnDefinition = "TEXT")
    private String hodAdditionalCondition;
    @Column(columnDefinition = "TEXT")
    private String gmAdditionalCondition;
    @Column(columnDefinition = "TEXT")
    private String chairmanAdditionalCondition;


//*********************************** ADDITIONAL REMARKS **********************************************

    @Column(columnDefinition = "TEXT")
    private String makerAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String branchManagerAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String cpcOfficerAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String cpcHeadAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String rmAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String hoOfficerAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String hodAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String gmAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String chairmanAppraisalRemarks;
    @Column(columnDefinition = "TEXT")
    private String applicationReturnRemarks;
    @Column(columnDefinition = "TEXT")
    private String sanctionAuthorityRejectRemarks;
    @Column(columnDefinition = "TEXT")
    private String applicationSanctionRemarks;

    private String cpcOfficerCersaiRefNumber; //Added on 27/03/2025
    @Column(columnDefinition = "TEXT")
    private String cpcOfficerCersaiRemark; //Added on 27/03/2025

    //*************************************************************************************************************************
    @Column(columnDefinition = "TEXT")
    private String rejectLevelRemark;
    @Column(columnDefinition = "TEXT")
    private String rejectedAtLevel;

    @Column(columnDefinition = "TEXT")
    private String borrowerBriefHistory;

    //**********************************************Loan matrices ********************************************************
    private String locationOfHouse;
    private String maximumAllowableLoanAmount;
    private String productCode;
    private String productName;
    private BigDecimal applicableRoi;
    private BigDecimal recommendedRoi;
    private BigDecimal processingFees;
    private BigDecimal documentationCharges;
    private BigDecimal emiDefaultCharges;
    private String kotakKliOptions;
    private BigDecimal totalKliPremium;
    private BigDecimal fundedKliPremium;
    private BigDecimal careInsuranceEmiPremium;
    private Integer loanTenureInMonths;

    private BigDecimal appliedLoanAmount; // NEW ADDITION
    private LocalDateTime createdDate;


    //----------For Takeover Loans----------//
    private String nameOfBank;
    private LocalDate dateOfSanction;
    private LocalDate dateOfFirstDisbursement;
    private Integer numberOfEmiDue;
    private Integer numberOfEmiPaid;
    private Integer standingInExistingBankInYears;
    private BigDecimal amountToBeTakenOver;

    private String moratoriumRequired;
    private Integer moratoriumPeriod=0;
    private String moratoriumInterestOptions;
    private Integer moratoriumCapitalizeTenure=0;

    private String loanTenureInYears;
    //******************************* CALCULATIONS FIELDS **************************************************************

    //private Integer loanTenureInMonths;
//    private BigDecimal recommendedRoi;


    //private BigDecimal appliedLoanAmount;
//    private BigDecimal emiAsPerApplied;
//
//    //eligible loan as per 3 criteria
//    private BigDecimal loanEligibleAsPerDeduction;
//    private BigDecimal loanEligibleAsPerMargin;
//    private BigDecimal loanEligibleAsPerLtv;
//
//    private BigDecimal finalLoanAsPerEligibility;
//    private BigDecimal emiAsPerEligibility;
//
//    //with KLI
//    private BigDecimal kliFundedPremium;
//    private BigDecimal kliWithAppliedLoanAmount;
//    private BigDecimal emiWithKliAsPerApplied;
//    private BigDecimal kliWithFinalLoanAsPerEligibility;
//    private BigDecimal emiWithKliAsPerEligibility;
//
//
//
//
//    //--------------------- MORATORIUM -----------------//
//    private BigDecimal appliedAmountPlusInterestCapitalization;
//    private Integer loanTenureAfterMoratorium;
//    //****************************top up*****************
//    private BigDecimal topUpEmiApplied= BigDecimal.valueOf(0.0);
//    private BigDecimal topUpEmiAppliedWithKli= BigDecimal.valueOf(0.0);
//
//    private BigDecimal topUpEmiEligible= BigDecimal.valueOf(0.0);
//    private BigDecimal topUpEmiEligibleWithKli= BigDecimal.valueOf(0.0);
//    //with KLI -TOP-UP
//    private BigDecimal kliFundedPremiumTopUp= BigDecimal.valueOf(0.0);
//    private BigDecimal kliWithAppliedLoanAmountTopUp= BigDecimal.valueOf(0.0);
//    private BigDecimal emiWithKliAsPerAppliedTopUp= BigDecimal.valueOf(0.0);
//    private BigDecimal kliWithFinalLoanAsPerEligibilityTopUp= BigDecimal.valueOf(0.0);
//    private BigDecimal emiWithKliAsPerEligibilityTopUp= BigDecimal.valueOf(0.0);
//
//    //TOP-UP FIELDS
//    private Integer topUpLoanAppliedTenureInMonths;
//    private Integer topUpLoanEligibleTenureInMonths;
//
//    private BigDecimal topUpRecommendedRoi;
//  //  private String topUpLoanTenureYears; ---------- AS ADDED IN TOP UP BLOCK ON 02/04/2025
//    private BigDecimal topUpAppliedAmt;
//    private BigDecimal finalTopUpEligibleAmt;
//
//
//    private BigDecimal costOfProjectCommon= BigDecimal.valueOf(0.0);
//    private BigDecimal marginAmountActualCommon= BigDecimal.valueOf(0.0);
//    private BigDecimal marginPercentageActualCommon= BigDecimal.valueOf(0.0);
//
//    private BigDecimal costOfProjectCommonTopUp= BigDecimal.valueOf(0.0);
//    private BigDecimal marginAmountActualTopUp= BigDecimal.valueOf(0.0);
//    private BigDecimal marginPercentageActualTopUp= BigDecimal.valueOf(0.0);
}

