package com.lotusCarVersion2.LotusCarVersion2.Services.CRIFRemark;

import com.lotusCarVersion2.LotusCarVersion2.Models.CRIFRemark.CrifRemarkModel;

public interface CrifRemarkService {

    String saveRemark(CrifRemarkModel crifRemarkModel);
    CrifRemarkModel getCrifRemarksByRefId(String referenceId);
}
