package com.lotusCarVersion2.LotusCarVersion2.Services.CrifList;


import com.lotusCarVersion2.LotusCarVersion2.Models.CrifIndividualRequest.StandardCrifIndvRequest;
import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import com.lotusCarVersion2.LotusCarVersion2.Repository.CRIFRemark.CrifRemarkRepo;
import com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo.IndividualBasicDetailsRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CrifListServiceImpl implements CrifListService{

    @Autowired
    private IndividualBasicDetailsRepo applicantCoappGuarantorRepo;

    @Autowired
    private CrifRemarkRepo crifRemarkRepo;

    @Override
    public List<StandardCrifIndvRequest> getAllApplicantCoAppGuarantor(String referenceId) {
        List<StandardCrifIndvRequest> crifIndvRequestList = new ArrayList<>();

        try{
            List<IndividualBasicDetailsEntity> foundIndividualsList = applicantCoappGuarantorRepo.findAllByReferenceId(referenceId);

            for(IndividualBasicDetailsEntity foundIndividuals : foundIndividualsList){

                StandardCrifIndvRequest crifIndividual = new StandardCrifIndvRequest();
                crifIndividual.setPermanentAddress(foundIndividuals.getAadharAddress());
                crifIndividual.setPermanentCity(foundIndividuals.getDistrict());
                crifIndividual.setPermanentPincode(foundIndividuals.getPincode());
                crifIndividual.setPermanentState(foundIndividuals.getState());

                crifIndividual.setCorrespondenceAddress(foundIndividuals.getPresentAddress());
                crifIndividual.setCorrespondenceCity(foundIndividuals.getTempAddressDist());
                crifIndividual.setCorrespondencePincode(foundIndividuals.getPincode());
                crifIndividual.setCorrespondenceState(foundIndividuals.getTempAddressState());

                crifIndividual.setCustomerType(foundIndividuals.getCustomerType());
                crifIndividual.setFullName(foundIndividuals.getFullName());
                crifIndividual.setPanNumber(foundIndividuals.getPan());
                crifIndividual.setAadharNumber(foundIndividuals.getAadhar());
                crifIndividual.setDateOfBirth(foundIndividuals.getDateOfBirth());
                crifIndividual.setEmailAddress(foundIndividuals.getEmail());
                crifIndividual.setGender(foundIndividuals.getGender());
                crifIndividual.setFatherName(foundIndividuals.getFatherName());
                crifIndividual.setMobileNumber(foundIndividuals.getAltMobile());
                crifIndividual.setReferenceId(foundIndividuals.getReferenceId());
                crifIndividual.setBranchCode(foundIndividuals.getBranchCode());
                crifIndividual.setUserId(foundIndividuals.getUserId());

                //-------------------CRIF VALIDATION FOR FETCH CRIF BUTTON ------------------//
                crifIndividual.setCrifFetched(foundIndividuals.getCrifFetched());

                //--------------------- SET CRIF FETCHED FLAG -----------------------

//                System.out.println(" CRIF LIST " + crifIndividual.getFullName() +" "+ crifIndividual.getCrifFetched());
                crifIndvRequestList.add(crifIndividual);
            }
        }catch (Exception e){
            throw new RuntimeException("Error Occurred While Getting All Applicant, CoApp, Guarantors for CRIF" +e);
        }
        return crifIndvRequestList;
    }



//    public String crifFetchVlaidation(String panNumber, String referenceId){
//        try{
//        String setValidationFlag = null;
//        CrifFetchList foundForCrifValidation = crifRemarkRepo.getCrifFetchedValidationData(panNumber,referenceId);
//        if(foundForCrifValidation !=null){
//            setValidationFlag="yes";
//        }else {
//            setValidationFlag="no";
//        }
//        return setValidationFlag;
//        }catch(Exception e){
//            throw new RuntimeException("In CRIF Fetch Button Validation " + e);
//        }
//    }


    @Override
    @Transactional
    public String updateCrifFetchedFlag(String referenceId, String panNumber, String crifFlagStatus) {
        try{
            IndividualBasicDetailsEntity foundIndividualsList = applicantCoappGuarantorRepo.findByReferenceIdAndPan(referenceId,panNumber);
            System.out.println(foundIndividualsList);
            foundIndividualsList.setCrifFetched(crifFlagStatus);
            applicantCoappGuarantorRepo.save(foundIndividualsList);
        }catch(Exception e){
            throw new RuntimeException("Error Occurred while updating CRIF Flag" + e);
        }

        return "Crif Fetched Flag Updated Successfully";
    }

    @Override
    @Transactional
    public String resetAllCrifFlagEveryMonth(String referenceId) {
        try{
            List<IndividualBasicDetailsEntity> allAppCoAppGuarantorList = applicantCoappGuarantorRepo.findAllByReferenceId(referenceId);
            for (IndividualBasicDetailsEntity individual : allAppCoAppGuarantorList){
                individual.setCrifFetched("no");
            }
        }catch(Exception e){
            throw new RuntimeException("Error While updating ALL CRIF Flag " + e);
        }

        return "All Crif Flags Updated Successfully";
    }


}

