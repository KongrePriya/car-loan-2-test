package com.lotusCarVersion2.LotusCarVersion2.Repository.IndividualBasicDetailsRepo;


import com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails.IndividualBasicDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface IndividualBasicDetailsRepo extends JpaRepository<IndividualBasicDetailsEntity, Long> {

    IndividualBasicDetailsEntity findByReferenceIdAndCustomerType(String referenceId, String customerType);

    @Query(value = "SELECT * FROM los_car_v2.individual_basic_details WHERE reference_id=:referenceId AND customer_type=:customerType AND pan=:pan", nativeQuery = true)
    IndividualBasicDetailsEntity findByReferenceIdAndCustomerTypeAndPan(String referenceId, String customerType, String pan);


    List<IndividualBasicDetailsEntity> findAllByReferenceId(String referenceId);


    @Query(value = "SELECT * FROM los_car_v2.individual_basic_details d Where reference_id=:referenceId and" +
            " d.considering_income ILIKE 'yes'",nativeQuery = true )
    List<IndividualBasicDetailsEntity> getAllApplicantCoappConsiderIncome(String referenceId);

    IndividualBasicDetailsEntity findByReferenceIdAndPan(String referenceId,String pan);

    @Query(value = "SELECT * FROM los_car_v2.individual_basic_details d Where reference_id=:referenceId and" +
            " d.pan=:pan",nativeQuery = true )
    List<IndividualBasicDetailsEntity> findAllByReferenceIdAndPan(String referenceId,String pan);


    @Query(value = """
            SELECT count(*) FROM los_car_v2.individual_basic_details aa WHERE aa.itr_filled_for_any_year='Yes' 
            AND  reference_id=:referenceId 
            """,nativeQuery = true )
    Integer countOfItrAvailablePerson(String referenceId);


    @Query(value = "SELECT * FROM los_car_v2.individual_basic_details " +
            "WHERE reference_id=:referenceId and " +
            "customer_type in('COAPPLICANT1','COAPPLICANT2','COAPPLICANT')",nativeQuery = true)
    List<IndividualBasicDetailsEntity> findAllCoappByReferenceId(String referenceId);


    @Query(value = "SELECT * FROM los_car_v2.individual_basic_details " +
            "WHERE reference_id=:referenceId and customer_type='GUARANTOR' ",nativeQuery = true)
    List<IndividualBasicDetailsEntity> findAllGuarantorByReferenceId(String referenceId);


    @Query(value = "SELECT COUNT(*) FROM los_car_v2.individual_basic_details WHERE reference_id=:referenceId " +
            " AND considering_income='Yes' AND customer_type  IN ('COAPPLICANT1','COAPPLICANT2')",nativeQuery = true)
    Integer countCoapplicantIncomeConsider (String referenceId);

    @Query(value = "SELECT customer_type FROM los_car_v2.individual_basic_details WHERE reference_id=:referenceId " +
            " AND considering_income='Yes' AND customer_type IN ('COAPPLICANT1','COAPPLICANT2')",nativeQuery = true)
    List<String> listOfEarningCoappCustType(String referenceId);

    @Query(value = "SELECT * FROM los_car_v2.individual_basic_details " +
            "WHERE reference_id=:referenceId and considering_income='Yes'" +
            "and customer_type in ('COAPPLICANT1','COAPPLICANT2')",nativeQuery = true)
    List<IndividualBasicDetailsEntity> getCoapplicantIncomeConsider (String referenceId);



    @Query(value = "SELECT * FROM los_car_v2.individual_basic_details " +
            "WHERE reference_id=:referenceId and aadhar=:aadhar " +
            "and pan=:pan",nativeQuery = true)
    Optional<IndividualBasicDetailsEntity> findByReferenceIdAndAadharAndPan(String referenceId, String aadhar, String pan);


    IndividualBasicDetailsEntity findByReferenceIdAndCustomerTypeAndAadhar(String referenceId, String customerType, String aadhar);



}
