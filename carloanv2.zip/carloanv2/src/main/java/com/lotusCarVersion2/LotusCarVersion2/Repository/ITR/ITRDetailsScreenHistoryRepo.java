package com.lotusCarVersion2.LotusCarVersion2.Repository.ITR;

import com.lotusCarVersion2.LotusCarVersion2.Models.ITR.ITRDetailsAsPerScreenHistoryEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface ITRDetailsScreenHistoryRepo extends JpaRepository<ITRDetailsAsPerScreenHistoryEntity, Long> {

    // To copy entry of ITR DETAILS to history table when Borrower/guarantor Deleted
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO kyc_itr.screen_itr_final_details_history " +
            "(reference_id_itr, reference_id_lotus, customer_name, customer_pan, fetched_by_user, branch_code, fetched_date, details_status, customer_type, " +
            "year1, year2, itr_type_year1, original_or_revised_year1, acknowledgement_number_year1, original_return_filing_date_year1, revised_return_filing_date_year1, " +
            "itr_type_year2, original_or_revised_year2, acknowledgement_number_year2, original_return_filing_date_year2, revised_return_filing_date_year2, " +
            "gross_income_from_salary_year1, income_from_house_property_year1, short_term_capital_gain_total_year1, long_term_capital_gain_total_year1, capital_gain_total_year1, " +
            "income_from_other_sources_year1, total_income_by_adding_all_year1, profit_gains_from_business_or_prof_year1, gross_income_from_salary_year2, income_from_house_property_year2, " +
            "short_term_capital_gain_total_year2, long_term_capital_gain_total_year2, capital_gain_total_year2, income_from_other_sources_year2, total_income_by_adding_all_year2, " +
            "profit_gains_from_business_or_prof_year2, gross_total_income_year1, total_taxable_income_year1, gross_total_income_year2, total_taxable_income_year2, " +
            "deduction_under6a_year1, deduction_under10aa_year1, income_excluding_total_income_year1, other_deductions_total_year1, net_tax_liability_year1, " +
            "deduction_under6a_year2, deduction_under10aa_year2, income_excluding_total_income_year2, other_deductions_total_year2, net_tax_liability_year2, " +
            " refetched_at, refetched_by) " +
            "SELECT reference_id_itr, reference_id_lotus, customer_name, customer_pan, fetched_by_user, branch_code, fetched_date, details_status, customer_type, " +
            "year1, year2, itr_type_year1, original_or_revised_year1, acknowledgement_number_year1, original_return_filing_date_year1, revised_return_filing_date_year1, " +
            "itr_type_year2, original_or_revised_year2, acknowledgement_number_year2, original_return_filing_date_year2, revised_return_filing_date_year2, " +
            "gross_income_from_salary_year1, income_from_house_property_year1, short_term_capital_gain_total_year1, long_term_capital_gain_total_year1, capital_gain_total_year1, " +
            "income_from_other_sources_year1, total_income_by_adding_all_year1, profit_gains_from_business_or_prof_year1, gross_income_from_salary_year2, income_from_house_property_year2, " +
            "short_term_capital_gain_total_year2, long_term_capital_gain_total_year2, capital_gain_total_year2, income_from_other_sources_year2, total_income_by_adding_all_year2, " +
            "profit_gains_from_business_or_prof_year2, gross_total_income_year1, total_taxable_income_year1, gross_total_income_year2, total_taxable_income_year2, " +
            "deduction_under6a_year1, deduction_under10aa_year1, income_excluding_total_income_year1, other_deductions_total_year1, net_tax_liability_year1, " +
            "deduction_under6a_year2, deduction_under10aa_year2, income_excluding_total_income_year2, other_deductions_total_year2, net_tax_liability_year2 ,NOW(), :refetchedBy " +
            "FROM kyc_itr.screen_itr_final_details " +
            "WHERE reference_id_lotus = :referenceIdLotus AND customer_type = :customerType", nativeQuery = true)
    int moveToITRDetailsHistory(String referenceIdLotus, String customerType, String refetchedBy);
}
//NOW(), :refetchedBy