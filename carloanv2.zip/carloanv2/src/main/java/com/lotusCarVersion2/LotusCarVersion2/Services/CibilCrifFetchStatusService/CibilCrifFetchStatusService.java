package com.lotusCarVersion2.LotusCarVersion2.Services.CibilCrifFetchStatusService;


import com.lotusCarVersion2.LotusCarVersion2.DTO.CibilCrifFetchedStatusDto;
import com.lotusCarVersion2.LotusCarVersion2.Models.CibilCrifStatus.CibilCrifFetchStatusEntity;

import java.math.BigDecimal;

public interface CibilCrifFetchStatusService {

    CibilCrifFetchedStatusDto getFetchStatusCibilCrif(String referenceId);

    //return entity because we need to then manipulate it
    CibilCrifFetchStatusEntity checkOrCreateCibilCrifEntity(String referenceIdGst);

    //Set Applicant CIBIL
    String setApplicantCibilFetched(String referenceId);

    //Set Income Coapp Count and CIBIL count and using that set CoappIncomeCibilFetched
    String setIncomeCoappCountAndCibil(String referenceId);

    //Set Non-Income Coapp Count and CIBIL and using that set CoappNonIncomeCibilFetched
    String setNonIncomeCoappCountAndCibil(String referenceId);

    //Set guarantor Count and CIBIL count and using that set guarantorCibilFetched
    String setGuarantorCountAndCibil(String referenceId);


//*************************************************************************************************************//

    CibilCrifFetchedStatusDto callAllStatusFunctions(String referenceId);

    //To RESET CIBIL-CRIF flags on 10th of every month for applications which are in process.
//     String ResetFlagsOfCibilAndCrif();


//---------------------------------------- :::: SET CRIF STATUS SERVICES :::: -------------------------------------------
    //Set Applicant CIBIL
    String setApplicantCrifFetched(String referenceId);

    //Set Income Coapp Count and CIBIL count and using that set CoappIncomeCibilFetched
    String setIncomeCoappCountAndCrif(String referenceId);

    //Set Non-Income Coapp Count and CIBIL and using that set CoappNonIncomeCibilFetched
    String setNonIncomeCoappCountAndCrif(String referenceId);

    //Set guarantor Count and CIBIL count and using that set guarantorCibilFetched
    String setGuarantorCountAndCrif(String referenceId);

//---------------------------------------- FROM GST PROJECT -----------------------------------------------------------//

    //COUNT CALCULATIONS
    String indvGuarCountStatus(String referenceId);

    String corpGuarCountStatus(String referenceId);

    String corpGuarCibilFetchedCountStatus(String referenceId);

    String corpGuarCrifFetchedCountStatus(String referenceId);

    CibilCrifFetchedStatusDto indvGuarCrifFetchedCountStatus(String referenceId);

    String indGuarCibilFecthedCountStatus(String referenceId);

    CibilCrifFetchedStatusDto CrifRequiredStatus(String referenceId, BigDecimal recommendedLoanAmt);



    //UPDATE UPTODATE FLAG.
    String firmComCibilFetchedStatus(String referenceId);

// No need to false it manually:-   CibilCrifStatusDto UpdateCorpGuarComCibilUptoDateToFalse(String referenceId);

    //    CibilCrifStatusDto firmComCrifFetchedStatus(String referenceId, String status);
    CibilCrifFetchedStatusDto firmComCrifFetchedStatus(String referenceId);

    String compareFirmCibilCrifCountMatching(String referenceId);




    // COUNT COMPARE FLAGS: TO CHECK WHETHER CIBIL FETCHED == CRIF FECTHED
    CibilCrifFetchedStatusDto corpGuarCibilCrifCountMatching(String referenceId);

    CibilCrifFetchedStatusDto indvGuarCibilCrifCountMatching(String referenceId);

//*************************************************************************************************************//

    CibilCrifFetchedStatusDto compareAndUpdateAllGuarCibilCrifUptodate(String referenceId);
    CibilCrifFetchedStatusDto allCibilCrifUptodate(String referenceId);


    String ResetFlagsOfCibilCrif();


    String callAllFunctionsAtLast(String referenceId);


    String indvGuarCibilAndCrifUptodate(String referenceIdGst);

    String corpGuarCibilAndCrifUptodate(String referenceId);
}
