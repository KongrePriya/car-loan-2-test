package com.lotusCarVersion2.LotusCarVersion2.Repository.IncomeAllRepos.IncomeSalary;


import com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomeSalary.IncomeSalaryHistoryModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncomeSalaryHistoryRepo extends JpaRepository<IncomeSalaryHistoryModel,Long> {

}
