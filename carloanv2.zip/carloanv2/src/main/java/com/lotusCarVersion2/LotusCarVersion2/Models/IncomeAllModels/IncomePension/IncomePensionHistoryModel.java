package com.lotusCarVersion2.LotusCarVersion2.Models.IncomeAllModels.IncomePension;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class IncomePensionHistoryModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String referenceId;
    private String userId;
    private String branchCode;
    private String panNumber;  // New Addition
    private String customerType; // New Addition
    private String customerName; //New Addition
    private String incomeType; //New Addition
    @Column(columnDefinition = "TEXT")
    private String incomeDetailOption; // Missing Field
    @Column(columnDefinition = "TEXT")
    private String organisationType;
    @Column(columnDefinition = "TEXT")
    private String employerName;
    @Column(columnDefinition = "TEXT")
    private String addressOfEmployment; // New Addition
    @Column(columnDefinition = "TEXT")
    private String departmentOnRetirement;
    @Column(columnDefinition = "TEXT")
    private String designationOnRetirement;

    private String monthOneTitle;
    private String monthTwoTitle;
    private String monthThreeTitle;
    private BigDecimal monthOneSalary;
    private BigDecimal monthTwoSalary;
    private BigDecimal monthThreeSalary;

    private String selectedFirstYear;
    private String selectedSecondYear; //Changed selectedSecondyear to selectedSecondYear
    private BigDecimal netIncomeFirstYear;
    private BigDecimal netIncomeSecondYear;
    private BigDecimal grossIncomeFirstYear;
    private BigDecimal grossIncomeSecondYear;

    private BigDecimal currentEmiDeduction;
    private BigDecimal incomeTaxDeduction;
    private BigDecimal pensionSlipDeduction;
    private BigDecimal otherDeduction;
    private BigDecimal totalCurrentDeduction;
    private String incomeAvailableFor; //New Addition

    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getPanNumber() {
        return panNumber;
    }

    public void setPanNumber(String panNumber) {
        this.panNumber = panNumber;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getIncomeType() {
        return incomeType;
    }

    public void setIncomeType(String incomeType) {
        this.incomeType = incomeType;
    }

    public String getIncomeDetailOption() {
        return incomeDetailOption;
    }

    public void setIncomeDetailOption(String incomeDetailOption) {
        this.incomeDetailOption = incomeDetailOption;
    }

    public String getOrganisationType() {
        return organisationType;
    }

    public void setOrganisationType(String organisationType) {
        this.organisationType = organisationType;
    }

    public String getEmployerName() {
        return employerName;
    }

    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getAddressOfEmployment() {
        return addressOfEmployment;
    }

    public void setAddressOfEmployment(String addressOfEmployment) {
        this.addressOfEmployment = addressOfEmployment;
    }

    public String getDepartmentOnRetirement() {
        return departmentOnRetirement;
    }

    public void setDepartmentOnRetirement(String departmentOnRetirement) {
        this.departmentOnRetirement = departmentOnRetirement;
    }

    public String getDesignationOnRetirement() {
        return designationOnRetirement;
    }

    public void setDesignationOnRetirement(String designationOnRetirement) {
        this.designationOnRetirement = designationOnRetirement;
    }

    public String getMonthOneTitle() {
        return monthOneTitle;
    }

    public void setMonthOneTitle(String monthOneTitle) {
        this.monthOneTitle = monthOneTitle;
    }

    public String getMonthTwoTitle() {
        return monthTwoTitle;
    }

    public void setMonthTwoTitle(String monthTwoTitle) {
        this.monthTwoTitle = monthTwoTitle;
    }

    public String getMonthThreeTitle() {
        return monthThreeTitle;
    }

    public void setMonthThreeTitle(String monthThreeTitle) {
        this.monthThreeTitle = monthThreeTitle;
    }

    public BigDecimal getMonthOneSalary() {
        return monthOneSalary;
    }

    public void setMonthOneSalary(BigDecimal monthOneSalary) {
        this.monthOneSalary = monthOneSalary;
    }

    public BigDecimal getMonthTwoSalary() {
        return monthTwoSalary;
    }

    public void setMonthTwoSalary(BigDecimal monthTwoSalary) {
        this.monthTwoSalary = monthTwoSalary;
    }

    public BigDecimal getMonthThreeSalary() {
        return monthThreeSalary;
    }

    public void setMonthThreeSalary(BigDecimal monthThreeSalary) {
        this.monthThreeSalary = monthThreeSalary;
    }

    public String getSelectedFirstYear() {
        return selectedFirstYear;
    }

    public void setSelectedFirstYear(String selectedFirstYear) {
        this.selectedFirstYear = selectedFirstYear;
    }

    public String getSelectedSecondYear() {
        return selectedSecondYear;
    }

    public void setSelectedSecondYear(String selectedSecondYear) {
        this.selectedSecondYear = selectedSecondYear;
    }

    public BigDecimal getNetIncomeFirstYear() {
        return netIncomeFirstYear;
    }

    public void setNetIncomeFirstYear(BigDecimal netIncomeFirstYear) {
        this.netIncomeFirstYear = netIncomeFirstYear;
    }

    public BigDecimal getNetIncomeSecondYear() {
        return netIncomeSecondYear;
    }

    public void setNetIncomeSecondYear(BigDecimal netIncomeSecondYear) {
        this.netIncomeSecondYear = netIncomeSecondYear;
    }

    public BigDecimal getGrossIncomeFirstYear() {
        return grossIncomeFirstYear;
    }

    public void setGrossIncomeFirstYear(BigDecimal grossIncomeFirstYear) {
        this.grossIncomeFirstYear = grossIncomeFirstYear;
    }

    public BigDecimal getGrossIncomeSecondYear() {
        return grossIncomeSecondYear;
    }

    public void setGrossIncomeSecondYear(BigDecimal grossIncomeSecondYear) {
        this.grossIncomeSecondYear = grossIncomeSecondYear;
    }

    public BigDecimal getCurrentEmiDeduction() {
        return currentEmiDeduction;
    }

    public void setCurrentEmiDeduction(BigDecimal currentEmiDeduction) {
        this.currentEmiDeduction = currentEmiDeduction;
    }

    public BigDecimal getIncomeTaxDeduction() {
        return incomeTaxDeduction;
    }

    public void setIncomeTaxDeduction(BigDecimal incomeTaxDeduction) {
        this.incomeTaxDeduction = incomeTaxDeduction;
    }

    public BigDecimal getPensionSlipDeduction() {
        return pensionSlipDeduction;
    }

    public void setPensionSlipDeduction(BigDecimal pensionSlipDeduction) {
        this.pensionSlipDeduction = pensionSlipDeduction;
    }

    public BigDecimal getOtherDeduction() {
        return otherDeduction;
    }

    public void setOtherDeduction(BigDecimal otherDeduction) {
        this.otherDeduction = otherDeduction;
    }

    public BigDecimal getTotalCurrentDeduction() {
        return totalCurrentDeduction;
    }

    public void setTotalCurrentDeduction(BigDecimal totalCurrentDeduction) {
        this.totalCurrentDeduction = totalCurrentDeduction;
    }

    public String getIncomeAvailableFor() {
        return incomeAvailableFor;
    }

    public void setIncomeAvailableFor(String incomeAvailableFor) {
        this.incomeAvailableFor = incomeAvailableFor;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }
}
