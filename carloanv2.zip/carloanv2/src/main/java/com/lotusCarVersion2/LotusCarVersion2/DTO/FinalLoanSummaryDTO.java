package com.lotusCarVersion2.LotusCarVersion2.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class FinalLoanSummaryDTO {

    private String referenceId;
    private String applicantName;
    private String loanType;
    private String borrowerType;
    private BigDecimal loanTenure;
    private BigDecimal rateOfInterest;
    private BigDecimal kliFundedAmount;

    //as per eligibility
    private BigDecimal finalEligibleLoanWithKLI;
    private BigDecimal finalEligibleLoanWithoutKLI;
    private BigDecimal emiAsPerEligibleLoan;
    //as per applied
    private BigDecimal appliedLoanWithKLI;
    private BigDecimal appliedLoanWithoutKLI;
    private BigDecimal emiAsPerAppliedLoan;

    private BigDecimal deductionPercentage;

}
