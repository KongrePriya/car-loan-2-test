package com.lotusCarVersion2.LotusCarVersion2.Repository.CalculationRepo;

import com.lotusCarVersion2.LotusCarVersion2.Models.Calculation.CalculationDataEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CalculationDataRepo extends JpaRepository<CalculationDataEntity,Long> {


    CalculationDataEntity findByReferenceId(String referenceId);
}
