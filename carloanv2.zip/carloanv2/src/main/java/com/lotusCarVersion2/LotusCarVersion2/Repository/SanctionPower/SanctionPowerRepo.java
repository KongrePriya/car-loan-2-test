package com.lotusCarVersion2.LotusCarVersion2.Repository.SanctionPower;
import com.lotusCarVersion2.LotusCarVersion2.Models.SanctionPowerModel.SanctionPowerModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.List;

public interface SanctionPowerRepo extends JpaRepository<SanctionPowerModel,Long> {


    //Get Sanction Power Data for Master Table
    @Query(value="SELECT * FROM los_gst.sanction_power",nativeQuery = true)
    List<SanctionPowerModel> getSanctionPowerDataForMasterTable();


//    --------------------------------------------- Get Sanction Power According to Loan Type and Loan Amount ----------------------------------------------------
    @Query(value = "SELECT * FROM los_housing.sanction_power WHERE loan_type=:loanType AND sanction_power_amt>=:loanAmount",nativeQuery = true)
    List<SanctionPowerModel> getSanctionPowerForHomeLoanFromMaster(String loanType, BigDecimal loanAmount);


//    --------------------------------------------- Get Sanction Amount For General Manager/Chariman ----------------------------------------------------
    @Query(value = "SELECT sanction_power_amt FROM los_housing.sanction_power WHERE loan_type=:loanType AND user_type=:userType",nativeQuery = true)
    BigDecimal getSanctionPowerForGeneralManagerAndChariman(String loanType, String userType);

    //    --------------------------------------------- Get Sanction Power For User Information ----------------------------------------------------
    @Query(value = "SELECT * FROM los_housing.sanction_power WHERE loan_type=:loanType ORDER BY sanction_power_amt ",nativeQuery = true)
    List<SanctionPowerModel> getSanctionPowerInfo(String loanType);


}
