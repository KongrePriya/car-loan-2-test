package com.lotusCarVersion2.LotusCarVersion2.Models.IndividualBasicDetails;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "individual_basic_details")
public class IndividualBasicDetailsEntity {

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long id;

        private String referenceId;
        private String branchCode;
        private String userId;

        private String title;
        private String fatherName;
        private String pan;
        private String aadhar;
        private String voterIdCard;
        private String drivingLicence;
        private String passportNum;
        private String rationCardNumber;
        private String qualification;
        private String permanentAddress;
        private String residenceOwnership;
        private String cif;
        private String netWorth;
        private String presentAddress;
        private String alternateEmail;
        private String altMobile;
        private String tempAddressLine1;
        private String tempAddressLandmark;
        private String tempAddressSubDist;
        private String tempAddressDist;
        private String tempAddressState;

        private String tempAddressPincode;
        private String customerType;
        private String ageInYears; //added on 20022025
        private int ageInMonths;
        private LocalDateTime timestamp=LocalDateTime.now();

        // Fetched fields
        private String fullName;
        private String gender;
        private String email;
        private String dateOfBirth;
        private String mobileNumber;
        private String careOf;
        private String house;
        private String street;
        private String district;
        private String subDistrict;
        private String landmark;
        private String locality;
        private String postOfficeName;
        private String state;
        private String pincode;
        private String country;
        private String vtcName;
        private String mobile;
        private String aadharAddress;

        private String consideringIncome="No";
        private String incomeSourceType;
        private String itrFilledForAnyYear;
        private String form16Available;

        private String crifFetched; //NEW ADDITION

        private String relationWithApplicant;//added on 26032025
        private String relationWithApplicantOther;//added on 26032025



        @PrePersist
        @PreUpdate
        private void updatePresentAddress() {
                this.presentAddress = String.join(", ",
                        tempAddressLine1 != null ? tempAddressLine1 : "",
                        tempAddressLandmark != null ? tempAddressLandmark : "",
                        tempAddressSubDist != null ? tempAddressSubDist : "",
                        tempAddressDist != null ? tempAddressDist : "",
                        tempAddressState != null ? tempAddressState : "",
                        tempAddressPincode != null ? tempAddressPincode : ""
                );

                System.out.println("Applicant/Co-applicant/Guarantor ,Present Address Updated: " + this.presentAddress);
        }

}
